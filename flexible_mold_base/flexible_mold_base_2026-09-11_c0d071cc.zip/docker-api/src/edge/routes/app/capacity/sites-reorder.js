/**
 * @openapi
 * /edge/app/capacity/scenarios/{scenarioId}/sites/reorder:
 *   put:
 *     tags: [App - Capacity]
 *     summary: Persist a Sites drag-reorder (owner+admin).
 *     description: >
 *       Rewrites `cap_sites.order_index` for every site in the scenario to
 *       its position in `orderedIds`, in one transaction. `orderedIds` MUST
 *       be exactly the scenario's current site id set — a partial or
 *       foreign-id list is rejected 400 rather than silently reordering a
 *       subset.
 *     parameters:
 *       - { name: scenarioId, in: path, required: true, schema: { type: string } }
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [orderedIds]
 *             properties:
 *               orderedIds: { type: array, items: { type: string } }
 *     responses:
 *       200: { description: Reordered }
 *       400: { description: Malformed body, or orderedIds does not match the scenario's site set }
 *       403: { description: Not the scenario owner (and not admin) }
 *       404: { description: Scenario not found }
 */

/**
 * capacity/sites-reorder.js — bulk Sites drag-reorder persist (phase-2 spec
 * §4.3 B2): `PUT /scenarios/:scenarioId/sites/reorder { orderedIds }`.
 *
 * Registered on `router` in index.js BEFORE `mountChildren`'s generic
 * `/scenarios/:scenarioId/sites` factory mount — Express matches middleware
 * in registration order, and without this ordering the generic factory's own
 * `PUT /:id` would treat "reorder" as a row id (404, never reaching here).
 *
 * `order_index` isn't one of the Sites grid's tracked `fields` (spec §4.3:
 * Sites' editable columns are just `name`), so this bypasses the generic
 * create/update/delete CRUD entirely — a bespoke bulk rewrite, not a
 * per-row PUT loop, keeping the whole reorder atomic (one transaction).
 */
const express = require('express');
const { sendError } = require('../../../../shared/lib/send-error');
const { pool, t } = require('../../../db');
const { requireAdminOrEditor, apiOk, apiError } = require('../../../../shared/helpers');
const { logger } = require('../../../../shared/lib/logger');
const { TABLES } = require('../../../../shared/constants');
const { resolveScenarioWriteAccess, safeRollback } = require('./_shared');

const router = express.Router();

// Matches wizard.js's own MAX_SITES ceiling (defense-in-depth bound on the
// bulk rewrite loop) — kept as a separate literal rather than a cross-file
// import so this route has no compile-time dependency on wizard.js.
const MAX_SITES = 200;

router.put('/scenarios/:scenarioId/sites/reorder', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const scenarioId = req.params.scenarioId;
  const { orderedIds } = req.body || {};

  if (
    !Array.isArray(orderedIds)
    || orderedIds.length === 0
    || !orderedIds.every((id) => typeof id === 'string' && id.length > 0)
  ) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'orderedIds must be a non-empty array of site ids' });
  }
  if (orderedIds.length > MAX_SITES) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: `orderedIds exceeds ${MAX_SITES} limit` });
  }
  if (new Set(orderedIds).size !== orderedIds.length) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'orderedIds contains a duplicate id' });
  }

  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();

    const access = await resolveScenarioWriteAccess(conn, scenarioId, req.user);
    if (!access.found) {
      await safeRollback(conn);
      return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Scenario not found' });
    }
    if (!access.allowed) {
      await safeRollback(conn);
      return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Not the scenario owner' });
    }

    // Lock every one of THIS scenario's site rows FOR UPDATE, then require
    // the body's id set to match EXACTLY — closes both a stale-tab drag (a
    // site deleted elsewhere mid-drag) and an attempt to smuggle a foreign
    // scenario's site id into the rewrite.
    const existing = await conn.query(
      `SELECT id FROM \`${t(TABLES.CAP_SITES)}\` WHERE scenario_id = ? FOR UPDATE`, [scenarioId],
    );
    const existingIds = new Set(existing.map((r) => r.id));
    const bodyIds = new Set(orderedIds);
    const sameSet = existingIds.size === bodyIds.size && [...existingIds].every((id) => bodyIds.has(id));
    if (!sameSet) {
      await safeRollback(conn);
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: "orderedIds must match this scenario's current site set exactly" });
    }

    for (let i = 0; i < orderedIds.length; i += 1) {
      await conn.query(
        `UPDATE \`${t(TABLES.CAP_SITES)}\` SET order_index = ? WHERE id = ? AND scenario_id = ?`,
        [i, orderedIds[i], scenarioId],
      );
    }

    await conn.commit();
    res.json(apiOk({ reordered: orderedIds.length }));
  } catch (err) {
    await safeRollback(conn);
    sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { scenarioId } });
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
