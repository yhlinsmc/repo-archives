/**
 * @openapi
 * /edge/app/capacity/scenarios/{scenarioId}/versions:
 *   get:
 *     tags: [App - Capacity]
 *     summary: List a scenario's frozen version snapshots (all authenticated).
 *     parameters:
 *       - { name: scenarioId, in: path, required: true, schema: { type: string } }
 *     responses:
 *       200: { description: Version metadata list (newest first; no snapshot body) }
 *   post:
 *     tags: [App - Capacity]
 *     summary: Save the scenario's current working state as a new immutable version (owner+admin).
 *     description: >
 *       The snapshot is SERVER-computed from the scenario's live rows; the client
 *       supplies only a name and optional note. A client-supplied snapshot body is
 *       ignored (a version can never be forged).
 *     parameters:
 *       - { name: scenarioId, in: path, required: true, schema: { type: string } }
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [name]
 *             properties:
 *               name: { type: string }
 *               note: { type: string }
 *     responses:
 *       201: { description: Created version (metadata) }
 *       403: { description: Not the scenario owner (and not admin) }
 *       404: { description: Scenario not found }
 * /edge/app/capacity/scenarios/{scenarioId}/versions/{versionId}/restore:
 *   post:
 *     tags: [App - Capacity]
 *     summary: Restore a version IN PLACE over the same scenario (owner+admin).
 *     description: >
 *       Destructive: every scenario-scoped row is deleted and replaced by the
 *       chosen version's frozen rows, in one transaction. The state being
 *       replaced is NOT saved automatically — the caller decides, and saves it
 *       through the ordinary create-version route before calling this. Version
 *       history, the scenario row itself and the global config layer are
 *       untouched. A snapshot whose schema_rev differs from the current one is
 *       refused (409); clone it to a new scenario instead.
 *     parameters:
 *       - { name: scenarioId, in: path, required: true, schema: { type: string } }
 *       - { name: versionId, in: path, required: true, schema: { type: string } }
 *     requestBody:
 *       required: false
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               saved_version_id:
 *                 type: string
 *                 nullable: true
 *                 description: >
 *                   The version the caller saved the replaced state as, recorded
 *                   in the audit trail. Must be a version of this scenario, and
 *                   its frozen rows must still match the scenario's live rows —
 *                   a scenario that moved since the save is refused rather than
 *                   overwritten.
 *     responses:
 *       200: { description: Restored; returns whether the replaced state was saved + restored row counts }
 *       400: { description: saved_version_id is not a version id string, or names the version being restored }
 *       403: { description: Not the scenario owner (and not admin) }
 *       404: { description: Scenario, version, or the named saved version not found }
 *       409: { description: "CONFLICT: the snapshot is unreadable or its schema_rev does not match. SCENARIO_CHANGED: the scenario moved since the named saved version was cut." }
 * /edge/app/capacity/scenarios/{scenarioId}/versions/{versionId}:
 *   get:
 *     tags: [App - Capacity]
 *     summary: Read one version including its frozen snapshot (all authenticated).
 *     responses:
 *       200: { description: The version row with its parsed snapshot }
 *       404: { description: Version not found in this scenario }
 *   delete:
 *     tags: [App - Capacity]
 *     summary: Delete a version (owner+admin). A version has no dependents.
 *     responses:
 *       200: { description: Deleted }
 *       403: { description: Not the scenario owner (and not admin) }
 *       404: { description: Version not found in this scenario }
 *   put:
 *     tags: [App - Capacity]
 *     summary: Rename a version or edit its note (owner+admin). Nothing else is editable.
 *     description: >
 *       A two-field whitelist. The snapshot body, its schema_rev and its
 *       provenance stay frozen; a request that carries any other field is
 *       REFUSED (400) rather than having that field ignored.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name: { type: string }
 *               note: { type: string, nullable: true }
 *     responses:
 *       200: { description: The updated version metadata }
 *       400: { description: A non-editable field was supplied, or name/note failed validation }
 *       403: { description: Not the scenario owner (and not admin) }
 *       404: { description: Version not found in this scenario }
 */

/**
 * capacity/versions.js — cap_versions bespoke mount (PR-E, spec §5).
 *
 * Unlike every generic scenario child (children.js), a version is a
 * SERVER-COMPUTED immutable snapshot, so this mount is hand-rolled rather than
 * the generic createCrudRoutes factory:
 *   - POST freezes the scenario's live working state into cap_versions.snapshot
 *     (a full deep copy of every scenario-scoped row); the client sends only
 *     name + optional note. A client-supplied snapshot / created_by is ignored.
 *   - PUT edits the NAME and NOTE only (D7); every other column, above all the
 *     snapshot body, stays frozen, and a request that carries one is refused.
 *   - A version is applied in one of two ways, neither of which touches the
 *     version row: /clone deep-copies it into a NEW scenario, and /restore
 *     replays it over the SAME scenario. /restore does NOT save the state it
 *     replaces (D6) — the caller is asked and saves it as a named version
 *     first, through the ordinary create route.
 *   - DELETE removes a version (owner+admin) — a version has no downstream FKs,
 *     so junk snapshots can be pruned; the created_by audit column remains the
 *     record of who cut it.
 *
 * Read is open to all authenticated users (spec §7); write (POST/DELETE) is the
 * scenario owner + admin (resolveScenarioWriteAccess).
 */
const express = require('express');
const { sendError } = require('../../../../shared/lib/send-error');
const { pool, t } = require('../../../db');
const {
  requireAuth, requireAdminOrEditor, apiOk, uuidv4,
} = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { mapRowsFromDb } = require('../../../lib/dto-mapper');
const { attachOwnerNames } = require('../../../lib/owner-name-enrichment');
const { logger } = require('../../../../shared/lib/logger');
const {
  SNAPSHOT_SCHEMA_REV, SNAPSHOT_TABLES, readScenarioSnapshotTables,
  writeVersionSnapshot, SnapshotTooLargeError,
  resolveScenarioWriteAccess, cloneScenarioFromTables,
  findSnapshotRestoreBlocker, deleteScenarioScopedRows, restoreScenarioRowsFromTables,
  safeRollback, hydrateSettingsNamePatterns,
} = require('./_shared');
const { fingerprintScenarioRows } = require('./snapshot-fingerprint');

// the live snapshot reader hydrates settings.name_patterns to the
// 4-key primary/standby split shape. A version snapshot FROZEN BEFORE that deploy
// holds the raw legacy 3-key value (or, in a driver era that serialised JSON as
// text, a string). Fingerprinting the raw saved side against the hydrated live
// side would report a false SCENARIO_CHANGED on a scenario nobody touched. Run
// BOTH sides through the SAME hydrator immediately before fingerprinting so the
// comparison is invariant to the stored shape: hydrateSettingsNamePatterns parses
// a string cell (leaving it as-is on parse failure) and is idempotent on an
// already-split value, so normalising the already-hydrated live side is a no-op.
function normalizeSettingsForFingerprint(tables) {
  if (!tables || !tables.settings) return tables;
  return { ...tables, settings: hydrateSettingsNamePatterns(tables.settings) };
}

const router = express.Router();

const MAX_NAME = 255;
const MAX_NOTE = 10000;

/**
 * Resolve created_by → created_by_name for a version row set (display name only,
 * never an email — attachOwnerNames reads display_name || kc_username). Reuses
 * the same security-reviewed enrichment the scenario owner_name path uses, then
 * renames its `owner_name` output to `created_by_name` (the audit-column name).
 * A NULL created_by yields created_by_name = null (the FE renders "System").
 */
async function enrichCreatedByName(conn, rows) {
  await attachOwnerNames(conn, rows, 'created_by', `\`${t(TABLES.USERS)}\``);
  for (const r of rows) {
    if (!r) continue;
    r.created_by_name = r.owner_name ?? null;
    delete r.owner_name;
    // owner_username is an avatar-initials byproduct of attachOwnerNames;
    // this endpoint renders plain text (VersionsTab), not an avatar, so
    // drop it rather than expose an unused, oddly-named field.
    delete r.owner_username;
  }
  return rows;
}

const dbError = (req, res, err, fields) => sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields });
const notFound = (req, res, message = 'Not found') => sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: message });

// A version row omits the (potentially large) snapshot body in list responses;
// list callers only need the metadata.
const VERSION_META_COLUMNS = 'id, scenario_id, name, note, created_at, created_by';

// GET /scenarios/:scenarioId/versions — metadata list, newest first.
router.get('/scenarios/:scenarioId/versions', async (req, res) => {
  if (!requireAuth(req, res)) return;
  try {
    const rows = await pool.ro.query(
      `SELECT ${VERSION_META_COLUMNS} FROM \`${t(TABLES.CAP_VERSIONS)}\`
        WHERE scenario_id = ? ORDER BY created_at DESC, id DESC`,
      [req.params.scenarioId],
    );
    await enrichCreatedByName(pool.ro, rows);
    res.json(apiOk(rows));
  } catch (err) {
    dbError(req, res, err, { scenarioId: req.params.scenarioId });
  }
});

// GET /scenarios/:scenarioId/versions/:versionId — one version + parsed snapshot.
router.get('/scenarios/:scenarioId/versions/:versionId', async (req, res) => {
  if (!requireAuth(req, res)) return;
  try {
    const rows = await pool.ro.query(
      `SELECT * FROM \`${t(TABLES.CAP_VERSIONS)}\` WHERE id = ? AND scenario_id = ?`,
      [req.params.versionId, req.params.scenarioId],
    );
    if (!rows.length) return notFound(req, res, 'Version not found');
    const row = rows[0];
    // The driver may return the JSON column as a string or an object; hand the
    // client a parsed document either way. A corrupt snapshot is left as-is
    // rather than 500ing a read.
    if (typeof row.snapshot === 'string') {
      try { row.snapshot = JSON.parse(row.snapshot); } catch { /* leave raw */ }
    }
    res.json(apiOk(row));
  } catch (err) {
    dbError(req, res, err, { scenarioId: req.params.scenarioId, versionId: req.params.versionId });
  }
});

// POST /scenarios/:scenarioId/versions — freeze the live state as a new version.
router.post('/scenarios/:scenarioId/versions', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const body = req.body || {};
  const name = typeof body.name === 'string' ? body.name.trim() : '';
  if (!name) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'name is required' });
  }
  if (name.length > MAX_NAME) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: `name exceeds ${MAX_NAME} characters` });
  }
  const note = body.note ?? null;
  if (note !== null && (typeof note !== 'string' || note.length > MAX_NOTE)) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: `note must be a string up to ${MAX_NOTE} characters` });
  }

  const scenarioId = req.params.scenarioId;
  // SECURITY: the actor is the sole authority on the audit trail — a
  // client-supplied created_by is never trusted.
  const createdBy = req.user && req.user.id ? req.user.id : null;
  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();

    const access = await resolveScenarioWriteAccess(conn, scenarioId, req.user);
    if (!access.found) { await safeRollback(conn); return notFound(req, res, 'Scenario not found'); }
    if (!access.allowed) {
      await safeRollback(conn);
      return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Not allowed: you do not own this scenario' });
    }

    // SERVER-computed snapshot via the SHARED writer (the same one a
    // threshold-crossing cascade delete calls): freeze every scenario-scoped row
    // (raw inputs only — derived values are never stored, spec §2.1). A
    // client-supplied body.snapshot is ignored entirely. The STORED scenario id
    // is bound, not the URL segment (see writeVersionSnapshot).
    let versionId;
    try {
      ({ id: versionId } = await writeVersionSnapshot(conn, access.scenarioId, name, { note, createdBy }));
    } catch (err) {
      if (err instanceof SnapshotTooLargeError) {
        await safeRollback(conn);
        return sendError(req, res, err, { status: 400, code: 'PAYLOAD_TOO_LARGE', reason: 'Scenario snapshot is too large to version' });
      }
      throw err;
    }
    await conn.commit();

    const rows = await conn.query(
      `SELECT ${VERSION_META_COLUMNS} FROM \`${t(TABLES.CAP_VERSIONS)}\` WHERE id = ?`,
      [versionId],
    );
    await enrichCreatedByName(conn, rows);
    res.status(201).json(apiOk(rows[0] || {
      // Same id the INSERT bound: this fallback describes the row that was just
      // written, so it must not describe it differently from the re-read above.
      id: versionId,
      scenario_id: access.scenarioId,
      name,
      note,
      created_by: createdBy,
      created_by_name: null,
    }));
  } catch (err) {
    await safeRollback(conn);
    dbError(req, res, err, { scenarioId });
  } finally {
    if (conn) conn.release();
  }
});

// DELETE /scenarios/:scenarioId/versions/:versionId — prune a version (owner+admin).
router.delete('/scenarios/:scenarioId/versions/:versionId', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const scenarioId = req.params.scenarioId;
  const versionId = req.params.versionId;
  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();

    const access = await resolveScenarioWriteAccess(conn, scenarioId, req.user);
    if (!access.found) { await safeRollback(conn); return notFound(req, res, 'Scenario not found'); }
    if (!access.allowed) {
      await safeRollback(conn);
      return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Not allowed: you do not own this scenario' });
    }

    // The version must belong to THIS scenario (else 404 without revealing a
    // cross-scenario version's existence).
    const rows = await conn.query(
      `SELECT id FROM \`${t(TABLES.CAP_VERSIONS)}\` WHERE id = ? AND scenario_id = ? FOR UPDATE`,
      [versionId, scenarioId],
    );
    if (!rows.length) { await safeRollback(conn); return notFound(req, res, 'Version not found'); }

    await conn.query(
      `DELETE FROM \`${t(TABLES.CAP_VERSIONS)}\` WHERE id = ? AND scenario_id = ?`,
      [versionId, scenarioId],
    );
    await conn.commit();
    res.json(apiOk({ id: versionId, deleted: true }));
  } catch (err) {
    await safeRollback(conn);
    dbError(req, res, err, { scenarioId, versionId });
  } finally {
    if (conn) conn.release();
  }
});

// POST /scenarios/:scenarioId/versions/:versionId/clone — restore a version by
// deep-copying its FROZEN snapshot into a brand-new scenario (spec §5: restore
// is clone, never overwrite history). The new scenario is a fresh create
// (owner-scope: editor stamps self, admin leaves NULL); every id is minted anew
// and every FK / waiver object_set_key remapped (deepCopyScenarioRows). The
// clone reproduces the frozen state, NOT the source scenario's current live
// state.
router.post('/scenarios/:scenarioId/versions/:versionId/clone', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const scenarioId = req.params.scenarioId;
  const versionId = req.params.versionId;
  const body = req.body || {};
  const rawName = typeof body.name === 'string' ? body.name.trim() : '';
  if (rawName.length > MAX_NAME) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: `name exceeds ${MAX_NAME} characters` });
  }
  const noteOverride = body.note;
  if (noteOverride != null && (typeof noteOverride !== 'string' || noteOverride.length > MAX_NOTE)) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: `note must be a string up to ${MAX_NOTE} characters` });
  }

  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();

    const rows = await conn.query(
      `SELECT id, name, note, snapshot FROM \`${t(TABLES.CAP_VERSIONS)}\` WHERE id = ? AND scenario_id = ?`,
      [versionId, scenarioId],
    );
    if (!rows.length) { await safeRollback(conn); return notFound(req, res, 'Version not found'); }
    const version = rows[0];

    // The driver may hand back the JSON column as a string or an object.
    let snapshotDoc = version.snapshot;
    if (typeof snapshotDoc === 'string') {
      try { snapshotDoc = JSON.parse(snapshotDoc); } catch { snapshotDoc = null; }
    }
    // A well-formed snapshot carries { schema_rev, tables }; a corrupt/empty one
    // clones an empty scenario rather than 500ing the restore.
    const tablesData = (snapshotDoc && typeof snapshotDoc === 'object' && snapshotDoc.tables) || {};
    if (snapshotDoc && snapshotDoc.schema_rev != null && snapshotDoc.schema_rev !== SNAPSHOT_SCHEMA_REV) {
      req.log.warn({ scenarioId, versionId, schemaRev: snapshotDoc.schema_rev }, 'cloning a capacity version with an unexpected snapshot schema_rev');
    }

    const cloneName = (rawName || `${version.name} (copy)`).slice(0, MAX_NAME);
    const cloneNote = noteOverride !== undefined ? (noteOverride ?? null) : (version.note ?? null);

    const newId = await cloneScenarioFromTables(conn, {
      name: cloneName, note: cloneNote, actor: req.user, tablesData, sourceScenarioId: scenarioId,
    });
    await conn.commit();

    const created = await conn.query(
      `SELECT * FROM \`${t(TABLES.CAP_SCENARIOS)}\` WHERE id = ?`, [newId],
    );
    res.status(201).json(apiOk(mapRowsFromDb(TABLES.CAP_SCENARIOS, created)[0]));
  } catch (err) {
    await safeRollback(conn);
    dbError(req, res, err, { scenarioId, versionId });
  } finally {
    if (conn) conn.release();
  }
});

// The audit event a restore records in feature_audit. An in-place restore is the
// only capacity route that destroys live rows, so it leaves a trail of its own:
// which version was switched to, and whether the state it replaced was saved.
const RESTORE_AUDIT_EVENT = 'cap_scenario.version.restore';

// POST /scenarios/:scenarioId/versions/:versionId/restore — replay a frozen
// version over the SAME scenario (destructive, spec Epic 2). Ordering inside one
// transaction: gate → delete every scenario-scoped row → replay the frozen rows
// (ids kept, so FKs and waiver object_set_keys still resolve) → audit. The
// version row is never edited, version history is never pruned, and the global
// config layer is never touched. Every rejection path fires BEFORE the delete.
//
// This route no longer freezes the state it is about to destroy (D6). Keeping
// the state was an automatic `Pre-restore backup <timestamp>` row nobody asked
// for and nobody pruned; the caller is now asked outright and, if the answer is
// yes, creates a NAMED version through the ordinary create route first. The
// caller then passes that version's id here so the audit trail records that the
// replaced state was kept and where it went. The id is verified twice: it must
// belong to this scenario, and its frozen rows must still be the scenario's live
// rows — otherwise the switch is refused, because the state being destroyed is
// not the state the caller saved.
router.post('/scenarios/:scenarioId/versions/:versionId/restore', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const scenarioId = req.params.scenarioId;
  const versionId = req.params.versionId;
  // SECURITY: the actor is the sole authority on the audit trail. Exactly one
  // field is read from the body — the id of the version the caller saved the
  // replaced state as — and it is verified against this scenario's own version
  // rows before it is recorded. Everything else a client might send (name,
  // created_by, snapshot) is ignored, as before.
  const actor = req.user;
  const createdBy = actor && actor.id ? actor.id : null;
  const rawSavedVersionId = (req.body || {}).saved_version_id;
  if (rawSavedVersionId !== undefined && rawSavedVersionId !== null && typeof rawSavedVersionId !== 'string') {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'saved_version_id must be a version id string' });
  }
  const claimedSavedVersionId = typeof rawSavedVersionId === 'string' && rawSavedVersionId ? rawSavedVersionId : null;

  // 409s come in two kinds, and the client tells them apart by CODE, not by
  // status: `CONFLICT` is "this snapshot cannot be replayed" (schema_rev drift,
  // an unreadable document, column drift), whose way out is cloning the version
  // into a new scenario; `SCENARIO_CHANGED` is "the scenario moved since it was
  // saved", whose way out is saving the current state and switching again.
  // Offering the clone route for the second would send the operator the wrong
  // way.
  const conflict = (message, code = 'CONFLICT') => {
    sendError(req, res, null, { status: 409, code: code, reason: message });
  };

  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();

    const access = await resolveScenarioWriteAccess(conn, scenarioId, actor);
    if (!access.found) { await safeRollback(conn); return notFound(req, res, 'Scenario not found'); }
    if (!access.allowed) {
      await safeRollback(conn);
      return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Not allowed: you do not own this scenario' });
    }

    // The version must belong to THIS scenario (else 404 without revealing a
    // cross-scenario version's existence).
    const rows = await conn.query(
      `SELECT id, name, snapshot FROM \`${t(TABLES.CAP_VERSIONS)}\` WHERE id = ? AND scenario_id = ?`,
      [versionId, scenarioId],
    );
    if (!rows.length) { await safeRollback(conn); return notFound(req, res, 'Version not found'); }
    const version = rows[0];

    // The driver may hand back the JSON column as a string or an object.
    let snapshotDoc = version.snapshot;
    if (typeof snapshotDoc === 'string') {
      try { snapshotDoc = JSON.parse(snapshotDoc); } catch { snapshotDoc = null; }
    }
    if (!snapshotDoc || typeof snapshotDoc !== 'object' || Array.isArray(snapshotDoc)) {
      await safeRollback(conn);
      return conflict('This version\'s snapshot cannot be read, so it cannot be restored. Restore a different version.');
    }

    // schema_rev is a HARD gate on the destructive path (unlike clone, which only
    // warns): replaying rows of an unknown shape over the live scenario could
    // write columns that no longer mean what they meant at freeze time. Any
    // difference — older, newer or absent — is refused, and the operator is
    // pointed at the non-destructive alternative.
    if (snapshotDoc.schema_rev !== SNAPSHOT_SCHEMA_REV) {
      await safeRollback(conn);
      const found = snapshotDoc.schema_rev == null ? 'none' : String(snapshotDoc.schema_rev);
      return conflict(
        `This version was saved in a different snapshot format (schema_rev ${found}; this server writes ${SNAPSHOT_SCHEMA_REV}), so it cannot be restored in place. Use "Clone to new scenario" to open it as a separate scenario.`,
      );
    }

    const blocker = findSnapshotRestoreBlocker(snapshotDoc.tables);
    if (blocker) {
      await safeRollback(conn);
      return conflict(`This version cannot be restored: ${blocker}. Use "Clone to new scenario" to inspect it instead.`);
    }

    // The caller's claim that the replaced state was saved is checked against
    // this scenario's own versions before it can reach the audit trail. An id
    // that is not a version of this scenario is a refusal, not a silent drop:
    // recording a saved-state pointer that leads nowhere would be worse than
    // recording nothing. Checked here, with every other gate, so it still fires
    // before the first delete.
    let savedVersionId = null;
    if (claimedSavedVersionId) {
      if (claimedSavedVersionId === versionId) {
        await safeRollback(conn);
        return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'saved_version_id cannot be the version being restored' });
      }
      const savedRows = await conn.query(
        `SELECT id, snapshot FROM \`${t(TABLES.CAP_VERSIONS)}\` WHERE id = ? AND scenario_id = ?`,
        [claimedSavedVersionId, scenarioId],
      );
      if (!savedRows.length) { await safeRollback(conn); return notFound(req, res, 'Saved version not found'); }

      // SAFETY — the saved version must hold the state this call is about to
      // destroy, not merely exist. The caller saves and switches in two separate
      // round-trips and may leave minutes between them (the client offers a
      // retry from an error dialog), so a write from a second tab or another
      // admin can land in the gap. That write is in neither version, and the
      // replay below would delete it with no copy anywhere while the audit row
      // claimed the replaced state was kept. Fingerprinting the scenario's own
      // rows against the named version makes `prior_state_saved` derived from
      // the data instead of taken on the caller's word.
      //
      // Scope of the guarantee: the fingerprint is read inside this
      // transaction, but only the scenario ROW is locked (resolveScenarioWriteAccess
      // FOR UPDATE), so a write committed between this read and the DELETE below
      // is still replaced. That residual window is the transaction's own
      // duration; closing it needs locking reads across all fourteen tables,
      // which is a different mechanism. The operator-paced window is gone.
      //
      // Only for a switch that CLAIMS a save: "switch without saving" is the
      // operator electing to destroy the working state, and there is nothing to
      // be stale against.
      let savedDoc = savedRows[0].snapshot;
      if (typeof savedDoc === 'string') {
        try { savedDoc = JSON.parse(savedDoc); } catch { savedDoc = null; }
      }
      const savedTables = savedDoc && typeof savedDoc === 'object' && !Array.isArray(savedDoc)
        ? savedDoc.tables
        : null;
      if (!savedTables) {
        await safeRollback(conn);
        return conflict(
          'The version named as the saved state has no readable snapshot, so there is no proof it holds the state this switch would replace. Nothing was changed.',
          'SCENARIO_CHANGED',
        );
      }
      const snapshotKeys = SNAPSHOT_TABLES.map(({ key }) => key);
      const liveTables = await readScenarioSnapshotTables(conn, scenarioId);
      // Normalise the name_patterns shape on BOTH sides before comparing, so a
      // pre-deploy-frozen snapshot's legacy override does not read as a change.
      const savedNorm = normalizeSettingsForFingerprint(savedTables);
      const liveNorm = normalizeSettingsForFingerprint(liveTables);
      if (fingerprintScenarioRows(savedNorm, snapshotKeys)
        !== fingerprintScenarioRows(liveNorm, snapshotKeys)) {
        await safeRollback(conn);
        return conflict(
          'This scenario changed after it was saved, so switching now would delete work that no version holds. Nothing was changed — start the switch again to save the current state first.',
          'SCENARIO_CHANGED',
        );
      }
      savedVersionId = claimedSavedVersionId;
    }

    // Clear and refill — one transaction, so a failure anywhere below leaves the
    // scenario exactly as it was.
    //
    // The scenario's OWN id is the scope, taken from the access gate that
    // resolved it. `WHERE id = ?` admits any spelling, so binding the URL
    // segment would re-insert every child row of the scenario carrying a
    // `scenario_id` no scenario's `id` holds — the same "half-editable,
    // unreferenceable" state the single-row write paths bind the stored id to
    // avoid, applied here to the whole scenario at once.
    await deleteScenarioScopedRows(conn, access.scenarioId);
    const restoredCounts = await restoreScenarioRowsFromTables(
      conn, snapshotDoc.tables, access.scenarioId,
    );

    // (4) Audit. SECURITY: allowlist actor.role so a spoofed claim cannot land an
    // arbitrary string in the audit metadata.
    const safeRole = ['admin', 'editor', 'user'].includes(actor.role) ? actor.role : 'unknown';
    await conn.query(
      `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata)
       VALUES (?, ?, ?, ?)`,
      [
        uuidv4(),
        RESTORE_AUDIT_EVENT,
        createdBy,
        JSON.stringify({
          // The resolved id, like the rows this restore just wrote. An audit
          // line is durable and is read long after the request that made it, so
          // a trail naming a scenario id no scenario carries is the same
          // unreferenceable value one layer up — and the one copy nobody can
          // repair by re-saving.
          scenario_id: access.scenarioId,
          version_id: versionId,
          // Derived, never a client boolean. Reaching this line means the id
          // named a version of THIS scenario and that version's frozen rows
          // fingerprinted equal to the rows about to be deleted — so "the prior
          // state was saved" is a statement about the data rather than about
          // what the caller said it had done.
          prior_state_saved: savedVersionId !== null,
          saved_version_id: savedVersionId,
          actor_role: safeRole,
          restored_counts: restoredCounts,
        }),
      ],
    );

    await conn.commit();
    res.json(apiOk({
      // The id the restored rows carry, so the client re-reads the scope it was
      // just told about rather than the one it happened to type.
      scenario_id: access.scenarioId,
      version_id: versionId,
      prior_state_saved: savedVersionId !== null,
      saved_version_id: savedVersionId,
      restored_counts: restoredCounts,
    }));
  } catch (err) {
    await safeRollback(conn);
    // Two driver errors are the snapshot's fault, not the server's, and the
    // operator can act on them: a duplicate id (1062) means a frozen row's id is
    // already live elsewhere, and an unknown column (1054) means the snapshot
    // predates a column drop. Both left the scenario intact (the transaction
    // rolled back), and both have the same non-destructive way out.
    if (err && (err.errno === 1062 || err.errno === 1054)) {
      // The 409 conflict responder (sendError with no err/no >=500 status)
      // never emits an app-error line, so this is the ONLY log for this
      // branch — logged here, not before the branch split, or the generic
      // path below would double-log via sendError's own line.
      req.log.error({ err, scenarioId, versionId }, 'Failed to restore capacity version');
      return conflict('This version no longer matches the current database shape, so it cannot be restored in place. Nothing was changed — use "Clone to new scenario" instead.');
    }
    // dbError -> sendError logs the app-error line itself for every >=500
    // response, carrying this same err as its cause; logging it again here
    // would duplicate the record for the one branch that already has a
    // logger of its own.
    dbError(req, res, err, { scenarioId, versionId });
  } finally {
    if (conn) conn.release();
  }
});

// The audit event a version's label edit records. Separate from the restore
// event because it is a different act: nothing about the scenario changes.
const EDIT_AUDIT_EVENT = 'cap_scenario.version.edit';

// The ONLY columns a version's PUT may touch (D7). Everything else about a
// version — above all the snapshot body, its schema_rev and its provenance —
// stays frozen, which is the whole reason a version is trustworthy.
const EDITABLE_VERSION_FIELDS = Object.freeze(['name', 'note']);

// PUT /scenarios/:scenarioId/versions/:versionId — rename a version / edit its
// note (D7). This is a two-field whitelist, not an update route: the snapshot
// body stays immutable, and a request that so much as MENTIONS a frozen column
// is refused rather than quietly having that field dropped. Silently ignoring
// it would let a caller believe they had rewritten history.
router.put('/scenarios/:scenarioId/versions/:versionId', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const scenarioId = req.params.scenarioId;
  const versionId = req.params.versionId;
  const body = req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : {};

  const badRequest = (message) => {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: message });
  };

  const rejected = Object.keys(body).filter((k) => !EDITABLE_VERSION_FIELDS.includes(k));
  if (rejected.length) {
    return badRequest(
      `A version's ${rejected.sort().join(', ')} cannot be changed; only ${EDITABLE_VERSION_FIELDS.join(' and ')} are editable. `
      + 'Clone the version into a new scenario to work from its contents.',
    );
  }

  const updates = [];
  const params = [];
  if (Object.prototype.hasOwnProperty.call(body, 'name')) {
    const name = typeof body.name === 'string' ? body.name.trim() : '';
    if (!name) return badRequest('name is required');
    if (name.length > MAX_NAME) return badRequest(`name exceeds ${MAX_NAME} characters`);
    updates.push('name = ?');
    params.push(name);
  }
  if (Object.prototype.hasOwnProperty.call(body, 'note')) {
    const note = body.note ?? null;
    if (note !== null && (typeof note !== 'string' || note.length > MAX_NOTE)) {
      return badRequest(`note must be a string up to ${MAX_NOTE} characters`);
    }
    updates.push('note = ?');
    params.push(note);
  }
  if (!updates.length) return badRequest(`Provide ${EDITABLE_VERSION_FIELDS.join(' or ')} to change`);

  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();

    const access = await resolveScenarioWriteAccess(conn, scenarioId, req.user);
    if (!access.found) { await safeRollback(conn); return notFound(req, res, 'Scenario not found'); }
    if (!access.allowed) {
      await safeRollback(conn);
      return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Not allowed: you do not own this scenario' });
    }

    // The version must belong to THIS scenario (else 404 without revealing a
    // cross-scenario version's existence).
    const existing = await conn.query(
      `SELECT id FROM \`${t(TABLES.CAP_VERSIONS)}\` WHERE id = ? AND scenario_id = ? FOR UPDATE`,
      [versionId, scenarioId],
    );
    if (!existing.length) { await safeRollback(conn); return notFound(req, res, 'Version not found'); }

    // The column list is built from the whitelist above, never from the request
    // — the request only decides WHICH of the two appear.
    await conn.query(
      `UPDATE \`${t(TABLES.CAP_VERSIONS)}\` SET ${updates.join(', ')} WHERE id = ? AND scenario_id = ?`,
      [...params, versionId, scenarioId],
    );

    // SECURITY: allowlist actor.role so a spoofed claim cannot land an arbitrary
    // string in the audit metadata (same guard the restore audit uses).
    const actor = req.user || {};
    const safeRole = ['admin', 'editor', 'user'].includes(actor.role) ? actor.role : 'unknown';
    await conn.query(
      `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata)
       VALUES (?, ?, ?, ?)`,
      [
        uuidv4(),
        EDIT_AUDIT_EVENT,
        actor.id || null,
        JSON.stringify({
          // The resolved id — same rule as the restore trail above.
          scenario_id: access.scenarioId,
          version_id: versionId,
          actor_role: safeRole,
          // Which labels moved, not their contents: a note can be 10k
          // characters and the audit is a trail, not a second copy.
          changed_fields: EDITABLE_VERSION_FIELDS.filter((f) => Object.prototype.hasOwnProperty.call(body, f)),
        }),
      ],
    );

    await conn.commit();

    const rows = await conn.query(
      `SELECT ${VERSION_META_COLUMNS} FROM \`${t(TABLES.CAP_VERSIONS)}\` WHERE id = ?`,
      [versionId],
    );
    await enrichCreatedByName(conn, rows);
    res.json(apiOk(rows[0] || null));
  } catch (err) {
    await safeRollback(conn);
    dbError(req, res, err, { scenarioId, versionId });
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
