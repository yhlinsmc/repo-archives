/**
 * @openapi
 * /edge/app/capacity/scenarios/{scenarioId}/local-catalogues/{catalogue}:
 *   get:
 *     tags: [App - Capacity]
 *     summary: List a scenario's LOCAL catalogue additions (all authenticated).
 *     parameters:
 *       - { name: scenarioId, in: path, required: true, schema: { type: string } }
 *       - { name: catalogue, in: path, required: true, schema: { type: string, enum: [hardware_specs, vm_profiles, disk_combos, teams] } }
 *     responses:
 *       200: { description: Scenario-local catalogue rows (scenario_id = the scenario) }
 *   post:
 *     tags: [App - Capacity]
 *     summary: Add a scenario-local catalogue row (owner+admin). scenario_id is bound to the URL.
 *     responses:
 *       201: { description: Created }
 *       403: { description: Not the scenario owner (and not admin) }
 */

/**
 * capacity/local-catalogues.js — scenario-LOCAL catalogue additions (spec §2.4).
 *
 * In the reference model a scenario REFERENCES the global catalogues, but it MAY
 * also add its OWN local hardware_specs / vm_profiles / disk_combos / teams
 * (a row whose scenario_id is the scenario, flagged local). R1 shipped the global
 * writes (config.js, scenario_id IS NULL); this mount adds the scenario-local
 * write path. Custom field defs are GLOBAL-ONLY (§8) and are deliberately absent.
 *
 * The four catalogues carry NO scalar catalogue FK, so no §17.1a FK validator is
 * wired here (parity with the global /config writes, which likewise do not
 * validate vm_profiles.allowed_disk_combos — a soft JSON allow-list).
 *
 * Permission = owner+admin (the scenario tier via parentOwnership), NOT the
 * admin+editor global-config tier: a scenario-local row belongs to the scenario,
 * so its owner is the scenario owner. Read = all authenticated (spec §7).
 * bindScenarioScope forces a write's scenario_id to the URL param and scopes the
 * LIST GET to the scenario's own local rows; scenario_id is immutable so a PUT
 * cannot move a local row across scenarios or promote it to global. makeConfigTypeGuard
 * runs the same per-column type checks as the global /config write; the bespoke
 * makeLocalCatalogueDelete refuses 409 while any live row references the local row.
 */
const { createCrudRoutes } = require('../schema');
const { sendError } = require('../../../../shared/lib/send-error');
const { TABLES } = require('../../../../shared/constants');
const { enumColumnsFor } = require('../../../lib/schema-manifest');
const {
  bindScenarioScope, childWriteRoleGate, makeScenarioExistsGuard, makeRowScenarioBinding,
  makeConfigTypeGuard, makeLocalCatalogueDelete, makeAppendOrderIndexOnCreate,
  makeAllowedDiskCombosCanonicalizer, missingRequiredColumnOnCreate,
  SCENARIO_OWNERSHIP, LOCAL_CATALOGUE_MOUNTS,
} = require('./_shared');
const { apiError } = require('../../../../shared/helpers');

// Each local catalogue's canonical ENUM columns — the generic factory 400s a
// non-canonical value (e.g. 'db') on POST/PUT rather than relying on the DB's
// case-insensitive ENUM to silently normalize it.
//
// READ FROM table-ddls.js, NOT LISTED HERE, exactly as children.js reads its
// own. The members restated at this mount were a second source of truth for the
// column's shape, and the first narrowing or widening of the ENUM would have
// left it wrong in silence — refusing a member the column accepts, or admitting
// one it no longer has. `enumColumnsFor` answers only for columns the DDL
// genuinely declares an ENUM, so a catalogue with none declares no domain.
//
// It also decides more than it used to. The factory derives its
// required-on-create set from the domains a mount declares: a NOT NULL ENUM
// with no DEFAULT must be NAMED by a create, because the engine would otherwise
// fill it with the first declared member. `cap_vm_profiles.class` is such a
// column, so a POST here that omits `class` is answered 400 COLUMN_REQUIRED
// instead of silently landing as 'DB'. That is INTENDED on this mount and not
// an accident of the rule being global: a scenario-local profile whose class
// nobody chose is the same silent mis-store the rule exists to end, and every
// surface that creates one sends the field.
const LOCAL_ENUM_COLUMNS = Object.freeze(Object.fromEntries(
  Object.entries(LOCAL_CATALOGUE_MOUNTS)
    .map(([catalogue, def]) => [catalogue, enumColumnsFor(def.table) || {}])
    .filter(([, domains]) => Object.keys(domains).length > 0)
    .map(([catalogue, domains]) => [catalogue, Object.freeze(domains)]),
));

// Only hardware_specs is drag-reorderable (phase-4 spec §6) — a grid-added local
// spec appends at the END of the scenario's local order (order_index = MAX+1).
// The other local catalogues (vm_profiles / disk_combos / teams) carry no
// order_index column, so they get no create transform.
const LOCAL_CATALOGUE_CREATE_TRANSFORM = {
  hardware_specs: makeAppendOrderIndexOnCreate(TABLES.CAP_HARDWARE_SPECS),
};

/**
 * POST-only pre-middleware, the local-catalogue twin of children.js's
 * `makeRequiredColumnGuard` (D5 review finding 3). `enumColumns` above already
 * covers a NOT-NULL-no-default ENUM (e.g. `vm_profiles.class` — the factory's
 * own `enumRequiredOnCreate` derivation, matching the global /config mount),
 * but a NOT-NULL-no-default column of any OTHER type (`name`, on every one of
 * these four catalogues) reached the database's own constraint violation as an
 * unmapped 500, the identical gap closed on children.js and config.js.
 *
 * MUST run after `bindScenarioScope` (the only column this mount fills
 * server-side — `scenario_id`, which is nullable on all four tables and so
 * never appears in the DDL-derived required set anyway) — placed after it in
 * the `pre` array below, mirroring children.js's own ordering rule.
 */
function makeLocalCatalogueRequiredColumnGuard(table) {
  return function requiredColumnGuard(req, res, next) {
    if (req.method !== 'POST') return next();
    const body = req.body || {};
    const missing = missingRequiredColumnOnCreate(table, Object.keys(body), body);
    if (missing) {
      return sendError(req, res, null, { status: 400, code: 'COLUMN_REQUIRED', reason: missing });
    }
    return next();
  };
}

/**
 * Mount every scenario-local catalogue write router under
 * `/scenarios/:scenarioId/local-catalogues/<catalogue>`.
 * @param {import('express').Router} capacityRouter
 */
function mountLocalCatalogues(capacityRouter) {
  for (const [catalogue, def] of Object.entries(LOCAL_CATALOGUE_MOUNTS)) {
    const pre = [];
    // Role gate FIRST: a non-admin/editor write is refused before any DB-touching
    // pre-guard runs (reads stay open).
    pre.push(childWriteRoleGate);
    pre.push(bindScenarioScope);
    // POST: refuse cheaply (400 COLUMN_REQUIRED) a create that omits a
    // DDL-required column, before any DB round trip — after bindScenarioScope
    // (the only server-fill step this mount has) so it judges the body that
    // step produces (D5 review finding 3).
    pre.push(makeLocalCatalogueRequiredColumnGuard(def.table));
    // Type-check the raw body exactly as the global /config write does.
    pre.push(makeConfigTypeGuard(catalogue));
    // POST: the URL scenario must exist (admin bypasses parentOwnership → guard here).
    pre.push(makeScenarioExistsGuard());
    // PUT: the target row must be a local row of this scenario (404 otherwise).
    pre.push(makeRowScenarioBinding(def.table));
    // DELETE: ownership + reference guard, transactional, handled fully ahead of
    // the factory (whose blind DELETE would dangle a referencing FK).
    pre.push(makeLocalCatalogueDelete(def.table, catalogue));
    capacityRouter.use(
      `/scenarios/:scenarioId/local-catalogues/${catalogue}`,
      ...pre,
      createCrudRoutes(def.table, {
        allowedRoles: ['admin', 'editor'],
        parentOwnership: SCENARIO_OWNERSHIP,
        filterableColumns: def.filterableColumns,
        // A PUT must never reparent a row to another scenario or to global.
        immutableColumns: ['scenario_id'],
        ...(LOCAL_ENUM_COLUMNS[catalogue] ? { enumColumns: LOCAL_ENUM_COLUMNS[catalogue] } : {}),
        // hardware_specs: append order_index = MAX+1 on create (spec §6).
        ...(LOCAL_CATALOGUE_CREATE_TRANSFORM[catalogue]
          ? { transformCreateInTx: LOCAL_CATALOGUE_CREATE_TRANSFORM[catalogue] }
          : {}),
        // vm_profiles: canonicalise a written allow-list to the referenced
        // combos' own spelling (item 4a) — the same shape D4 fixed for
        // dc_refs, on the other side of diskComboAllowed's byte compare.
        ...(catalogue === 'vm_profiles'
          ? { preWriteInTx: makeAllowedDiskCombosCanonicalizer() }
          : {}),
      }),
    );
  }
}

module.exports = { mountLocalCatalogues };
