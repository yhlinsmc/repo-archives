/**
 * @openapi
 * /edge/app/capacity/scenarios/{scenarioId}/specs:
 *   get:
 *     tags: [App - Capacity]
 *     summary: The hardware specs a scenario sees (global + its own local, read-only).
 *     parameters:
 *       - { name: scenarioId, in: path, required: true, schema: { type: string } }
 *     responses:
 *       200: { description: Global-or-same-scenario cap_hardware_specs rows }
 */

/**
 * capacity/catalogue-reads.js — read-only scenario-scoped global-or-same-scenario
 * reads (reference model, spec §2 / §17.1a).
 *
 * The catalogues (hardware specs, vm_profiles) went GLOBAL in the config rewrite
 * (spec §5 / §3), and RULES are the GLOBAL default template a scenario references
 * and locally adjusts (spec §13.1a / §13.4): a scenario REFERENCES the global
 * rows (scenario_id IS NULL) and MAY add its own LOCAL rows (scenario_id = X,
 * spec §2.2 — for rules: scenario-local standalone rules + override rows). A
 * consumer that needs what a scenario ACTUALLY sees — the live placement model's
 * usable / SGA math AND its live rule evaluation, the Grid tab's spec/profile
 * dropdowns — must read global-or-same-scenario, matching the §17.1a write
 * validator's visibility rule and the /violations snapshot (so the FE evaluator
 * and the backend endpoint agree on the exact rule set). The global
 * /config/{hardware_specs,vm_profiles,rules} mounts return ONLY the global layer
 * and would miss a scenario's local additions; these GET-only mounts close that.
 *
 * These GET mounts are registered ahead of the generic child mounts, so a rules
 * LIST read (GET /scenarios/:id/rules) resolves here (global+local); rule WRITES
 * (POST/PUT/DELETE) and the single-row GET /:id fall through to children.js.
 *
 * READ-ONLY: writes stay on /config (global) and the scenario child mounts.
 * Reads are open to all authenticated users (spec §7), exactly like /violations.
 */
const { pool, t } = require('../../../db');
const { sendError } = require('../../../../shared/lib/send-error');
const { TABLES } = require('../../../../shared/constants');
const { requireAuth, apiOk, apiError } = require('../../../../shared/helpers');
const { mapRowsFromDb } = require('../../../lib/dto-mapper');
const { logger } = require('../../../../shared/lib/logger');

// URL segment → table read global-or-same-scenario. The segment names match the
// frontend's live queries (usePlacementModel `${base}/specs`, `${base}/profiles`;
// useCapacityRules `${base}/rules`). `rules` is here — not a "catalogue" per se,
// but the same reference-model visibility rule: the global default template +
// this scenario's local rules/overrides (the FE evaluator resolves overrides).
const CATALOGUE_READS = Object.freeze({
  specs: TABLES.CAP_HARDWARE_SPECS,
  profiles: TABLES.CAP_VM_PROFILES,
  // disk_combos + teams join the reference-model reads in R2: once a scenario may
  // ADD local disk combos / teams (§2.4, local-catalogues.js), the scenario view
  // must see the global rows PLUS its own local additions to offer them as VM /
  // database references — exactly the global-or-same-scenario visibility the
  // §17.1a write validator accepts. The global /config/{disk_combos,teams} mounts
  // return only the global layer and would miss local additions.
  disk_combos: TABLES.CAP_DISK_COMBOS,
  teams: TABLES.CAP_TEAMS,
  rules: TABLES.CAP_RULES,
});

/**
 * Register the read-only catalogue GET mounts on the capacity router. Mounted
 * ahead of the generic child + scenario mounts so the two-segment paths win.
 * @param {import('express').Router} capacityRouter
 */
function mountCatalogueReads(capacityRouter) {
  for (const [segment, table] of Object.entries(CATALOGUE_READS)) {
    capacityRouter.get(`/scenarios/:scenarioId/${segment}`, async (req, res) => {
      if (!requireAuth(req, res)) return;
      const scenarioId = req.params.scenarioId;
      try {
        // The URL scenario must exist — else 404 (a missing scenario must not
        // return the bare global catalogue as if it were the scenario's).
        const scen = await pool.ro.query(
          `SELECT 1 AS ok FROM \`${t(TABLES.CAP_SCENARIOS)}\` WHERE id = ?`, [scenarioId],
        );
        if (!scen.length) {
          return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
        }
        const rows = await pool.ro.query(
          `SELECT * FROM \`${t(table)}\` WHERE scenario_id IS NULL OR scenario_id = ?`,
          [scenarioId],
        );
        return res.json(apiOk(mapRowsFromDb(table, rows)));
      } catch (err) {
        return sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { scenarioId } });
      }
    });
  }
}

module.exports = { mountCatalogueReads, CATALOGUE_READS };
