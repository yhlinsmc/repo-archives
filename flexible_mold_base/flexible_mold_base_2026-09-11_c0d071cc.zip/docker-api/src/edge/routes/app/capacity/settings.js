/**
 * @openapi
 * /edge/app/capacity/scenarios/{scenarioId}/settings:
 *   get:
 *     tags: [App - Capacity]
 *     summary: Get the scenario's cap_settings singleton row (all authenticated).
 *     parameters:
 *       - { name: scenarioId, in: path, required: true, schema: { type: string } }
 *     responses:
 *       200: { description: The scenario's EFFECTIVE settings — its own override row (is_override true) or the global seed fallback (is_override false) }
 *       404: { description: The scenario id does not exist, or no global settings seed row is present }
 *   put:
 *     tags: [App - Capacity]
 *     summary: Update the scenario's cap_settings singleton row (owner+admin).
 *     parameters:
 *       - { name: scenarioId, in: path, required: true, schema: { type: string } }
 *     responses:
 *       200: { description: Updated (or minted, if the scenario had none yet) }
 *       403: { description: Not the scenario owner (and not admin/editor) }
 */

/**
 * capacity/settings.js — per-scenario cap_settings singleton (PR-B Task 1).
 *
 * Unlike every other scenario-scoped child (children.js), a scenario carries
 * AT MOST ONE cap_settings row — an OPTIONAL per-scenario OVERRIDE of the global
 * settings row (spec §9 / §2.4). In the reference model (spec §2) scenario
 * create copies nothing; a scenario without an override row falls back to the
 * seeded GLOBAL settings row (the evaluator snapshot resolves that fallback,
 * violations.js). This mount is bespoke rather than the generic
 * createCrudRoutes factory (which has no singleton semantic): GET returns the
 * scenario's override row, PUT edits it — and, race-safely, MINTS the override
 * row on first write. There is deliberately no POST and no DELETE.
 *
 * Permission mirrors every other scenario child (owner + admin via
 * SCENARIO_OWNERSHIP, spec §7) — NOT admin+editor, which is config.js's
 * global-template tier only.
 */
const express = require('express');
const { sendError } = require('../../../../shared/lib/send-error');
const { pool, t } = require('../../../db');
const {
  requireAuth, requireAdminOrEditor, apiOk, uuidv4,
} = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { mapRowsFromDb } = require('../../../lib/dto-mapper');
const { logger } = require('../../../../shared/lib/logger');
const {
  validateColumnTypes, SETTINGS_COLUMN_TYPES, validateSettingsWrite, dropAbsentColumns,
} = require('./_shared');
const { sameStoredValue } = require('../schema/write-value');

const router = express.Router();

const WRITABLE_COLUMNS = [
  'mem_cpu_ratio', 'sga_factor', 'sga_divisor', 'sga_subtract', 'util_amber_pct',
  'util_red_pct', 'overcommit_default_enabled', 'layer_defaults',
  // Per-entity-type hostname patterns (spec B5a): a whole-set override object, or
  // null to inherit the global/built-in defaults.
  'name_patterns',
  // Dense-placement layout config (post-ar2-residuals P6, Q13): a per-key
  // override object, or null to inherit the global/built-in defaults.
  'placement_layout',
];

// JSON columns are stringified for the DB driver; a null (inherited) value stays
// null so a scenario can clear its override back to inherited.
const JSON_COLUMNS = new Set(['layer_defaults', 'name_patterns', 'placement_layout']);

// Mint-fill eligibility (same defect family as the CV-CFG
// panel fix, client-side): only the NOT-NULL columns (a DDL default exists,
// so "inherit" is not a representable state) are safe to backfill from the
// global row on a partial first PUT. The three JSON columns are all
// `nullable: true` in SETTINGS_COLUMN_TYPES because NULL there means
// "inherit the global/built-in default" (see their WRITABLE_COLUMNS
// comments) — copying the global row's CURRENT value into a scenario's
// override row would materialize a point-in-time snapshot and silently
// break that inherit contract the moment the global value changes again.
// Derived from SETTINGS_COLUMN_TYPES (not hand-listed) so a future nullable
// WRITABLE_COLUMNS entry is excluded automatically.
const MINT_FILL_COLUMNS = new Set(
  WRITABLE_COLUMNS.filter((col) => !(SETTINGS_COLUMN_TYPES[col] || {}).nullable),
);

function collectWrite(body) {
  const cols = [];
  const values = [];
  for (const col of WRITABLE_COLUMNS) {
    if (!Object.prototype.hasOwnProperty.call(body, col)) continue;
    let v = body[col];
    if (JSON_COLUMNS.has(col) && v !== null && typeof v === 'object') v = JSON.stringify(v);
    cols.push(col);
    values.push(v);
  }
  return { cols, values };
}

const dbError = (req, res, err, fields) => sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields });

// GET returns the scenario's EFFECTIVE settings (config-rewrite obligation 4 /
// spec §2.4 / §9.2): the scenario's own OVERRIDE row when present (is_override
// true), else the guaranteed GLOBAL seed row as a fallback (is_override false).
// It never 404s on "no override row" — that path was the §9.1 undefined-crash
// family; the reference model guarantees a global row so the effective settings
// always resolve. A 404 is reserved for a scenario id that does not exist (a
// fallback for a non-existent scenario would mask a bad id). This keeps the FE
// queryFn's never-undefined obligation (§9.2 guard 2) satisfiable with a real
// payload rather than an empty resolve.
router.get('/scenarios/:scenarioId/settings', async (req, res) => {
  if (!requireAuth(req, res)) return;
  const scenarioId = req.params.scenarioId;
  try {
    const scen = await pool.ro.query(
      `SELECT 1 AS ok FROM \`${t(TABLES.CAP_SCENARIOS)}\` WHERE id = ?`, [scenarioId],
    );
    if (!scen.length) {
      return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
    }
    const overrideRows = await pool.ro.query(
      `SELECT * FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id = ?`, [scenarioId],
    );
    if (overrideRows.length) {
      const row = mapRowsFromDb(TABLES.CAP_SETTINGS, overrideRows)[0];
      return res.json(apiOk({ ...row, is_override: true }));
    }
    const globalRows = await pool.ro.query(
      `SELECT * FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id IS NULL LIMIT 1`,
    );
    if (!globalRows.length) {
      // The seed guarantees a global row; its absence means an un-seeded / broken
      // DB. 404 rather than fabricate constants — the FE queryFn maps it to null.
      return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'No settings available' });
    }
    const row = mapRowsFromDb(TABLES.CAP_SETTINGS, globalRows)[0];
    res.json(apiOk({ ...row, is_override: false }));
  } catch (err) {
    dbError(req, res, err, { scenarioId });
  }
});

router.put('/scenarios/:scenarioId/settings', async (req, res) => {
  // Role gate FIRST (mirrors children.js childWriteRoleGate / makeChildDelete):
  // a plain user is refused before any DB-touching guard runs, regardless of
  // ownership — editor write additionally requires owning (or a shared) scenario.
  if (!requireAdminOrEditor(req, res)) return;
  const scenarioId = req.params.scenarioId;
  // Type-check the RAW body before collectWrite's JSON stringification, so a
  // wrong-shaped value (e.g. a string where a number is expected) 400s with
  // the offending column name instead of either violating the DB column's
  // type at INSERT/UPDATE time (a 500) or silently coercing.
  const typeErr = validateColumnTypes(req.body || {}, SETTINGS_COLUMN_TYPES);
  if (typeErr) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: typeErr });
  }
  // All-or-nothing hostname-pattern validation (spec B5a) — the same whole-body
  // guard the global config route runs, so a malformed pattern set is rejected
  // 400 rather than stored on a scenario override row.
  const bodyErr = validateSettingsWrite(req.body || {});
  if (bodyErr) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: bodyErr });
  }
  const { cols, values } = collectWrite(req.body || {});
  if (!cols.length) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'No writable fields supplied' });
  }

  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();

    // Locking the scenario row here is also the cardinality guard: two
    // concurrent PUTs for the same scenario serialize on this lock, so the
    // "settings row exists?" check below can never race into a double INSERT.
    // The id comes back with the owner because the INSERT below binds it. This
    // `WHERE id = ?` resolves the scenario for any spelling of it — the column
    // is CHAR(36) under a case-folding collation — so binding the caller's
    // spelling would stamp the settings row with a value no scenario's id
    // holds. Every SQL reader would still find it and every JavaScript reader
    // would not, which is the same split the scenario-scoped child mounts
    // produced.
    const scenRows = await conn.query(
      `SELECT id, owner_id FROM \`${t(TABLES.CAP_SCENARIOS)}\` WHERE id = ? FOR UPDATE`,
      [scenarioId],
    );
    if (!scenRows.length) {
      await conn.rollback();
      return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
    }
    const ownerId = scenRows[0].owner_id;
    // collation-compare, the same question as the id above and for the same
    // reason: `owner_id` folds case, so a JavaScript `===` refuses the genuine
    // owner a scenario every `WHERE owner_id = ?` already calls theirs.
    if (req.user.role !== 'admin' && ownerId !== null
      && !(await sameStoredValue(conn, t(TABLES.CAP_SCENARIOS), 'owner_id', ownerId, req.user.id))) {
      await conn.rollback();
      return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Not allowed: you do not own this scenario' });
    }

    // Degraded-mode guard (C1): a warn-skipped name_patterns migration leaves the
    // column absent, and naming it in the write would 500 EVERY settings save.
    // Drop any column the physical table lacks so old-schema DBs keep saving.
    const { cols: writeCols, values: writeValues } = await dropAbsentColumns(
      conn, TABLES.CAP_SETTINGS, cols, values,
    );
    if (!writeCols.length) {
      // Everything the caller sent is a column this DB does not have — nothing to
      // persist. Not an error: return the current row so a new panel writing only
      // a degraded-away field on an old schema is a no-op, not a 400/500.
      const current = await conn.query(
        `SELECT * FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id = ?`, [scenarioId],
      );
      await conn.commit();
      if (current.length) return res.json(apiOk(mapRowsFromDb(TABLES.CAP_SETTINGS, current)[0]));
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'No writable fields supplied' });
    }

    const existing = await conn.query(
      `SELECT id FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id = ?`,
      [scenarioId],
    );
    if (existing.length) {
      const sets = writeCols.map((c) => `\`${c}\` = ?`).join(', ');
      await conn.query(
        `UPDATE \`${t(TABLES.CAP_SETTINGS)}\` SET ${sets} WHERE scenario_id = ?`,
        [...writeValues, scenarioId],
      );
    } else {
      // Mint-on-write hardening: a partial first PUT (e.g. only
      // `placement_layout`) used to leave
      // every OTHER writable column entirely out of the INSERT's column
      // list, so the DB filled them from the DDL default instead of the
      // seeded global row's own values — a scenario's very first override
      // silently reset every field it did not name, rather than starting
      // from the same baseline `GET` already promises the caller (this
      // route's own doc comment: "global seed fallback"). Fill every
      // caller-omitted MINT_FILL_COLUMNS column (NOT NULL, no inherit
      // semantic) from the CURRENT global row here; only fall through to
      // the DDL default (by leaving the column out of the INSERT, same as
      // before) when no global row exists — the seed guarantees one (spec
      // §2.4), so this is a defensive fallback, not the expected path. A
      // caller-omitted nullable JSON column (layer_defaults, name_patterns,
      // placement_layout) is NEVER filled here — leaving it out of the
      // INSERT lets the DDL's NULL default stand, which is exactly
      // "inherit", the same state GET already reports for a scenario with
      // no override row at all.
      const sentCols = new Set(writeCols);
      const fillCols = [];
      const fillValues = [];
      // The global-row SELECT only exists to fill
      // MINT_FILL_COLUMNS the caller left out — when the caller's own PUT
      // already named every one of them (the common full-settings-panel
      // save shape), the loop below can never produce a fillCol no matter
      // what the global row contains, so the read is pure waste on every
      // such save. Skip it in that case; `needsGlobalFill` is false exactly
      // when `sentCols` already covers all of `MINT_FILL_COLUMNS`.
      const needsGlobalFill = [...MINT_FILL_COLUMNS].some((col) => !sentCols.has(col));
      if (needsGlobalFill) {
        const globalRows = await conn.query(
          `SELECT * FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id IS NULL LIMIT 1`,
        );
        const globalRow = globalRows[0] || null;
        if (globalRow) {
          for (const col of MINT_FILL_COLUMNS) {
            if (sentCols.has(col)) continue;
            // Degraded-mode parity with dropAbsentColumns above: a column this
            // DB lacks was never selected either, so `hasOwnProperty` is false
            // and it is skipped exactly the way the caller-supplied path drops
            // it — never a KeyError, never an inserted `undefined`.
            if (!Object.prototype.hasOwnProperty.call(globalRow, col)) continue;
            let v = globalRow[col];
            // Same JSON_COLUMNS stringify collectWrite applies to a caller
            // value — the driver returns a native JSON column already parsed
            // into an object, and the INSERT below binds raw driver values.
            if (JSON_COLUMNS.has(col) && v !== null && typeof v === 'object') v = JSON.stringify(v);
            fillCols.push(col);
            fillValues.push(v);
          }
        }
      }
      const id = uuidv4();
      const allCols = ['id', 'scenario_id', ...writeCols, ...fillCols];
      const quoted = allCols.map((c) => `\`${c}\``).join(', ');
      const placeholders = allCols.map(() => '?');
      await conn.query(
        `INSERT INTO \`${t(TABLES.CAP_SETTINGS)}\` (${quoted}) VALUES (${placeholders.join(', ')})`,
        [id, scenRows[0].id, ...writeValues, ...fillValues],
      );
    }

    const rows = await conn.query(
      `SELECT * FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id = ?`,
      [scenarioId],
    );
    await conn.commit();
    res.json(apiOk(mapRowsFromDb(TABLES.CAP_SETTINGS, rows)[0]));
  } catch (err) {
    if (conn) await conn.rollback();
    dbError(req, res, err, { scenarioId });
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
