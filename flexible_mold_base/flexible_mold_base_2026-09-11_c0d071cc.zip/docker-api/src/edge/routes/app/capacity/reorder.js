/**
 * @openapi
 * /edge/app/capacity/scenarios/{scenarioId}/{entity}/reorder:
 *   put:
 *     tags: [App - Capacity]
 *     summary: Persist a drag-reorder for a scenario's Local editable table (owner+admin).
 *     description: >
 *       Phase-4 spec §6. Rewrites `order_index` for every row of the entity in
 *       the scenario to its position in `orderedIds`, in one transaction.
 *       `orderedIds` MUST be exactly the scenario's current row-id set for that
 *       entity — a partial or foreign-id list is rejected 400 rather than
 *       silently reordering a subset. For the hardware_specs catalogue the set is
 *       scoped to the scenario's LOCAL rows (scenario_id = the scenario); GLOBAL
 *       rows (scenario_id IS NULL) are never in the set, so a global id in the
 *       body fails the exact-match check (400) — global rows are read-only.
 *     parameters:
 *       - { name: scenarioId, in: path, required: true, schema: { type: string } }
 *       - { name: entity, in: path, required: true, schema: { type: string, enum: [hypervisors, vms, db_instances, local-catalogues/hardware_specs] } }
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [orderedIds]
 *             properties:
 *               orderedIds: { type: array, items: { type: string } }
 *     responses:
 *       200: { description: Reordered }
 *       400: { description: Malformed body, or orderedIds does not match the scenario's row set }
 *       403: { description: Not the scenario owner (and not admin) }
 *       404: { description: Scenario not found }
 */

/**
 * capacity/reorder.js — bulk drag-reorder persist for the phase-4 reorderable
 * Local editable tables (spec §6): Hypervisors / KVMs / DB Instances (the
 * scenario-scoped child entities) plus the scenario-LOCAL Hardware Specs
 * catalogue. It generalises the Sites reorder (sites-reorder.js) — Sites keeps
 * its own dedicated route (its `order_index` predates this rule and its route is
 * already wired + tested), this module adds the four new entities with the
 * identical request/response contract.
 *
 * Each route is registered BEFORE the generic CRUD mounts (children.js /
 * local-catalogues.js) in index.js — Express matches middleware in registration
 * order, and without this ordering the generic factory's own `PUT /:id` would
 * treat "reorder" as a row id (404, never reaching here).
 *
 * `order_index` is NOT one of these grids' tracked editable `fields`, so this
 * bypasses the generic per-row create/update/delete CRUD entirely — a bespoke
 * bulk rewrite keeps the whole reorder atomic (one transaction).
 */
const express = require('express');
const { sendError } = require('../../../../shared/lib/send-error');
const { pool, t } = require('../../../db');
const { requireAdminOrEditor, apiOk, apiError } = require('../../../../shared/helpers');
const { logger } = require('../../../../shared/lib/logger');
const { TABLES } = require('../../../../shared/constants');
const { resolveScenarioWriteAccess, safeRollback } = require('./_shared');

// Per-entity upper bound on a reorder body. The endpoint requires the COMPLETE
// current id set, so each bound MUST be >= the entity's supported row maximum or
// a legal full-size scenario could never reorder. These MIRROR wizard.js's
// per-entity maxima (MAX_HYPERVISORS / MAX_VMS / MAX_DB_INSTANCES) — kept as
// separate literals rather than a cross-file import so this route has no
// compile-time dependency on wizard.js; keep the two in step. hardware_specs has
// no wizard cap (a scenario's LOCAL specs are grid-added one at a time), so it
// gets a generous bound well above any realistic local-catalogue set.
const MAX_REORDER_ROWS = Object.freeze({
  [TABLES.CAP_HYPERVISORS]: 500,
  [TABLES.CAP_VMS]: 2000,
  [TABLES.CAP_DB_INSTANCES]: 4000,
  [TABLES.CAP_HARDWARE_SPECS]: 2000,
  // phase-6 spec §D8: Databases tab reorder. A generous bound (databases are a
  // small per-scenario set; no wizard cap governs them) — well above any
  // realistic count so a legal full-set reorder is never rejected here.
  [TABLES.CAP_DATABASES]: 2000,
});

/**
 * Build the `PUT …/reorder` handler for one entity `table` (a TABLES.* logical
 * name). `entityLabel` is used only in the 400 message. Scopes every read and
 * write to `scenario_id = :scenarioId`, so for the hardware_specs catalogue the
 * scenario's LOCAL rows are the entire set and GLOBAL rows (scenario_id NULL)
 * are structurally excluded.
 */
function makeReorderHandler(table, entityLabel) {
  const maxRows = MAX_REORDER_ROWS[table];
  return async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    const scenarioId = req.params.scenarioId;
    const { orderedIds } = req.body || {};

    if (
      !Array.isArray(orderedIds)
      || orderedIds.length === 0
      || !orderedIds.every((id) => typeof id === 'string' && id.length > 0)
    ) {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: `orderedIds must be a non-empty array of ${entityLabel} ids` });
    }
    if (orderedIds.length > maxRows) {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: `orderedIds exceeds ${maxRows} limit` });
    }
    if (new Set(orderedIds).size !== orderedIds.length) {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'orderedIds contains a duplicate id' });
    }

    let conn;
    try {
      conn = await pool.rw.getConnection();
      await conn.beginTransaction();

      const access = await resolveScenarioWriteAccess(conn, scenarioId, req.user);
      if (!access.found) {
        await safeRollback(conn);
        return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Scenario not found' });
      }
      if (!access.allowed) {
        await safeRollback(conn);
        return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Not the scenario owner' });
      }

      // Lock every one of THIS scenario's rows FOR UPDATE, then require the
      // body's id set to match EXACTLY — closes both a stale-tab drag (a row
      // deleted elsewhere mid-drag) and an attempt to smuggle a foreign
      // scenario's row id (or, for hardware_specs, a read-only GLOBAL row id)
      // into the rewrite.
      //
      // INVARIANT: acquire the row locks in ascending primary-key (`id`) order.
      // placement-apply.js writes the same cap_vms / cap_db_instances rows and
      // orders its own per-move FOR UPDATE by (table, id) (`compareMove`); an
      // unordered scan here could take this scenario's row locks in a plan-
      // dependent order and invert against that writer. Both paths also lock the
      // scenario row FOR UPDATE first (resolveScenarioWriteAccess), so same-
      // scenario writers already serialise — the explicit ORDER BY id keeps the
      // per-row lock order canonical regardless, closing any lock-order cycle on
      // the shared rows. `id` is the CHAR(36) PRIMARY KEY, so this orders by the
      // clustered index (no filesort — locks are taken in id order).
      const existing = await conn.query(
        `SELECT id FROM \`${t(table)}\` WHERE scenario_id = ? ORDER BY id FOR UPDATE`, [scenarioId],
      );
      const existingIds = new Set(existing.map((r) => r.id));
      const bodyIds = new Set(orderedIds);
      const sameSet = existingIds.size === bodyIds.size && [...existingIds].every((id) => bodyIds.has(id));
      if (!sameSet) {
        await safeRollback(conn);
        return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: `orderedIds must match this scenario's current ${entityLabel} set exactly` });
      }

      for (let i = 0; i < orderedIds.length; i += 1) {
        await conn.query(
          `UPDATE \`${t(table)}\` SET order_index = ? WHERE id = ? AND scenario_id = ?`,
          [i, orderedIds[i], scenarioId],
        );
      }

      await conn.commit();
      res.json(apiOk({ reordered: orderedIds.length }));
    } catch (err) {
      await safeRollback(conn);
      sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { scenarioId } });
    } finally {
      if (conn) conn.release();
    }
  };
}

const router = express.Router();
router.put('/scenarios/:scenarioId/hypervisors/reorder', makeReorderHandler(TABLES.CAP_HYPERVISORS, 'hypervisor'));
router.put('/scenarios/:scenarioId/vms/reorder', makeReorderHandler(TABLES.CAP_VMS, 'KVM'));
router.put('/scenarios/:scenarioId/db_instances/reorder', makeReorderHandler(TABLES.CAP_DB_INSTANCES, 'DB instance'));
router.put('/scenarios/:scenarioId/databases/reorder', makeReorderHandler(TABLES.CAP_DATABASES, 'database'));
router.put(
  '/scenarios/:scenarioId/local-catalogues/hardware_specs/reorder',
  makeReorderHandler(TABLES.CAP_HARDWARE_SPECS, 'local hardware spec'),
);

module.exports = router;
