/**
 * capacity/delete-preview.js — fail-closed delete-impact preview endpoints
 * (spec §10, item 8). Two tiers of blast-radius preview, both READ-ONLY (ro
 * pool): the FE fetches a preview BEFORE opening its confirm dialog and BLOCKS
 * the delete if the fetch fails (never degrades to a generic confirm).
 *
 *   T1  GET /scenarios/:id/delete-preview
 *       Whole-scenario blast radius: per-scoped-table row counts + a bounded
 *       list of the primary entities' names (sites/hypervisors/VMs/databases).
 *       Authz MIRRORS the scenario DELETE gate exactly (admin always; an editor
 *       only for a shared or self-owned scenario) — a non-owner editor gets 403
 *       so the preview cannot enumerate a scenario they may not delete. The
 *       names listed all belong to THIS scenario (the caller is authorized to
 *       delete it), so surfacing them leaks nothing across a scope boundary.
 *
 *   T2  GET /config/:group/:id/delete-preview
 *       Which entities reference a GLOBAL catalogue row (a delete is refused
 *       server-side while any live row references it). Returns COUNTS + kind
 *       nouns only ('a VM', 'a database', …) — deliberately NO scenario names or
 *       ids (SECURITY: a global row is cross-scope by nature; the prior
 *       cross-scenario precedent surfaces kind nouns, never foreign names/UUIDs).
 *       Admin+editor (the global-config tier).
 */
'use strict';

const express = require('express');
const { sendError } = require('../../../../shared/lib/send-error');
const { pool, t } = require('../../../db');
const { requireAdminOrEditor, apiOk, apiError } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { logger } = require('../../../../shared/lib/logger');
const {
  CONFIG_DELETE_GUARDS, SCENARIO_SCOPED_TABLES, SCENARIO_ENTITY_DISPLAY, resolveScenarioWriteAccess,
  CHILD_MOUNTS, CHILD_DELETE_BEHAVIOR, DELETE_IMPACT_DISPLAY, computeChildDeleteImpact,
} = require('./_shared');

const router = express.Router();

// The cap of names returned in a T1 preview. The exact per-kind counts are
// always accurate; the list is bounded so a huge scenario cannot balloon the
// response or the dialog ("+N more" is derived from names_total on the FE).
const NAME_LIST_CAP = 40;

// Primary named entities surfaced in the T1 affected-name list — each with its
// real display column (SCENARIO_ENTITY_DISPLAY; cap_databases uses function_name,
// not name). Local catalogue rows are config, not placement — counted, not listed.
const T1_NAMED_ENTITIES = SCENARIO_ENTITY_DISPLAY;

// T1: whole-scenario delete impact. RO pool. Authz + counted-table set both reuse
// the DELETE handler's single sources of truth (resolveScenarioWriteAccess and
// SCENARIO_SCOPED_TABLES) so the preview can never disagree with the real delete.
router.get('/scenarios/:id/delete-preview', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const id = req.params.id;
  try {
    // Same gate as DELETE /:id, RO + unlocked (a replica must not FOR UPDATE): a
    // non-owner editor is 403'd so the preview never enumerates a scenario they
    // cannot delete.
    const access = await resolveScenarioWriteAccess(pool.ro, id, req.user, { lock: false });
    if (!access.found) {
      return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
    }
    if (!access.allowed) {
      return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Not allowed: you do not own this scenario' });
    }
    // The gate helper reads owner_id only; fetch the name for the response body.
    const nameRows = await pool.ro.query(
      `SELECT name FROM \`${t(TABLES.CAP_SCENARIOS)}\` WHERE id = ?`, [id],
    );
    const name = nameRows.length ? nameRows[0].name : '';

    // Per-scoped-table counts, keyed by logical table name and derived from the
    // SAME SCENARIO_SCOPED_TABLES the DELETE iterates — so a table added to the
    // cascade automatically appears in the blast radius (no hand-list drift).
    const counts = {};
    for (const table of SCENARIO_SCOPED_TABLES) {
      const rows = await pool.ro.query(
        `SELECT COUNT(*) AS c FROM \`${t(table)}\` WHERE scenario_id = ?`, [id],
      );
      counts[String(table)] = Number(rows[0].c);
    }

    // Bounded affected-name list drawn from the primary placement entities. The
    // true total is the sum of their exact counts, so the FE "+N more" is exact.
    const namesTotal = T1_NAMED_ENTITIES.reduce((sum, e) => sum + (counts[String(e.table)] || 0), 0);
    const names = [];
    for (const { kind, table, nameCol } of T1_NAMED_ENTITIES) {
      if (names.length >= NAME_LIST_CAP) break;
      const remaining = NAME_LIST_CAP - names.length;
      // nameCol is from a frozen static config (never request-derived), so the
      // interpolated identifier is safe — value is still parameterized.
      const rows = await pool.ro.query(
        `SELECT id, \`${nameCol}\` AS name FROM \`${t(table)}\` WHERE scenario_id = ? ORDER BY \`${nameCol}\` LIMIT ?`,
        [id, remaining],
      );
      for (const r of rows) names.push({ id: r.id, name: r.name, kind });
    }

    res.json(apiOk({
      scenario: { id, name },
      counts,
      names,
      names_total: namesTotal,
    }));
  } catch (err) {
    sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { scenarioId: id } });
  }
});

// T3: per-child delete impact. RO pool, unlocked. The three confirm-dialog zones
// (will_delete / will_unplace / blocked) are derived from the SAME
// CHILD_DELETE_BEHAVIOR the DELETE executes (computeChildDeleteImpact), so the
// dialog and the delete cannot count different rows (spec §4). Authz MIRRORS the
// child DELETE gate (admin always; a non-owner editor 403). Registered ahead of
// the generic children mount (index.js): its five-segment path does not clash
// with the child factory's /:id, and the /delete-preview suffix shadows no real
// endpoint.
router.get('/scenarios/:scenarioId/:segment/:id/delete-preview', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const { scenarioId, segment, id } = req.params;
  const mount = CHILD_MOUNTS[segment];
  const behavior = CHILD_DELETE_BEHAVIOR[segment];
  if (!mount || !behavior) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'No delete-impact preview for this entity type' });
  }
  try {
    // Same gate as the child DELETE, RO + unlocked (a replica must not FOR UPDATE).
    const access = await resolveScenarioWriteAccess(pool.ro, scenarioId, req.user, { lock: false });
    if (!access.found) {
      return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
    }
    if (!access.allowed) {
      return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Not allowed: you do not own this scenario' });
    }
    // Resolve the row (stored id + display name) within THIS scenario — a 404
    // without revealing a cross-scenario row's existence, mirroring the DELETE.
    const display = DELETE_IMPACT_DISPLAY[String(mount.table)] || { nameCol: null };
    const { nameCol } = display;
    const entityRows = await pool.ro.query(
      `SELECT id${nameCol ? `, \`${nameCol}\` AS name` : ''} FROM \`${t(mount.table)}\` WHERE id = ? AND scenario_id = ?`,
      [id, scenarioId],
    );
    if (!entityRows.length) {
      return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
    }
    const storedId = entityRows[0].id;
    const name = nameCol && entityRows[0].name != null ? String(entityRows[0].name) : '';
    const zones = await computeChildDeleteImpact(pool.ro, segment, storedId, scenarioId);
    res.json(apiOk({
      entity: { segment, id: storedId, name },
      will_delete: zones.will_delete,
      will_unplace: zones.will_unplace,
      blocked: zones.blocked,
      blocked_reason: zones.blocked_reason,
    }));
  } catch (err) {
    sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { scenarioId, segment, rowId: id } });
  }
});

// T2: which entities reference a GLOBAL catalogue row. RO pool. Counts + kind
// nouns only (no scenario names/ids — SECURITY, cross-scope). Admin+editor.
router.get('/config/:group/:id/delete-preview', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const { group, id } = req.params;
  const guard = CONFIG_DELETE_GUARDS[group];
  if (!guard) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'No delete-impact preview for this catalogue group' });
  }
  try {
    const references = [];
    let total = 0;
    for (const ref of guard.refs) {
      const rows = await pool.ro.query(
        `SELECT COUNT(*) AS c FROM \`${t(ref.table)}\` WHERE \`${ref.column}\` = ?`, [id],
      );
      const count = Number(rows[0].c);
      if (count > 0) {
        references.push({ by: ref.by, count });
        total += count;
      }
    }
    res.json(apiOk({
      group,
      id,
      label: guard.label,
      references, // [{ by: 'a VM', count: 3 }, …] — kind nouns only, no names
      total,
      blocked: total > 0, // a referenced global row cannot be deleted (§ delete guard)
    }));
  } catch (err) {
    sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { group, rowId: id } });
  }
});

module.exports = router;
