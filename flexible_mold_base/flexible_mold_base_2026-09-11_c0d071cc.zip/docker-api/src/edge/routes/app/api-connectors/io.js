/**
 * io.js — cross-environment export / import for api_connectors.
 *
 *   GET  /:id/export   export a connector as portable JSON, WITHOUT secrets
 *   POST /import       import a connector from such a payload
 *
 * Secrets never travel: export strips the sensitive auth_config leaves so the
 * operator re-enters them on the target. Import binds to a local blueprint
 * only when the payload's blueprint resolves here; an admin may store an
 * "unbound" connector (blueprint_id NULL) to re-bind later, but an editor is
 * rejected (403) when no own/shared blueprint resolves — an unbound connector
 * is unmanageable through the editor CRUD ownership chain, so it would be an
 * orphan only an admin could fix. Gated to admin/editor, matching the CRUD
 * surface; export carries no secrets, so an editor may export any connector.
 */
const { pool, t } = require('../../../db');
const { sendError } = require('../../../../shared/lib/send-error');
const { apiOk, apiError, requireAdminOrEditor, uuidv4 } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { isMissingTable } = require('../schema/helpers');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { mapRowsFromDb } = require('../../../lib/dto-mapper');
const { buildHierarchyPath, findBlueprintIdsByPath } = require('../../../lib/hierarchy-path');
const { stripAuthConfigSecrets, stripStraySecretLeaves, serializeRead } = require('./serializer');
const { declaredAuthTypeOr } = require('../../../lib/auth-config-secrets');
const {
  validateInputFromStep, validateResponseOutputs, validateInputCells, validateConnectorCoherence,
  loadFollowerColumnKeys, validateNoFollowerColumnTarget,
} = require('./validate');
// sameStoredId (case/whitespace-insensitive id compare) for the editor
// home-import ownership check below.
const { sameStoredId } = require('../../../lib/connector-binding-keys');
const { callerHasBlueprintGrant } = require('../../../lib/delegated-grants');
// The ONE binding-target decision (existence + node_type + authority +
// completeness + follower) — an imported extra binding is held to the exact
// rules the bindings PUT and the bundle-join guard enforce, so an import can
// never create a binding state those paths would have refused. A failure drops
// just that target (with the function's code/dropReason) rather than failing
// the whole import.
const { assertBindingTargets } = require('../../../lib/connector-binding-authority');
const { egressAllowedForUrl } = require('../../../../shared/lib/egress-policy');
// SECURITY: a connector url is dispatched outbound in P2; the shared guard pins it
// to an absolute http(s) URL with NO embedded credentials at the storage boundary,
// and sanitizes any pre-existing userinfo out of the exported bundle. One
// definition shared with the flow io + the CRUD url guards.
const {
  isStorableHttpUrl, sanitizeUrlForExport, redactRequestConfigHeaders,
  resolveMaskedRequestConfigHeaders,
} = require('../../../../shared/lib/portable-url-redaction');
// SAME source_kind/source_config rules the CRUD write guard uses (index.js) —
// import validates its own payload (it is excluded from that guard's route
// scope), but through this one definition, never a second copy.
const { validateSourceConfig, normalizeForSourceKind, probeSourceColumns, SOURCE_KINDS } = require('./source-config');
const { parseJsonColumn } = require('../../../../shared/serializers/parse-json-column');

const logger = rootLogger.child({ module: 'api-connectors:io' });

const MAX_NAME = 255;

module.exports = function register(router) {
  // GET /:id/export — portable JSON, secrets stripped.
  router.get('/:id/export', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    let conn;
    try {
      conn = await pool.ro.getConnection();
      const rows = await conn.query(
        `SELECT name, description, is_active, blueprint_id, method, url,
                auth_type, auth_config, request_config, response_config,
                dispatch_origin,
                group_id, group_label, group_mode, \`sequence\`
         FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`,
        [req.params.id],
      );
      if (!rows.length) {
        return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Connector not found' });
      }
      const row = rows[0];
      // Tolerant per-connector timeout probe: a separate query so the main export
      // SELECT never names timeout_ms (a no-ALTER source lacking the column would
      // 500). Absent column → omit (null) and the import keeps the default.
      let timeoutMs = null;
      try {
        const tr = await conn.query(
          `SELECT timeout_ms FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`,
          [req.params.id],
        );
        timeoutMs = tr[0]?.timeout_ms ?? null;
      } catch (probeErr) {
        timeoutMs = null;
        // Unknown column on a no-ALTER source is expected; anything else (pool
        // drop, transient) is worth a breadcrumb since the export silently omits.
        if (!(probeErr?.code === 'ER_BAD_FIELD_ERROR' || probeErr?.errno === 1054)) {
          req.log.warn({ err: probeErr, connectorId: req.params.id }, 'timeout_ms export probe failed');
        }
      }
      // Tolerant per-connector source-kind/config probe: a separate query so
      // the main export SELECT never names source_kind/source_config (a
      // no-ALTER source lacking the columns would 500 every export, not just a
      // non-http one). Absent → export as 'http'/null, matching the
      // grandfathered-row read posture everywhere else (D-F5).
      let sourceKind = 'http';
      let sourceConfig = null;
      try {
        const sr = await conn.query(
          `SELECT source_kind, source_config FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`,
          [req.params.id],
        );
        if (sr.length) {
          sourceKind = sr[0].source_kind || 'http';
          sourceConfig = parseJsonColumn(sr[0].source_config);
        }
      } catch (probeErr) {
        sourceKind = 'http';
        sourceConfig = null;
        if (!(probeErr?.code === 'ER_BAD_FIELD_ERROR' || probeErr?.errno === 1054)) {
          req.log.warn({ err: probeErr, connectorId: req.params.id }, 'source_kind/source_config export probe failed');
        }
      }
      // The connector's "also usable in" extra bindings. Tolerant of
      // a missing join table (its migration is severity 'warning') — export
      // degrades to bindings: [] rather than failing.
      let extraBlueprintIds = [];
      try {
        const joinRows = await conn.query(
          `SELECT blueprint_id FROM \`${t(TABLES.API_CONNECTOR_BLUEPRINTS)}\` WHERE connector_id = ?`,
          [req.params.id],
        );
        extraBlueprintIds = joinRows.map((r) => r.blueprint_id);
      } catch (probeErr) {
        extraBlueprintIds = [];
        if (!isMissingTable(probeErr)) {
          req.log.warn({ err: probeErr, connectorId: req.params.id }, 'connector bindings export probe failed');
        }
      }
      // Carry the blueprint's root→self lineage as a natural key. blueprint_id
      // is environment-local (fresh UUIDs on import), so import re-binds by
      // this name path; blueprint_id stays only as a legacy fallback. Extra
      // bindings carry the SAME natural key, for the same reason.
      let blueprintPath = null;
      let bindings = [];
      if (row.blueprint_id || extraBlueprintIds.length) {
        const nodes = await conn.query(
          `SELECT id, parent_id, name FROM \`${t(TABLES.HIERARCHY_NODES)}\``,
        );
        if (row.blueprint_id) {
          const p = buildHierarchyPath(nodes, row.blueprint_id);
          if (p.length) blueprintPath = p;
        }
        bindings = extraBlueprintIds.map((id) => {
          const p = buildHierarchyPath(nodes, id);
          return { blueprint_id: id, blueprint_path: p.length ? p : null };
        });
      }
      const exported = {
        name: row.name,
        description: row.description,
        is_active: row.is_active === 1 || row.is_active === true,
        blueprint_id: row.blueprint_id,
        blueprint_path: blueprintPath,
        bindings,
        source_kind: sourceKind,
        source_config: sourceConfig,
        method: row.method,
        // SECURITY: strip any URL-embedded credentials a legacy row may carry.
        url: sanitizeUrlForExport(row.url),
        auth_type: row.auth_type,
        // SECURITY: stray-leaf strip (a stale secret from a since-changed auth_type)
        // before the sanctioned-leaf strip, so no secret survives even on a row that
        // predates the write-path stray-leaf cleanup.
        auth_config: stripAuthConfigSecrets(
          stripStraySecretLeaves(parseJsonColumn(row.auth_config) || {}, row.auth_type),
          row.auth_type,
        ),
        // SECURITY: blank credential-valued headers (Authorization / api-key) typed
        // literally into request_config.headers — export must carry no secret.
        request_config: redactRequestConfigHeaders(parseJsonColumn(row.request_config)),
        response_config: parseJsonColumn(row.response_config),
        group_id: row.group_id ?? null,
        group_label: row.group_label ?? null,
        group_mode: row.group_mode ?? null,
        sequence: row.sequence ?? null,
        timeout_ms: timeoutMs,
        exported_at: new Date().toISOString(),
      };
      res.json(apiOk(exported));
    } catch (err) {
      sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { connectorId: req.params.id } });
    } finally {
      if (conn) conn.release();
    }
  });

  // POST /import — create a connector from a portable payload.
  router.post('/import', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    const { connector } = req.body || {};
    if (!connector || !connector.name) {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'Invalid import data: name is required' });
    }
    if (typeof connector.name !== 'string' || connector.name.length > MAX_NAME) {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: `name must be a string ≤ ${MAX_NAME} characters` });
    }
    // A template/static source is normalised to url='' (no upstream to
    // dispatch to) — the url requirement and the absolute-http(s) shape guard
    // apply to an http source only. ABSENT (undefined) or explicit `null`
    // source_kind both default to 'http' — a round-tripped export of a
    // grandfathered http row serialises the column as JSON `null`, not an
    // omitted key, so the two must coalesce the same way (R-C6). Any other
    // supplied value is validated as-is: a hand-edited export naming an
    // unsupported kind must 400, not silently coerce to http and discard the
    // caller's source_config, exactly as the CRUD write guard (index.js)
    // treats the same column — SOURCE_KINDS is the one validator both read.
    const importedKind = connector.source_kind == null ? 'http' : connector.source_kind;
    if (!SOURCE_KINDS.includes(importedKind)) {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: `source_kind must be one of ${SOURCE_KINDS.join(', ')}` });
    }
    if (importedKind === 'http') {
      if (!connector.url) {
        return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'Invalid import data: name and url are required' });
      }
      if (!isStorableHttpUrl(connector.url)) {
        return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'url must be an absolute http(s) URL' });
      }
    }

    const id = uuidv4();
    const ownerId = req.user?.id || null;
    let conn;
    try {
      conn = await pool.rw.getConnection();

      // SECURITY: save-time mirror of the dispatch-time egress allow-list gate.
      // The blanket CRUD save guard skips /import (it validates its own payload),
      // so enforce the egress gate here too — an off-list import gets a fast 422 at
      // save instead of a silent EGRESS_BLOCKED only when later dispatched.
      // Empty/absent list = allow-all; a corrupt list THROWS → outer catch → 500
      // (fail-closed, never allow-all). Dispatch-time gate remains the backstop.
      // Applies to an http source only — a template/static source never
      // dispatches outbound, so there is no url to check against the allow-list.
      if (importedKind === 'http') {
        const egress = await egressAllowedForUrl(connector.url, connector.method || 'GET', (sql, params) => pool.ro.query(sql, params), t);
        if (!egress.ok) {
          return sendError(req, res, null, { status: 422, code: 'EGRESS_BLOCKED', reason: 'Connector request is not on the admin egress allow-list' });
        }
      }

      // Same columns-exist probe the CRUD write guard uses (source-config.js),
      // one definition. Run for every import (not only a non-http one) — the
      // core INSERT below names source_kind/source_config in the SAME
      // statement precisely when this says they exist, so the decision has to
      // be made before that statement is built, regardless of kind.
      const columnsExist = await probeSourceColumns(conn, t);
      // Fail closed on a no-DDL target rather than silently landing an http
      // row for a declared non-http source.
      if (importedKind !== 'http' && !columnsExist) {
        return sendError(req, res, null, { status: 409, code: 'SOURCE_KIND_UNAVAILABLE', reason: 'Template and static sources are unavailable until the schema migration is applied.' });
      }
      const importedSourceConfigRaw = parseJsonColumn(connector.source_config);
      // SAME validator the CRUD write guard uses. A template's blueprint_id
      // must resolve on THIS target (a fresh-UUID import can miss it) — refused
      // rather than dropped, since an unresolved source leaves the connector
      // unusable (unlike an optional extra binding, which is fine to drop).
      const sourceMsg = await validateSourceConfig(conn, t, importedKind, importedSourceConfigRaw);
      if (sourceMsg) {
        const isBlueprintUnknown = importedKind === 'template'
          && sourceMsg === 'source_config.blueprint_id does not name a known blueprint';
        return sendError(req, res, null, { status: 400, code: isBlueprintUnknown ? 'SOURCE_BLUEPRINT_UNKNOWN' : 'BAD_REQUEST', reason: sourceMsg });
      }

      // Re-bind by the blueprint's lineage (name path), which survives the
      // fresh-UUID import that breaks a raw id match across environments. A
      // unique path match binds; 0 or >1 matches stay unbound for the operator
      // to bind manually. A payload without a path (legacy export) falls back
      // to the old id-existence check.
      // Validate the payload-supplied path: non-empty array of strings, depth
      // capped well above the 4-tier hierarchy so a crafted huge array can't
      // drive an O(nodes × len) scan.
      const blueprintPath = Array.isArray(connector.blueprint_path)
        && connector.blueprint_path.length > 0
        && connector.blueprint_path.length <= 32
        && connector.blueprint_path.every((s) => typeof s === 'string')
        ? connector.blueprint_path : null;
      const wantedBinding = !!blueprintPath || !!connector.blueprint_id;
      // An exported "also usable in" entry carries the SAME
      // lineage-path natural key as the home blueprint. Same validation shape
      // (non-empty array of strings, depth-capped) applied per entry below.
      // Cap the imported extra-binding list (same order-of-magnitude bound as
      // blueprint_path's depth cap) so a crafted payload cannot drive an
      // unbounded per-entry resolve+probe loop; extras beyond the cap are
      // reported in dropped_bindings (BINDING_CAP_EXCEEDED), matching import's
      // never-fail posture — never silently discarded.
      const allBindings = Array.isArray(connector.bindings) ? connector.bindings : [];
      const rawBindings = allBindings.slice(0, 32);
      const validPathShape = (p) => Array.isArray(p) && p.length > 0 && p.length <= 32
        && p.every((s) => typeof s === 'string');
      const overflowBindings = allBindings.slice(32).map((entry) => ({
        blueprint_id: typeof entry?.blueprint_id === 'string' ? entry.blueprint_id : null,
        blueprint_path: validPathShape(entry?.blueprint_path) ? entry.blueprint_path : null,
        reason: 'BINDING_CAP_EXCEEDED',
      }));

      // One hierarchy read shared by the home resolution and every binding
      // entry below (path resolution never mutates the DB, so one snapshot is
      // fine for all of them).
      let nodes = null;
      if (blueprintPath || rawBindings.some((e) => validPathShape(e?.blueprint_path))) {
        nodes = await conn.query(
          `SELECT id, parent_id, name, node_type FROM \`${t(TABLES.HIERARCHY_NODES)}\``,
        );
      }

      let blueprintId = null;
      if (blueprintPath) {
        const matches = findBlueprintIdsByPath(nodes, blueprintPath);
        if (matches.length === 1) blueprintId = matches[0];
      } else if (connector.blueprint_id) {
        const bp = await conn.query(
          `SELECT 1 FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ? LIMIT 1`,
          [connector.blueprint_id],
        );
        if (bp.length) blueprintId = connector.blueprint_id;
      }

      // Parsed once: the shape-validation and INSERT further down reuse them,
      // and each is the config assertBindingTargets judges a resolved extra
      // against.
      const parsedRequestConfig = parseJsonColumn(connector.request_config);
      const parsedResponseConfig = parseJsonColumn(connector.response_config);

      // Resolve each exported extra binding the same two-step way (unique
      // path match, falling back to a raw id match); a path that matches 0 or
      // >1 local blueprints yields no candidate and is reported in the import
      // summary without a reason (it is drift, not a rule violation), never a
      // reason to fail the whole import. A candidate that DOES resolve is run
      // through the ONE binding-target decision (assertBindingTargets) — the
      // exact existence + node_type + authority + completeness + follower rules
      // the bindings PUT and the bundle-join guard enforce — so an import can
      // never create a binding state those paths would have refused; a failure
      // drops just that binding, with the decision's code (or dropReason) as the
      // summary reason, rather than failing the whole import.
      const bindingConnector = { id, request_config: parsedRequestConfig, response_config: parsedResponseConfig };
      const droppedBindings = [...overflowBindings];
      const resolvedBindingIds = [];
      const seenBindingIds = new Set();
      for (const entry of rawBindings) {
        const entryPath = validPathShape(entry?.blueprint_path) ? entry.blueprint_path : null;
        const entryId = typeof entry?.blueprint_id === 'string' ? entry.blueprint_id : null;
        // Extras presuppose a home. When no home resolved on this target (an
        // admin's unbound import), every extra is dropped rather than stored
        // against a NULL home — the same rule the bindings PUT enforces
        // (BINDING_HOME_BLUEPRINT), so an import can never create a binding
        // state that route would refuse.
        if (!blueprintId) {
          droppedBindings.push({ blueprint_id: entryId, blueprint_path: entryPath, reason: 'BINDING_HOME_BLUEPRINT' });
          continue;
        }
        // A candidate id: a unique local path match, or the raw id (whose
        // existence + node_type='blueprint' assertBindingTargets then judges —
        // a non-existent or non-blueprint id becomes BINDING_BLUEPRINT_UNKNOWN
        // there, not a second node_type probe here).
        let candidateId = null;
        if (entryPath) {
          const matches = findBlueprintIdsByPath(nodes, entryPath);
          if (matches.length === 1) candidateId = matches[0];
        } else if (entryId) {
          candidateId = entryId;
        }
        // No candidate (unresolvable path), the home itself, or an already-seen
        // extra → reported without a reason (resolution drift / dedup), never a
        // rule violation.
        if (!candidateId || candidateId === blueprintId || seenBindingIds.has(candidateId)) {
          droppedBindings.push({ blueprint_id: entryId, blueprint_path: entryPath });
          continue;
        }

        const failure = await assertBindingTargets({
          req, connector: bindingConnector, targetIds: [candidateId], conn,
        });
        if (failure) {
          // Preserve each reason's existing summary shape: UNKNOWN carries the
          // resolution context (blueprint_path); the config/authority reasons do
          // not; FIELD_KEYS carries the missing list.
          const drop = { blueprint_id: candidateId, reason: failure.dropReason || failure.code };
          if (failure.code === 'BINDING_BLUEPRINT_UNKNOWN') drop.blueprint_path = entryPath;
          if (failure.details && Array.isArray(failure.details.missing)) drop.missing = failure.details.missing;
          droppedBindings.push(drop);
          continue;
        }

        seenBindingIds.add(candidateId);
        resolvedBindingIds.push(candidateId);
      }

      // An editor must never create a connector they cannot later manage. CRUD
      // create rejects an editor's null/foreign blueprint (checkParentOwnership),
      // and an unbound connector fails the editor PUT/DELETE ownership-chain
      // EXISTS predicate — so an unbound import would be an orphan only an admin
      // could fix. Reject for editors; admins may keep an unbound connector.
      if (req.user?.role !== 'admin') {
        let ownOrShared = false;
        if (blueprintId) {
          const own = await conn.query(
            `SELECT owner_id FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ?`,
            [blueprintId],
          );
          const bpOwner = own.length ? own[0].owner_id : undefined;
          // Fold case exactly as the per-extra check above and the bindings PUT
          // do: ids collate case-insensitively, so a byte compare here would
          // refuse a home a same-user PUT would keep.
          ownOrShared = own.length > 0 && (bpOwner == null || sameStoredId(bpOwner, req.user?.id));
          // spec §6.1: import CREATES a connector homed on this
          // blueprint — the same rule as CRUD create, which now admits a
          // blueprint-scope grantee (api_connectors sets blueprintGrantScope).
          // this gate was previously "by design" owner-only; under the 2026-09-04
          // ruling it flips. Reuse the shared resolver rather than a second
          // grant EXISTS. Skipped when already owned/shared.
          if (!ownOrShared && own.length > 0 && bpOwner != null && req.user?.id) {
            ownOrShared = await callerHasBlueprintGrant(conn, req.user.id, blueprintId, req.user.role);
          }
        }
        if (!ownOrShared) {
          return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'An editor can only import a connector bound to a blueprint they own, hold a grant on, or that is shared' });
        }
      }

      // The member list is the COLUMN's, asked of the DDL — the literal array
      // this replaced was a third copy of it, and a copy is what stops being
      // updated. The degrade-to-'none' posture is kept on purpose: a hand-edited
      // bundle should import rather than fail, and an import stores no secret
      // leaf under any type.
      const authType = declaredAuthTypeOr(TABLES.API_CONNECTORS, connector.auth_type);
      // The payload carries no secrets (export stripped them); a hand-edited bundle
      // could still inject a stray-type leaf, so strip stray leaves AND the sanctioned
      // leaf before storing — no secret is ever persisted from import.
      const authConfig = stripAuthConfigSecrets(
        stripStraySecretLeaves(parseJsonColumn(connector.auth_config) || {}, authType),
        authType,
      );
      // ONE definition of the http/non-http column split (source-config.js),
      // applied to the already-clamped values above. For importedKind==='http'
      // this is a pass-through (no-op); for template/static it forces the
      // inert url/method/auth/dispatch_origin values, same as a CRUD write.
      const normalized = normalizeForSourceKind({
        source_kind: importedKind,
        source_config: importedSourceConfigRaw,
        url: connector.url,
        method: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'].includes(connector.method) ? connector.method : 'GET',
        auth_type: authType,
        auth_config: authConfig,
        dispatch_origin: ['infra', 'edge'].includes(connector.dispatch_origin) ? connector.dispatch_origin : 'infra',
      });

      const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
      // Import degrades malformed bundle metadata to ungrouped instead of 400ing:
      // a hand-edited payload should not fail the whole import, and orphan
      // label/mode/sequence must never be stored without their group_id.
      const groupValid = typeof connector.group_id === 'string' && UUID_RE.test(connector.group_id)
        && (connector.group_mode === 'aggregation' || connector.group_mode === 'chain')
        && Number.isInteger(connector.sequence) && connector.sequence >= 1;
      const groupFields = groupValid
        ? {
            group_id: connector.group_id,
            group_label: typeof connector.group_label === 'string' ? connector.group_label.slice(0, 255) : null,
            group_mode: connector.group_mode,
            sequence: connector.sequence,
          }
        : { group_id: null, group_label: null, group_mode: null, sequence: null };

      // A hand-edited import payload is held to the same chain-wiring shape as a
      // CRUD write. Validate against the effective stored sequence, not the raw
      // payload value: when malformed group metadata degrades to ungrouped the
      // stored sequence becomes null, so chain wiring that referenced a numeric
      // payload sequence must be rejected — otherwise input_from_step survives
      // with a null sequence and surfaces as a confusing runtime chain break.
      // (parsedRequestConfig / parsedResponseConfig are hoisted above the
      // binding-resolution loop — the per-binding completeness re-check needs
      // them too.)
      // Q9 (D2 amendment A4): held to the same follower-column guard as a CRUD
      // write. `blueprintId` is null for an unbound import (0/>1 path matches,
      // or no path/id at all) — nothing to judge outputs against, so the guard
      // is a no-op exactly like the CRUD twin's own unbound-connector branch.
      const followerColumnKeys = await loadFollowerColumnKeys(conn, t, blueprintId);
      const shapeError = validateInputFromStep(parsedRequestConfig, groupFields.sequence)
        || validateInputCells(parsedRequestConfig)
        || validateResponseOutputs(parsedResponseConfig)
        || validateConnectorCoherence(parsedRequestConfig, parsedResponseConfig)
        || validateNoFollowerColumnTarget(parsedResponseConfig, followerColumnKeys);
      if (shapeError) {
        return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: shapeError });
      }

      // source_kind/source_config are additive columns. Named in the SAME
      // INSERT statement as the rest of the row (one write, atomic) exactly
      // when columnsExist says the physical columns are there — never as a
      // separate follow-up UPDATE, which would leave a partial row (source_kind
      // still the DEFAULT 'http', url already normalised to '') behind an
      // autocommitted INSERT if the second statement failed. When the columns
      // are absent (no-ALTER target), they are left out entirely — the
      // no-DDL http import path is unchanged, and a non-http import already
      // 409s above before reaching here.
      const sourceColumnsSql = columnsExist ? ', source_kind, source_config' : '';
      const sourceValuesSql = columnsExist ? ', ?, ?' : '';
      const sourceParams = columnsExist
        ? [normalized.source_kind, normalized.source_config ? JSON.stringify(normalized.source_config) : null]
        : [];

      // Task 8 back-compat: an incoming payload from an older export that still
      // carries `allowed_hosts` is ignored silently (dropped on read) — the column
      // is gone, and a hand-edited/legacy bundle must still import cleanly.
      await conn.query(
        `INSERT INTO \`${t(TABLES.API_CONNECTORS)}\`
         (id, name, description, is_active, owner_id, blueprint_id,
          method, url, auth_type, auth_config, request_config, response_config,
          dispatch_origin,
          group_id, group_label, group_mode, \`sequence\`${sourceColumnsSql})
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?${sourceValuesSql})`,
        [
          id,
          connector.name,
          connector.description || null,
          connector.is_active === false ? 0 : 1,
          ownerId,
          blueprintId,
          normalized.method,
          normalized.url,
          normalized.auth_type,
          JSON.stringify(normalized.auth_config),
          // THE SENTINEL IS NEVER A CREDENTIAL, ON THIS VERB EITHER. An import is
          // a create, and a bundle carrying `"Authorization":"****"` stored the
          // four literal characters as the header a request is dispatched with —
          // the same shape the create path had for `auth_config`. There is no
          // stored row behind an import, so the resolution takes its safe arm and
          // drops the key. A genuine export/re-import round trip never carries
          // the sentinel (export blanks these to `''`), so this only bites a
          // hand-built bundle — which is exactly the input this path accepts.
          connector.request_config
            ? JSON.stringify(resolveMaskedRequestConfigHeaders(
              parseJsonColumn(connector.request_config), null,
            ))
            : null,
          connector.response_config ? JSON.stringify(parseJsonColumn(connector.response_config)) : null,
          normalized.dispatch_origin,
          groupFields.group_id,
          groupFields.group_label,
          groupFields.group_mode,
          groupFields.sequence,
          ...sourceParams,
        ],
      );

      // SECURITY: an import is a create path, so it must obey the approval
      // lifecycle — without this an editor could import a connector that lands
      // with NULL status (= grandfathered = dispatches immediately), bypassing
      // review. Stamped as a separate best-effort UPDATE (not folded into the
      // core INSERT) so a no-ALTER DB lacking the column degrades to NULL =
      // approved rather than failing the whole import. admin → approved; editor
      // → pending. The dispatch gate is the backstop regardless.
      try {
        if (req.user?.role === 'admin') {
          await conn.query(
            `UPDATE \`${t(TABLES.API_CONNECTORS)}\` SET status='approved', approved_by=?, approved_at=NOW() WHERE id = ?`,
            [ownerId, id],
          );
        } else {
          await conn.query(
            `UPDATE \`${t(TABLES.API_CONNECTORS)}\` SET status='pending' WHERE id = ?`,
            [id],
          );
        }
      } catch (stampErr) {
        if (!(stampErr?.code === 'ER_BAD_FIELD_ERROR' || stampErr?.errno === 1054)) throw stampErr;
      }

      // Best-effort timeout_ms carry: apply the exported per-connector timeout
      // when present and in range (1000–120000ms). Separate best-effort UPDATE so
      // a no-ALTER target lacking the column degrades to the default; an absent or
      // out-of-range value is ignored so the INSERT default stands.
      const importTimeout = connector.timeout_ms;
      if (Number.isInteger(importTimeout) && importTimeout >= 1000 && importTimeout <= 120000) {
        try {
          await conn.query(
            `UPDATE \`${t(TABLES.API_CONNECTORS)}\` SET timeout_ms = ? WHERE id = ?`,
            [importTimeout, id],
          );
        } catch (toErr) {
          if (!(toErr?.code === 'ER_BAD_FIELD_ERROR' || toErr?.errno === 1054)) throw toErr;
        }
      }

      // Best-effort join-row insert for every resolved extra binding. A
      // no-DDL target lacking the additive join table degrades to "every
      // resolved binding dropped" rather than failing the import; any OTHER
      // insert failure still surfaces (fail-closed on an unverifiable state).
      if (resolvedBindingIds.length > 0) {
        try {
          for (const extraId of resolvedBindingIds) {
            await conn.query(
              `INSERT INTO \`${t(TABLES.API_CONNECTOR_BLUEPRINTS)}\` (id, connector_id, blueprint_id) VALUES (?, ?, ?)`,
              [uuidv4(), id, extraId],
            );
          }
        } catch (bindErr) {
          if (!isMissingTable(bindErr)) throw bindErr;
          for (const extraId of resolvedBindingIds) droppedBindings.push({ blueprint_id: extraId, blueprint_path: null });
          resolvedBindingIds.length = 0;
        }
      }

      const rows = await conn.query(
        `SELECT * FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`, [id],
      );
      // Shape the row like the CRUD read path (parse JSON columns, coerce
      // booleans) and mask any secret leaf before returning.
      const shaped = serializeRead(mapRowsFromDb('api_connectors', rows)[0]);
      res.status(201).json(apiOk({
        ...shaped,
        unbound: blueprintId === null && wantedBinding,
        bindings: [...resolvedBindingIds].sort(),
        dropped_bindings: droppedBindings,
      }));
    } catch (err) {
      sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { name: connector.name } });
    } finally {
      if (conn) conn.release();
    }
  });
};
