'use strict';
// probe-exempt: validateSourceConfig's own SQL never names api_connectors.source_kind
// or source_config (its two queries read hierarchy_nodes.id and blueprint_fields.field_key)
// — the degraded-schema census flags this file anyway because the error-message prose
// below says "select" (the source_config.select field name), which collides
// case-insensitively with the SQL SELECT keyword the census matcher looks for.
// probeSourceColumns() below IS a real source_kind/source_config probe (the write-path
// guard's columns-exist check) and carries its own ER_BAD_FIELD_ERROR/errno-1054
// fallback directly, same posture as index.js's stored-row probe and
// internal/connectors.js's CONNECTOR_SELECT.
const { STATIC_BODY_MAX_BYTES } = require('../../../../shared/connector-source-limits');
const { TABLES } = require('../../../../shared/constants');

const SOURCE_KINDS = ['http', 'template', 'static'];
const PARTS = ['inputs', 'outputs'];

function byteLength(s) {
  return Buffer.byteLength(String(s), 'utf8');
}

/**
 * Force the http-only columns to their inert values for a non-http connector,
 * and clear source_config for an http one. INVARIANT: a template/static row
 * stores url='' and never dispatches, so its method/auth/dispatch_origin must
 * not read as a live outbound config — the approval and egress gates key off
 * those columns. Symmetrically, an http row's source_config must not keep a
 * stale template/static config around after the kind switches back to http.
 * R6-D2: request_config is the same shape of leak — a template/static row has
 * no Request section in the editor to author or clear it, so a stale http
 * request template (headers/body carrying {{var}} tokens) from before a kind
 * switch would keep being scanned by the /usable input-derivation. Defence
 * in depth alongside the editor's own null (buildPayload): whatever the
 * caller sends is overwritten here regardless.
 */
function normalizeForSourceKind(body) {
  if (!body || typeof body !== 'object') return body;
  const kind = body.source_kind;
  if (kind === 'http') return { ...body, source_config: null };
  if (kind !== 'template' && kind !== 'static') return body;
  return {
    ...body,
    url: '',
    method: 'GET',
    auth_type: 'none',
    auth_config: {},
    dispatch_origin: 'edge',
    request_config: null,
  };
}

/**
 * Confirms the two schema-additive columns physically exist on this
 * database's api_connectors table. LIMIT 0 never touches a row — this is a
 * schema probe, not a data read. Same ER_BAD_FIELD_ERROR/1054 degradation
 * posture as every other optional-column probe in this feature (index.js's
 * stored-row load, internal/connectors.js's ADDITIVE_COLS fallback).
 */
async function probeSourceColumns(conn, t) {
  try {
    await conn.query(`SELECT source_kind, source_config FROM \`${t(TABLES.API_CONNECTORS)}\` LIMIT 0`);
    return true;
  } catch (err) {
    if (err?.code === 'ER_BAD_FIELD_ERROR' || err?.errno === 1054) return false;
    throw err;
  }
}

function validateTemplateConfig(cfg) {
  if (!cfg || typeof cfg !== 'object') return 'source_config is required for a template source';
  if (typeof cfg.blueprint_id !== 'string' || !cfg.blueprint_id) return 'source_config.blueprint_id is required';
  if (cfg.mode !== 'one' && cfg.mode !== 'list') return "source_config.mode must be 'one' or 'list'";
  if (!Array.isArray(cfg.parts) || cfg.parts.length === 0) return 'source_config.parts must be a non-empty array';
  for (const p of cfg.parts) if (!PARTS.includes(p)) return `source_config.parts contains an unknown value '${p}'`;
  if (cfg.select !== undefined) {
    if (cfg.mode !== 'one') return 'source_config.select does not apply to mode "list" (pick/match apply only to mode "one")';
    const s = cfg.select;
    if (!s || typeof s !== 'object') return 'source_config.select is malformed';
    if (s.kind === 'pick') { /* ok, no extra shape */ }
    else if (s.kind === 'match') {
      if (typeof s.value !== 'string') return 'source_config.select.value must be a string';
      if (s.field !== 'name' && !(s.field && typeof s.field === 'object' && typeof s.field.field_key === 'string')) {
        return "source_config.select.field must be 'name' or { field_key }";
      }
    } else return "source_config.select.kind must be 'pick' or 'match'";
  }
  return null;
}

/**
 * @returns {Promise<string|null>} an English message when invalid, else null.
 * `conn` is a live pool connection (the caller resolves the rw pool); the two
 * existence checks below are the reason this validator is async.
 */
async function validateSourceConfig(conn, t, sourceKind, sourceConfig) {
  if (!SOURCE_KINDS.includes(sourceKind)) return `source_kind must be one of ${SOURCE_KINDS.join(', ')}`;
  if (sourceKind === 'http') return null; // source_config ignored for http

  if (sourceKind === 'static') {
    const cfg = sourceConfig;
    if (!cfg || typeof cfg.body !== 'string') return 'source_config.body is required for a static source';
    if (byteLength(cfg.body) > STATIC_BODY_MAX_BYTES) return `source_config.body exceeds the ${STATIC_BODY_MAX_BYTES / 1024} KB limit`;
    try { JSON.parse(cfg.body); } catch { return 'source_config.body must be valid JSON'; }
    return null;
  }

  // template
  const shapeError = validateTemplateConfig(sourceConfig);
  if (shapeError) return shapeError;
  const bpRows = await conn.query(
    `SELECT id FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ? LIMIT 1`,
    [sourceConfig.blueprint_id],
  );
  if (!bpRows.length) return 'source_config.blueprint_id does not name a known blueprint';
  const sel = sourceConfig.select;
  if (sel && sel.kind === 'match' && typeof sel.field === 'object') {
    const fkRows = await conn.query(
      `SELECT field_key FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\` WHERE blueprint_id = ? AND field_key = ? LIMIT 1`,
      [sourceConfig.blueprint_id, sel.field.field_key],
    );
    if (!fkRows.length) return `source_config.select.field.field_key '${sel.field.field_key}' is not a field of the source blueprint`;
  }
  return null;
}

/**
 * The one place a template mode-one connector's default select strategy is
 * decided. `select` omitted means "let the caller pick" — resolveTemplateSource
 * (template-source.js) and the /usable projection (usable.js) each used to
 * hand-copy that default inline, and one copy read the omitted case as "no
 * template selection at all", sending the fetch UI down the wrong branch
 * (R-C5). Both now call this instead of re-deriving it.
 * @returns {'pick'|'match'|null} the stored select.kind for a template
 * mode-one config, 'pick' when select is omitted (the documented default),
 * or null for mode 'list', a non-template kind, or a malformed config.
 */
function effectiveSelectKind(sourceKind, sourceConfig) {
  if (sourceKind !== 'template') return null;
  if (!sourceConfig || typeof sourceConfig !== 'object') return null;
  if (sourceConfig.mode !== 'one') return null;
  const sel = sourceConfig.select;
  if (sel === undefined) return 'pick';
  if (!sel || typeof sel !== 'object') return null;
  return sel.kind ?? null;
}

module.exports = {
  validateSourceConfig, normalizeForSourceKind, probeSourceColumns, SOURCE_KINDS, effectiveSelectKind,
};
