/**
 * health.js — GET /health — admin/editor, live-derived health of every
 * connector for the connectors-list status column. Cross-blueprint: one IN
 * query for the bound blueprints' field keys and one for the bound
 * transformers' declared output keys, then the shared derivation per connector.
 *
 * Mirrors the schema-status visibility-surface contract: admin/editor, not
 * cached, hard per-query timeout, and a derive failure degrades to an empty
 * statuses map (HTTP 200) rather than a 5xx — the calling list UI keeps working
 * and renders an "unknown" icon for any connector absent from the map.
 */
const { pool, t } = require('../../../db');
const { apiOk, requireAdminOrEditor } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { isMissingTable } = require('../schema/helpers');
const { mapRowsFromDb } = require('../../../lib/dto-mapper');
const { parseOutputKeys } = require('./usable');
const { computeConnectorHealth } = require('../../../lib/connector-health');
const { probeDecryptable } = require('./serializer');
const { logger: rootLogger } = require('../../../../shared/lib/logger');

const logger = rootLogger.child({ module: 'api-connectors:health' });

const DERIVE_TIMEOUT_MS = 3000;

// A key is "known" for a multi-bound connector only when every bound
// blueprint's own field-key set has it — a single-element list is a no-op
// (returns that set unchanged), so a connector with no extra bindings pays no
// intersection cost.
function intersectKnownSets(sets) {
  if (sets.length === 0) return new Set();
  if (sets.length === 1) return sets[0];
  let acc = sets[0];
  for (let i = 1; i < sets.length; i += 1) {
    const next = sets[i];
    acc = new Set([...acc].filter((k) => next.has(k)));
  }
  return acc;
}

// spec §5.2 census: `{connector_id}::{output_id}`, or null when the raw
// options_source value is not a connector-type source naming both a connector
// and an output. Read RAW (never through the FE strict parser — this route
// has no FE import), so a malformed/legacy row (no output_id, spec §1.6) is
// skipped rather than thrown on.
function connectorOutputPair(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  if (raw.type !== 'connector') return null;
  const connectorId = raw.connector_id;
  const outputId = raw.output_id;
  if (typeof connectorId !== 'string' || !connectorId) return null;
  if (typeof outputId !== 'string' || !outputId) return null;
  return `${connectorId}::${outputId}`;
}

// Race a promise against a timeout. Never throws: resolves { ok, value } or
// { ok: false }. A timed-out query may still be mid-protocol on the connection,
// so the caller destroys (not releases) the connection on any non-ok result.
function withTimeout(promise, ms) {
  return new Promise((resolve) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      resolve({ ok: false });
    }, ms);
    Promise.resolve(promise).then(
      (value) => { if (!settled) { settled = true; clearTimeout(timer); resolve({ ok: true, value }); } },
      // Surface the rejection (a timeout resolves { ok:false } with no err), so
      // a caller can tell an expected error apart from a timeout — the join
      // read below distinguishes a missing table from a timed-out query.
      (err) => { if (!settled) { settled = true; clearTimeout(timer); resolve({ ok: false, err }); } },
    );
  });
}

function register(router) {
  router.get('/health', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;

    let conn;
    let poisoned = false;
    try {
      conn = await pool.ro.getConnection();

      let connectorsRace = await withTimeout(
        conn.query(
          `SELECT id, blueprint_id, request_config, response_config, auth_type, auth_config, source_kind
             FROM \`${t(TABLES.API_CONNECTORS)}\``,
        ),
        DERIVE_TIMEOUT_MS,
      );
      // source_kind is additive; a no-ALTER DB throws ER_BAD_FIELD_ERROR on the
      // SELECT above. Retry once without it rather than poisoning the whole
      // derive — every row then reads as undefined → 'http' below (D-F5), the
      // same grandfathered-row posture the write guard already applies.
      if (!connectorsRace.ok && connectorsRace.err
          && (connectorsRace.err.code === 'ER_BAD_FIELD_ERROR' || connectorsRace.err.errno === 1054)) {
        connectorsRace = await withTimeout(
          conn.query(
            `SELECT id, blueprint_id, request_config, response_config, auth_type, auth_config
               FROM \`${t(TABLES.API_CONNECTORS)}\``,
          ),
          DERIVE_TIMEOUT_MS,
        );
      }
      if (!connectorsRace.ok) { poisoned = true; throw new Error('connectors read failed'); }
      const connectors = mapRowsFromDb('api_connectors', connectorsRace.value);

      const blueprintIds = [...new Set(connectors.map((c) => c.blueprint_id).filter(Boolean))];
      const transformerIds = [
        ...new Set(connectors.map((c) => (c.response_config || {}).transformer_id).filter(Boolean)),
      ];

      // A connector's extra "also usable in" blueprints. Inside the same
      // withTimeout cap as every other read here — an un-timed query could hang
      // past the 3s budget the rest of the derive respects. A MISSING join
      // table (a no-DDL DB; the join table's migration is severity 'warning')
      // still degrades to "no extra bindings known" rather than poisoning the
      // whole /health response the way every other read failure does; only a
      // timeout (or any non-missing-table error) poisons.
      const extraBlueprintsByConnector = new Map();
      if (connectors.length > 0) {
        const extraRace = await withTimeout(
          conn.query(
            `SELECT connector_id, blueprint_id FROM \`${t(TABLES.API_CONNECTOR_BLUEPRINTS)}\`
              WHERE connector_id IN (${connectors.map(() => '?').join(', ')})`,
            connectors.map((c) => c.id),
          ),
          DERIVE_TIMEOUT_MS,
        );
        if (!extraRace.ok) {
          if (!(extraRace.err && isMissingTable(extraRace.err))) { poisoned = true; throw new Error('connector bindings read failed'); }
        } else {
          for (const row of extraRace.value) {
            let arr = extraBlueprintsByConnector.get(row.connector_id);
            if (!arr) { arr = []; extraBlueprintsByConnector.set(row.connector_id, arr); }
            arr.push(row.blueprint_id);
          }
        }
      }
      const allBlueprintIds = [...new Set([
        ...blueprintIds,
        ...[...extraBlueprintsByConnector.values()].flat(),
      ])];

      // field_key set per blueprint (scalar field_keys and table table_keys both
      // live in blueprint_fields; every field_key is a valid output target).
      // ALSO the spec §5.2 census source: options_source + table_config carry
      // every {connector_id, output_id} pair a field/column names as its live
      // options source, over the SAME allBlueprintIds scope — a field may only
      // pick a connector already usable for its blueprint (§4.2), so any
      // connector these rows could reference is already covered by this set.
      const fieldsByBlueprint = new Map();
      const optionsReferencedPairs = new Set();
      if (allBlueprintIds.length > 0) {
        const fieldRace = await withTimeout(
          conn.query(
            `SELECT blueprint_id, field_key, field_type, options_source, table_config FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\`
              WHERE blueprint_id IN (${allBlueprintIds.map(() => '?').join(', ')})`,
            allBlueprintIds,
          ),
          DERIVE_TIMEOUT_MS,
        );
        if (!fieldRace.ok) { poisoned = true; throw new Error('blueprint_fields read failed'); }
        for (const row of mapRowsFromDb('blueprint_fields', fieldRace.value)) {
          let set = fieldsByBlueprint.get(row.blueprint_id);
          if (!set) { set = new Set(); fieldsByBlueprint.set(row.blueprint_id, set); }
          if (row.field_key) set.add(row.field_key);
          const scalarPair = connectorOutputPair(row.options_source);
          if (scalarPair) optionsReferencedPairs.add(scalarPair);
          // Mirrors the FE census guard (collect-connector-options-refs.ts):
          // table_config.columns is only walked for a field_type:'table' row —
          // a non-table field's table_config is stale/irrelevant leftover, not
          // a live column source, and must not count toward optionsReferenced.
          if (row.field_type !== 'table') continue;
          const columns = row.table_config && typeof row.table_config === 'object' && Array.isArray(row.table_config.columns)
            ? row.table_config.columns : [];
          for (const col of columns) {
            if (!col || typeof col !== 'object' || Array.isArray(col)) continue;
            const colPair = connectorOutputPair(col.options_source);
            if (colPair) optionsReferencedPairs.add(colPair);
          }
        }
      }

      const outputKeysById = new Map();
      if (transformerIds.length > 0) {
        const tRace = await withTimeout(
          conn.query(
            `SELECT id, output_keys FROM \`${t(TABLES.TRANSFORMERS)}\`
              WHERE id IN (${transformerIds.map(() => '?').join(', ')})`,
            transformerIds,
          ),
          DERIVE_TIMEOUT_MS,
        );
        if (!tRace.ok) { poisoned = true; throw new Error('transformers read failed'); }
        for (const row of tRace.value) outputKeysById.set(row.id, parseOutputKeys(row.output_keys));
      }

      const statuses = {};
      for (const c of connectors) {
        // Every source_kind answers the same question — does this connector's
        // outputs map onto its bound blueprints' fields (+ referenced options
        // lists)? A template/static row has url='' and request_config=null
        // (normalizeForSourceKind), so collectTargetKeys/getTableBinding read
        // an empty request_config and derive off response_config.outputs the
        // same as an http row; auth_type='none' for non-http rows makes
        // probeDecryptable's pathsFor loop a no-op (true), never a throw.

        // SECURITY: probeDecryptable returns only a boolean; the secret is never
        // read into the response.
        let secretDecryptable = true;
        try {
          secretDecryptable = probeDecryptable(c.auth_config || {}, c.auth_type);
        } catch { secretDecryptable = false; }

        if (!c.blueprint_id) {
          statuses[c.id] = { status: 'unbound', resolved_count: 0, missing_count: 0, missing_keys: [], secret_decryptable: secretDecryptable };
          continue;
        }
        // A connector bound to more than one blueprint (home + extras) is
        // healthy only when EVERY bound blueprint resolves each referenced
        // key — the narrowest (intersection) set, not the home blueprint
        // alone, or a save could pass health while an already-bound extra
        // silently loses the field the connector fills.
        const boundBlueprintIds = [c.blueprint_id, ...(extraBlueprintsByConnector.get(c.id) || [])];
        const known = intersectKnownSets(boundBlueprintIds.map((id) => fieldsByBlueprint.get(id) || new Set()));
        const transformerId = (c.response_config || {}).transformer_id || null;
        const projected = {
          request_config: c.request_config || {},
          response_config: {
            ...(c.response_config || {}),
            transformer_output_keys: transformerId ? (outputKeysById.get(transformerId) ?? null) : null,
          },
        };
        // spec §5.3: a referenced options list on THIS connector counts as a
        // real target — any of its to.mode:'options' outputs whose id appears
        // in the census set keyed by this connector's own id.
        const optionsReferenced = (projected.response_config.outputs || []).some(
          (o) => o && o.to && o.to.mode === 'options' && optionsReferencedPairs.has(`${c.id}::${o.id}`),
        );
        const h = computeConnectorHealth(projected, known, optionsReferenced);
        statuses[c.id] = {
          status: h.status,
          resolved_count: h.resolvedKeys.length,
          missing_count: h.missingKeys.length,
          missing_keys: h.missingKeys,
          secret_decryptable: secretDecryptable,
        };
      }

      return res.json(apiOk({ statuses, derived_at: new Date().toISOString() }));
    } catch (err) {
      // SAFETY: never 5xx — degrade to an empty map so the list UI keeps
      // working and renders "unknown" for every connector. Raw error to logs.
      req.log.warn({ err }, 'connector-health derive failed — returning empty map');
      return res.json(apiOk({ statuses: {}, derived_at: new Date().toISOString() }));
    } finally {
      if (conn) {
        try {
          if (poisoned && typeof conn.destroy === 'function') conn.destroy();
          else conn.release();
        } catch { /* connection already gone */ }
      }
    }
  });
}

module.exports = register;
