/**
 * api-connectors/reassign.js — PATCH /:id/owner
 *
 * Transfer a connector to another real user. Unlike the shared pool
 * (hierarchy_nodes claim/release), connectors are personal: there is no
 * shared (NULL) state and no claim/release. Two callers are allowed:
 *   - admin            → may transfer ANY connector (requireCondition='any')
 *   - the current owner → may transfer their OWN connector (requireCondition='self')
 * A non-owner editor is rejected (403 via NOT_SELF). make_shared (NULL) is
 * forbidden — new_owner_id must be a real, existing user id.
 *
 * Registered BEFORE the generic CRUD `/:id` so the `/:id/owner` PATCH is not
 * shadowed by the factory's `/:id` PUT/DELETE.
 */
const { pool, t, getDynamicPool } = require('../../../db');
const { sendError } = require('../../../../shared/lib/send-error');
const {
  apiOk, apiError, requireAdminOrEditor,
} = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { applyOwnerChange } = require('../../../services/ownership');
const { resolveCanonicalUserId, sameStoredValue, ownerTargetRejection } = require('../schema/write-value');
const { callerHasBlueprintGrant } = require('../../../lib/delegated-grants');
const { logger } = require('../../../../shared/lib/logger');
const { enforceClientDbBoundary } = require('../../../lib/client-db-guard');

const AUDIT_EVENT = 'api_connector.owner.transfer';

// Mirror schema.js's resolveOwnershipRwPool. NOTE: the entire api-connectors
// mount is NOT in the X-Database middleware's schema-routable prefix list, so
// `req.body.db` is never populated by injection here and this resolves to
// `pool.rw` today — exactly like every other connector route (CRUD/io/health).
// The branch is kept so this route stays correct if connectors ever join
// per-request schema routing (a feature-wide change, not this route's call).
// Duplicated because the schema.js helper is module-local.
//
// SECURITY: the getDynamicPool trust boundary is enforced by the global
// x-database-validate middleware (sole injector, runs first), but this dynamic
// branch is guarded again at the route entry (enforceClientDbBoundary below) as
// defense in depth — so a client-supplied `db` can never reach getDynamicPool
// even if this route's mount order ever changes. By the time control reaches
// here, any surviving `req.body.db` is server-trusted (reject mode 400s a
// client value; warn mode deletes it → falls back to pool.rw).
const resolveRwPool = async (req) =>
  req.body?.db ? (await getDynamicPool(req.body.db)).rw : pool.rw;

module.exports = function registerReassign(router) {
  router.patch('/:id/owner', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    // SECURITY: reject a client-supplied db config before any DB work.
    if (!enforceClientDbBoundary(req, res)) return;
    const { new_owner_id } = req.body || {};
    // Non-empty string id — this also forbids make_shared (null), which
    // connectors have no state for.
    //
    // NO UUID SHAPE FLOOR, AND THE REASON IT WAS ADDED WAS NOT TRUE. The comment
    // this replaces said "every sibling owner route reaches its target through a
    // `UUID_RE`-checked path; this one did not". None of the four does: the
    // blueprint, template, transformer and scenario transfers all take a
    // non-empty string. And the harm it named — `WHERE id = '<uuid> '` resolving
    // the row because a CHAR comparison pads the shorter operand — is already
    // answered two lines below, where the resolver returns the STORED id and
    // every statement binds that. A padded spelling never reaches the column.
    //
    // What the floor cost is measured elsewhere in this same file's neighbours:
    // `crud-factory.js` records that deployments exist whose `users.id` values
    // are not canonical uuids, and `routes-hierarchy.js` documents templates
    // seeded from another environment. On such a deployment an administrator can
    // transfer a blueprint, a template, a scenario and a transformer to that
    // user — and a connector answered 400, with the generic-PUT fallback closed
    // by `immutableColumns: ['owner_id']` in this same PR. Two defensible
    // changes combining into data nobody can repair.
    if (typeof new_owner_id !== 'string' || new_owner_id.length === 0) {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'new_owner_id must be a non-empty string id' });
    }
    const isAdmin = req.user && req.user.role === 'admin';
    let conn;
    try {
      conn = await (await resolveRwPool(req)).getConnection();
      await conn.beginTransaction();

      // collation-compare: the column decides which user row this spelling
      // names, because `users.id` folds case. `target.id` is the STORED
      // spelling and is what every statement below binds — resolving the row
      // without rebinding its id is what left the new owner unable to find
      // their own connector in the front end while SQL still admitted them.
      const target = await resolveCanonicalUserId(conn, t(TABLES.USERS), new_owner_id);
      if (!target.ok) {
        await conn.rollback();
        // One mapping for every route that asks the shared resolver, so an
        // administrator gets the same sentence whichever record they transfer —
        // including the banned-account refusal, which is not "no such user".
        const rejection = ownerTargetRejection(target.reason);
        return sendError(req, res, null, { status: rejection.status, code: rejection.code, reason: rejection.message });
      }
      // SECURITY: a connector is only reachable by admin/editor. Transferring it
      // to a plain user would lock the new owner out of their own row, so reject
      // server-side (the FE picker already filters, but a direct PATCH must not
      // bypass it).
      if (target.role !== 'admin' && target.role !== 'editor') {
        await conn.rollback();
        return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'Target user must be an admin or editor' });
      }

      // INTEGRITY: an editor can only PUT/DELETE a connector whose bound
      // blueprint they own or that is shared (the CRUD parentOwnership EXISTS
      // predicate). Transferring an unbound or foreign-blueprint connector to
      // an editor would hand them a row they cannot manage (admin-only to fix).
      // Reject such transfers up front. Admin targets manage anything.
      if (target.role === 'editor') {
        const cRows = await conn.query(
          `SELECT blueprint_id FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`,
          [req.params.id],
        );
        if (cRows.length) {
          const bpId = cRows[0].blueprint_id;
          if (bpId == null) {
            await conn.rollback();
            return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'Cannot transfer an unbound connector to an editor; bind it to a blueprint they own or that is shared first' });
          }
          const bRows = await conn.query(
            `SELECT owner_id FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ?`,
            [bpId],
          );
          const bpOwner = bRows.length ? bRows[0].owner_id : undefined;
          // collation-compare: this predicts whether the CRUD `parentOwnership`
          // gate will admit the new owner later, and that gate is a SQL EXISTS
          // on `bp.owner_id = ?` — so it has to fold case exactly as the engine
          // will. A byte comparison here refuses a transfer the write path
          // would then have allowed, which is a refusal the operator cannot
          // explain or work around.
          const ownsBlueprint = bpOwner !== undefined
            && await sameStoredValue(conn, t(TABLES.HIERARCHY_NODES), 'owner_id', bpOwner, target.id);
          // spec §6.1: the write path now admits a blueprint-scope
          // GRANTEE too (api_connectors sets blueprintGrantScope), so this
          // prediction has to ask the SAME question of the TARGET subject or it
          // would refuse a transfer the grantee could then manage. Reuses the
          // shared resolver with the target's id + role — a grant held by the
          // target, not the caller — so the EXISTS keeps one spelling.
          const targetHasGrant = !ownsBlueprint && bpOwner !== null
            && await callerHasBlueprintGrant(conn, target.id, bpId, target.role);
          if (!(bpOwner === null || ownsBlueprint || targetHasGrant)) {
            await conn.rollback();
            return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: "Target editor does not own this connector's blueprint, hold a grant on it, or find it shared; they would be unable to manage it" });
          }
        }
      }

      const result = await applyOwnerChange(conn, TABLES.API_CONNECTORS, req.params.id, target.id, {
        actor: req.user,
        action: 'transfer',
        // admin transfers any connector; a plain owner only their own row.
        requireCondition: isAdmin ? 'any' : 'self',
        auditEventType: AUDIT_EVENT,
        t,
      });

      if (result.conflict_reason === 'NOT_FOUND') {
        await conn.rollback();
        return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
      }
      if (result.conflict_reason === 'NOT_SELF') {
        await conn.rollback();
        return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'You can only reassign a connector you own' });
      }
      // NOTE: applyOwnerChange's idempotent_same_actor branch only fires for
      // requireCondition='null' (claim); this route uses 'any'/'self' so it is
      // unreachable here. No handling needed.
      if (result.unchanged_same_owner) {
        await conn.commit();
        return res.json(apiOk({ owner_id: result.new_owner, changed: false }));
      }
      await conn.commit();
      res.json(apiOk({
        owner_id: result.new_owner,
        old_owner_id: result.prior_owner,
        changed: true,
      }));
    } catch (err) {
      if (conn) {
        try { await conn.rollback(); } catch (rbErr) {
          req.log.warn({ err: rbErr }, 'rollback after api_connector owner transfer failed');
        }
      }
      sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { rowId: req.params.id } });
    } finally {
      if (conn) conn.release();
    }
  });
};
