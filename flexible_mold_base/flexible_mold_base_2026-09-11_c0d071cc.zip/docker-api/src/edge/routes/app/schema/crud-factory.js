const express = require('express');
const { sendError } = require('../../../../shared/lib/send-error');
const {
  TABLES,
  VARIANT_OVERRIDE_ACTIONS,
  t,
  apiOk,
  apiError,
  requireAuth,
  requireAdmin,
  requireAdminOrEditor,
  isOwnerOrAdmin,
  uuidv4,
  mapRowFromDb,
  mapRowsFromDb,
  mapRowToDb,
  previewCascade,
  cascadeDeleteNode,
  collectDescendantIds,
  tableExistsInCurrentSchema,
  buildVariantOverrideUpdateExistsClause,
  buildVariantOverrideInsertExistsClause,
  buildDuplicateActionTripleNotExistsClause,
  applyOwnerChange,
  enrichOwnerNames,
  validateComputeRule,
  detectCycle,
  invalidChoiceConfigShape,
  resolveAncestors,
  restampTemplates,
  countAffectedTemplates,
  isValidBlueprintParent,
  HIERARCHY_OWNER_AUDIT_EVENT,
  USER_TEMPLATE_OWNER_AUDIT_EVENT,
  resolveOwnershipRwPool,
  cascadeBlueprintOwnerToVariants,
  SAFE_COL_RE,
  isSafeColumnName,
  SLUG_KEY_PATTERN,
  isValidSlugKey,
  isBlueprintLinked,
  isBlueprintLinkedLocked,
  isLinkedParentLocked,
  auditSchemaClearFailed,
  validateLinkConstraints,
  resolveLinkCheckBlueprintId,
  _columnSetCache,
  getConnDatabaseName,
  getActualColumnSet,
  _historyTableCache,
  isCodeVersionHistoryAvailable,
  gateKeysByColumnSet,
  findNonCanonicalWriteKeys,
  TABLE_VALUES,
  validateCodeVersioning,
  isMissingTableOrColumn,
  isMissingTable,
  _codeVersioningDegraded,
  warnCodeVersioningDegradedOnce,
  validateAndPrepareParentOwnership,
  validateAndPrepareParentRepend,
  buildChainSelectSql,
  buildChainExistsForRow,
  buildChainBlueprintGrantExistsForRow,
  ENCRYPTION_GATE_422,
  runSerializeWrite,
  editorMayWriteBlueprint,
  storedRowId,
  MAX_BATCH_FIELD_IDS,
  MAX_BATCH_BLUEPRINT_IDS,
} = require('./helpers');
const { buildListHandler } = require('./list-query');
const { resolveCanonicalUserId, sameStoredValue, ownerTargetRejection } = require('./write-value');
const { referencesFor } = require('./row-references');
const { resolveRwPool, resolveRoPool } = require('./request-pool');
const {
  grantsTableAvailable, buildTemplateAccessExists, GRANT_SCOPE_COLUMN, grantEligibleRole,
  callerHasBlueprintGrant,
} = require('../../../lib/delegated-grants');
const {
  recordTemplateActivity, ACTIVITY_ACTIONS,
} = require('../../../lib/template-activity');
const {
  columnNullabilityFor, charColumnsFor, notNullNoDefaultColumnsFor, enumMembersFor,
} = require('../../../lib/schema-manifest');
// The re-pend POLICY — including what a NULL status means — is one module's, not
// this factory's and not each mount's. See review-status.js.
const { repandRequired, PENDING: REVIEW_PENDING } = require('../../../lib/review-status');
// lint-allow: file-size single CRUD factory function, tracked

// The declared width of an identifier column, and the refusal itself, both from
// the shared module: the hand-written handlers that SHADOW a factory verb build
// their own statements, so a floor that lived only in this file would be a floor
// with holes in exactly the routes that bypass this file.
const { UUID_CHAR_LENGTH, identifierFloorViolation } = require('./identifier-floor');

// One entry per mount that this process has built:
//   { table, declared: <the DDL's CHAR(36) columns>, exempt: <nonUuidCharColumns> }
//
// WHY IT IS COLLECTED AT ALL. The floor's domain is derived from the DDL, and
// which of those columns a mount excuses is a per-mount declaration — so the
// only complete answer to "what does this deployment refuse, and what did
// somebody decide is not a row id" lives in the wiring, not in any one file. The
// sub-step that was supposed to produce that answer by hand missed a column
// whose writer is the browser, because a search of server code cannot see a
// browser. This list is what the inventory test compares a written-down
// classification against, so the next such column is a red test rather than a
// 400 in production.
const declaredCharColumnEscapes = [];

// Which logical tables this factory has been mounted on, filled in as each mount
// registers. Read by the row-reference coverage test, which needs "the tables
// served" to be an OBSERVED fact: a mount added in a file nobody thought to grep
// is the case that a list maintained by hand does not contain.
const servedTables = new Set();

// The per-mount facts the wiring tests judge, recorded as each mount registers:
// which columns hold an owner, which of them the generic PUT refuses to move,
// and whether that PUT runs in a transaction. Observed rather than listed, for
// the same reason `servedTables` is.
const mountShapes = new Map();

// A write the engine gave up on rather than a write the server got wrong.
//
// ONE ANSWER FOR EVERY VERB, which is why it is here and not beside the gate
// that prompted it. errno 1213 (deadlock — the engine chose this transaction as
// the victim and rolled it back) and 1205 (lock wait timeout) both say the same
// thing: nothing about this request was invalid, the work simply did not get its
// turn, and repeating it is the correct response. Reported as a 500
// INTERNAL_ERROR — which is what every verb here did — that is indistinguishable
// from a server fault, so a client has no way to know retrying is worth
// anything, and an operator reads a bug report where there is contention.
//
// Returns null for every other error so the caller's existing mapping (1062,
// the mount's own codes) and the catch-all are untouched.
function writeConflictError(err) {
  if (!err || (err.errno !== 1213 && err.errno !== 1205)) return null;
  return apiError(
    'This record was being changed by another request; retry.',
    'WRITE_CONFLICT',
    409,
  );
}

// The `boolean` valueGuard's accepted value set — held IDENTICAL to
// dto-mapper.js's own truthy/falsy recognition for a `booleans`-registry
// column (`v === true || v === 1 || v === '1' || v === 'true'` → true, else
// false) so a value the guard passes on the client-facing call is still
// recognised on PUT's second, post-coercion reassertWriteGates call (see the
// comment at the guard's use site). Anything outside this set — 'yes', 2, {},
// [] — is refused on either call rather than silently landing as false.
const BOOLEAN_COERCIBLE = new Set([true, false, 1, 0, '1', '0', 'true', 'false']);

// Machine-readable discriminators for `checkParentOwnership`'s two distinct
// refusals. Both verbs used to word the same refusal identically
// ('parent row is not owned by you and is not shared') and the only
// way a caller could tell a `parentOwnership` 403 apart from every other
// FORBIDDEN a mount can raise (e.g. a null-owner row an editor may never
// touch at all) was to match that prose — a contract that breaks the moment
// the message is translated or reworded. `details.reason` survives the trip
// through `apiInvoke`/`platformFetch` (both already thread ApiError.details),
// so the client switches on this instead. PARENT_NOT_OWNED is the same
// reason on BOTH verbs — POST and PUT ask `checkParentOwnership` the same
// question. PARENT_REQUIRED is distinct: a null target names no blueprint at
// all, so "owned by another user" would be naming one that was never sent.
const PARENT_NOT_OWNED = 'parent_not_owned';
const PARENT_REQUIRED = 'parent_required';

// Single source for the PARENT_REQUIRED refusal so POST (create) and PUT
// (rebind/unbind) cannot drift onto different wording or a different
// `details.reason` — they are the same rule ("a null target names no
// blueprint at all") applied at two points in the row's lifecycle.
function parentRequiredError() {
  return apiError(
    'Not allowed: this row must remain bound to a parent', 'FORBIDDEN', 403,
    { details: { reason: PARENT_REQUIRED } },
  );
}

function createCrudRoutes(logicalName, opts = {}) {
  const r = express.Router();
  const filterCols = opts.filterableColumns ? new Set(opts.filterableColumns) : null;
  // SECURITY: when set, non-admin GET requests are restricted to rows where
  // the named column equals req.user.id (or req.user.email for SSO), so a
  // regular user cannot read another user's drafts via direct API call.
  const userScopeColumn = opts.userScopeColumn || null;
  // SECURITY: when set, non-admin users can also WRITE to this table, but
  // the named column is ALWAYS overridden server-side to `req.user.id`
  // regardless of what the client supplied. Without this opt the table is
  // admin-write-only. Applied to user_templates so regular users can save /
  // draft their own templates.
  const writeScopeColumn = opts.writeScopeColumn || null;
  // Which roles may POST/PUT/DELETE through this factory. Defaults to
  // ['admin'] for backward compatibility; mounts whose row class is editable
  // by editors pass ['admin','editor']. The userScopeColumn / writeScopeColumn
  // paths are not affected — they continue to honour requireAuth+scope-write.
  const writeRoles = Array.isArray(opts.allowedRoles) && opts.allowedRoles.length
    ? new Set(opts.allowedRoles)
    : new Set(['admin']);
  // Per-column value guards keyed by role.
  //
  //   rejectFor — blacklist; reject if value IS in the list, and ON CREATE
  //     reject when the column is ABSENT: the INSERT would leave the value to
  //     the database, whose default the role may not be allowed to hold.
  //     valueGuards: { node_type: { rejectFor: { editor: ['category','release'] } } }
  //
  //   acceptFor — whitelist; reject if value is set AND NOT in the list
  //     valueGuards: { action: { acceptFor: { editor: ['lock','hide','autofill'] } } }
  //
  //   numeric — role-agnostic type/range; a present value must be a finite
  //     number in [min, max] (null only when allowNull), and a whole number
  //     when `integer`. 400 on violation.
  //     valueGuards: { primary_sga_gb: { numeric: { min: 0, allowNull: true, integer: true } } }
  //
  //   boolean — role-agnostic type check; a present value must be one of
  //     true/false/1/0/'1'/'0'/'true'/'false' (BOOLEAN_COERCIBLE — the same
  //     set dto-mapper.js's own coercion recognises, so the guard's answer
  //     stays the same before AND after that coercion runs on PUT's second,
  //     reassertion pass). Anything else (e.g. 'yes', 2) is a 400.
  //     valueGuards: { name_locked: { boolean: { allowNull: false } } }
  //
  // POST/PUT 403 on violation. Admin role bypasses both forms by virtue
  // of the per-role keying (no entry → no check). Closes both the
  // editor-escalation path (POST /hierarchy_nodes node_type='category')
  // AND the editor-input-corruption path (POST /variant_overrides
  // action='bad' crashes the FmbVariantPolicy ACTION_ICONS lookup).
  const valueGuards = opts.valueGuards || null;
  // Owner-on-create scoping. When set, POST forces
  // `data[ownerColumn] = req.user.id` for editor role (admin-created
  // rows leave owner_id NULL = shared). PUT/DELETE check that the row's
  // owner_id is NULL or equals req.user.id, else 403.
  const ownerColumn = opts.ownerColumn || null;
  // NOTE: variants inherit the parent blueprint's owner_id so admin-created
  // variants under a shared blueprint stay shared and editor-created variants
  // under a private blueprint stay owned by the same editor. Stamping the
  // actor's id unconditionally would let admin variants under a shared
  // blueprint become admin-owned and break editor PUT/DELETE.
  // Shape: { whenNodeType: 'variant', via: 'parent_id', parentNodeType: 'blueprint' }
  const inheritOwnerFromParent = opts.inheritOwnerFromParent || null;
  // Child tables that resolve their owner via an FK chain to a Blueprint
  // hierarchy_node. Single-hop and N-hop both expressed as a chain spec.
  //
  //   parentOwnership: {
  //     via: 'field_id',                                  // body / row column to start the chain
  //     chain: [
  //       { table: TABLES.BLUEPRINT_FIELDS, match: 'id' },
  //       { table: TABLES.HIERARCHY_NODES,  from: 'blueprint_id',
  //         match: 'id', readOwner: 'owner_id' },
  //     ],
  //   }
  //
  // Single-hop equivalent (existing 3 callers):
  //   parentOwnership: {
  //     via: 'blueprint_id',
  //     chain: [{ table: TABLES.HIERARCHY_NODES, match: 'id', readOwner: 'owner_id' }],
  //   }
  //
  // Self-join (variant_overrides):
  //   parentOwnership: {
  //     via: 'variant_id',
  //     chain: [
  //       { table: TABLES.HIERARCHY_NODES, match: 'id' },
  //       { table: TABLES.HIERARCHY_NODES, from: 'parent_id',
  //         match: 'id', readOwner: 'owner_id' },
  //     ],
  //   }
  //
  // Field semantics:
  //   chain[0]:    no `from` (root hop is keyed off `via`)
  //   chain[i>0]:  required `from` (column on previous hop's row that feeds
  //                this hop's `match`)
  //   terminal:    required `readOwner` (owner column to compare to req.user.id)
  //   non-terminal:forbidden `readOwner`
  //
  // Validated at registration time; throws Error prefixed `[parentOwnership]: `
  // on any shape violation (chain empty / unsafe column name / non-TABLES
  // value / wrong field placement).
  const parentOwnership = opts.parentOwnership
    ? validateAndPrepareParentOwnership(
      opts.parentOwnership, logicalName,
      opts.enumColumns && opts.enumColumns.node_type,
    )
    : null;
  // A node_type-scoped parentOwnership folds its owner+grant logic into the
  // ownerColumn write-scope arm (a scoped row's own owner_id already reflects
  // its parent's owner via inheritOwnerFromParent), so the mount MUST declare
  // ownerColumn — without it the create/update would have no gate at all.
  if (parentOwnership && parentOwnership.whenNodeType && !opts.ownerColumn) {
    throw new Error(
      `[parentOwnership]: ${logicalName} sets whenNodeType but no ownerColumn — the scoped `
      + 'owner/grant arm has nothing to widen',
    );
  }
  // The gate's parent-type and inheritOwnerFromParent's parent-type must name
  // the SAME kind of row: the gate reads that row's owner to decide the write,
  // and inherit copies that row's owner onto the new record. If they disagreed,
  // the gate could admit against one parent while inherit stamped from another
  // (guard value != written value). Asserted here so a future edit to one
  // cannot silently drift from the other.
  if (parentOwnership && parentOwnership.parentNodeType
      && inheritOwnerFromParent && inheritOwnerFromParent.parentNodeType
      && parentOwnership.parentNodeType !== inheritOwnerFromParent.parentNodeType) {
    throw new Error(
      `[parentOwnership]: ${logicalName} parentNodeType=${parentOwnership.parentNodeType} `
      + `disagrees with inheritOwnerFromParent.parentNodeType=${inheritOwnerFromParent.parentNodeType}`,
    );
  }
  // spec §6.4a: opt-in for the ONE factory table whose only reachable generic
  // write is DELETE (variant_overrides — POST/PUT are shadowed by a custom
  // route). When set, the editor DELETE's owner-scoped chain EXISTS is widened
  // to "OR a blueprint-scope grant on the terminal blueprint", so a grantee may
  // delete an override under a blueprint they were granted. The terminal chain
  // hop MUST be a blueprint hierarchy_node (asserted in the predicate). Unset
  // (every other mount) leaves the DELETE predicate byte-identical.
  const blueprintGrantScope = opts.blueprintGrantScope === true;
  // Escape hatch for the assert below, ONLY for a mount whose generic PUT can
  // never be reached: a custom route for the same path is registered ahead of
  // this `router.use` call and always ends the request first (variant_overrides
  // — see routes-variant-overrides.js's PUT /:id). Setting this on a mount
  // whose generic PUT IS reachable reopens the ordering hazard the assert
  // exists to close, so every caller must justify it at the call site.
  const putShadowedByCustomRoute = opts.putShadowedByCustomRoute === true;
  // Opt-in: when set, every write (POST/PUT/DELETE) re-pends the parent row to
  // 'pending' inside the SAME transaction as the child write, with the parent
  // row locked FOR UPDATE. Absent (every other table) → no transaction, no
  // extra query, byte-identical to today. Validated at registration time;
  // throws Error prefixed `[parentRepend]: ` on any shape violation.
  const parentRepend = opts.parentRepend ? validateAndPrepareParentRepend(opts.parentRepend) : null;
  // Opt-in zero-FK cascade substitute: when set, a successful DELETE of a row
  // also deletes dependent rows in the listed tables (matched by a foreign-key
  // column = the deleted row's id) inside the SAME transaction. This closes the
  // orphan the generic delete would otherwise leave now that there are no DB
  // foreign keys. Each entry: { table: <TABLES value>, fk: <safe column name> }.
  // Validated at registration time; throws on any shape violation.
  const dependentCleanup = (Array.isArray(opts.dependentCleanup) ? opts.dependentCleanup : []).map((dep) => {
    if (!dep || typeof dep !== 'object') {
      throw new Error('[dependentCleanup]: each entry must be an object');
    }
    if (!Object.values(TABLES).includes(dep.table)) {
      throw new Error(`[dependentCleanup]: table=${dep.table} must be a TABLES constant value`);
    }
    if (!isSafeColumnName(dep.fk)) {
      throw new Error(`[dependentCleanup]: fk=${dep.fk} fails the column whitelist`);
    }
    return { table: dep.table, fk: dep.fk };
  });
  // Like dependentCleanup, but the dependent is an ADDITIVE table whose
  // create-table migration is severity 'warning' — a target DB may legitimately
  // lack it. A missing table (1146) therefore means "nothing to orphan", not a
  // failed delete, so each cleanup is best-effort (the codeVersioning
  // delete-cleanup precedent). Same registration-time shape validation.
  const tolerantDependentCleanup = (Array.isArray(opts.tolerantDependentCleanup) ? opts.tolerantDependentCleanup : []).map((dep) => {
    if (!dep || typeof dep !== 'object') {
      throw new Error('[tolerantDependentCleanup]: each entry must be an object');
    }
    if (!Object.values(TABLES).includes(dep.table)) {
      throw new Error(`[tolerantDependentCleanup]: table=${dep.table} must be a TABLES constant value`);
    }
    if (!isSafeColumnName(dep.fk)) {
      throw new Error(`[tolerantDependentCleanup]: fk=${dep.fk} fails the column whitelist`);
    }
    return { table: dep.table, fk: dep.fk };
  });
  // Opt-in code versioning: when set, POST/PUT/DELETE run inside a transaction
  // and a change to `watchColumn` appends an immutable history row to
  // `historyTable` and bumps `versionColumn` on the row — all in the SAME
  // transaction. Absent (every other mount) → no-op, byte-identical autocommit
  // path. Degrades gracefully on a DB missing the table/columns (1146/1054 →
  // versioning skipped, warn once). Shape:
  //   { watchColumn, versionColumn, historyTable, historyFkColumn }
  const codeVersioning = opts.codeVersioning ? validateCodeVersioning(opts.codeVersioning) : null;
  // Columns the generic PUT must never rewrite. Stripped from the update body
  // for ALL roles before the SET clause is built, so a structural FK change is
  // forced through a dedicated endpoint that runs the required side effects
  // (cycle guard, denormalized re-stamp, audit) which the generic PUT does not.
  // Role-agnostic because those side effects are needed for every role. Create
  // is untouched.
  const immutableColumns = Array.isArray(opts.immutableColumns) ? opts.immutableColumns : [];
  // Columns the SERVER owns: stripped from the write body on CREATE as well as
  // UPDATE, for every role.
  //
  // ITS OWN OPTION BECAUSE `immutableColumns` IS DOING TWO JOBS. That list means
  // "not rewritable through the generic PUT", and two of its users rely on the
  // create path still setting the column: a node's `parent_id` and a group's
  // `group_key` are chosen at creation and only afterwards forced through the
  // endpoint that runs the cascade. Widening it to POST would break both. But a
  // third kind of column was on the same list for a different reason — the run
  // cache on a template record, which no role has any reason to set by hand —
  // and for that one "update-only" meant a caller could simply CREATE the row
  // already carrying a forged value. Measured live: a plain user POSTed a
  // `flow_last_run_id` and a `flow_link` of their choosing and the row stored
  // them, while the PUT of the same two values was correctly stripped.
  //
  // Disjoint from `immutableColumns` at require time: a column on both lists is
  // a mount that has not decided which of the two rules it means.
  const serverOnlyColumns = Array.isArray(opts.serverOnlyColumns) ? opts.serverOnlyColumns : [];
  for (const c of serverOnlyColumns) {
    if (!isSafeColumnName(c)) throw new Error(`[serverOnlyColumns]: ${c} fails column whitelist`);
    if (immutableColumns.includes(c)) {
      throw new Error(
        `[serverOnlyColumns]: ${logicalName}.${c} is also in immutableColumns — one column cannot `
        + 'be both "the server owns it on every path" and "the create path may set it"',
      );
    }
  }
  // SECURITY: when set to a column name, list + detail GETs enrich each row
  // with a derived `owner_name`, resolved from the users directory but
  // BOUNDED to the owner ids already present in this caller's auth-scoped
  // result set. Runs under requireAuth (NOT requireAdmin) on purpose: the
  // value exposed is the display name of an owner whose row the caller can
  // already see — not a directory listing, and not an enumeration vector
  // (ids are never client-supplied here). Name only; email is never read.
  const resolveOwnerNameColumn =
    typeof opts.resolveOwnerName === 'string' ? opts.resolveOwnerName : null;
  if (resolveOwnerNameColumn && !isSafeColumnName(resolveOwnerNameColumn)) {
    throw new Error(`[resolveOwnerName]: ${resolveOwnerNameColumn} fails column whitelist`);
  }
  // Optional serializer hooks for tables that need a transform the generic
  // DTO mapper cannot express — currently only api_connectors, which holds
  // encrypted secrets inside a JSON column (encrypt on write, mask `****` on
  // read). Both default to null, so the seven existing mounts that pass
  // neither behave byte-identically. serializeWrite runs on the create/update
  // body BEFORE mapRowToDb (so it sees the still-parsed object, and its own
  // ctx.isUpdate/ctx.id let it read-back to preserve a masked secret);
  // serializeRead runs on each already-parsed row before the response.
  const serializeWrite = typeof opts.serializeWrite === 'function' ? opts.serializeWrite : null;
  const serializeRead = typeof opts.serializeRead === 'function' ? opts.serializeRead : null;
  // Optional batched post-read enrichment (e.g. a join-table projection).
  // Runs after owner-name enrichment, before the read serializer, on the same
  // conn. No-op for every mount that does not declare it.
  const enrichRows = typeof opts.enrichRows === 'function' ? opts.enrichRows : null;
  // Opt-in: run `serializeWrite` INSIDE the update transaction, on the write
  // connection, with that connection handed to it as `ctx.conn`. Forces the
  // guarded-tx path on for PUT. Default off ⇒ every mount that omits it is
  // byte-identical.
  //
  // WHY A HOOK WOULD WANT THE WRITE CONNECTION, said about the case that needs
  // it. The connector serializers implement "a `****` leaf means unchanged" by
  // reading the stored ciphertext back and binding it — a read that was on
  // `pool.ro`, a different pool, a different connection, and outside any
  // transaction or row lock, while the statement it feeds runs on the write
  // pool afterwards. So the value bound as "what is stored" is whatever an
  // unsynchronised snapshot answered: `DB_RO_*` may address a real replica, and
  // even on one server a concurrent commit between the two lands under the
  // write. Two outcomes, both silent. The read MISSES — replica lag, a row
  // created moments earlier — and the resolver's own "no stored secret" arm
  // DROPS the leaf, so "keep what is stored" deletes the credential. Or the read
  // succeeds with a stale value and the write puts it back over a rotation that
  // had already committed. Measured, deterministically, in the real-DB test: a
  // concurrent commit is reverted by the snapshot.
  //
  // UPDATE-ONLY, deliberately. On create there is no stored row to be
  // unsynchronised with — the connector serializers read nothing when
  // `ctx.isUpdate` is false — so opening a transaction there would buy a lock
  // and change nothing. The option's contract is therefore about the verb that
  // has a prior value, and POST keeps the path it had.
  //
  // The hook is not REQUIRED to use `ctx.conn`; what the factory guarantees is
  // that a statement issued on it is inside the transaction the UPDATE commits,
  // so a `FOR UPDATE` the hook takes is held across that write.
  const serializeWriteInTx = opts.serializeWriteInTx === true;
  if (serializeWriteInTx && !serializeWrite) {
    throw new Error('[serializeWriteInTx]: declared with no serializeWrite to run');
  }
  // Opt-in SELF re-pend: when a PUT changes one of `columns`, clear this row's
  // own approval so what it dispatches cannot outrun the review that covered it.
  // Shape: { statusCol, clearCols, columns }. Forces the guarded-tx path on for
  // PUT. Default off ⇒ every mount that omits it is byte-identical.
  //
  // WHY IT IS HERE AND NOT IN A MIDDLEWARE, which is where both mounts had it.
  // The probe read the row on `pool.ro` while the approval PATCHes write
  // `pool.rw`, and nothing held the row between the probe and the factory's
  // UPDATE — so the decision "is this row approved, and did something sensitive
  // change" was taken against a snapshot that an admin approve, a concurrent
  // PUT or a replica's lag could each make wrong by the time the statement ran.
  // Inside the transaction the row is taken FOR UPDATE and the verdict is folded
  // into the SAME statement, which also means the re-pend inherits the UPDATE's
  // ownership scoping instead of being a second, unscoped write.
  //
  // WHICH COLUMNS EXIST IS DERIVED, NOT RETRIED. The probe SELECT is built from
  // `columns` intersected with the table's actual column set — the same set this
  // path already probes — so a database missing an additive column simply does
  // not compare it, and one missing `statusCol` entirely has no approval feature
  // to enforce and is skipped. The hand-written "try the full SELECT, catch
  // errno 1054, try a shorter one" this replaces could only degrade in the one
  // shape somebody thought of.
  //
  // WHEN THAT SET IS UNKNOWN the columns are derived from the locked row
  // instead, because unknown is not absent: it is a probe that failed, and
  // reading it as "no status column here" turns an unreadable
  // `information_schema` into a silently disabled review gate. See the block
  // itself for why the answer comes from the row rather than from a retry.
  //
  // The POLICY — which statuses re-pend, and what NULL means — is NOT a mount
  // option: it lives in `edge/lib/review-status.js` so all five readers of the
  // column state it once.
  const repandOnSensitiveChange = opts.repandOnSensitiveChange || null;
  if (repandOnSensitiveChange) {
    const { statusCol, clearCols, columns, jsonColumns } = repandOnSensitiveChange;
    if (!isSafeColumnName(statusCol)) {
      throw new Error('[repandOnSensitiveChange]: statusCol fails column whitelist');
    }
    for (const c of [...(clearCols || []), ...(columns || []), ...(jsonColumns || [])]) {
      if (!isSafeColumnName(c)) {
        throw new Error(`[repandOnSensitiveChange]: ${c} fails column whitelist`);
      }
    }
    if ((!Array.isArray(columns) || columns.length === 0)
      && (!Array.isArray(jsonColumns) || jsonColumns.length === 0)) {
      throw new Error(
        '[repandOnSensitiveChange]: declared with no columns — a re-pend that watches nothing '
        + 'is a review gate that never fires, and nothing else would say so',
      );
    }
  }
  /**
   * Compare a JSON column's written value with its stored one by CONTENT.
   *
   * `jsonColumns` exist because the two operands are not the same
   * representation of the same document: the DTO mapper has already
   * re-serialised the written one, and the driver hands the stored one back
   * either parsed or raw depending on its configuration. A `!==` between those
   * answers "changed" on every save, which would re-pend a recipe whose author
   * only renamed it — a review gate that fires on everything is one an operator
   * learns to clear without looking. An unparseable value falls back to the raw
   * text, which is the honest answer for a document nothing can read.
   */
  // Opt-in delete gate: refuse the DELETE when a child table still references
  // this row. Shape: [{ table, fk, code, message }]. Forces the guarded-tx path
  // on for DELETE. Default empty ⇒ every mount that omits it is byte-identical.
  //
  // WHY IT IS HERE AND NOT IN A MIDDLEWARE. Both halves of a check-then-write
  // have to be under the same lock, and the mount that needed this ran an
  // unlocked `SELECT 1 … LIMIT 1` on `pool.ro` before the factory's transaction
  // even opened. A child inserted in that window was orphaned — and the mount's
  // own comment says why that matters: orphan step rows carry ENCRYPTED
  // CREDENTIALS and become unreachable to editors, because the ownership chain
  // needs the parent that no longer exists.
  //
  // It runs AFTER the ownership-scoped DELETE and refuses by rolling the
  // transaction back, so a caller who may not touch the row keeps getting the
  // 404 every other refusal on this path gives instead of learning from a 409
  // that it exists. The probe's `FOR UPDATE` is what makes it a gate rather than
  // an observation — see the call site.
  const refuseDeleteWhenReferenced = Array.isArray(opts.refuseDeleteWhenReferenced)
    ? opts.refuseDeleteWhenReferenced : [];
  for (const ref of refuseDeleteWhenReferenced) {
    if (!ref || !isSafeColumnName(ref.fk) || typeof ref.table !== 'string' || !ref.table) {
      throw new Error('[refuseDeleteWhenReferenced]: each entry needs a table and a safe fk column');
    }
    if (typeof ref.code !== 'string' || !ref.code) {
      throw new Error(`[refuseDeleteWhenReferenced]: ${ref.table} needs a stable error code`);
    }
  }
  const canonicalJsonValue = (v) => {
    if (v == null) return '';
    let o = v;
    if (typeof v === 'string') { try { o = JSON.parse(v); } catch { return v; } }
    try { return JSON.stringify(o); } catch { return String(v); }
  };
  // Additive-table tolerance for the list GET only. When set, ER_NO_SUCH_TABLE
  // (1146) on the SELECT degrades to an empty list instead of a 500, so a
  // Schema Builder open never 5xxes on an operator install whose boot migration
  // warn-skipped an additive engine table (blueprint_groups). Mirrors the
  // export path's selectBlueprintGroups 1146 tolerance. Write paths are
  // intentionally NOT covered: a write against a genuinely absent table is an
  // operator-misconfig that must surface, and there is no row to lose.
  const tolerateMissingTableOnList = opts.tolerateMissingTableOnList === true;
  // Write-time column validators (POST + PUT). Both default empty so every
  // mount that declares neither is byte-identical.
  //   slugColumns — columns whose value must match the identity-key slug shape
  //     (isValidSlugKey). Validated only when the column is present in the write
  //     body, so a partial PUT that omits the key is unaffected. Rejects with a
  //     stable 400 INVALID_KEY_FORMAT.
  //   enumColumns — { col: [allowed...] }. Validated whenever the column is
  //     PRESENT in the write body, including when its value is null (see
  //     enumNotNullColumns below). Rejects with a stable 400
  //     INVALID_COLUMN_VALUE. Read semantics are unchanged — this is a
  //     write-time gate only.
  const slugColumns = Array.isArray(opts.slugColumns) ? opts.slugColumns : [];
  for (const c of slugColumns) {
    if (!isSafeColumnName(c)) throw new Error(`[slugColumns]: ${c} fails column whitelist`);
  }
  const enumColumns = opts.enumColumns && typeof opts.enumColumns === 'object' ? opts.enumColumns : null;
  // The declared-domain columns on which a written NULL is itself a violation.
  //
  // DERIVED FROM THE DDL, NOT CHOSEN. "May this column be written null?" is a
  // question the schema already answers, and the two ways of answering it here
  // by hand are both wrong: refusing every null would break a nullable
  // enumerated column whose null is a legitimate value, and admitting every
  // null hands a NOT NULL column a value it cannot store — which arrives as a
  // 500 with a driver stack logged per request rather than as the stable 400
  // every other spelling of an unstorable value gets. So the rule is exactly
  // the column's own: a NULL is a violation precisely when the DDL declares the
  // column NOT NULL.
  //
  // A column whose nullability the DDL does not state is a question this gate
  // must not guess at, so the mount does not build at all — the same
  // require-time refusal a blocklist with no domain gets, and for the same
  // reason: a gate that cannot judge what it is admitting must not serve a
  // request.
  const enumNotNullColumns = new Set();
  if (enumColumns) {
    for (const c of Object.keys(enumColumns)) {
      if (!isSafeColumnName(c)) throw new Error(`[enumColumns]: ${c} fails column whitelist`);
      if (!Array.isArray(enumColumns[c])) throw new Error(`[enumColumns]: ${c} allowlist must be an array`);
      const nullable = columnNullabilityFor(logicalName, c);
      if (nullable === null) {
        throw new Error(
          `[enumColumns]: ${logicalName}.${c} declares a domain but table-ddls.js does not say `
          + 'whether the column accepts NULL (unknown column, or a line stating no nullability) — '
          + 'whether a written null is a violation cannot be derived, and this gate does not guess',
        );
      }
      if (nullable === 'NO') enumNotNullColumns.add(c);
    }
  }
  // The enumerated columns a CREATE must name, because the engine would
  // otherwise choose one by declaration order. Derived, never listed — see the
  // gate that consumes it in `checkWriteColumns`. `notNullNoDefaultColumnsFor`
  // answers null for a table the DDL does not describe, which reads here as
  // "require nothing": the mount already refuses to build for a domain whose
  // nullability it cannot read, so an undescribed table cannot reach this with
  // a declared domain at all.
  //
  // `enumOptionalOnCreate` is the one escape, and it is a DECLARATION rather
  // than a default: a mount whose column already has a guard owning the
  // omission names it, so the asymmetry is written down at the mount instead of
  // being inferred from the absence of a rule. The rule is on by default
  // because the failure it prevents is silent.
  const enumOptionalOnCreate = new Set(
    Array.isArray(opts.enumOptionalOnCreate) ? opts.enumOptionalOnCreate : [],
  );
  for (const c of enumOptionalOnCreate) {
    if (!isSafeColumnName(c)) throw new Error(`[enumOptionalOnCreate]: ${c} fails column whitelist`);
  }
  const enumRequiredOnCreate = new Set(
    (notNullNoDefaultColumnsFor(logicalName) || [])
      .filter((c) => enumColumns && Array.isArray(enumColumns[c]) && !enumOptionalOnCreate.has(c)),
  );
  // SECURITY — A BLOCKLIST NEEDS A DOMAIN, AND THIS IS WHERE THAT IS ENFORCED.
  //
  // `valueGuards.rejectFor` denies a role a list of values, and it decides with
  // a JavaScript comparison. The columns it guards are database ENUMs, and the
  // database's notion of "the same value" is not JavaScript's: an ENUM
  // comparison folds case and a trailing space under the column's collation, and
  // MariaDB additionally reads an INTEGER written to an ENUM column as a 1-BASED
  // MEMBER INDEX. So 'Category', 'CATEGORY', 'category ', 1, '1', true and
  // ['category'] are all stored as 'category' while being identical to nothing
  // in the list. A blocklist can only be trusted on a value already known to be
  // IDENTICALLY one of the column's members — which is precisely what an
  // `enumColumns` domain establishes, and why one is required here rather than
  // remembered at each mount. Building without it throws at require time: a
  // mount that cannot judge what it is denying must not serve a request at all.
  //
  // `acceptFor` (whitelist) and `numeric` need no domain: a whitelist refuses
  // anything not identically allowed, and the numeric guard checks the value's
  // own type and range — both are already closed against a value they cannot
  // read, which is the property `rejectFor` lacks by construction.
  if (valueGuards) {
    for (const [col, rules] of Object.entries(valueGuards)) {
      if (!rules || !rules.rejectFor) continue;
      const domain = enumColumns ? enumColumns[col] : undefined;
      if (!Array.isArray(domain) || domain.length === 0) {
        throw new Error(
          `[valueGuards]: ${logicalName}.${col} declares rejectFor with no enumColumns domain — `
          + 'a blocklist compared with JavaScript equality cannot judge a value the database '
          + 'folds into one of its entries (case, trailing space, integer member index)',
        );
      }
    }
  }
  // SECURITY — A BYTE COMPARE NEEDS A DOMAIN TOO, AND FOR THE SAME REASON.
  //
  // The re-pend decides "did something sensitive change" with `!==` against the
  // stored value, under a comment saying that is sound because every watched
  // column is either an ENUM whose written value the mount's own domain gate has
  // already proved is identically a member, or a column stored verbatim. That
  // sentence was true of two of the three mounts that declare this option and
  // false of the third: `flow_recipes` declared no `enumColumns` at all while two
  // of its three watched scalars are ENUMs, so `PUT {"content_type":
  // "application/JSON"}` reached the statement with the caller's spelling and
  // nothing had judged it.
  //
  // The failure DIRECTION there is safe — the engine folds the spelling, the
  // compare says "changed", and the row costs an extra review. What is not safe
  // is a justification nobody can check: this makes the premise a condition of
  // building the mount, so the next mount to watch an enumerated column without a
  // domain fails at require time instead of inheriting a comment that is wrong
  // about it. Asked of the DDL, so a column that becomes an ENUM later is caught
  // by the same rule.
  if (repandOnSensitiveChange) {
    const watchedCols = [
      ...(repandOnSensitiveChange.columns || []),
      ...(repandOnSensitiveChange.jsonColumns || []),
    ];
    for (const col of watchedCols) {
      if (!enumMembersFor(logicalName, col)) continue; // not enumerated: stored verbatim
      const domain = enumColumns ? enumColumns[col] : undefined;
      if (!Array.isArray(domain) || domain.length === 0) {
        throw new Error(
          `[repandOnSensitiveChange]: ${logicalName}.${col} is an ENUM this mount watches with `
          + 'no enumColumns domain — the change compare is a JavaScript `!==` against the stored '
          + 'member, and a spelling the database would fold reaches the statement unjudged',
        );
      }
    }
  }
  // trimmedNonEmptyColumns — columns that, when PRESENT in a write body, must
  // trim to a non-empty string. Present-only, exactly like slugColumns, so a
  // partial PUT that omits them is unaffected. Default empty ⇒ every mount
  // that omits it is byte-identical.
  const trimmedNonEmptyColumns = Array.isArray(opts.trimmedNonEmptyColumns) ? opts.trimmedNonEmptyColumns : [];
  for (const c of trimmedNonEmptyColumns) {
    if (!isSafeColumnName(c)) throw new Error(`[trimmedNonEmptyColumns]: ${c} fails column whitelist`);
  }
  // ── THE IDENTIFIER FLOOR ────────────────────────────────────────────────────
  //
  // The rule itself, and why a number reaching a CHAR(36) comparison resolves an
  // arbitrary set of rows, are in identifier-floor.js. What lives HERE is the
  // per-mount half: the domain is READ FROM THE DDL rather than listed at each
  // mount, the way `enumColumns` reads `enumMembersFor` — a per-mount list is a
  // second source of truth, and the first FK column added to a table would be
  // admitted with no shape check and nothing would say so.
  //
  // One exemption the shared rule does not need to state, because it is about
  // this factory's routing: `req.params.id` is not judged. Express hands a path
  // segment over as a STRING, so the numeric-coercion family cannot be reached
  // through it, and a malformed id already answers 404 — the existence-leak
  // parity every row-scoped route on this path keeps.
  const declaredIdentifierColumns = charColumnsFor(logicalName, UUID_CHAR_LENGTH);
  if (declaredIdentifierColumns === null) {
    // Same failure mode as an enumerated column whose nullability the DDL does
    // not state: a gate that cannot read its own domain must not serve a
    // request, so the mount does not build.
    throw new Error(
      `[identifierColumns]: table-ddls.js declares no table '${logicalName}', so which of its `
      + 'columns hold identifiers cannot be derived — this gate does not guess',
    );
  }
  // A mount that legitimately stores a non-UUID value in a CHAR(36) column says
  // so here, with a reason. Declared rather than discovered: the alternative is
  // finding out from a 400 in production on whichever column nobody thought
  // about. Every entry must name a column the DDL really declares CHAR(36), or
  // the mount does not build — an escape for a column that does not exist is an
  // escape nobody will notice has stopped applying.
  const nonUuidCharColumns = Array.isArray(opts.nonUuidCharColumns) ? opts.nonUuidCharColumns : [];
  for (const c of nonUuidCharColumns) {
    if (!declaredIdentifierColumns.includes(c)) {
      throw new Error(
        `[nonUuidCharColumns]: ${logicalName}.${c} is not declared CHAR(${UUID_CHAR_LENGTH}) in `
        + 'table-ddls.js — an escape naming a column that does not exist is an escape that has '
        + 'silently stopped applying',
      );
    }
  }
  const identifierColumns = declaredIdentifierColumns.filter((c) => !nonUuidCharColumns.includes(c));
  // Recorded as the mount is BUILT, so the question "which CHAR(36) columns does
  // this deployment's floor actually judge" has one answer that is read off the
  // running wiring instead of re-derived by searching for mount files. The
  // inventory test reads it; nothing at request time does. It is a list rather
  // than a map because a table mounted twice with two different escape lists is
  // itself something the inventory must be able to see.
  declaredCharColumnEscapes.push(Object.freeze({
    table: logicalName,
    declared: Object.freeze([...declaredIdentifierColumns]),
    exempt: Object.freeze([...nonUuidCharColumns]),
  }));
  // Blueprint-scoped uniqueness guard (POST + PUT). When set, a create/update
  // that would produce a second row with the same (scope, key) pair is rejected
  // with a stable 4xx before the write — the write-path complement to the DB
  // UNIQUE index (which only exists on DBs where the ALTER could run). Shape:
  //   { scope: 'blueprint_id', key: 'group_key', code: 'DUPLICATE_GROUP_KEY' }
  // The check runs inside the write transaction (uniqueWithin forces guardTx),
  // and errno 1062 from the index is mapped to the same code so both layers
  // surface one stable response.
  const uniqueWithin = opts.uniqueWithin || null;
  if (uniqueWithin) {
    if (!isSafeColumnName(uniqueWithin.scope) || !isSafeColumnName(uniqueWithin.key)) {
      throw new Error('[uniqueWithin]: scope/key fail column whitelist');
    }
    if (typeof uniqueWithin.code !== 'string' || !uniqueWithin.code) {
      throw new Error('[uniqueWithin]: code required');
    }
  }
  // Opt-in lightweight duplicate-key mapping (no pre-check, no forced
  // transaction — unlike uniqueWithin): when set, a DB UNIQUE-index violation
  // (errno 1062) on POST/PUT is mapped to a stable 409 with the given code +
  // message instead of a generic 500. Used where an app-layer pre-check already
  // returns the friendly 409 in the common case, and this is only the race
  // backstop for the rare TOCTOU insert (e.g. cap_rules' override uniqueness).
  const mapDuplicateKey = opts.mapDuplicateKey && typeof opts.mapDuplicateKey === 'object'
    ? {
        code: typeof opts.mapDuplicateKey.code === 'string' && opts.mapDuplicateKey.code
          ? opts.mapDuplicateKey.code : 'CONFLICT',
        message: typeof opts.mapDuplicateKey.message === 'string' && opts.mapDuplicateKey.message
          ? opts.mapDuplicateKey.message : 'This value conflicts with an existing row',
      }
    : null;
  // Opt-in in-transaction pre-write guard: an async hook
  // `(conn, req, data, { keys, isUpdate, id }) => { status, code, message } | null`
  // run INSIDE the write transaction (it forces
  // the guarded-tx path on) right after beginTransaction and BEFORE the
  // INSERT/UPDATE, on the SAME connection. A non-null return rolls the tx back and
  // responds with that error. CONTRACT: the guarantee is that a lock the hook takes
  // (e.g. a FOR UPDATE on a referenced row) is held across the subsequent write, so a
  // check-then-write validation cannot be invalidated by a concurrent delete between
  // the two — the hook and the write commit atomically. The factory stays
  // domain-agnostic; the hook is a caller-supplied closure.
  //
  // A HOOK IS HANDED THE OBJECT THE STATEMENT WILL BIND. It used to be handed
  // `req` and nothing else, which made every hook resolve the request a second
  // way — and the two ways disagree, because by the time a hook runs the factory
  // has already stripped the columns this caller may not write. A guard reading
  // `req.body.blueprint_id` on a mount that strips that column for every
  // non-administrator locked, and decided about, a blueprint the UPDATE was
  // never going to touch. `req` stays in the signature (a hook legitimately
  // needs the caller's identity and the verb), but reading a COLUMN value off
  // `req.body` is a review failure from here on: `data` is the answer.
  //   keys     — the columns this write carries that the physical table has, AS
  //              OF THE MOMENT THE HOOK RUNS. On a mount with a
  //              `transformCreateInTx` this is deliberately PRE-TRANSFORM: the
  //              transform runs after the hook, because it is documented to read
  //              rows the hook has just locked FOR UPDATE, and it adds
  //              server-derived columns (an appended `order_index`, a derived
  //              SGA) that are therefore not in this list. The same is true of
  //              the PUT side of a `codeVersioning` mount: the version bump is
  //              folded in after the hook, so the version column is in the
  //              UPDATE and not in this list. Stated rather than
  //              quietly implied: a hook that asked "does this write carry
  //              order_index" would be told "no" on the write that sets it, and
  //              a contract that is wrong at birth is worse than no contract.
  //              THE ONE RULE THAT HOLDS ON BOTH VERBS: this is what the REQUEST
  //              carries, never what the statement finally names.
  //   isUpdate — false on create
  //   id       — the row's id (the server-generated one on create)
  const preWriteInTx = typeof opts.preWriteInTx === 'function' ? opts.preWriteInTx : null;
  // Opt-in in-transaction CREATE transform: an async hook `(conn, req, data) =>
  // data` run INSIDE the create transaction (it forces the guarded-tx path on),
  // AFTER preWriteInTx (so it can read a row that guard just locked FOR UPDATE)
  // and BEFORE the column gate + INSERT, on the SAME connection. It returns the
  // (possibly mutated) `data` object used for the INSERT — the factory stays
  // domain-agnostic; a caller uses it to server-derive a column value from
  // locked context (e.g. a role-derived sga_gb, or an append order_index read
  // as MAX+1 in-tx). CREATE-ONLY: PUT is unaffected (it keeps its own
  // immutableColumns strip). Default no-op ⇒ every non-opting mount byte-identical.
  const transformCreateInTx = typeof opts.transformCreateInTx === 'function' ? opts.transformCreateInTx : null;
  // Opt-in in-transaction post-UPDATE cascade: an async hook `(conn, req, data) =>
  // void` run INSIDE the update transaction (it forces the guarded-tx path on),
  // AFTER the ownership-scoped UPDATE has matched a row (so an unauthorized PUT
  // 404s before the hook fires) and BEFORE commit, on the SAME connection. It
  // receives the COLUMN-GATED `data` — only the keys that were actually persisted
  // to the row (filtered to the physical column set, so a column absent on a
  // lagging schema is absent here too). A caller uses the present keys to decide
  // what to cascade — e.g. re-derive child db_instances.sga_gb when a database's
  // Primary/Standby SGA changes. UPDATE-ONLY: POST uses transformCreateInTx. A
  // throw rolls the whole tx back (child cascade and parent write commit or fail
  // together). Default no-op ⇒ every non-opting mount byte-identical.
  const postUpdateInTx = typeof opts.postUpdateInTx === 'function' ? opts.postUpdateInTx : null;
  // Opt-in delegated write. When set, a non-administrator's UPDATE matches a row
  // they do not own IF they hold a grant reaching it — the predicate is ORed
  // into the writeScopeColumn check rather than replacing it, so ownership keeps
  // working exactly as it did and a caller with neither still matches nothing.
  //
  // NOT GENERAL, and named so a reader is not misled into thinking it is: the
  // grant model it applies is the template one (a grant on the template, or on
  // the blueprint the template names), spelled out in `delegated-grants.js`.
  // A second table wanting delegation would need its own subject vocabulary,
  // not this flag.
  //
  // UPDATE ONLY. A create stamps the caller as owner and needs no delegation,
  // and a delete is not what a grant conveys — see the same module's note on
  // what a grant does not do.
  const delegatedTemplateWrite = opts.delegatedTemplateWrite === true;
  // Opt-in activity trail: a successful UPDATE records who made it, on the
  // record's own trail. Its own flag rather than a second meaning for the one
  // above — a mount could reasonably want one without the other, and a flag that
  // silently does two things is a flag whose next reader gets one of them by
  // accident. Best effort by construction: the writer logs a dropped row and
  // never raises, so this cannot fail the write it follows.
  const templateActivityTrail = opts.templateActivityTrail === true;
  /**
   * ABSENT — the object does not name this column at all, so the statement will
   * not carry it and the column takes whatever it takes for a value nobody
   * supplied. Distinct from every value, including `null`.
   */
  const ABSENT = Symbol('absent');
  /**
   * What the statement will bind for `col`, as a value a gate can judge.
   *
   * PRESENCE IS `hasOwnProperty`, NOT `!== undefined`, and the difference is a
   * real one. The two halves of the write path ask "is this column present" in
   * two different ways — the gates by `data[col] === undefined`, the statement
   * builder by `Object.keys` — so `{...data, col: undefined}` is INVISIBLE to
   * every gate and still writes the column, as SQL NULL (measured through this
   * deployment's driver; write-value.js says the same thing for the same
   * reason). A body cannot express that, but a hook, a serializer or the DTO
   * mapper can, and "no hook does it today" is the standard this rebuild exists
   * to stop relying on. So a key present with `undefined` is judged as the
   * `null` it will become, which is what every gate below already knows how to
   * answer.
   */
  function writtenValue(data, col) {
    if (!Object.prototype.hasOwnProperty.call(data, col)) return ABSENT;
    const v = data[col];
    return v === undefined ? null : v;
  }
  /**
   * The one place that decides whether a written value is IDENTICALLY a member
   * of a column's declared domain. Returns a { status, code, column, message }
   * error, or
   * null when the column has no domain / the value is ABSENT (unset ⇒ the
   * column's own default) / the value is a member / the value is null on a
   * column the DDL declares nullable.
   *
   * A NULL IS A VALUE HERE, NOT AN ABSENCE. `{"col": null}` names the column and
   * asks for NULL to be written; on a NOT NULL column that is a value the column
   * cannot hold, and refusing it here is what makes the answer the same stable
   * 400 that every other unstorable spelling gets instead of the driver error
   * that reaches the client as a 500 with a stack logged per request. Which
   * columns those are is read from the DDL (see enumNotNullColumns) — a nullable
   * enumerated column keeps accepting null exactly as before.
   *
   * Shared by `checkWriteColumns` (the role-agnostic column gate) and
   * `checkValueGuards` (the role-scoped guard) so the two can never come to
   * different conclusions about what counts as a member, and so the guard's
   * safety does not depend on which of the two the handler happens to call
   * first. Identity — not the database's equality — is the whole point: a value
   * that merely FOLDS to a member is one the guard above it cannot judge.
   */
  function enumViolation(data, col) {
    const allowed = enumColumns ? enumColumns[col] : undefined;
    if (!Array.isArray(allowed)) return null;
    const value = writtenValue(data, col);
    if (value === ABSENT) return null;
    if (value !== null && allowed.includes(value)) return null;
    const shown = allowed.map((a) => (a === '' ? '(empty)' : a)).join(', ');
    if (value === null) {
      if (!enumNotNullColumns.has(col)) return null;
      return {
        status: 400,
        code: 'INVALID_COLUMN_VALUE',
        column: col,
        message: `${col} may not be null; it must be one of: ${shown}`,
      };
    }
    return {
      status: 400,
      code: 'INVALID_COLUMN_VALUE',
      column: col,
      message: `${col} must be one of: ${shown}`,
    };
  }
  // Write-time column validation (identifier shape + slug + enum + trimmed).
  // Returns a { status, code, column, message } error object or null — `column`
  // is the column the refusal is ABOUT, carried as a field rather than left to
  // be read back out of the message, because the re-assertion below has to tell
  // a refusal about a column the client sent from one about a column this server
  // stamped, and parsing a sentence for a column name is not telling.
  // Shared by POST and
  // PUT. `requireTrimmedPresent` is POST-only: a create must not be able to
  // persist NULL by simply omitting a trimmedNonEmptyColumns entry (present-only
  // semantics stay correct for PUT, where a column can be legitimately absent
  // from a partial update).
  //
  // IT NORMALISES AS WELL AS JUDGES, and the two cannot be separated: a
  // validator that trims a value to decide and then lets the caller bind the
  // UNTRIMMED one has decided about a value the column will not hold. Measured —
  // the trailing space is physically stored; it only COMPARES equal because the
  // collation pads. So `'  Fitting'` passed the emptiness rule and persisted with
  // its spaces, and downstream the two layers then disagreed about identity:
  // SQL folds a trailing space and JavaScript does not, so a stored option value
  // is the same token to one of them and a different token to the other, and two
  // decision tables whose names differ by a leading space are two rows an
  // operator sees as one name. What this function trims is what the statement
  // binds, because `data` is the object the statement is built from.
  function checkWriteColumns(data, { requireTrimmedPresent = false } = {}) {
    // Before any other judgement, and before any query: a value that will be
    // bound to an identifier column — or used by a guard to resolve the row this
    // request is decided about — is a string of the identifier shape. See the
    // identifierColumns block above for why a number is not merely wrong here
    // but resolves an arbitrary set of rows.
    const identifierIssue = identifierFloorViolation(identifierColumns, data);
    if (identifierIssue) return identifierIssue;
    for (const col of slugColumns) {
      const slug = writtenValue(data, col);
      if (slug === ABSENT) continue;
      if (!isValidSlugKey(slug)) {
        return {
          status: 400,
          code: 'INVALID_KEY_FORMAT',
          column: col,
          message: `${col} must start with a lowercase letter and contain only lowercase letters, digits, and underscores`,
        };
      }
    }
    if (enumColumns) {
      for (const col of Object.keys(enumColumns)) {
        // A CREATE MUST NAME AN ENUM COLUMN THE ENGINE WOULD OTHERWISE CHOOSE
        // FOR IT. Measured (db-enum-omission-1500.md): under the deployed strict
        // sql_mode an INSERT that omits a NOT NULL ENUM with no declared DEFAULT
        // stores the FIRST DECLARED MEMBER, silently, with no error and no
        // warning — and declaring an explicit DEFAULT changes nothing about that
        // outcome. So on such a column "the caller did not say" becomes a value
        // nobody chose, picked by declaration order, and on a guarded column it
        // is the value the guard exists to forbid. The gate below judges a value
        // that is PRESENT; this is the door beside it.
        //
        // The column set is the DDL's answer, not a list: `enumRequiredOnCreate`
        // is every ENUM column this table declares NOT NULL with nothing the
        // engine can supply. A hand-written list would be a second source of
        // truth about a fact the schema already states, which is how the three
        // mounts that DID declare domains still let this through.
        if (requireTrimmedPresent && enumRequiredOnCreate.has(col)
          && writtenValue(data, col) === ABSENT) {
          return {
            status: 400,
            code: 'COLUMN_REQUIRED',
            column: col,
            message: `${col} is required; it must be one of: ${enumColumns[col].join(', ')}`,
          };
        }
        const err = enumViolation(data, col);
        if (err) return err;
      }
    }
    for (const col of trimmedNonEmptyColumns) {
      const v = writtenValue(data, col);
      if (v === ABSENT) {
        if (requireTrimmedPresent) {
          return {
            status: 400,
            code: 'EMPTY_NOT_ALLOWED',
            column: col,
            message: `${col} is required`,
          };
        }
        continue;
      }
      if (typeof v !== 'string' || v.trim().length === 0) {
        return {
          status: 400,
          code: 'EMPTY_NOT_ALLOWED',
          column: col,
          message: `${col} must not be empty or whitespace-only`,
        };
      }
      // The value this rule judged is the value the statement binds.
      data[col] = v.trim();
    }
    return null;
  }

  /**
   * The identifier-shape check `checkWriteColumns` runs for `col`, asked about
   * ONE value that never sat in `data` at all.
   *
   * The PUT handler captures `data[parentOwnership.via]` into
   * `requestedParentValue` and `delete`s it from `data` BEFORE calling
   * `checkWriteColumns` — so the identifier-floor check that every other
   * column on the same write receives never sees this one, and a numeric
   * `via` would otherwise reach `checkParentOwnership`'s chain SELECT as a
   * bare number against a CHAR(36) column (identifier-floor.js's RC-2). This
   * calls the SAME `identifierFloorViolation`, on a one-column view, so the
   * two call sites can never validate the shape differently — `col` only
   * participates when it is one of this mount's declared identifier columns,
   * exactly the membership `checkWriteColumns` itself is scoped to.
   */
  function checkIdentifierFormat(col, value) {
    return identifierFloorViolation(
      identifierColumns.filter((c) => c === col),
      { [col]: value },
    );
  }
  // S1/S2 linked-blueprint schema guard. When set, every write (POST/PUT/
  // DELETE) is rejected 409 if it targets a blueprint whose linked_blueprint_id
  // is non-null (schema is borrowed from a source, so it is read-only here).
  // Shape: { column: 'blueprint_id' } (direct FK) OR
  //   { fk, lookupTable, lookupIdCol, blueprintCol } (one-hop, e.g. field_options).
  const rejectIfParentLinked = opts.rejectIfParentLinked || null;
  if (rejectIfParentLinked) {
    const cfg = rejectIfParentLinked;
    const colsToCheck = cfg.column ? [cfg.column] : [cfg.fk, cfg.lookupIdCol, cfg.blueprintCol];
    for (const c of colsToCheck) {
      if (!isSafeColumnName(c)) {
        throw new Error(`[rejectIfParentLinked]: ${c} fails column whitelist`);
      }
    }
    // The one-hop form interpolates lookupTable into SQL via t(); pin it to the
    // TABLES allowlist (mirrors parentOwnership's chain-table validation).
    if (!cfg.column && !TABLE_VALUES.has(cfg.lookupTable)) {
      throw new Error(`[rejectIfParentLinked]: lookupTable=${cfg.lookupTable} not in TABLES allowlist`);
    }
  }
  // Returns true (and sends the 409) when the write must be blocked because its
  // target blueprint is linked. `data` is the create/update body (undefined for
  // DELETE — the row id drives the lookup).
  async function rejectLinkedParent(req, res, data) {
    if (!rejectIfParentLinked) return false;
    const conn = await (await resolveRwPool(req)).getConnection();
    try {
      // Check BOTH the row's current (stored) parent AND any incoming parent FK
      // in the body. Stored-parent → can't edit a row already under a linked
      // blueprint; incoming-parent → can't MOVE a row into a linked blueprint
      // (an admin keeps the body FK on update, so a reparent would otherwise
      // land schema rows under a linked blueprint).
      const ids = new Set();
      if (req.params.id != null) {
        const sid = await resolveLinkCheckBlueprintId(conn, logicalName, rejectIfParentLinked, undefined, req.params.id);
        if (sid) ids.add(sid);
      }
      const bid = await resolveLinkCheckBlueprintId(conn, logicalName, rejectIfParentLinked, data, null);
      if (bid) ids.add(bid);
      for (const id of ids) {
        if (await isBlueprintLinked(conn, id)) {
          sendError(req, res, null, { status: 409, code: 'LINKED_BLUEPRINT_READONLY', reason: 'Cannot edit the schema of a linked blueprint; edit the source blueprint instead' });
          return true;
        }
      }
    } finally {
      conn.release();
    }
    return false;
  }
  /**
   * The delegated-write predicate for THIS request, or null when it does not
   * apply — the mount did not opt in, or the caller is an administrator (who
   * never needed delegated access).
   *
   * Returning null rather than an always-false predicate is what keeps every
   * non-opting mount's statement byte-identical to what it was.
   *
   * A database with no grants table still gets a predicate, with the two arms
   * that read that table left out: the third arm — the blueprint's owner — reads
   * the hierarchy, which every database has, and their reach must not depend on
   * a table an operator account may not have been able to create.
   */
  async function grantWritePredicate(req, conn, writtenColumns, data) {
    if (!delegatedTemplateWrite) return null;
    if (!req.user || req.user.role === 'admin') return null;
    // R-3-P1: a plain user's write is scoped to writeScopeColumn alone (below
    // in buildPutScope) — there is no grant arm to widen it with, so the
    // predicate this returns is null rather than one whose grant arms this
    // caller could never satisfy on purpose.
    if (!grantEligibleRole(req.user.role)) return null;
    // callerRole re-states the same floor inside the predicate builder (the
    // check above already returns null for this request; this is defence in
    // depth against a future caller of buildTemplateAccessExists that forgets
    // its own floor, not a second decision this route makes).
    const { sql, paramCount } = buildTemplateAccessExists(`\`${t(logicalName)}\``, {
      includeGrants: await grantsTableAvailable(conn),
      callerRole: req.user.role,
    });
    const params = Array(paramCount).fill(req.user.id);
    // A write that carries the column the delegated arm's reach is derived from
    // may only proceed through that arm when it leaves the column where it is.
    // Otherwise a delegated writer could carry the record out from under the
    // blueprint whose owner delegated it, using the access that delegation
    // gave. `<=>` rather than `=` so a record with no blueprint compares as
    // equal to an incoming absence instead of matching nothing.
    //
    // WHERE is evaluated against the row as it stands, so the comparison is
    // between the STORED value and the incoming one — which is exactly the
    // question "is this write moving it".
    //
    // The owner's arm is untouched: re-filing their own record is theirs to do.
    // Keyed off the columns the statement will actually WRITE rather than off
    // the body: a column the physical table does not have is dropped by the
    // gate above, and naming it here would put a reference to a missing column
    // into the predicate on exactly the databases that are missing it.
    if (writtenColumns.includes(GRANT_SCOPE_COLUMN)) {
      return {
        sql: `(${sql} AND \`${GRANT_SCOPE_COLUMN}\` <=> ?)`,
        params: [...params, data[GRANT_SCOPE_COLUMN]],
      };
    }
    return { sql, params };
  }
  const writeGate = (req, res) => {
    if (writeScopeColumn) return requireAuth(req, res);
    if (writeRoles.has('editor')) return requireAdminOrEditor(req, res);
    return requireAdmin(req, res);
  };
  /**
   * SECURITY: refuse a write body that names a column in any case but the one
   * the column is declared in — see findNonCanonicalWriteKeys for why such a
   * key is written by the statement and read by none of the guards.
   *
   * IT RUNS AHEAD OF EVERY GUARD, not merely ahead of the strips. The value and
   * enum guards below decide by `data[col] === undefined`, and a mis-cased key
   * makes that read "the column is absent" — so the guard does not run at all
   * while the value still reaches the column. Placed after the write gate so an
   * unauthenticated or unauthorised caller keeps getting the answer they got
   * before, and never learns from this one that the mount is there.
   *
   * The shared column gate drops these keys too, which is what covers the write
   * paths that build their own statements. This is the answer: a body that is
   * silently written in part is a body whose author was told it landed.
   */
  const refuseNonCanonicalBody = (req, res) => {
    const cased = findNonCanonicalWriteKeys(req.body);
    if (!cased.length) return false;
    req.log.warn(
      // Bounded: the key names are caller-supplied text, so log a few of them,
      // truncated, and never their values.
      { table: logicalName, keys: cased.slice(0, 5).map((k) => k.slice(0, 64)), count: cased.length },
      'Refused a write body naming a column in another case on ' + logicalName,
    );
    // Names no column: which spelling collided with which column is a question
    // about the table, and the neighbouring 400s ('No valid fields to update')
    // do not answer questions about the table either.
    sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'Field names must be spelled as the column is declared (lower case)' });
    return true;
  };
  /**
   * @param {object} req
   * @param {object} data write body, already stripped of id/db/version
   * @param {{ isCreate?: boolean }} [opts] isCreate: the statement to follow is
   *   an INSERT, so a column absent from `data` is one the DATABASE will fill.
   */
  function checkValueGuards(req, data, { isCreate = false } = {}) {
    if (!valueGuards || !req.user) return null;
    for (const [col, rules] of Object.entries(valueGuards)) {
      // ABSENT when the object does not name the column; a key carrying
      // `undefined` reads as the `null` the statement will store (writtenValue).
      const value = writtenValue(data, col);
      // numeric — role-agnostic type/range check. A present value must be a
      // finite number within [min, max]; null is allowed only when allowNull.
      // Rejects a negative/NaN/non-numeric write (400) BEFORE it can persist —
      // e.g. an SGA that the phase-7 cascade would otherwise propagate into
      // existing child rows. (Runs alongside the role-keyed forms below.)
      const numeric = rules?.numeric;
      if (numeric && value !== ABSENT) {
        if (value === null) {
          if (!numeric.allowNull) {
            return { status: 400, code: 'VALUE_GUARD', column: col, message: `${col} may not be null` };
          }
        } else {
          const n = typeof value === 'number'
            ? value
            : (typeof value === 'string' && value.trim() !== '' ? Number(value) : NaN);
          if (!Number.isFinite(n)
              || (numeric.min != null && n < numeric.min)
              || (numeric.max != null && n > numeric.max)) {
            const bound = numeric.min != null ? ` >= ${numeric.min}` : '';
            return {
              status: 400, code: 'VALUE_GUARD', column: col, message: `${col} must be a finite number${bound}`,
            };
          }
          // `integer` — the column takes whole numbers only (e.g. every SGA
          // column). Refused rather than floored: the value cascades
          // into child rows, so the caller must see it rejected, not rewritten.
          if (numeric.integer && !Number.isInteger(n)) {
            return { status: 400, code: 'VALUE_GUARD', column: col, message: `${col} must be a whole number` };
          }
        }
      }
      // boolean — role-agnostic type check. PUT calls this TWICE on the SAME
      // data object (reassertWriteGates re-checks the object the UPDATE will
      // actually bind, AFTER mapRowToDb's own boolean coercion has already
      // run — see the comment above reassertWriteGates). A guard that only
      // accepted `true`/`false` would pass the client's raw `true` on the
      // first call and then refuse the SAME field's own coerced `1` on the
      // second, 500ing every write (WRITE_GATE_REASSERTION_FAILED). The
      // accepted set is therefore held IDENTICAL to BOOLEAN_COERCIBLE below
      // (dto-mapper.js's own truthy/falsy recognition) so a value this guard
      // passes on the client-facing call is still recognised once mapRowToDb
      // has rewritten it — anything outside that set (e.g. 'yes', 2, {}) is
      // refused on EITHER call.
      const booleanGuard = rules?.boolean;
      if (booleanGuard && value !== ABSENT) {
        if (value === null) {
          if (!booleanGuard.allowNull) {
            return { status: 400, code: 'VALUE_GUARD', column: col, message: `${col} may not be null` };
          }
        } else if (!BOOLEAN_COERCIBLE.has(value)) {
          return { status: 400, code: 'VALUE_GUARD', column: col, message: `${col} must be a boolean` };
        }
      }
      // rejectFor — blacklist semantic
      const forbidden = rules?.rejectFor?.[req.user.role];
      if (Array.isArray(forbidden) && forbidden.length > 0) {
        // SECURITY: ON CREATE, AN ABSENT COLUMN IS NOT "NO OPINION". The INSERT
        // names only the columns the body carried, so a column left out is one
        // the DATABASE chooses a value for — and for a NOT NULL ENUM with no
        // declared DEFAULT, MariaDB chooses the FIRST member. On
        // hierarchy_nodes.node_type that first member is 'category', the very
        // top tier this list denies an editor. Judging only what the body spells
        // is therefore a guard a caller walks past by not naming the column, the
        // same destination the mis-cased spelling reached by making a present
        // column read as absent. Both are "a column reaches the statement with
        // no guard having judged it", so both are closed here.
        //
        // Required rather than resolved: filling in what the database would have
        // chosen means keeping a second copy of the schema's defaults here, and
        // that copy goes wrong silently the first time the DDL moves. A role this
        // list names must say what it is creating.
        //
        // Create-only. On update the statement sets exactly the columns the body
        // carried, so an omitted column keeps its stored value and nothing
        // forbidden can land; requiring it there would refuse every partial edit.
        // An update that NAMES the column with a null is a different act and is
        // judged by the domain check below, which refuses it on a NOT NULL
        // column — this branch is about absence, not about storability.
        //
        // A role the list does not name (administrator, and any role with no
        // entry) never enters this branch — `forbidden` is undefined for them,
        // and their create keeps reaching the database exactly as before.
        // NULL IS THE SAME STATEMENT AS ABSENCE, and is required here for the
        // same reason. `{"node_type": null}` says "I am not choosing" just as
        // plainly as leaving the key out, and the write path treats it that way
        // too: the column takes whatever it takes for a value nobody supplied.
        // That the row happens not to land on THIS column is a fact about the
        // column being NOT NULL, not about this guard — against a nullable
        // guarded column carrying a DEFAULT, a body that named the column and
        // said nothing would take the default the list exists to deny.
        if (isCreate && (value === ABSENT || value === null)) {
          return {
            status: 403,
            code: 'VALUE_GUARD',
            column: col,
            message: `Role '${req.user.role}' must set ${col} explicitly when creating a row on this table`,
          };
        }
        if (value !== ABSENT && forbidden.includes(value)) {
          return {
            status: 403,
            code: 'VALUE_GUARD',
            column: col,
            message: `Role '${req.user.role}' may not set ${col}='${value}' on this table`,
          };
        }
        // SECURITY: EVERYTHING ABOVE IS A JAVASCRIPT COMPARISON, AND THE COLUMN
        // IS NOT COMPARED IN JAVASCRIPT. The list is four lower-case strings; the
        // column is a database ENUM that folds case and a trailing space under
        // its collation and reads an INTEGER as a 1-based member index. So
        // 'Category', 'CATEGORY', 'category ', 1, '1', true and ['category'] are
        // each identical to no entry in the list and each stored as 'category' —
        // the top tier the list exists to deny, reached by spelling rather than
        // by permission.
        //
        // The refusal is therefore not "this value is forbidden" but "this value
        // is not one this guard can judge": anything not IDENTICALLY a member of
        // the column's declared domain is refused before the comparison above is
        // trusted. The domain is required at construction (see the enumColumns
        // check at the top of this factory), so it is always present here.
        //
        // Deliberately repeated rather than left to the column gate that runs
        // after this one: which of the two runs first is an ordering the next
        // edit to a handler can change, and the guard must not be the thing that
        // silently stops holding when it does.
        const notAMember = enumViolation(data, col);
        if (notAMember) return notAMember;
      }
      // acceptFor — whitelist semantic.
      //
      // STRICT-REQUIRED: when acceptFor is set for a role, the column
      // MUST be present AND in the allowlist. Two rejection cases:
      //   (a) the column is ABSENT → role required to provide it
      //   (b) value present but not in allowlist → role provided wrong value
      //
      // NOTE: "absent = no opinion" is intentionally NOT the semantic here.
      // variant_overrides POST without `action` would persist a row with
      // undefined action, then FmbVariantPolicy crashes on
      // ACTION_ICONS[undefined]. The whitelist exists because the column
      // has a fixed enum the UI depends on — making it optional defeats
      // the guard.
      const allowed = rules?.acceptFor?.[req.user.role];
      if (Array.isArray(allowed) && allowed.length > 0) {
        if (value === ABSENT) {
          return {
            status: 403,
            code: 'VALUE_GUARD',
            column: col,
            message: `Role '${req.user.role}' must provide ${col}; allowed values: ${allowed.join(', ')}`,
          };
        }
        if (!allowed.includes(value)) {
          return {
            status: 403,
            code: 'VALUE_GUARD',
            column: col,
            message: `Role '${req.user.role}' may not set ${col}='${value}'; allowed values: ${allowed.join(', ')}`,
          };
        }
      }
    }
    return null;
  }

  /**
   * The columns THIS FACTORY writes itself, after both gates have judged the
   * body — column → where the value it stamps comes from.
   *
   * WHY THE MAP EXISTS: to make the re-assertion below say which of two
   * different things happened. Measured on a real database: a deployment whose
   * `users.id` values are not canonical uuids fails EVERY create on an
   * owner-stamped mount, because the owner stamp lands after the column gate ran
   * and the re-assertion is the first thing that sees it — and the line an
   * operator was handed said a write hook had rewritten the row. No hook was
   * involved, so that sentence sends them to read hooks that are not there while
   * the actual cause is the identity store. A wrong diagnosis printed with
   * authority is worse than none.
   *
   * It is not "which columns does the server own" (that is serverOnlyColumns,
   * a different question about what a CLIENT may send). It is "which columns
   * does the code between the gate and the statement assign", and it is built
   * from the mount's own options rather than written down, so a mount that stops
   * stamping stops being listed.
   */
  const serverStampedColumns = new Map();
  if (ownerColumn) {
    serverStampedColumns.set(
      ownerColumn,
      "the authenticated caller's own id (or, where a mount inherits ownership, the parent row's owner)",
    );
  }
  if (writeScopeColumn) {
    serverStampedColumns.set(writeScopeColumn, "the authenticated caller's own id");
  }
  if (codeVersioning) {
    serverStampedColumns.set(codeVersioning.versionColumn, 'the server-computed code-version counter');
  }
  /**
   * THE GATE VERDICT, RE-TAKEN AFTER EVERYTHING THAT CAN REWRITE `data`.
   *
   * Both write gates run on the parsed body long before the statement is built,
   * and three things may rewrite `data` in between — `serializeWrite`, the DTO
   * mapper, and (on create) `transformCreateInTx` — so anything one of them puts
   * into the object reaches the INSERT with no gate having judged it. That has
   * been latent rather than live: every serializer in the tree today was audited
   * and none writes an enumerated, guarded, slug or trimmed column. Nothing
   * PREVENTED the next one, and the ordering gave no warning; this is what turns
   * "audited safe today" into "cannot happen".
   *
   * IT COMPARES THE VERDICT, NOT THE KEY SET. A hook legitimately ADDS a column —
   * the run mount's serializer stamps `actor_id` on create, and that column is
   * simultaneously its write scope and on its immutable list. Asking "did any key
   * appear" would refuse that write; asking "would the gates still admit this
   * object" refuses only a hook that has moved the write past a decision that
   * already ran. The gates only ever refuse, so re-taking the verdict cannot
   * admit anything they refused the first time.
   *
   * Throws rather than answering the caller, and logs at error level so the
   * source location is auto-injected: a hook that rewrites a guarded column is a
   * defect in this server, not a bad request, and the transaction it is inside
   * rolls back.
   *
   * IT NAMES THE RIGHT CULPRIT. Two different failures arrive here and only one
   * of them is a hook (see serverStampedColumns above): the refused column is
   * either one something in the request path put there, or one this factory
   * stamped from the caller's identity — and the second is the one that fails
   * every create on a mount rather than one write, so it is the one an operator
   * is most likely to be reading about.
   */
  function reassertWriteGates(req, data, { isCreate }) {
    const err = checkValueGuards(req, data, { isCreate })
      || checkWriteColumns(data, { requireTrimmedPresent: isCreate });
    if (!err) return;
    const stampedFrom = err.column ? serverStampedColumns.get(err.column) : undefined;
    if (stampedFrom) {
      req.log.error(
        { table: logicalName, isCreate, gateCode: err.code, reason: err.message, column: err.column },
        `A value this server stamped onto ${logicalName}.${err.column} is one a write gate refuses`,
      );
      throw Object.assign(
        new Error(
          `server-stamped ${logicalName}.${err.column} fails the write gate: ${err.message}`
          + ` — the value comes from ${stampedFrom}, not from the request body and not from a hook`,
        ),
        { code: 'SERVER_STAMP_REJECTED_BY_WRITE_GATE', column: err.column },
      );
    }
    req.log.error(
      { table: logicalName, isCreate, gateCode: err.code, reason: err.message, column: err.column },
      'A write hook rewrote ' + logicalName + ' past a gate that had already run',
    );
    throw Object.assign(
      new Error(`write-gate re-assertion failed on ${logicalName}: ${err.message}`),
      { code: 'WRITE_GATE_REASSERTION_FAILED' },
    );
  }

  /**
   * Chain DSL — verify the editor owns (or shares) the row resolved by
   * walking the FK chain from `parentValue`. Returns true to
   * allow, false to deny. Admin always allowed; admin-only sites that
   * omit `parentOwnership` opt are not affected.
   *
   * Walks the chain by issuing a single SELECT with N-1 JOINs and reads
   * the terminal hop's readOwner column. NULL → shared (allowed for any
   * editor). Chain breaking (any intermediate hop missing) → 0 rows → 403.
   */
  // Whether the parentOwnership gate applies to a row of this node_type. A
  // mount with no whenNodeType gates every row. A scoped mount gates only its
  // named type — but a caller that cannot name the row's type (undefined) is
  // judged, not skipped, so a reparent/pre-write path fails closed rather than
  // waving a row through unchecked.
  function parentOwnershipInScope(nodeType) {
    if (!parentOwnership || !parentOwnership.whenNodeType) return true;
    if (nodeType === undefined) return true;
    return nodeType === parentOwnership.whenNodeType;
  }

  async function checkParentOwnership(req, conn, parentValue, nodeType) {
    if (!parentOwnership) return true;
    if (!req.user) return false;
    if (req.user.role === 'admin') return true;
    if (req.user.role !== 'editor') return false;
    // Out-of-scope rows on a node_type-scoped mount are not gated by the chain
    // (a blueprint's parent is a release an editor never owns). Every caller
    // inherits this one test, so the POST gate carries no duplicate node_type
    // compare and the reparent/pre-write callers pick it up for free.
    if (!parentOwnershipInScope(nodeType)) return true;
    if (parentValue == null) return false;
    const sql = buildChainSelectSql(parentOwnership.chain, parentOwnership.parentNodeType);
    const params = parentOwnership.parentNodeType
      ? [parentValue, parentOwnership.parentNodeType]
      : [parentValue];
    const rows = await conn.query(sql, params);
    if (!rows.length) return false;
    const ownerId = rows[0].owner_id;
    if (ownerId == null) return true; // shared — any editor may act
    // collation-compare: "does this column name the caller" is a question about
    // a COLUMN, and every other enforcement point on the same owner asks SQL —
    // the CRUD write scope's `AND (owner_id IS NULL OR owner_id = ?)`, the
    // chain EXISTS appended to the UPDATE, the delegated-grant probe. All of
    // them fold case, so a `===` here refused the GENUINE owner a parent every
    // statement in the system calls theirs, on every mount that declares
    // `parentOwnership`. The table asked is the chain's TERMINAL hop, which is
    // where `readOwner` was read from, so the question and the read cannot end
    // up aimed at different columns.
    const terminal = parentOwnership.chain[parentOwnership.chain.length - 1];
    if (await sameStoredValue(conn, t(terminal.table), terminal.readOwner, ownerId, req.user.id)) {
      return true;
    }
    // spec §6.1: after owner/admin denies, a blueprint-scope grant on the home
    // blueprint admits the create — the POST twin of the "OR grant" arm the
    // DELETE predicate carries (buildChainBlueprintGrantExistsForRow), so a
    // grantee cannot be admitted to create under X yet refused to delete what
    // they created. Reuses the shared resolver so the grant EXISTS has one
    // spelling, not a POST-only copy.
    //
    // INVARIANT: keys on `parentValue` because `blueprintGrantScope` is only set
    // on single-hop-to-blueprint chains whose `via` IS the blueprint id
    // (api_connectors, blueprint_fields, and hierarchy_nodes' variant rows whose
    // `via` is parent_id = the home blueprint — variant_overrides sets the flag
    // but custom-routes POST, so never reaches here). callerHasBlueprintGrant
    // re-asserts `node_type='blueprint'` on that id, so a multi-hop `via` fails
    // closed rather than granting through a non-blueprint parent.
    //
    // For hierarchy_nodes this POST arm admits a grantee's variant CREATE; the
    // matching rename and delete stations are the widened ownerColumn arm in
    // buildPutScope (a granted variant's own owner_id is the foreign blueprint
    // owner, so the bare owner arm is OR'd with a grant EXISTS) and the custom
    // DELETE route's mayActOnHierarchyNode (routes-hierarchy.js) — so a grantee
    // admitted to create is never refused the rename/delete of what they made.
    if (blueprintGrantScope) {
      return callerHasBlueprintGrant(conn, req.user.id, parentValue, req.user.role);
    }
    return false;
  }

  /**
   * The editor PUT/DELETE chain-existence gate, shared by buildPutScope and
   * buildDeleteScope: the row's parent (via the FK chain) must be owned/shared,
   * OR — on a blueprintGrantScope mount with the grants table present — covered
   * by a blueprint grant on the terminal blueprint. Returns { sql, params } to
   * append as `AND ${sql}`. The grant arm is added ONLY when the grants table is
   * present, so the statement is byte-identical on a DB without it.
   *
   * Used only by mounts that do NOT scope by node_type; a scoped mount folds the
   * same owner/grant question into its ownerColumn arm (buildPutScope) because a
   * scoped row's own owner_id already reflects its parent's owner, and routes
   * its delete through a custom handler (hierarchy_nodes).
   */
  const parentOwnershipScopeFragment = async (req, conn) => {
    const ownerExists = buildChainExistsForRow(parentOwnership.chain, logicalName, parentOwnership.via);
    if (blueprintGrantScope && await grantsTableAvailable(conn)) {
      const grantExists = buildChainBlueprintGrantExistsForRow(
        parentOwnership.chain, logicalName, parentOwnership.via,
      );
      return { sql: `(${ownerExists} OR ${grantExists})`, params: [req.user.id, req.user.id] };
    }
    return { sql: ownerExists, params: [req.user.id] };
  };

  /**
   * The columns of a write that NAME ANOTHER ROW, and the table each names it in.
   *
   * TWO SOURCES, AND THE SECOND ONE IS THE ANSWER. The options that declare a
   * parent — `inheritOwnerFromParent`, `parentOwnership`, `parentRepend` — were
   * the only source, on the reasoning that a mount which gains a parent gains
   * the rule with it. That reasoning is sound about a different question. Those
   * options answer "which row decides whether this caller may write"; this rule
   * is about "which values must be stored as the spelling the referenced row
   * carries", and a column can be the second without being the first.
   * `user_templates` is five such columns and declares none of the three
   * options, so it got no binding at all while the front end read its
   * `parent_id` and `blueprint_id` back with `===`.
   *
   * So the membership now comes from `row-references.js`, which is keyed on the
   * TABLE and checked against the DDL by a test — and the option-derived set is
   * still merged in beneath it. The merge is deliberate rather than belt-and-
   * braces cosmetics: it makes this change incapable of REMOVING a binding that
   * exists today, so a mistake in the new map can only fail to add one, and the
   * test above it is what catches that.
   */
  const parentReferenceColumns = (() => {
    const byColumn = new Map();
    const add = (column, table) => {
      if (!column || !isSafeColumnName(column) || byColumn.has(column)) return;
      byColumn.set(column, { column, table });
    };
    for (const [column, table] of Object.entries(referencesFor(logicalName) || {})) {
      add(column, table);
    }
    // A self-parent (hierarchy_nodes.parent_id names another hierarchy_node).
    if (inheritOwnerFromParent) add(inheritOwnerFromParent.via, logicalName);
    if (parentOwnership) add(parentOwnership.via, parentOwnership.chain[0].table);
    if (parentRepend) add(parentRepend.via, parentRepend.table);
    return [...byColumn.values()];
  })();
  // Every table this factory is mounted on, recorded as it registers. The
  // coverage test reads it rather than re-deriving "which tables are served"
  // from the call sites, because a mount added in a file nobody grepped is
  // exactly the case a hand-derived list misses.
  servedTables.add(logicalName);

  /**
   * Rewrite every parent reference the write carries to the id the parent row
   * actually holds.
   *
   * WHY A WRITE NEEDS THIS AND A GATE DOES NOT. Every gate on these columns asks
   * SQL — the ownership chain's JOIN, the linked-blueprint probe, the FK's own
   * `WHERE id = ?` — and `id` is `CHAR(36)` under a case-folding collation, so
   * all of them resolve the parent for ANY spelling of its id and pass. The
   * statement then stored the spelling the body sent.
   *
   * `parent_id` is read back by the front end as `.find(n => n.id ===
   * node.parent_id)`, so a column holding a spelling no node's id carries drops
   * the whole branch out of the tree — while every SQL reader goes on resolving
   * it and reports the row as healthy. The reparent route was fixed to bind the
   * stored id; the CREATE, which reaches the same column through the same body,
   * was not, and it is the verb that puts the row there in the first place.
   *
   * A value naming no row is left exactly as it was: whether that is a refusal
   * is the FK guards' question, not this one's, and rewriting it would only
   * change which error the caller is told about.
   */
  async function bindStoredParentIds(conn, data) {
    for (const { column, table } of parentReferenceColumns) {
      const value = data[column];
      const stored = await storedRowId(conn, table, value);
      if (stored != null) data[column] = stored;
    }
  }

  /**
   * The column this mount records ownership in, ENUMERATED BY COLUMN rather than
   * by which option declares it.
   *
   * A sweep keyed on `ownerColumn` closed three mounts and missed a fourth,
   * because `user_templates` spells the same column `writeScopeColumn`. The two
   * options mean different things about READING — one gates by owner, the other
   * scopes writes — but they name the same kind of value, a `users.id`, and this
   * is the rule about the VALUE.
   */
  const ownerIdentityColumns = [...new Set(
    [ownerColumn, writeScopeColumn].filter((c) => c && isSafeColumnName(c)),
  )];

  // A mount whose owner column an administrator's PUT can still move should run
  // that PUT in a transaction, so the handover and the audit line recording it
  // land together or not at all. Today `flow_recipes` is the only mount in that
  // condition — every other owner-bearing mount declares its owner column
  // immutable and transfers through a dedicated endpoint — and it satisfies this
  // because it declares `codeVersioning`. That is a coincidence of two unrelated
  // options, which is the kind of fact that stops being true unnoticed.
  //
  // HELD BY A TEST OVER THE REAL WIRING (`owner-transfer-atomicity.test.js`)
  // rather than by a throw here. A registration-time refusal would also fire on
  // the synthetic mounts several suites build to probe unrelated behaviour —
  // pagination counting, write-gate re-assertion, guard-domain parity — forcing
  // each of them to declare an option it is not about, which changes what they
  // measure. The shape is recorded instead, and the test reads it.
  const putRunsInTransaction = !!rejectIfParentLinked || !!parentRepend || !!uniqueWithin
    || !!codeVersioning || !!preWriteInTx || !!postUpdateInTx;

  // Whether anything on a write path takes a lock BEFORE the statement whose
  // predicate is the authorization. Only then is there anything to gate, so a
  // mount that locks nothing keeps its path byte-identical.
  //
  // HOISTED TO THE MOUNT, not because either handler needed it earlier, but
  // because both handlers computed it from these same mount constants and the
  // parity suite has to read the same answer the request path acts on. A copy
  // in the suite would be a second derivation of exactly the kind this whole
  // line of work exists to remove.
  //
  // `postUpdateInTx` is deliberately absent from the update arm: it runs after
  // the UPDATE has matched. `serializeWriteInTx` is deliberately present — the
  // mounts that declare it read the row `FOR UPDATE` on this connection, and a
  // hook the factory hands its write connection to inside a transaction is a
  // hook that may lock whatever it likes.
  const locksBeforeUpdate = !!rejectIfParentLinked || !!parentRepend || !!uniqueWithin
    || !!codeVersioning || !!preWriteInTx || !!serializeWriteInTx || !!repandOnSensitiveChange;
  const locksBeforeDelete = !!parentRepend || refuseDeleteWhenReferenced.length > 0;
  // FAIL-CLOSED, AT MOUNT TIME. The PUT handler's entitlement 404 (the block
  // guarded by `if (locksBeforeUpdate)` below) only runs when this mount also
  // takes a lock somewhere on the write; a `parentOwnership` mount with none
  // of the options that feed `locksBeforeUpdate` skips straight to the
  // ownership-scoped 403 (`checkParentOwnership` on a client-supplied
  // `parentOwnership.via`), which answers "parent row is not owned by you"
  // for a row this caller may not even be entitled to know exists —
  // existence-leak ahead of the 404 every other refusal on this path gives.
  // Registration is the right place to close this: it costs nothing on the
  // request path and a future mount cannot add `parentOwnership` alone and
  // ship the ordering hazard unnoticed.
  //
  // EXEMPT when `parentOwnership.via` is ALSO in `immutableColumns` (the
  // capacity scenario_id shape): `parentViaProvided` further down is
  // unconditionally false for that column (see its own guard), so the
  // ownership-403 branch it feeds can never run for ANY role on this mount —
  // there is no 403 left to race the 404. Every capacity child mount already
  // carries this shape AND a lock trigger (preWriteInTx/makeScenarioRowLock)
  // regardless, so this exemption only matters for a lock-free mount that
  // deliberately disables rebind entirely.
  const parentViaIsImmutable = !!(parentOwnership && immutableColumns.includes(parentOwnership.via));
  if (parentOwnership && !locksBeforeUpdate && !putShadowedByCustomRoute && !parentViaIsImmutable) {
    throw new Error(
      `[parentOwnership]: ${logicalName} declares parentOwnership with no lock-taking option `
      + '(rejectIfParentLinked / parentRepend / uniqueWithin / codeVersioning / preWriteInTx / '
      + 'serializeWriteInTx / repandOnSensitiveChange), no putShadowedByCustomRoute, and '
      + 'parentOwnership.via is not in immutableColumns — the PUT entitlement 404 only runs when '
      + 'locksBeforeUpdate is true, so this mount would answer the parentOwnership 403 before any '
      + 'existence check.',
    );
  }
  // WHAT THIS MOUNT DECLARES, recorded as it is built.
  //
  // Every field below is the RESOLVED option, not the text that produced it. A
  // reader that parses the mount files instead sees fourteen of these
  // twenty-seven mounts: the capacity children and the local catalogues are
  // built by two loops over a config object, with a computed table name and
  // their guard sets spread in from a map, so a source parser either skips them
  // or has to evaluate the module anyway. Thirteen mounts silently outside the
  // corpus is the shape of blindness the parity suite exists to end, so the
  // mount is built and asked.
  //
  // Recorded here rather than thrown on, for the reason the transaction shape
  // above states: several suites build synthetic mounts to probe unrelated
  // behaviour, and a registration-time refusal would force each of them to
  // declare options they are not about.
  mountShapes.set(logicalName, {
    ownerIdentityColumns: [...ownerIdentityColumns],
    immutableColumns: [...immutableColumns],
    putRunsInTransaction,
    // The write-time value gates, as the request path holds them.
    enumColumns: enumColumns ? Object.fromEntries(
      Object.entries(enumColumns).map(([c, members]) => [c, [...members]]),
    ) : {},
    enumOptionalOnCreate: [...enumOptionalOnCreate],
    slugColumns: [...slugColumns],
    trimmedNonEmptyColumns: [...trimmedNonEmptyColumns],
    // STRING-shaped guards only (rejectFor/acceptFor compare string values) —
    // the write-path-parity "no value gate is aimed at a column that does not
    // store a string" check reads this list. `numeric`/`boolean` are
    // deliberately excluded: a numeric or boolean guard is aimed AT a numeric
    // or boolean column by design, so listing it here would make that check
    // flag its own correct pairing (name_locked/boolean, cap-renumber-lock).
    valueGuardColumns: valueGuards
      ? Object.entries(valueGuards)
        .filter(([, rules]) => rules && (rules.rejectFor || rules.acceptFor))
        .map(([col]) => col)
      : [],
    // The strips: what a body may never name on each verb.
    serverOnlyColumns: [...serverOnlyColumns],
    // The identifier floor's per-mount half.
    nonUuidCharColumns: [...nonUuidCharColumns],
    // Whether a grant can widen this mount's write scope beyond its own owner.
    delegatedTemplateWrite,
    // THE CAPABILITY VECTOR — which kinds of check this lane runs at all,
    // derived from the options rather than declared a second time. Two lanes
    // that are meant to be mirrors of each other can then be compared without
    // anybody re-stating what each one does.
    capabilities: Object.freeze({
      locks: Object.freeze({ update: locksBeforeUpdate, delete: locksBeforeDelete }),
      referenceCheck: refuseDeleteWhenReferenced.length > 0,
      duplicateCheck: !!uniqueWithin || !!mapDuplicateKey,
      auditRow: !!templateActivityTrail || !!codeVersioning,
      stripsOnCreate: serverOnlyColumns.length > 0,
      stripsOnUpdate: serverOnlyColumns.length > 0 || immutableColumns.length > 0,
      degradationFallback: tolerateMissingTableOnList,
    }),
  });

  /**
   * A client-supplied owner is the id of a REAL USER, spelled the way that user
   * row spells it — or the write is refused.
   *
   * WHERE A CLIENT VALUE STILL REACHES THE COLUMN. Every non-admin path already
   * removes it: `ownerColumn` is server-stamped on create and stripped from a
   * non-admin update, `writeScopeColumn` is overwritten with the caller's own id
   * on a non-admin write. What is left is the ADMINISTRATOR, whose value is
   * taken verbatim — with no check that it names a user at all, let alone the
   * spelling that user's row carries.
   *
   * Both halves matter and neither covers the other. `users.id` is `CHAR(36)`
   * under a case-folding collation, so a respelled id leaves the row owned, to
   * SQL, by someone whom no JavaScript reader of the column can find — the split
   * this card exists to close. And a value that is not a user id at all leaves
   * the row owned by nobody, unreachable through every owner-scoped read, with
   * no route left to repair it.
   *
   * NULL PASSES THROUGH: on a mount whose column is nullable that is "shared",
   * a decision the mount makes and not this rule's to overrule.
   *
   * AND THE TARGET MUST BE ABLE TO HOLD THE RECORD. Resolving the id is one of
   * the three facts a dedicated transfer endpoint establishes; the other two are
   * that the new owner may act on this kind of record at all, and that the
   * handover was recorded. `immutableColumns: ['owner_id']` gives the mounts
   * that HAVE such an endpoint exactly one route to a transfer — but
   * `flow_recipes` has no such endpoint, so its generic PUT is the only way its
   * owner can ever change, and it did neither of the other two. Handing a recipe
   * to a plain `user` left it owned by somebody the mount's own role gate then
   * refuses, i.e. a record nobody can edit, with nothing recording how it got
   * that way.
   *
   * THE ELIGIBLE ROLES ARE THE MOUNT'S OWN `allowedRoles`, not a list repeated
   * here. A mount that admits only admins and editors cannot have a useful owner
   * outside that set — which is precisely the "must be admin or editor" the
   * dedicated endpoints spell out one by one — and a mount with no `allowedRoles`
   * (`user_templates`, `flow_recipe_runs`) is owned by ordinary users by design,
   * so deriving the rule leaves those alone instead of breaking them.
   *
   * @returns {Promise<{rejection: object|null, transfers: Array}>} `transfers`
   *   lists the owner columns whose stored value this write will actually MOVE,
   *   for the caller to record once the statement has matched a row. Empty on a
   *   create and on any write that does not carry a client-chosen owner.
   */
  async function bindStoredOwnerId(conn, data, clientOwnerValues, rowId = null) {
    const transfers = [];
    for (const column of ownerIdentityColumns) {
      if (!Object.prototype.hasOwnProperty.call(data, column)) continue;
      const value = data[column];
      if (value == null) continue;
      // ONLY A VALUE THE CLIENT CHOSE. A server-stamped owner is the actor's own
      // id, already resolved by the authentication path, and re-validating it
      // here would make an ordinary create conditional on the actor having a
      // `users` row — refusing writes this rule has nothing to say about. The
      // test for provenance is that the value is still the one the body sent:
      // every server stamp on these columns REPLACES it.
      if (!clientOwnerValues || clientOwnerValues.get(column) !== value) continue;
      const target = await resolveCanonicalUserId(conn, t(TABLES.USERS), value);
      if (!target.ok) {
        // One mapping for every route that asks the shared resolver, so an
        // administrator gets the same sentence whichever record they transfer.
        // This site had its own, written before the resolver learned to refuse a
        // BANNED account, and it folded every reason but `ambiguous` into "must
        // be the id of an existing user" — so an administrator saving a record
        // whose owner had since been banned was told that owner does not exist,
        // about an account they can see in the user list.
        //
        // The column name goes with it, deliberately: `ownerIdentityColumns` is
        // the mount's owner column, the message already says the value must be a
        // user, and a sentence that varies by mount is the thing the shared map
        // exists to stop.
        return { rejection: ownerTargetRejection(target.reason), transfers };
      }
      // The role came back with the id, so this costs no query. The sentence is
      // the dedicated endpoints' own, because it is their rule.
      //
      // ONLY ON AN `ownerColumn`. The two options in `ownerIdentityColumns` name
      // the same kind of value and mean opposite things about who may hold it.
      // `ownerColumn` gates writing on the mount's own role set, so an owner
      // outside that set owns a record they cannot touch. `writeScopeColumn` is
      // the BYPASS of that gate — it is what lets an ordinary user write their
      // own rows on a mount whose `allowedRoles` defaults to admin — so on those
      // mounts every authenticated role is a legitimate owner, and reading
      // `writeRoles` there would refuse a plain user their own template.
      const roleGated = column === ownerColumn && column !== writeScopeColumn;
      if (roleGated && writeRoles && !writeRoles.has(target.role)) {
        return {
          rejection: {
            status: 400,
            code: 'BAD_REQUEST',
            message: `Owner must be ${[...writeRoles].sort().join(' or ')}`,
          },
          transfers,
        };
      }
      // What the row holds now, read ONLY when the write actually carries an
      // owner the client chose — which is an administrator's transfer, not an
      // ordinary save. Gating the read on that keeps every other PUT free of an
      // extra locked round trip. `FOR UPDATE` so the value recorded below is the
      // one this transaction replaces.
      if (rowId != null) {
        const priorRows = await conn.query(
          `SELECT \`${column}\` AS prior FROM \`${t(logicalName)}\` WHERE id = ? FOR UPDATE`,
          [rowId],
        );
        const prior = priorRows.length ? priorRows[0].prior : null;
        // BYTE comparison, and deliberately not the collation one used to decide
        // ownership. The question here is not "who owns this row" but "will the
        // statement move the stored bytes", and the UPDATE binds `target.id`
        // verbatim — a case-only rewrite really does replace the value, so
        // asking the collation would report "nothing happened" about a write
        // that changes which JavaScript readers can find the owner. Same
        // reasoning, and the same direction, as `applyOwnerChange`.
        if (prior !== target.id) {
          transfers.push({ column, priorOwner: prior ?? null, newOwner: target.id });
        }
      }
      data[column] = target.id;
    }
    return { rejection: null, transfers };
  }

  /**
   * The trail an owner handover leaves on a mount whose only transfer route is
   * the generic PUT. Written INSIDE the write transaction, matching
   * `applyOwnerChange` (the dedicated endpoints' shared helper) rather than the
   * activity trail below it: an ownership change and its record have to land
   * together or not at all, whereas the activity trail is a note about a change
   * that has already committed.
   */
  async function recordOwnerTransfers(conn, req, rowId, transfers) {
    if (!transfers.length) return;
    // SECURITY: allowlist the role so a spoofed claim cannot land an arbitrary
    // string in the audit metadata — the same guard every other audit writer on
    // this path uses.
    const actor = req.user || {};
    const safeRole = ['admin', 'editor', 'user'].includes(actor.role) ? actor.role : 'unknown';
    for (const transfer of transfers) {
      await conn.query(
        `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata)
         VALUES (?, ?, ?, ?)`,
        [
          uuidv4(),
          // The logical table name rather than a singular noun. The dedicated
          // endpoints each name their own event, and inventing a singular for an
          // arbitrary mount would be guesswork; the table is the one stable,
          // predictable string an audit consumer can derive for itself.
          `${logicalName}.owner.transfer`,
          actor.id || null,
          JSON.stringify({
            row_id: rowId,
            action: 'transfer',
            column: transfer.column,
            old_owner_id: transfer.priorOwner,
            new_owner_id: transfer.newOwner,
            actor_role: safeRole,
          }),
        ],
      );
    }
  }

  /**
   * The owner values THE BODY SENT, captured before any server stamp replaces
   * them, so the rule above can tell a value a client chose from one this server
   * put there.
   */
  function readClientOwnerValues(body) {
    const out = new Map();
    if (!body || typeof body !== 'object') return out;
    for (const column of ownerIdentityColumns) {
      if (Object.prototype.hasOwnProperty.call(body, column)) out.set(column, body[column]);
    }
    return out;
  }

  /**
   * The FK a stored row hangs off, read on the write connection so the answer
   * belongs to the same transaction as the check that uses it. Only reached on
   * a PUT whose body does not carry the FK itself (a PATCH-style update).
   */
  async function readOwnParentValue(conn, viaColumn, rowId) {
    if (!isSafeColumnName(viaColumn) || rowId == null) return null;
    const rows = await conn.query(
      `SELECT \`${viaColumn}\` AS parent_value FROM \`${t(logicalName)}\` WHERE id = ?`,
      [rowId],
    );
    return rows.length ? rows[0].parent_value : null;
  }

  // SECURITY: re-pend a parent recipe so an approved/rejected parent cannot
  // silently keep its approval after a child step is created/edited/deleted.
  // Runs INSIDE the caller's write transaction on the SAME conn, with the
  // parent row locked FOR UPDATE — this closes the TOCTOU where a concurrent
  // admin approve could land between the step write and a separate re-pend,
  // leaving an approved recipe with a swapped step. Non-admin callers only
  // re-pend a parent they own or that is shared (owner_id IS NULL); admins
  // re-pend unconditionally. Fail-safe: a missing column (errno 1054) or table
  // (errno 1146) is swallowed so the child write still succeeds on a DB whose
  // approval columns are not yet migrated.
  //
  // AND IT REPORTS A PARENT THAT IS NOT THERE, because this is the only point in
  // the child's transaction that asks about the parent AT ALL. The delete gate on
  // the other side claimed its gap lock meant a child inserted into the range it
  // just found empty "waits for this transaction instead of landing behind it and
  // being orphaned". It waits — and then it lands, and it is orphaned, because
  // nothing re-checked the parent after the wait. Measured through the routes:
  // 20 of 20 concurrent (recipe DELETE, step POST) pairs left a step whose parent
  // no longer exists, carrying an encrypted credential and unreachable to any
  // editor, since the ownership chain needs the parent that is gone. The same
  // end state needs no concurrency at all: an admin POST naming a recipe_id that
  // never existed took the identical route, because `checkParentOwnership`
  // returns true for an admin without querying and there is no foreign key.
  //
  // Reported rather than refused here: this function is also called from the
  // DELETE path, where a vanished parent is not a reason to refuse — the caller
  // is removing the child. The verbs that ADD or MOVE a child decide for
  // themselves, on the parent the row will actually hang off.
  //
  // @returns {Promise<{ parentMissing: boolean }>}
  async function repandParentInTx(conn, parentId, req) {
    if (!parentRepend || parentId == null) return { parentMissing: false };
    // THE EXISTENCE QUESTION IS ASKED ON ITS OWN, and it names `id` and nothing
    // else, because it is the one question here that no DB shape can refuse to
    // answer. The re-pend needs `statusCol` / `ownerCol`; those are ADDITIVE —
    // `table-ddls.js` documents `flow_recipes.status` / `approved_by` /
    // `approved_at` / `review_note` as columns a no-ALTER DB may simply not have,
    // and `flow-recipes/approval.js` carries an APPROVAL_UNAVAILABLE arm for
    // exactly that install. Asking all three in one SELECT made the missing
    // additive column (errno 1054) swallow the existence answer with it, and the
    // degrade below then reported `parentMissing: false` — "the parent is fine" —
    // for a parent that was never looked for. Measured on a scratch DB with those
    // four columns dropped: POST /edge/app/flow-recipe-steps naming a recipe that
    // never existed answered 200 and left a row carrying an encrypted credential,
    // and 10 of 10 concurrent (recipe DELETE, step POST) pairs orphaned a step —
    // the precise end state the guard above was written to close, on a deployment
    // shape this codebase explicitly supports.
    //
    // So the degrade is scoped to the half that earns it: only a missing TABLE
    // (1146) can defeat this probe, and only then is "cannot be asked" true.
    // The FOR UPDATE stays HERE so the lock this function has always taken on the
    // parent is taken at the same point in the transaction as before.
    let parentRow;
    try {
      const idRows = await conn.query(
        `SELECT id FROM \`${t(parentRepend.table)}\` WHERE id = ? FOR UPDATE`,
        [parentId],
      );
      if (!idRows.length) return { parentMissing: true };
    } catch (err) {
      if (err && err.errno === 1146) return { parentMissing: false };
      throw err;
    }
    try {
      const rows = await conn.query(
        `SELECT \`${parentRepend.statusCol}\` AS status, \`${parentRepend.ownerCol}\` AS owner_id `
        + `FROM \`${t(parentRepend.table)}\` WHERE id = ? FOR UPDATE`,
        [parentId],
      );
      // Vanished between the two statements is not reachable — this transaction
      // holds the row's X lock from the probe above — but a defensive empty read
      // must not index into nothing.
      if (!rows.length) return { parentMissing: false };
      parentRow = rows[0];
      if (req.user?.role !== 'admin') {
        const owner = parentRow.owner_id;
        // Skip only a parent owned by someone else. owner_id IS NULL = shared,
        // editable by any editor via parentOwnership, so its approval MUST still
        // be reset — "no owner" is not "not my recipe".
        //
        // ASKED OF THE COLUMN, because the gate that ADMITTED this caller asks it
        // that way and two gates deciding one question must not disagree. Every
        // admission point on this path is SQL — `checkParentOwnership`'s chain
        // SELECT on the POST, the chain EXISTS appended to the UPDATE and to the
        // DELETE — and all of them fold case, so an editor whose stored
        // `owner_id` differs from their token only in spelling IS admitted and
        // the child write lands. A `===` here then skipped the re-pend for
        // exactly that caller, leaving an APPROVED recipe carrying a step its
        // approver never saw — the one end state the paragraph above says this
        // function exists to prevent. Measured before this line changed: POST
        // 200, step inserted, `status` still `approved`, `approved_by` still set;
        // the same editor spelling their id as the row stores it re-pended
        // correctly, and a stranger was refused 403.
        //
        // THE UNKNOWN CASE RE-PENDS, and that direction is the opposite of
        // `sameStoredValue`'s own fail-safe on purpose. The child write has
        // ALREADY landed in this transaction by the time this runs, so the
        // parent's approval is stale as a matter of fact; declining to clear it
        // does not undo the write, it only leaves the row asserting an approval
        // that no longer covers its contents. So the SKIP is what needs positive
        // evidence — an operand the column can actually be asked about, and an
        // answer that the parent belongs to somebody else.
        const callerId = req.user?.id;
        const callerAskable = typeof callerId === 'string' && callerId.length > 0;
        if (owner != null && callerAskable && !(await sameStoredValue(
          conn, t(parentRepend.table), parentRepend.ownerCol, owner, callerId,
        ))) return { parentMissing: false };
      }
      if (!parentRepend.repandFrom.includes(parentRow.status)) return { parentMissing: false };
      const sets = [`\`${parentRepend.statusCol}\` = 'pending'`,
        ...parentRepend.clearCols.map((c) => `\`${c}\` = NULL`)].join(', ');
      await conn.query(`UPDATE \`${t(parentRepend.table)}\` SET ${sets} WHERE id = ?`, [parentId]);
      return { parentMissing: false };
    } catch (err) {
      // Degraded: the approval COLUMNS are absent on this DB, so there is no
      // approval to re-pend — and a degrade must not become a refusal. Whether
      // the ROW is there was already answered above, by a statement this cannot
      // swallow.
      if (err && (err.errno === 1054 || err.errno === 1146)) return { parentMissing: false };
      throw err;
    }
  }

  // Pool resolver is split into rw/ro variants so each sub-route picks the
  // right facade explicitly. Per-request `db` overrides go through
  // getDynamicPool, and the resolver itself lives in request-pool.js — one
  // definition, because every guard mounted BESIDE this factory has to aim at
  // the same database this factory writes to, and the copy that did not is what
  // put it there.

  // parseRows delegates to the DTO mapper, which handles boolean coercion
  // (TINYINT → bool), timestamp normalisation (MariaDB string → ISO 8601 with
  // Z), and JSON parsing — driven by a per-column registry, keyed by table.
  //
  // A mount CANNOT name its JSON columns here. An earlier `jsonColumns` opt
  // survived as three mount-side literals after the registry took the job over;
  // nothing read them, so they aged out of step with the DDL in silence and read
  // as authoritative to anyone adding a column. A table this factory serves has
  // to be in the registry — a mount-side answer would be a second one.
  const parseRows = (rows) => mapRowsFromDb(logicalName, rows);

  // Apply the optional read serializer (e.g. secret masking) to a parsed row
  // array. No-op when the mount declared no serializeRead.
  const applyReadSerializer = (rows) =>
    serializeRead ? rows.map((row) => serializeRead(row)) : rows;

  // Thin wrapper over the shared enrichment helper — keeps the closure-
  // captured `resolveOwnerNameColumn` + table-prefix wiring local to the
  // CRUD factory. See docker-api/src/edge/lib/owner-name-enrichment.js
  // for the bounded-lookup + name-only contract.
  async function attachOwnerNames(conn, rows) {
    return enrichOwnerNames(conn, rows, resolveOwnerNameColumn, `\`${t(TABLES.USERS)}\``);
  }

  // Optional mount-supplied enrichment, threaded into both the list and detail
  // reads so a join-table projection lands on every served row exactly once.
  async function attachEnrichment(conn, rows) {
    if (enrichRows) await enrichRows(conn, rows);
  }

  // GET / — list with optional filters, plus opt-in pagination. The body lives
  // in list-query.js: this file carries a file-size pragma, so the pagination
  // work was an extraction rather than an append. Only the closure state the
  // handler reads crosses over.
  // lint-allow: route-auth guarded inside the imported factory — buildListHandler (list-query.js:122) calls requireAuth before doing any work; the route-auth scanner does not follow a cross-file call graph
  r.get('/', buildListHandler({
    logicalName,
    filterCols,
    userScopeColumn,
    tolerateMissingTableOnList,
    resolveRoPool,
    parseRows,
    attachOwnerNames,
    attachEnrichment,
    applyReadSerializer,
  }));

  // GET /:id
  r.get('/:id', async (req, res) => {
    if (!requireAuth(req, res)) return;
    try {
      const conn = await (await resolveRoPool(req)).getConnection();
      try {
        // SECURITY: same user-scope enforcement as the list handler.
        // Falling through with a 404 (rather than 403) avoids leaking the
        // existence of another user's row.
        let sql = `SELECT * FROM \`${t(logicalName)}\` WHERE id = ?`;
        const params = [req.params.id];
        if (userScopeColumn && req.user && req.user.role !== 'admin') {
          if (!isSafeColumnName(userScopeColumn)) {
            return sendError(req, res, null, { status: 500, code: 'INTERNAL_ERROR', reason: 'Internal misconfiguration' });
          }
          sql += ` AND \`${userScopeColumn}\` = ?`;
          params.push(req.user.id);
        }
        const rows = await conn.query(sql, params);
        if (!rows.length) {
          return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
        }
        const parsed = parseRows(rows);
        await attachOwnerNames(conn, parsed);
        await attachEnrichment(conn, parsed);
        res.json(apiOk(applyReadSerializer(parsed)[0]));
      } finally {
        conn.release();
      }
    } catch (err) {
      sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { table: logicalName, rowId: req.params.id } });
    }
  });

  // POST / — create
  // lint-allow: route-auth guarded via the local writeGate() wrapper (defined above, calls requireAuth/requireAdmin/requireAdminOrEditor by role) — not a literal call the route-auth scanner's evidence regex matches
  r.post('/', async (req, res) => {
    // NOTE: if writeScopeColumn is set, allow any authenticated user (not
    // just admin) and force the scope column to req.user.id. Otherwise keep
    // the default admin-only gate.
    if (!writeGate(req, res)) return;
    if (refuseNonCanonicalBody(req, res)) return;
    try {
      let data = { ...req.body };
      const clientOwnerValues = readClientOwnerValues(req.body);
      // SECURITY: ignore any client-supplied id and always server-generate a
      // UUID. Interactive create and clone rely on the server-returned id
      // (clone-blueprint maps source→returned ids), and id-preserving flows
      // (cross-env sync, blueprint/connector import) use dedicated routes — so
      // nothing legitimate needs a client id here. Honoring one let a caller
      // create a row with a malformed (non-UUID) id, which downstream
      // S2S-only dispatch paths then carried unvalidated.
      delete data.id;
      data.id = uuidv4();
      // Strip the per-request `db` override field from the body before
      // it lands in the column list.
      delete data.db;
      // SECURITY: the code-version counter is server-computed only. Strip any
      // client-supplied value on create so it can never be set out of step with
      // the history chain — a fresh row starts at the DDL default (1) and the v1
      // 'create' history row is the sole authority for that first version.
      if (codeVersioning) delete data[codeVersioning.versionColumn];

      // A column the server owns is not accepted from a client on ANY path, so
      // the strip runs here as well as on the update — and ahead of the gates,
      // which judge the object the statement will write.
      for (const col of serverOnlyColumns) {
        delete data[col];
      }

      // Reject value combinations the caller's role isn't allowed to
      // write — eg editor cannot POST node_type='category' to escalate
      // via generic CRUD, nor omit node_type and have the database write it.
      const guardErr = checkValueGuards(req, data, { isCreate: true });
      if (guardErr) {
        // lint-allow: logger-discipline response body is assembled at the call site (augmented apiError body or a bespoke shape); the responder owns its body and cannot delegate to sendError — the request-log access line covers the request
        return res.status(guardErr.status).json({
          ok: false,
          error: { code: guardErr.code, message: guardErr.message },
        });
      }

      // Write-time slug/enum column validation (no-op for mounts that declare
      // neither). Runs before any DB work so a malformed key/enum is rejected
      // cheaply. A create must not be able to bypass trimmedNonEmptyColumns by
      // simply omitting the column (that would persist NULL, recreating the
      // dirty rows the gate exists to prevent).
      const colErr = checkWriteColumns(data, { requireTrimmedPresent: true });
      if (colErr) {
        return sendError(req, res, null, { status: colErr.status, code: colErr.code, reason: colErr.message });
      }

      // Every authenticated POST stamps owner_id = req.user.id regardless of
      // role. Admin can still hand a row to another user (or NULL) via
      // PATCH /:id/owner. Explicit `owner_id` in the request body is ignored
      // on create — the server is the sole authority on who owns a new row.
      //
      // NOTE: if inheritOwnerFromParent matches data.node_type, look up the
      // parent's owner_id and use that instead of the actor's. Closes the
      // variant-under-shared-blueprint footgun: variants must carry the
      // blueprint owner's id so editors can match it on PUT/DELETE.
      if (ownerColumn && req.user && req.user.id) {
        if (!isSafeColumnName(ownerColumn)) {
          return sendError(req, res, null, { status: 500, code: 'INTERNAL_ERROR', reason: 'Internal misconfiguration' });
        }
        let resolvedOwner = req.user.id;
        if (inheritOwnerFromParent
            && data.node_type === inheritOwnerFromParent.whenNodeType
            && data[inheritOwnerFromParent.via]) {
          const lookupConn = await (await resolveRwPool(req)).getConnection();
          try {
            const parentRows = await lookupConn.query(
              `SELECT \`${ownerColumn}\` AS owner_id FROM \`${t(logicalName)}\`
                 WHERE id = ? AND node_type = ?`,
              [data[inheritOwnerFromParent.via], inheritOwnerFromParent.parentNodeType],
            );
            if (parentRows.length) {
              resolvedOwner = parentRows[0].owner_id;
            }
          } finally {
            lookupConn.release();
          }
        }
        data[ownerColumn] = resolvedOwner;
      }

      // S1/S2 + 2a: the linked-blueprint guard for create runs inside the write
      // transaction below (FOR UPDATE), not here — folding the check into the
      // write connection closes the check-conn/write-conn TOCTOU.

      // Editor's POST on a child table must target a parent row they own (or
      // that's shared). Admin bypasses. Chain walks 1+ hops from data[via]
      // up to the owning Blueprint row.
      //
      // `whenNodeType`, when the mount sets it, narrows this to rows of one
      // node_type on a polymorphic table (hierarchy_nodes: category/release
      // rows an editor never creates pass straight through untouched, only
      // 'variant' is gated). The node_type test lives in parentOwnershipInScope,
      // shared with checkParentOwnership itself, so the gate has one spelling —
      // this block gate exists only to scope the null-parent refusal below to
      // the same rows (a blueprint an editor may create names its own parent and
      // is judged by ownerColumn, not this chain).
      if (parentOwnership && req.user && req.user.role === 'editor'
          && parentOwnershipInScope(data.node_type)) {
        // A null/absent `via` on create names no blueprint at all — the same
        // refusal PUT raises for an editor un-binding one, via the same
        // `parentRequiredError()` helper, so the two verbs cannot drift onto
        // different wording or a different `details.reason`. Judged BEFORE
        // calling checkParentOwnership: that call answers `false` for a null
        // parentValue too, which produced the ownership-refusal message below
        // with no blueprint named — the "owned by another user" copy an
        // editor creating a brand-new, unbound connector used to see.
        if (data[parentOwnership.via] == null) {
          const e = parentRequiredError();
          // lint-allow: logger-discipline two-step consumes a helper-built apiError-shaped result, not a direct apiError call at this site
          return res.status(e.status).json(e.body);
        }
        const conn = await (await resolveRwPool(req)).getConnection();
        try {
          const allowed = await checkParentOwnership(req, conn, data[parentOwnership.via], data.node_type);
          if (!allowed) {
            return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Not allowed: parent row is not owned by you and is not shared', details: { reason: PARENT_NOT_OWNED } });
          }
        } finally {
          conn.release();
        }
      }

      // SECURITY: never trust a client-supplied scope column value for
      // non-admin writes. Override it server-side. Admin can still write rows
      // for other users (e.g. bulk import tooling).
      if (writeScopeColumn && req.user && req.user.role !== 'admin') {
        if (!isSafeColumnName(writeScopeColumn)) {
          return sendError(req, res, null, { status: 500, code: 'INTERNAL_ERROR', reason: 'Internal misconfiguration' });
        }
        data[writeScopeColumn] = req.user.id;
      }

      // Optional write serializer (e.g. encrypt connector secrets) runs on the
      // still-parsed object before mapRowToDb stringifies the JSON columns.
      if (serializeWrite) {
        data = await runSerializeWrite(serializeWrite, data, { req, isUpdate: false, id: data.id }, res);
        if (data === ENCRYPTION_GATE_422) return;
      }

      // Coerce frontend shapes (true/false, ISO 8601, plain objects) into
      // MariaDB shapes (1/0, "YYYY-MM-DD HH:mm:ss", JSON.stringify) via
      // the per-column registry. Idempotent.
      data = mapRowToDb(logicalName, data);

      const conn = await (await resolveRwPool(req)).getConnection();
      // 2a: guarded mounts write inside a transaction so the FOR UPDATE lock on
      // the target blueprint serialises a concurrent link. parentRepend also
      // requires the transaction (parent re-pend locked + committed atomically
      // with the child write). Non-guarded tables keep the autocommit path
      // byte-identical (no begin / no FOR UPDATE).
      const guardTx = !!rejectIfParentLinked || !!parentRepend || !!uniqueWithin || !!codeVersioning || !!preWriteInTx || !!transformCreateInTx;
      try {
        if (guardTx) {
          await conn.beginTransaction();
        }
        // Operator-mode gate: which of the body's keys the physical table
        // actually has. Probed here rather than just before the INSERT so the
        // hook below can be told the columns this write carries.
        //
        // On a mount with a `transformCreateInTx` that list is NOT the one the
        // statement ends up being built from: the transform runs after the hook
        // (it may read a row the hook locked) and adds server-derived columns.
        // The hook's `keys` is therefore what the REQUEST carries — see the
        // preWriteInTx doc-block, which says so rather than claiming otherwise.
        const colSet = await getActualColumnSet(conn, t(logicalName));
        // The parent this row will hang off is stored as the PARENT's own id,
        // not as the spelling the body named it with — ahead of the hook, so
        // anything that reads `data` reads one spelling.
        await bindStoredParentIds(conn, data);
        // And an owner an administrator named is a real user, spelled the way
        // that user's row spells it.
        {
          // No row id: a create has no prior owner, so it reports no transfer.
          const { rejection } = await bindStoredOwnerId(conn, data, clientOwnerValues);
          if (rejection) {
            if (guardTx) await conn.rollback();
            return sendError(req, res, null, { status: rejection.status, code: rejection.code, reason: rejection.message });
          }
        }
        // In-tx pre-write guard (e.g. §17.1a catalogue-FK check under a FOR UPDATE
        // lock on THIS connection). Runs first so a referenced row is locked before
        // the INSERT and stays held to commit — closing the check-then-write race.
        if (preWriteInTx) {
          const hookErr = await preWriteInTx(conn, req, data, {
            keys: gateKeysByColumnSet(data, colSet), isUpdate: false, id: data.id,
          });
          if (hookErr) {
            await conn.rollback();
            return sendError(req, res, null, { status: hookErr.status || 400, code: hookErr.code, reason: hookErr.message });
          }
        }
        // In-tx CREATE transform — runs after the FK lock so it may read a locked
        // referenced row, and mutates `data` between the write gates and the
        // INSERT.
        //
        // BOTH WRITE GATES HAVE ALREADY RUN, and that is now ASSERTED rather than
        // asked for: checkValueGuards and checkWriteColumns are called on the
        // parsed body long before the transaction opens, so anything this hook
        // (or serializeWrite above it) puts into `data` would otherwise reach the
        // INSERT with no gate having judged it. The verdict is re-taken below.
        if (transformCreateInTx) {
          data = (await transformCreateInTx(conn, req, data)) || data;
        }
        // The last mutation of `data` on this path has now happened, so this is
        // where the gates' answer is checked against the object the INSERT will
        // bind rather than against the body they were shown.
        reassertWriteGates(req, data, { isCreate: true });
        if (rejectIfParentLinked
          && await isLinkedParentLocked(conn, logicalName, rejectIfParentLinked, data, null)) {
          await conn.rollback();
          return sendError(req, res, null, { status: 409, code: 'LINKED_BLUEPRINT_READONLY', reason: 'Cannot edit the schema of a linked blueprint; edit the source blueprint instead' });
        }
        // Blueprint-scoped uniqueness pre-check inside the transaction. On DBs
        // where the UNIQUE index exists this narrows the race window; on no-ALTER
        // (operator-mode) DBs that lack the index it is the ONLY duplicate guard,
        // so the write-path carries the integrity burden. The residual
        // microsecond race on no-ALTER DBs is accepted (documented) — the index
        // closes it fully wherever it could be created.
        if (uniqueWithin && data[uniqueWithin.scope] != null && data[uniqueWithin.key] != null) {
          const dupRows = await conn.query(
            `SELECT id FROM \`${t(logicalName)}\` WHERE \`${uniqueWithin.scope}\` = ? AND \`${uniqueWithin.key}\` = ? LIMIT 1`,
            [data[uniqueWithin.scope], data[uniqueWithin.key]],
          );
          if (dupRows.length) {
            await conn.rollback();
            return sendError(req, res, null, { status: 409, code: uniqueWithin.code, reason: 'A row with this key already exists for this blueprint' });
          }
        }
        // Drop any safe key whose column is known to be absent from the physical
        // table (colSet was probed above, before the hook).
        const keys = gateKeysByColumnSet(data, colSet);
        if (!keys.length) {
          if (guardTx) await conn.rollback();
          return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'No valid fields provided' });
        }
        const placeholders = keys.map(() => '?').join(', ');
        const cols = keys.map((k) => `\`${k}\``).join(', ');
        await conn.query(
          `INSERT INTO \`${t(logicalName)}\` (${cols}) VALUES (${placeholders})`,
          keys.map((k) => data[k])
        );
        // Re-pend the parent recipe inside this transaction (FOR UPDATE lock) —
        // and refuse a create whose parent is not there to re-pend.
        //
        // THE ROW THIS INSERT HANGS OFF HAS TO EXIST, and this is the first point
        // in the transaction that knows. There is no foreign key, and
        // `checkParentOwnership` answers an admin `true` without querying — so a
        // recipe_id naming nothing produced a 200 and a step no editor can ever
        // reach again, because the ownership chain needs the parent. Under
        // concurrency the same end state arrives by the interleaving the delete
        // gate is supposed to prevent: measured, 20 of 20 (recipe DELETE, step
        // POST) pairs left an orphan carrying an encrypted credential.
        if (parentRepend) {
          const { parentMissing } = await repandParentInTx(conn, data[parentRepend.via], req);
          if (parentMissing) {
            await conn.rollback();
            return sendError(req, res, null, { status: 404, code: 'PARENT_NOT_FOUND', reason: 'The parent record this belongs to does not exist' });
          }
        }
        // Seed the code-version history at v1 (action 'create') in the same tx.
        // COHERENCE: only seed when the watch column actually exists on this DB —
        // otherwise the column gate stripped the code from the INSERT and the row
        // never stored it, so a v1 row would claim a code the recipe does not hold.
        // The recorded value is exactly what the row now holds: the body's value
        // when the column was inserted, else null (the DDL default). Best-effort on
        // the history table itself (a DB with the column but no history table just
        // gets no history — no false claim, only a missing audit row).
        if (codeVersioning) {
          const watchLc = codeVersioning.watchColumn.toLowerCase();
          const versionLc = codeVersioning.versionColumn.toLowerCase();
          const watchColumnStored = colSet === null || colSet.has(watchLc);
          const versionColumnPresent = colSet === null || colSet.has(versionLc);
          // Seed v1 only when the FULL versioning surface is live: the code was
          // actually stored (watch column present) AND the counter column exists
          // AND the history table exists. Otherwise a v1 row would be a stale
          // chain start that later PUTs — which degrade to unversioned when the
          // counter/table is absent — never advance, masquerading as live history.
          const surfaceLive = watchColumnStored && versionColumnPresent
            && await isCodeVersionHistoryAvailable(conn, t(codeVersioning.historyTable));
          if (surfaceLive) {
            const seedCode = Object.prototype.hasOwnProperty.call(data, codeVersioning.watchColumn)
              ? (data[codeVersioning.watchColumn] ?? null)
              : null;
            try {
              await conn.query(
                `INSERT INTO \`${t(codeVersioning.historyTable)}\` (id, \`${codeVersioning.historyFkColumn}\`, version, code, action, created_by) VALUES (?, ?, 1, ?, 'create', ?)`,
                [uuidv4(), data.id, seedCode, (req.user && req.user.id) || null],
              );
            } catch (cvErr) {
              if (!isMissingTableOrColumn(cvErr)) throw cvErr;
              warnCodeVersioningDegradedOnce(logicalName, 'post-seed', req.log);
            }
          } else {
            warnCodeVersioningDegradedOnce(logicalName, 'post-seed-surface-incomplete', req.log);
          }
        }
        // Return inserted row
        const rows = await conn.query(`SELECT * FROM \`${t(logicalName)}\` WHERE id = ?`, [data.id]);
        if (guardTx) await conn.commit();
        // Enrich the write response the same way a read is (e.g. the connector
        // `bindings` join projection), so a create reply carries the shape a
        // later GET would. No-op on a mount that declares no enrichRows.
        const insertedRows = parseRows(rows);
        await attachEnrichment(conn, insertedRows);
        res.json(apiOk(applyReadSerializer(insertedRows)[0]));
      } catch (errInner) {
        if (guardTx) { try { await conn.rollback(); } catch { /* best effort */ } }
        throw errInner;
      } finally {
        conn.release();
      }
    } catch (err) {
      // The UNIQUE index (present on ALTER-capable DBs) is the race backstop:
      // a duplicate that slipped past the in-tx pre-check surfaces as 1062,
      // mapped to the same stable 409 the pre-check returns.
      if (uniqueWithin && err && err.errno === 1062) {
        return sendError(req, res, err, { status: 409, code: uniqueWithin.code, reason: 'A row with this key already exists for this blueprint' });
      }
      if (mapDuplicateKey && err && err.errno === 1062) {
        return sendError(req, res, err, { status: 409, code: mapDuplicateKey.code, reason: mapDuplicateKey.message });
      }
      const conflict = writeConflictError(err);
      if (conflict) {
        req.log.warn({ err, table: logicalName }, 'Create lost a lock race in ' + logicalName);
        // lint-allow: logger-discipline two-step consumes a helper-built apiError-shaped result, not a direct apiError call at this site
        return res.status(conflict.status).json(conflict.body);
      }
      sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { table: logicalName } });
    }
  });

  // PUT /:id — update
  // lint-allow: route-auth guarded via the local writeGate() wrapper (defined above, calls requireAuth/requireAdmin/requireAdminOrEditor by role) — not a literal call the route-auth scanner's evidence regex matches
  r.put('/:id', async (req, res) => {
    // NOTE: writeScopeColumn path allows any authenticated user; default
    // path keeps admin-only gate.
    if (!writeGate(req, res)) return;
    if (refuseNonCanonicalBody(req, res)) return;
    try {
      let data = { ...req.body };
      const clientOwnerValues = readClientOwnerValues(req.body);
      delete data.id;
      delete data.db;
      // SECURITY: server-computed only — strip any client-supplied version
      // counter unconditionally. The only writer of versionColumn is the
      // codeVersioning bump below, which re-adds it after diffing the code, so a
      // client can never fold in an arbitrary version with no matching history row.
      if (codeVersioning) delete data[codeVersioning.versionColumn];

      // ── THE STRIPS RUN BEFORE THE GATES ────────────────────────────────────
      //
      // A gate judges the object the statement will write, and a column removed
      // here is not in that object. Judging it first was a second answer to
      // "what is this request writing": a body naming an immutable column with a
      // value the column's own rule refuses was answered with a refusal, about a
      // column the UPDATE was never going to name — while a body naming it with
      // an acceptable value was silently ignored. Same column, same request, two
      // different contracts.
      //
      // Moving them ahead can only ever turn a refusal into an acceptance of a
      // write that DOES NOT CARRY THE COLUMN, so nothing unjudged reaches the
      // statement: every gate below refuses, none admits.
      //
      // Editor cannot rewrite owner_id via PUT — transfer is admin-only
      // via the dedicated PATCH endpoint.
      if (ownerColumn && req.user && req.user.role !== 'admin') {
        delete data[ownerColumn];
      }

      // The FK a body claims to move the row onto is no longer dropped
      // unread: it is judged below, once the row this UPDATE will lock is
      // known, by the same rule the create path already enforces
      // (`checkParentOwnership`). Captured here and removed only so the
      // gates between here and that judgment (value guards, enum
      // validation, the serializer) never see an un-vetted foreign key;
      // it goes back into `data` once the value is settled — same,
      // or a parent this caller may act on.
      //
      // EXCEPT where the mount ALSO lists this column in `immutableColumns`
      // (capacity's scenario-scoped children: `via` and the immutable column
      // are the same `scenario_id`, on purpose — parentOwnership there judges
      // who may act on the row's CURRENT scenario, not whether the row may
      // move to another one). That loop below still strips it for every role,
      // unconditionally, and this block must not undo that by handing the
      // value back once ownership of the NEW value clears — the column is
      // never rebindable at all, lawfully or not.
      let requestedParentValue;
      const parentViaProvided = !!(parentOwnership && req.user && req.user.role !== 'admin'
        && !immutableColumns.includes(parentOwnership.via)
        && Object.prototype.hasOwnProperty.call(data, parentOwnership.via));
      if (parentViaProvided) {
        requestedParentValue = data[parentOwnership.via];
        delete data[parentOwnership.via];
      }

      // INVARIANT: immutable columns are never mutable via the generic PUT —
      // see immutableColumns option above. Role-agnostic, update-only.
      for (const col of immutableColumns) {
        delete data[col];
      }

      // The server-owned columns, stripped on this path too. Same loop as the
      // create path above, and deliberately not folded into the list above it:
      // the two lists answer different questions and a mount says which it means.
      for (const col of serverOnlyColumns) {
        delete data[col];
      }

      // SECURITY: never trust a client-supplied scope column on non-admin
      // updates. Strip it so the WHERE clause below (extended with the
      // scope condition) is the only thing that decides which row gets
      // touched.
      if (writeScopeColumn && req.user && req.user.role !== 'admin') {
        delete data[writeScopeColumn];
      }

      // Same value-guard as POST.
      const guardErr = checkValueGuards(req, data);
      if (guardErr) {
        // lint-allow: logger-discipline response body is assembled at the call site (augmented apiError body or a bespoke shape); the responder owns its body and cannot delegate to sendError — the request-log access line covers the request
        return res.status(guardErr.status).json({
          ok: false,
          error: { code: guardErr.code, message: guardErr.message },
        });
      }

      // Same write-time slug/enum validation as POST (only when the column is
      // present in the update body).
      const colErr = checkWriteColumns(data);
      if (colErr) {
        return sendError(req, res, null, { status: colErr.status, code: colErr.code, reason: colErr.message });
      }

      // S1/S2 + 2a: the linked-blueprint guard runs inside the write
      // transaction below (FOR UPDATE), closing the check-conn/write-conn TOCTOU.

      // Optional write serializer (e.g. encrypt connector secrets, and
      // preserve an unchanged `****`-masked secret by reading the stored row).
      //
      // A mount that declares `serializeWriteInTx` runs it INSIDE the write
      // transaction instead, on the write connection — see the option's
      // doc-block. Here that means: not yet.
      if (serializeWrite && !serializeWriteInTx) {
        data = await runSerializeWrite(serializeWrite, data, { req, isUpdate: true, id: req.params.id }, res);
        if (data === ENCRYPTION_GATE_422) return;
        // Coerce frontend → MariaDB shapes via the DTO registry.
        data = mapRowToDb(logicalName, data);
      } else if (!serializeWrite) {
        data = mapRowToDb(logicalName, data);
      }

      const conn = await (await resolveRwPool(req)).getConnection();
      // 2a: guarded mounts update inside a transaction so the FOR UPDATE lock on
      // the target blueprint serialises a concurrent link. parentRepend also
      // requires the transaction (parent re-pend locked + committed atomically
      // with the child write). Non-guarded tables keep the autocommit path
      // byte-identical (no begin / no FOR UPDATE).
      const guardTx = !!rejectIfParentLinked || !!parentRepend || !!uniqueWithin || !!codeVersioning
        || !!preWriteInTx || !!postUpdateInTx || !!serializeWriteInTx || !!repandOnSensitiveChange;
      // THE SCOPE THE UPDATE MATCHES ON, built in one place so the entitlement
      // read below and the statement itself cannot be scoped differently.
      // Returns null when a configured column fails the identifier whitelist —
      // the same 500 the inline checks raised, moved here with the predicate.
      //
      // The delegated arm is passed IN rather than resolved here: its narrowed
      // form depends on the columns the statement will actually write, and those
      // are not settled until every hook above has run.
      const buildPutScope = async (granted) => {
        let clause = '';
        const params = [];
        // SECURITY: non-admin updates are scoped by the write column so a
        // user cannot UPDATE another user's row even if they know the
        // primary key. Returns 404 (via affectedRows === 0) on missing or
        // foreign rows to avoid existence leaks.
        if (writeScopeColumn && req.user && req.user.role !== 'admin') {
          if (!isSafeColumnName(writeScopeColumn)) return null;
          // The delegated arm is ORed INSIDE the ownership condition, never
          // beside it: `AND (owner OR granted)` widens who matches, whereas
          // `AND owner AND granted` or a bare `OR granted` outside the
          // parentheses would either match nobody or drop the id predicate
          // entirely and update every row the caller holds any grant over.
          if (granted) {
            clause += ` AND (\`${writeScopeColumn}\` = ? OR ${granted.sql})`;
            params.push(req.user.id, ...granted.params);
          } else {
            clause += ` AND \`${writeScopeColumn}\` = ?`;
            params.push(req.user.id);
          }
        }
        // Editor's UPDATE matches only owner-of OR shared (NULL) rows.
        // 0 affectedRows → 404 (existence-leak parity).
        if (ownerColumn && req.user && req.user.role === 'editor') {
          if (!isSafeColumnName(ownerColumn)) return null;
          const ownerCheck = `(\`${ownerColumn}\` IS NULL OR \`${ownerColumn}\` = ?)`;
          // A node_type-scoped grant mount (hierarchy_nodes variant rows) widens
          // THIS arm rather than adding a second parentOwnership arm below: a
          // granted variant's own owner_id is the (foreign) blueprint owner, so
          // the bare owner arm would 404 the grantee's rename — and a separate
          // `AND (chain owner OR grant)` arm would be absorbed away by this one
          // (`O AND (O OR G)` = `O`, the grant never reached). One fragment
          // `O OR (variant AND grant)` is the whole rule: owner/shared, or a
          // blueprint grant on the variant's parent. A blueprint row (node_type
          // != the scoped type) sees only `O`, its own owner arm, unchanged.
          if (parentOwnership && parentOwnership.whenNodeType
              && blueprintGrantScope && await grantsTableAvailable(conn)) {
            const grantExists = buildChainBlueprintGrantExistsForRow(
              parentOwnership.chain, logicalName, parentOwnership.via,
            );
            clause += ` AND (${ownerCheck} OR (\`node_type\` = ? AND ${grantExists}))`;
            params.push(req.user.id, parentOwnership.whenNodeType, req.user.id);
          } else {
            clause += ` AND ${ownerCheck}`;
            params.push(req.user.id);
          }
        }
        // NOTE: chain DSL — editor PUT requires both chain existence and
        // owner-check. EXISTS form (single subquery) closes two holes:
        //   (1) operator-precedence: missing outer parens around
        //       `IS NULL OR = ?` let OR break AND scope, allowing
        //       mass-update of rows whose parent owner = editor. Fixed
        //       by using a single EXISTS expression.
        //   (2) NULL-ambiguity: scalar subquery on an orphan child row
        //       (broken FK chain) returned NULL, conflating "shared parent"
        //       with "no parent at all". EXISTS returns 0 rows for broken
        //       chains so the predicate denies them outright.
        //
        // A node_type-scoped mount does NOT reach here: its owner+grant question
        // is folded into the ownerColumn arm above (a scoped row's own owner_id
        // already reflects its parent's owner), so a second arm would only
        // re-AND the same owner test and cancel the grant. Every other
        // parentOwnership mount (api_connectors, blueprint_fields) leaves
        // whenNodeType unset and uses the shared fragment, byte-identical to
        // before this option existed. spec §6.1/§6.4a: the grant arm mirrors the
        // DELETE predicate so a mount that widens delete widens update the same
        // way (the two-path write family).
        if (parentOwnership && !parentOwnership.whenNodeType
            && req.user && req.user.role === 'editor') {
          const frag = await parentOwnershipScopeFragment(req, conn);
          clause += ` AND ${frag.sql}`;
          params.push(...frag.params);
        }
        return { clause, params };
      };
      // The delegated arm for a given set of written columns, or null where the
      // scope has no arm to widen. Gated exactly as the statement's call was, so
      // no mount acquires a grants-table probe it did not make before.
      const delegatedArm = (writtenColumns) => (
        writeScopeColumn && req.user && req.user.role !== 'admin'
          ? grantWritePredicate(req, conn, writtenColumns, data)
          : null
      );
      // Owner columns this write will actually move, filled in by
      // `bindStoredOwnerId` below and recorded once the scoped UPDATE has
      // matched a row — never before, so an unauthorized PUT that answers 404
      // leaves no trail claiming a handover that did not happen.
      let ownerTransfers = [];
      try {
        if (guardTx) {
          await conn.beginTransaction();
        }
        // ENTITLEMENT IS ESTABLISHED BEFORE ANY LOCK IS TAKEN, with a read that
        // takes none itself.
        //
        // Everything between here and the UPDATE that authorises this request
        // can lock: the serializer reads the row `FOR UPDATE`, the pre-write
        // hook locks the rows this one REFERENCES, the linked-blueprint guard
        // locks the parent, and the uniqueness, re-parent, code-version and
        // re-pend probes each take this row. All of them ran for any
        // authenticated caller who knew an id — so a caller with no right to the
        // row could park the handler behind whoever holds those locks and still
        // (correctly) receive its 404 afterwards. The delete path had the same
        // exposure and it was measured there: one unauthorised request waited
        // 1213 ms against a held lock, and six in flight starved the pool, each
        // holding a handler and a pooled connection for up to
        // `innodb_lock_wait_timeout`. The wait is also a timing side channel —
        // it is observable only for rows that exist and are contended, which is
        // more than the 404 discloses.
        //
        // Deliberately NOT `FOR UPDATE`. It decides only whether to proceed,
        // never what is written; the UPDATE below carries the same predicate and
        // remains the authority, so a row whose ownership changes between the
        // two still ends in the same 404. A lock here would recreate exactly the
        // exposure it removes.
        //
        // Lock ORDER is untouched: this adds no lock, and every probe below
        // still runs where it ran, on the same connection, before the statement.
        //
        // A CALLER WHOSE SCOPE IS EMPTY IS NOT ASKED. Every arm of the scope is
        // conditioned on a role, and an administrator — or any caller on a mount
        // that declares no scope column at all — matches every row this
        // statement could name, so there is no entitlement left to establish and
        // the read would only be asking whether the row exists. Their path stays
        // byte-identical, exactly as a mount that locks nothing does; the
        // exposure is about a caller who is scoped OUT of the row, and that
        // caller always has a clause.
        if (locksBeforeUpdate) {
          // The widest form of the delegated arm — the reach a grant conveys,
          // with the "and this write is not moving the record out from under the
          // blueprint that conveyed it" conjunct left off. That conjunct is a
          // restriction on the WRITE, not on who may touch the row, and it is
          // keyed to columns this request has not settled yet. Leaving it off
          // can only make the read admit a caller the statement then refuses,
          // which is the same 404 by the same predicate; folding it in early
          // would 404 a delegated writer the statement would have let through.
          const scope = await buildPutScope(await delegatedArm([]));
          if (!scope) {
            if (guardTx) await conn.rollback();
            return sendError(req, res, null, { status: 500, code: 'INTERNAL_ERROR', reason: 'Internal misconfiguration' });
          }
          if (scope.clause) {
            const entitled = await conn.query(
              `SELECT id FROM \`${t(logicalName)}\` WHERE id = ?${scope.clause}`,
              [req.params.id, ...scope.params],
            );
            if (!entitled.length) {
              if (guardTx) await conn.rollback();
              return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
            }
          }
        }
        // THE FK CHANGE IS JUDGED HERE, on the connection that will write it —
        // the same transaction as the entitlement read above and the UPDATE
        // below, so "the current parent" this compares against is the row
        // that UPDATE is about to lock, not a value read on some other
        // connection that could already be stale.
        //
        // `checkParentOwnership` already answers `false` for any role that is
        // neither admin nor editor, and `parentViaProvided` is only ever true
        // for a non-admin caller — so a hypothetical third role that somehow
        // reached this far is refused by the same call, with no separate
        // branch to keep in step with the one above.
        if (parentViaProvided) {
          // 400 BEFORE ANY PROBE THAT BINDS THIS VALUE. `requestedParentValue`
          // was stripped out of `data` above so `checkWriteColumns` never saw
          // it — this is the one identifier-floor check it would have
          // received had it stayed. Same validator, same code/message as
          // every other identifier column on this write; ordered after the
          // entitlement read above (404 for a row this caller cannot see at
          // all) and before `readOwnParentValue`/`checkParentOwnership`
          // (403 for a well-formed value naming a row this caller does not
          // own) — a malformed value never reaches either.
          const formatIssue = checkIdentifierFormat(parentOwnership.via, requestedParentValue);
          if (formatIssue) {
            if (guardTx) await conn.rollback();
            return sendError(req, res, null, { status: formatIssue.status, code: formatIssue.code, reason: formatIssue.message });
          }
          const storedParentValue = await readOwnParentValue(conn, parentOwnership.via, req.params.id);
          const unchanged = await sameStoredValue(
            conn, t(logicalName), parentOwnership.via, storedParentValue, requestedParentValue,
          );
          if (!unchanged) {
            // A null target names no blueprint at all — POST refuses an
            // editor's null `via` on create through the same
            // `parentRequiredError()` helper, so a PUT that un-binds raises
            // the identical refusal. Judged BEFORE calling
            // checkParentOwnership: that call would produce the
            // ownership-refusal message below with no blueprint named,
            // which is what an editor's "None" pick in the binding picker
            // used to render as "owned by another user".
            if (requestedParentValue == null) {
              if (guardTx) await conn.rollback();
              const e = parentRequiredError();
              // lint-allow: logger-discipline two-step consumes a helper-built apiError-shaped result, not a direct apiError call at this site
              return res.status(e.status).json(e.body);
            }
            if (!(await checkParentOwnership(req, conn, requestedParentValue))) {
              if (guardTx) await conn.rollback();
              return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Not allowed: parent row is not owned by you and is not shared', details: { reason: PARENT_NOT_OWNED } });
            }
            // Re-add `via` only on a lawful CHANGE. The unchanged branch
            // above falls through this assignment and leaves it stripped
            // exactly as it was on entry — re-adding it on BOTH branches
            // wrote the caller's spelling over a
            // collation-equal but differently-cased stored value, and made
            // `uniqueWithin`'s `scopeInBody` (below) true for an editor's
            // same-value PUT (an unneeded dup SELECT, and a possible false
            // 409 on a no-index DB).
            data[parentOwnership.via] = requestedParentValue;
          }
        }
        // THE SERIALIZER, ON THE CONNECTION THAT WILL WRITE. Placed as the first
        // thing inside the transaction so the order everything below it sees is
        // the order it saw before — this pair used to run just above
        // `getConnection`, and nothing between there and here reads `data`.
        //
        // What moving it buys is stated at the option: a hook that resolves
        // "unchanged means keep what is stored" is asking about the row this
        // statement is about to update, and it now asks the row under the lock
        // it will hold to commit.
        if (serializeWrite && serializeWriteInTx) {
          data = await runSerializeWrite(
            serializeWrite, data, { req, isUpdate: true, id: req.params.id, conn }, res,
          );
          if (data === ENCRYPTION_GATE_422) { await conn.rollback(); return; }
          data = mapRowToDb(logicalName, data);
        }
        // SECURITY: ownership BEFORE the pre-write hook, matching POST.
        // Ownership on this path is otherwise enforced only by the EXISTS clause
        // appended to the UPDATE far below, so a hook that reads (and, with
        // FOR UPDATE, locks) the parent's sibling rows would run for a caller
        // who owns none of them — and can report what it found there. A hook
        // with no ownership option beside it keeps the single-check path
        // byte-identical.
        // 404 rather than POST's 403: this path answers a non-owned row with
        // 404 everywhere else (existence-leak parity), and a different code here
        // would say whether the row exists.
        if (preWriteInTx && parentOwnership && req.user && req.user.role === 'editor') {
          const parentValue = data[parentOwnership.via] != null
            ? data[parentOwnership.via]
            : await readOwnParentValue(conn, parentOwnership.via, req.params.id);
          if (!(await checkParentOwnership(req, conn, parentValue))) {
            await conn.rollback();
            return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
          }
        }
        // Which of the body's keys the physical table actually has. Probed here
        // rather than just before the UPDATE so the hook below can be told the
        // columns this write carries.
        //
        // On a `codeVersioning` mount that list is NOT the one the statement
        // ends up being built from: the version bump is folded into `data`
        // further down, after the watched code has been diffed against the
        // stored one, so the version column is in the UPDATE's SET clause and
        // not in the hook's `keys`. Stated here rather than left implied — the
        // POST side says the same thing about its own transform, and a `keys`
        // that meant "the request's columns" on one verb and "the statement's
        // columns" on the other would be a contract whose reader has to know
        // which handler they are in.
        //
        // The bump is not moved above the hook to make one sentence simpler.
        // Doing so would take this row's own FOR UPDATE before the hook's locks
        // on the rows it REFERENCES, reordering how every guarded PUT acquires
        // its locks — the class of change this path has already been bitten by
        // — and would hand hooks a server-derived column that the create path
        // deliberately does not.
        const colSet = await getActualColumnSet(conn, t(logicalName));
        // Same rule as the create, on the verb that can also carry the column:
        // an administrator's PUT is not stripped of a parent reference, and a
        // respelled one would move the row onto a parent no JavaScript reader
        // resolves.
        await bindStoredParentIds(conn, data);
        {
          const bound = await bindStoredOwnerId(conn, data, clientOwnerValues, req.params.id);
          if (bound.rejection) {
            if (guardTx) await conn.rollback();
            return sendError(req, res, null, { status: bound.rejection.status, code: bound.rejection.code, reason: bound.rejection.message });
          }
          ownerTransfers = bound.transfers;
        }
        // In-tx pre-write guard (§17.1a catalogue-FK check under a FOR UPDATE lock on
        // THIS connection) — same protocol as POST: lock the referenced rows before
        // the UPDATE and hold them to commit, closing the check-then-write race.
        if (preWriteInTx) {
          const hookErr = await preWriteInTx(conn, req, data, {
            keys: gateKeysByColumnSet(data, colSet), isUpdate: true, id: req.params.id,
          });
          if (hookErr) {
            await conn.rollback();
            return sendError(req, res, null, { status: hookErr.status || 400, code: hookErr.code, reason: hookErr.message });
          }
        }
        if (rejectIfParentLinked
          && await isLinkedParentLocked(conn, logicalName, rejectIfParentLinked, data, req.params.id)) {
          await conn.rollback();
          return sendError(req, res, null, { status: 409, code: 'LINKED_BLUEPRINT_READONLY', reason: 'Cannot edit the schema of a linked blueprint; edit the source blueprint instead' });
        }
        // Blueprint-scoped uniqueness pre-check for the generic PUT. The check
        // must run against the EFFECTIVE destination pair, not the row's current
        // one: a PUT can change the scope (blueprint_id — a reparent) with OR
        // without also changing the key, and either move can create a duplicate
        // (blueprint_id, group_key) in the DESTINATION on a no-index (operator)
        // DB. Compute effective scope + key by taking the request value when
        // present and falling back to the stored row's value for whichever is
        // omitted; run the check whenever EITHER changes. On the mounts that
        // declare BOTH `uniqueWithin.scope` and `parentOwnership.via` on the
        // same column, `scopeInBody` is only true here for an admin's reparent
        // or an editor's LAWFUL one (the ownership judgment above already
        // refused an unlawful one); an editor's key-only rename still checks
        // against the current blueprint, unchanged. The UNIQUE index (1062,
        // mapped below) is the backstop on ALTER-capable DBs.
        if (uniqueWithin) {
          const scopeInBody = Object.prototype.hasOwnProperty.call(data, uniqueWithin.scope);
          const keyInBody = Object.prototype.hasOwnProperty.call(data, uniqueWithin.key);
          if (scopeInBody || keyInBody) {
            const cur = await conn.query(
              `SELECT \`${uniqueWithin.scope}\` AS scope, \`${uniqueWithin.key}\` AS keyval FROM \`${t(logicalName)}\` WHERE id = ? FOR UPDATE`,
              [req.params.id],
            );
            if (cur.length) {
              const effScope = scopeInBody ? data[uniqueWithin.scope] : cur[0].scope;
              const effKey = keyInBody ? data[uniqueWithin.key] : cur[0].keyval;
              if (effScope != null && effKey != null) {
                const dupRows = await conn.query(
                  `SELECT id FROM \`${t(logicalName)}\`
                     WHERE \`${uniqueWithin.scope}\` = ? AND \`${uniqueWithin.key}\` = ? AND id <> ? LIMIT 1`,
                  [effScope, effKey, req.params.id],
                );
                if (dupRows.length) {
                  await conn.rollback();
                  return sendError(req, res, null, { status: 409, code: uniqueWithin.code, reason: 'A row with this key already exists for this blueprint' });
                }
              }
            }
          }
        }
        // Capture the child's CURRENT parent before the UPDATE so an admin
        // re-parent (changing `via`) re-pends both the old and the new parent.
        let rependStoredVia = null;
        if (parentRepend) {
          // SECURITY: lock the child row so a concurrent re-parent cannot
          // move it to a different parent between this read and the UPDATE,
          // which would silently skip re-pending the intermediate parent.
          const cr = await conn.query(
            `SELECT \`${parentRepend.via}\` AS via FROM \`${t(logicalName)}\` WHERE id = ? FOR UPDATE`,
            [req.params.id],
          );
          rependStoredVia = cr.length ? cr[0].via : null;
        }
        // Code-versioning: when the write carries the watched code column, pre-read
        // the current code + version FOR UPDATE and, if the value actually changes,
        // fold a version bump into this same UPDATE and remember to append a history
        // row after the ownership-scoped UPDATE confirms it matched a row. A partial
        // PUT that omits the watch column never bumps. On a no-ALTER DB the pre-read
        // 1054/1146s → versioning is skipped and the plain update proceeds.
        let cvBump = null; // { newVersion, code } when a bump is due
        if (codeVersioning
            && Object.prototype.hasOwnProperty.call(data, codeVersioning.watchColumn)) {
          try {
            const preRows = await conn.query(
              `SELECT \`${codeVersioning.watchColumn}\` AS code, \`${codeVersioning.versionColumn}\` AS version FROM \`${t(logicalName)}\` WHERE id = ? FOR UPDATE`,
              [req.params.id],
            );
            if (preRows.length) {
              const storedCode = preRows[0].code ?? null;
              const newCode = data[codeVersioning.watchColumn] ?? null;
              // A NULL→code or code→NULL transition is itself a recorded change.
              if (newCode !== storedCode) {
                // COHERENCE: decide versioning-active BEFORE folding the bump. The
                // counter must never move without its history row landing in the
                // SAME tx. If the history table is absent (partial migration), do a
                // plain unversioned write — the code change still persists, the
                // counter simply does not advance until the table exists.
                if (await isCodeVersionHistoryAvailable(conn, t(codeVersioning.historyTable))) {
                  const storedVersion = Number.isInteger(preRows[0].version) ? preRows[0].version : 0;
                  const newVersion = storedVersion + 1;
                  data[codeVersioning.versionColumn] = newVersion; // folded into the SET via the gate below
                  cvBump = { newVersion, code: newCode };
                } else {
                  warnCodeVersioningDegradedOnce(logicalName, 'put-history-unavailable', req.log);
                }
              }
            }
          } catch (cvErr) {
            if (!isMissingTableOrColumn(cvErr)) throw cvErr;
            warnCodeVersioningDegradedOnce(logicalName, 'put-preread', req.log);
          }
        }
        // SELF RE-PEND, folded into this statement rather than decided before it.
        // See the option's doc-block for why the probe belongs here; the policy —
        // and in particular what a NULL status means — is review-status.js's.
        //
        // AND WHAT IT DOES WHEN THE COLUMN LIST IS UNKNOWN. `colSet` is null for
        // three situations — the probe threw, it answered no rows, or it
        // answered rows carrying no usable names — and null means UNKNOWN, not
        // "the column is absent"; the same value is read as "assume present" by
        // the create path's versioning surface. Gating this block on a truthy
        // `colSet` therefore made an unreadable `information_schema` disable the
        // review gate on a table that does have `status`: the editor re-points a
        // connector and it keeps the approval that covered the old endpoint. The
        // null is cached per (database, table) for the life of the process, so
        // one unlucky probe does that to every write until a restart.
        //
        // The row is the other place the question has an answer, and it is one
        // this block takes FOR UPDATE anyway — so when the set is unknown the
        // probe reads the whole row and the columns are derived from what came
        // back. That also keeps a PARTIAL absence partial: attempting the
        // configured projection and swallowing the missing-column error would
        // lose every watched column to the one this database lacks, which is the
        // same fail-open wearing a `try`.
        if (repandOnSensitiveChange
          && (colSet === null || colSet.has(repandOnSensitiveChange.statusCol))) {
          const columnsUnknown = colSet === null;
          const probeCols = columnsUnknown ? null : [
            repandOnSensitiveChange.statusCol,
            ...(repandOnSensitiveChange.columns || []).filter((c) => colSet.has(c)),
            ...(repandOnSensitiveChange.jsonColumns || []).filter((c) => colSet.has(c)),
          ];
          const cur = (await conn.query(
            `SELECT ${probeCols ? probeCols.map((c) => `\`${c}\``).join(', ') : '*'} `
            + `FROM \`${t(logicalName)}\` WHERE id = ? FOR UPDATE`,
            [req.params.id],
          ))[0];
          // SECURITY: the row's keys carry the column's OWN declared case while
          // the mount's lists and `colSet` are lower-case, so the derived lookup
          // folds — a name comparison defeated by a capital letter is a defect
          // this repo has already shipped, and here it would fold back into the
          // fail-open above.
          const rowCols = cur && columnsUnknown
            ? new Map(Object.keys(cur).map((k) => [k.toLowerCase(), k]))
            : null;
          // SAFETY: `present` must not answer through `colSet` when the column
          // list is unknown — `colSet` is null in that branch precisely because
          // it is unknown, so `colSet.has(c)` throws on a missing row before the
          // `cur &&` guard below has a chance to short-circuit it away. The row
          // (`rowCols`) is the only witness this branch has; a missing row means
          // nothing is present, not "ask the column list instead".
          const present = (c) => (columnsUnknown ? !!rowCols && rowCols.has(c) : colSet.has(c));
          const storedValue = (c) => (rowCols ? cur[rowCols.get(c)] : cur?.[c]);
          if (cur && present(repandOnSensitiveChange.statusCol)) {
            const watched = (repandOnSensitiveChange.columns || []).filter(present);
            const watchedJson = (repandOnSensitiveChange.jsonColumns || []).filter(present);
            // byte-compare: every watched column is either an ENUM whose written
            // value the mount's own domain gate has already proved is identically
            // a member, or a VARCHAR/TEXT the column stores verbatim. The only
            // difference a collation would fold and this will not — a case or
            // trailing-space variant of the stored value — is answered "changed",
            // which re-pends a row that arguably did not change. That direction
            // costs a review; the other direction dispatches unreviewed.
            const sensitiveChanged = watched.some(
              (c) => Object.prototype.hasOwnProperty.call(data, c) && data[c] !== storedValue(c),
            ) || watchedJson.some(
              (c) => Object.prototype.hasOwnProperty.call(data, c)
                && canonicalJsonValue(data[c]) !== canonicalJsonValue(storedValue(c)),
            );
            if (repandRequired(storedValue(repandOnSensitiveChange.statusCol), sensitiveChanged)) {
              data[repandOnSensitiveChange.statusCol] = REVIEW_PENDING;
              for (const c of (repandOnSensitiveChange.clearCols || [])) {
                if (present(c)) data[c] = null;
              }
            }
          }
        }
        // The last mutation of `data` on this path has now happened (the version
        // bump above is the final one), so this is where the gates' answer is
        // checked against the object the UPDATE will bind rather than against the
        // body they were shown.
        reassertWriteGates(req, data, { isCreate: false });
        // Drop any safe key whose column is known to be absent from the physical
        // table (colSet was probed above, before the hook). An explicit null on a
        // present column stays so the value is cleared.
        const keys = gateKeysByColumnSet(data, colSet);
        if (!keys.length) {
          if (guardTx) await conn.rollback();
          return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'No valid fields to update' });
        }
        const sets = keys.map((k) => `\`${k}\` = ?`).join(', ');
        // The same builder the entitlement read used, now with the delegated arm
        // in its narrowed form: the columns the statement writes are settled, so
        // a grantee re-filing the record under another blueprint is refused by
        // the predicate rather than by a second rule beside it.
        const scope = await buildPutScope(await delegatedArm(keys));
        if (!scope) {
          if (guardTx) await conn.rollback();
          return sendError(req, res, null, { status: 500, code: 'INTERNAL_ERROR', reason: 'Internal misconfiguration' });
        }
        const updateSql = `UPDATE \`${t(logicalName)}\` SET ${sets} WHERE id = ?${scope.clause}`;
        const updateParams = [...keys.map((k) => data[k]), req.params.id, ...scope.params];
        const result = await conn.query(updateSql, updateParams);
        if (result.affectedRows === 0) {
          if (guardTx) await conn.rollback();
          return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
        }
        // The handover is recorded now that the ownership-scoped UPDATE has
        // matched — on a mount whose only transfer route is this verb, this is
        // the only record that it happened at all.
        await recordOwnerTransfers(conn, req, req.params.id, ownerTransfers);

        // Re-read with the same scope so we never leak another user's row.
        //
        // ON A DELEGATED MOUNT THE RE-READ IS BY ID ALONE, and that is not a
        // relaxation. The UPDATE immediately above matched under the full scope
        // — that is what got us past the 404 — so this row is one the caller was
        // just permitted to write, and the id is a primary key that cannot come
        // to mean another row. Re-applying a permission predicate here asks the
        // question a SECOND time, at a moment when the answer can have changed:
        // access revoked between the two statements makes the re-read match
        // nothing and the caller is told 200 with an empty body about a write
        // that landed. Every other mount keeps the statement it always had.
        let selectSql = `SELECT * FROM \`${t(logicalName)}\` WHERE id = ?`;
        const selectParams = [req.params.id];
        if (writeScopeColumn && req.user && req.user.role !== 'admin' && !delegatedTemplateWrite) {
          selectSql += ` AND \`${writeScopeColumn}\` = ?`;
          selectParams.push(req.user.id);
        }
        const rows = await conn.query(selectSql, selectParams);
        // In-tx post-UPDATE cascade (e.g. re-derive child db_instances.sga_gb from
        // the database's new Primary/Standby SGA). Runs only now that the
        // ownership-scoped UPDATE matched a row, so an unauthorized PUT never
        // triggers it. A throw propagates to the outer catch → whole-tx rollback,
        // so the parent write and the cascade commit or fail together.
        if (postUpdateInTx) {
          // Pass only the keys actually written (gated to the physical column
          // set), so the hook's presence checks reflect the persisted row: on a
          // lagging schema a dropped column is simply absent → the cascade skips
          // it, matching the graceful degrade the rest of this path uses (no
          // unknown-column tx abort).
          const gatedData = {};
          for (const k of keys) gatedData[k] = data[k];
          await postUpdateInTx(conn, req, gatedData);
        }
        // Append the immutable code-version history row in the SAME transaction —
        // only now that the ownership-scoped UPDATE has matched a row (an
        // unauthorized no-op returned 404 above and never reaches here). The
        // history-table presence was already probed before the bump was folded in,
        // so a failure HERE is a genuine error (e.g. the table was dropped mid-
        // request): it is NOT swallowed — it propagates to the outer catch and
        // rolls the whole tx back, reverting the counter bump too. Counter and
        // history row succeed or fail together.
        if (cvBump) {
          await conn.query(
            `INSERT INTO \`${t(codeVersioning.historyTable)}\` (id, \`${codeVersioning.historyFkColumn}\`, version, code, action, created_by) VALUES (?, ?, ?, ?, 'update', ?)`,
            [uuidv4(), req.params.id, cvBump.newVersion, cvBump.code, (req.user && req.user.id) || null],
          );
        }
        // Re-pend the parent recipe inside this transaction (FOR UPDATE lock).
        // Stored parent always; the destination parent too whenever the write
        // actually settles on one.
        if (parentRepend) {
          // SAFETY: read destVia from `data` (the row this UPDATE will write) so
          // the destination re-pend only fires when the re-parent actually
          // persists. `data[parentRepend.via]` is absent for a PUT that never
          // named the column, and — for a non-admin caller — for one the
          // ownership judgment above refused (the request never reaches this
          // line; it returned 403). It is present for a lawful admin OR editor
          // re-parent alike, so both callers' genuine moves re-pend the
          // destination the same way.
          const destVia = data ? data[parentRepend.via] : undefined;
          // SAFETY: an admin re-parent re-pends TWO parents (stored + destination).
          // Acquire the two FOR UPDATE locks in a deterministic (sorted) order so two
          // concurrent opposite-direction re-parents can never lock the pair in
          // reverse order and deadlock (ABBA). Mirrors isLinkedParentLocked's sort.
          // The owner/status gate inside repandParentInTx is per-id and
          // order-independent, so sorting only changes lock-acquisition order.
          // Canonicalise by lowercase: parent ids are CHAR(36) under MariaDB's
          // case-insensitive collation (so 'A…' and 'a…' are the SAME row), but JS
          // sort/Set are case-sensitive — without a canonical key two concurrent
          // re-parents using different-case ids for the same pair (destVia comes
          // from the client body) could still sort divergently and deadlock. The
          // original-case value is kept for the query (the DB matches either case).
          const byKey = new Map();
          for (const v of [rependStoredVia, destVia]) {
            if (v != null) byKey.set(String(v).toLowerCase(), v);
          }
          const targets = [...byKey.keys()].sort().map((k) => byKey.get(k));
          // A PARENT THIS WRITE NAMES HAS TO EXIST. Only that one — and "names"
          // means the body carried the FK, not that the row already has one.
          //
          // Falling back to the stored parent here made the refusal fire on
          // every PARTIAL edit, which is every edit that does not re-parent, and
          // that is the opposite of the rule: a PUT whose STORED parent has
          // already vanished is an edit of a row that is ALREADY orphaned, and
          // refusing it removes the only ways to repair the row in place.
          // Measured, admin, on a step whose recipe was deleted:
          // `PUT {name}` → 404, and `PUT {auth_type:'none'}` — the request that
          // strips the stored credential — → 404, so the encrypted secret stayed
          // in the row with no way to clear it. Re-parent and delete still
          // worked, so nothing was trapped; what was blocked was every repair
          // short of those two.
          //
          // Refusing a MOVE onto a parent that is not there stays: that write
          // names its destination, and landing the row under nothing is the
          // orphan this guard exists to prevent. The other target is still
          // re-pended, best-effort, exactly as before.
          const effectiveKey = destVia == null ? null : String(destVia).toLowerCase();
          for (const pid of targets) {
            const { parentMissing } = await repandParentInTx(conn, pid, req);
            if (parentMissing && effectiveKey !== null
              && String(pid).toLowerCase() === effectiveKey) {
              await conn.rollback();
              return sendError(req, res, null, { status: 404, code: 'PARENT_NOT_FOUND', reason: 'The parent record this belongs to does not exist' });
            }
          }
        }
        if (guardTx) await conn.commit();
        // The trail of who changed what, written AFTER the change has landed
        // and outside its transaction. Inside it, a trail row would be able to
        // roll the change back, which is the one thing recording must never do.
        // The writer never throws — a dropped row is logged, not raised — so
        // this needs no guard of its own.
        if (templateActivityTrail) {
          await recordTemplateActivity(conn, {
            templateId: req.params.id,
            actorId: req.user && req.user.id,
            action: ACTIVITY_ACTIONS.CONTENT_EDITED,
            // Which columns were written, never their values: the trail says
            // what was touched and by whom, and the record itself is where the
            // values live.
            metadata: { columns: keys },
          });
        }
        // Enrich the write response the same way a read is (see the create
        // handler); a PUT reply then carries the same shape as a later GET.
        const updatedRows = parseRows(rows);
        await attachEnrichment(conn, updatedRows);
        res.json(apiOk(applyReadSerializer(updatedRows)[0]));
      } catch (errInner) {
        if (guardTx) { try { await conn.rollback(); } catch { /* best effort */ } }
        throw errInner;
      } finally {
        conn.release();
      }
    } catch (err) {
      if (uniqueWithin && err && err.errno === 1062) {
        return sendError(req, res, err, { status: 409, code: uniqueWithin.code, reason: 'A row with this key already exists for this blueprint' });
      }
      if (mapDuplicateKey && err && err.errno === 1062) {
        return sendError(req, res, err, { status: 409, code: mapDuplicateKey.code, reason: mapDuplicateKey.message });
      }
      const conflict = writeConflictError(err);
      if (conflict) {
        req.log.warn({ err, table: logicalName, rowId: req.params.id }, 'Update lost a lock race on id=' + req.params.id + ' in ' + logicalName);
        // lint-allow: logger-discipline two-step consumes a helper-built apiError-shaped result, not a direct apiError call at this site
        return res.status(conflict.status).json(conflict.body);
      }
      sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { table: logicalName, rowId: req.params.id } });
    }
  });

  // DELETE /:id
  // lint-allow: route-auth guarded via the local writeGate() wrapper (defined above, calls requireAuth/requireAdmin/requireAdminOrEditor by role) — not a literal call the route-auth scanner's evidence regex matches
  r.delete('/:id', async (req, res) => {
    // SECURITY: user-scoped tables let non-admins delete their
    // own rows. Otherwise admin-only.
    if (!writeGate(req, res)) return;
    try {
      // S1/S2: block schema deletes on a linked blueprint (all roles).
      // NOTE: DELETE intentionally keeps the non-transactional separate-conn
      // guard (no FOR UPDATE) — removing a row from a now-linked blueprint is
      // harmless cleanup, so the 2a write-path TOCTOU (orphan rows on INSERT/
      // UPDATE) does not apply here.
      if (await rejectLinkedParent(req, res, undefined)) return;
      const conn = await (await resolveRwPool(req)).getConnection();
      // parentRepend or dependentCleanup require a transaction so the parent
      // re-pend / dependent-row cleanup is committed atomically with the delete.
      // Non-opt-in tables keep the autocommit path byte-identical (no begin /
      // no FOR UPDATE / no commit).
      const guardTx = !!parentRepend || dependentCleanup.length > 0 || !!codeVersioning
        || refuseDeleteWhenReferenced.length > 0 || tolerantDependentCleanup.length > 0;
      // THE SCOPE THE DELETE MATCHES ON, built before anything is locked so the
      // same predicate can answer "may this caller touch this row at all" first.
      // Returns null when a configured column fails the identifier whitelist —
      // the same 500 the inline checks used to raise, moved to one place so the
      // entitlement read and the statement can never be scoped differently.
      const buildDeleteScope = async () => {
        let clause = '';
        const params = [];
        if (writeScopeColumn && req.user && req.user.role !== 'admin') {
          if (!isSafeColumnName(writeScopeColumn)) return null;
          clause += ` AND \`${writeScopeColumn}\` = ?`;
          params.push(req.user.id);
        }
        // Editor's DELETE matches only owner-of OR shared (NULL) rows.
        if (ownerColumn && req.user && req.user.role === 'editor') {
          if (!isSafeColumnName(ownerColumn)) return null;
          clause += ` AND (\`${ownerColumn}\` IS NULL OR \`${ownerColumn}\` = ?)`;
          params.push(req.user.id);
        }
        // NOTE: chain DSL — DELETE shares the EXISTS form with PUT.
        // Closes the same two holes (precedence + NULL-ambiguity) and
        // additionally hardens against orphan-row mass-delete: an editor
        // who knows an orphan field_options.id can no longer DELETE it
        // because a broken parent chain yields 0 EXISTS rows.
        // spec §6.4a: (owns/shared parent) OR (holds a blueprint grant on it),
        // via the shared fragment. A node_type-scoped mount does NOT reach here:
        // hierarchy_nodes routes its DELETE through a custom handler
        // (routes-hierarchy.js), so its variant grant arm for delete lives in
        // mayActOnHierarchyNode, not this factory DELETE — this arm stays
        // byte-identical to before the whenNodeType option existed for every
        // mount that uses the generic delete (variant_overrides et al.).
        if (parentOwnership && !parentOwnership.whenNodeType
            && req.user && req.user.role === 'editor') {
          const frag = await parentOwnershipScopeFragment(req, conn);
          clause += ` AND ${frag.sql}`;
          params.push(...frag.params);
        }
        return { clause, params };
      };
      try {
        if (guardTx) await conn.beginTransaction();
        const scope = await buildDeleteScope();
        if (!scope) {
          if (guardTx) await conn.rollback();
          return sendError(req, res, null, { status: 500, code: 'INTERNAL_ERROR', reason: 'Internal misconfiguration' });
        }
        // ENTITLEMENT IS ESTABLISHED BEFORE ANY LOCK IS TAKEN, with a read that
        // takes none itself.
        //
        // The two probes below both lock rows, and both used to run ahead of the
        // ownership-scoped DELETE — so a caller with no right to this row could
        // still make the handler take an X lock on its children and then wait on
        // whoever holds them. Measured with one step row locked by an unrelated
        // transaction: a single unauthorised DELETE waited 1213 ms before
        // answering its (correct) 404, and six of them in flight took the pool
        // down — an unrelated, legitimate GET that answered in 4 ms on the tree
        // before the probes moved into the transaction did not answer within
        // 3000 ms. Each parked request holds a handler and a pooled connection
        // for up to `innodb_lock_wait_timeout`, which is 50 s by default. The
        // wait is also a timing side channel: it is observable only for rows
        // that exist and are contended, which is more than a 404 discloses.
        //
        // This read is deliberately NOT `FOR UPDATE`. It decides only whether to
        // proceed, never what is written; the DELETE below carries the identical
        // predicate and remains the authority, so a row whose ownership changes
        // between the two still ends in the same 404. A lock here would recreate
        // exactly the exposure it exists to remove.
        //
        // Child-before-parent ordering is untouched: the probes still run in the
        // same order, on the same connection, before the statement.
        if (locksBeforeDelete) {
          const entitled = await conn.query(
            `SELECT id FROM \`${t(logicalName)}\` WHERE id = ?${scope.clause}`,
            [req.params.id, ...scope.params],
          );
          if (!entitled.length) {
            if (guardTx) await conn.rollback();
            return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
          }
        }
        // Resolve the deleted child's parent BEFORE the DELETE removes the row.
        let rependStoredVia = null;
        if (parentRepend) {
          // SECURITY: lock the child row so a concurrent re-parent cannot
          // move it to a different parent between this read and the DELETE,
          // which would silently skip re-pending the intermediate parent.
          const cr = await conn.query(
            `SELECT \`${parentRepend.via}\` AS via FROM \`${t(logicalName)}\` WHERE id = ? FOR UPDATE`,
            [req.params.id],
          );
          rependStoredVia = cr.length ? cr[0].via : null;
        }
        // THE REFERENCE PROBE, TAKEN BEFORE THE STATEMENT AND ANSWERED AFTER IT.
        //
        // The two halves are separated on purpose, and each half is where it is
        // for a different reason.
        //
        // The LOCK is taken here because every other path that touches this pair
        // of tables locks the CHILD first and the parent last — the step write's
        // own `FOR UPDATE` on its row, then `repandParentInTx` on the recipe.
        // Taking the child lock AFTER the DELETE had already taken the parent's
        // inverted that order and closed a cycle: measured over 40 concurrent
        // step-write/recipe-delete pairs, 13 of the step writes died with errno
        // 1213 and were reported to the client as a 500. Before this gate moved
        // into the transaction the probe was an unlocked `pool.ro` read outside
        // it and took no child lock at all, so no cycle existed to inherit.
        //
        // The ANSWER is deferred to after the ownership-scoped DELETE, because a
        // 409 raised here would speak about a row the caller may not be allowed
        // to know exists — every other refusal on this path answers 404 for
        // exactly that reason. Once the DELETE has matched, the caller has been
        // shown to have the right to remove the row, so a 409 tells them nothing
        // a 404 would have hidden. The refusal is still carried out by rolling
        // the transaction back, so the row and the cleanup below are restored.
        //
        // A missing child TABLE is not a refusal: there is nothing to orphan.
        let referencedBy = null;
        for (const ref of refuseDeleteWhenReferenced) {
          try {
            const hit = await conn.query(
              `SELECT 1 FROM \`${t(ref.table)}\` WHERE \`${ref.fk}\` = ? LIMIT 1 FOR UPDATE`,
              [req.params.id],
            );
            if (hit.length) { referencedBy = ref; break; }
          } catch (refErr) {
            if (!(refErr && refErr.errno === 1146)) throw refErr;
          }
        }
        const deleteSql = `DELETE FROM \`${t(logicalName)}\` WHERE id = ?${scope.clause}`;
        const deleteParams = [req.params.id, ...scope.params];
        const result = await conn.query(deleteSql, deleteParams);
        if (result.affectedRows === 0) {
          if (guardTx) await conn.rollback();
          return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
        }
        // The verdict the probe above reached, spoken only now that the
        // ownership-scoped DELETE has established the caller may know this row
        // exists. See the probe for why the lock and the answer are separated.
        if (referencedBy) {
          await conn.rollback();
          return sendError(req, res, null, { status: 409, code: referencedBy.code, reason: referencedBy.message || 'This record is still referenced and cannot be deleted' });
        }
        // Zero-FK cascade substitute: only after the ownership-scoped delete
        // actually matched a row (checked above) do we clean dependents, so an
        // unauthorized/no-op delete never touches child tables. Keyed on the
        // deleted row's id (req.params.id).
        for (const dep of dependentCleanup) {
          await conn.query(
            `DELETE FROM \`${t(dep.table)}\` WHERE \`${dep.fk}\` = ?`,
            [req.params.id],
          );
        }
        // Additive dependent tables: a missing table (1146) means there is
        // nothing to orphan, so it must not 1146-fail the whole delete the way
        // the strict dependentCleanup loop above would. MISSING TABLE ONLY: a
        // missing COLUMN (1054) is a schema-parity defect and must surface, so
        // this shares isMissingTable with the read-enrichment path rather than
        // the broader isMissingTableOrColumn the codeVersioning cleanup uses.
        for (const dep of tolerantDependentCleanup) {
          try {
            await conn.query(
              `DELETE FROM \`${t(dep.table)}\` WHERE \`${dep.fk}\` = ?`,
              [req.params.id],
            );
          } catch (depErr) {
            if (!isMissingTable(depErr)) throw depErr;
          }
        }
        // Code-versioning: clean the deleted row's history in the SAME transaction.
        // dependentCleanup is NOT reused for this because it would 1146-fail the
        // whole delete on a no-ALTER DB that never got the history table; here the
        // cleanup is best-effort (a missing table simply has nothing to clean).
        if (codeVersioning) {
          try {
            await conn.query(
              `DELETE FROM \`${t(codeVersioning.historyTable)}\` WHERE \`${codeVersioning.historyFkColumn}\` = ?`,
              [req.params.id],
            );
          } catch (cvErr) {
            if (!isMissingTableOrColumn(cvErr)) throw cvErr;
            warnCodeVersioningDegradedOnce(logicalName, 'delete-cleanup', req.log);
          }
        }
        // Re-pend the parent recipe inside this transaction (FOR UPDATE lock).
        if (parentRepend) await repandParentInTx(conn, rependStoredVia, req);
        if (guardTx) await conn.commit();
        res.json(apiOk(null));
      } catch (errInner) {
        if (guardTx) { try { await conn.rollback(); } catch { /* best effort */ } }
        throw errInner;
      } finally {
        conn.release();
      }
    } catch (err) {
      const conflict = writeConflictError(err);
      if (conflict) {
        req.log.warn({ err, table: logicalName, rowId: req.params.id }, 'Delete lost a lock race on id=' + req.params.id + ' from ' + logicalName);
        // lint-allow: logger-discipline two-step consumes a helper-built apiError-shaped result, not a direct apiError call at this site
        return res.status(conflict.status).json(conflict.body);
      }
      sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { table: logicalName, rowId: req.params.id } });
    }
  });

  return r;
}

module.exports = {
  createCrudRoutes, declaredCharColumnEscapes, servedTables, mountShapes,
  writeConflictError, PARENT_NOT_OWNED, PARENT_REQUIRED,
};
