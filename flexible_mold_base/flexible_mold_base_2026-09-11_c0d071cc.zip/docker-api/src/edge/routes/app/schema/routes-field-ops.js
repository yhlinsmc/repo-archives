const {
  TABLES,
  VARIANT_OVERRIDE_ACTIONS,
  pool,
  t,
  getDynamicPool,
  apiOk,
  apiError,
  requireAuth,
  requireAdmin,
  requireAdminOrEditor,
  isOwnerOrAdmin,
  uuidv4,
  UUID_RE,
  mapRowFromDb,
  mapRowsFromDb,
  mapRowToDb,
  previewCascade,
  cascadeDeleteNode,
  collectDescendantIds,
  tableExistsInCurrentSchema,
  buildVariantOverrideUpdateExistsClause,
  buildVariantOverrideInsertExistsClause,
  buildDuplicateActionTripleNotExistsClause,
  applyOwnerChange,
  enrichOwnerNames,
  validateComputeRule,
  detectCycle,
  invalidChoiceConfigShape,
  resolveAncestors,
  restampTemplates,
  countAffectedTemplates,
  isValidBlueprintParent,
  HIERARCHY_OWNER_AUDIT_EVENT,
  USER_TEMPLATE_OWNER_AUDIT_EVENT,
  resolveOwnershipRwPool,
  cascadeBlueprintOwnerToVariants,
  SAFE_COL_RE,
  isSafeColumnName,
  SLUG_KEY_PATTERN,
  isValidSlugKey,
  isBlueprintLinked,
  isBlueprintLinkedLocked,
  isLinkedParentLocked,
  auditSchemaClearFailed,
  validateLinkConstraints,
  resolveLinkCheckBlueprintId,
  _columnSetCache,
  getConnDatabaseName,
  getActualColumnSet,
  _historyTableCache,
  isCodeVersionHistoryAvailable,
  gateKeysByColumnSet,
  TABLE_VALUES,
  validateCodeVersioning,
  isMissingTableOrColumn,
  _codeVersioningDegraded,
  warnCodeVersioningDegradedOnce,
  validateAndPrepareParentOwnership,
  validateAndPrepareParentRepend,
  buildChainSelectSql,
  buildChainExistsForRow,
  ENCRYPTION_GATE_422,
  runSerializeWrite,
  editorMayWriteBlueprint,
  MAX_BATCH_FIELD_IDS,
  MAX_BATCH_BLUEPRINT_IDS,
} = require('./helpers');
const { metadataKeySitesPresentIn } = require('../../../lib/user-template-metadata');
const { sendError } = require('../../../../shared/lib/send-error');
// The shape rule and the clash probe live beside each other in one module
// because they are one rule about one column, and the endpoint that WRITES a
// key must apply exactly what the endpoint below applies to migrate it.
const { isValidFieldKey, fieldKeyTaken, FIELD_KEY_TAKEN } = require('./field-key');


// ---------------------------------------------------------------------------
// Schema Impact Detection + Field Rename Migration
// ---------------------------------------------------------------------------

/**
 * The answers document. Not part of the shared metadata declaration — it is the
 * values themselves rather than metadata about them — but it is a field-key-
 * indexed document on the same row, so the rename treats it as one more site and
 * builds its statement the same way. Always present (it predates every additive
 * column), so it needs no column probe.
 */
const PAYLOAD_KEY_SITE = Object.freeze({ column: 'payload', container: '$' });

/**
 * Every blueprint id a `user_templates` row may carry in its own `blueprint_id`
 * column and still be governed by `blueprintId`'s fields: `blueprintId` itself,
 * plus every blueprint that LINKS to it (`hierarchy_nodes.linked_blueprint_id`).
 * `{ut rows with blueprint_id IN (this list)}` is exactly `{ut rows whose
 * EFFECTIVE blueprint — effectiveBlueprintIdSql in helpers.js, the same
 * resolution the orphan scanner uses — is blueprintId}`, because
 * `hierarchy_nodes.id` is the primary key both expressions resolve a link
 * against.
 *
 * Resolved as a small, indexed lookup against `hierarchy_nodes` (blueprint
 * count) rather than spelled out as a per-row expression over `user_templates`
 * (answer count): `WHERE effectiveBlueprintIdSql(...) = ?` cannot use
 * `idx_user_templates_blueprint`, so it forced a full scan of the largest table
 * this rename touches and held the UPDATE's row locks for the length of that
 * scan. `WHERE blueprint_id IN (...)` on the result below is sargable again.
 *
 * A stored `''` never reaches this list: `linked_blueprint_id = ?` only matches
 * rows holding the literal target id, and an empty string can never equal a
 * real one — no NULLIF needed on this side of the equivalence, unlike resolving
 * a possibly-absent stored value.
 *
 * `forUpdate: true` is what the rename write MUST pass, and why is worth
 * spelling out. The COALESCE-JOIN shape this replaced resolved the link
 * atomically inside the UPDATE itself; resolving it as a separate SELECT
 * reopened a window between "read which blueprints are in scope" and "write
 * every row in scope" — a concurrent PUT that unlinks a blueprint from
 * `blueprintId` in that window would still have its templates rewritten, even
 * though its answers are no longer governed by `blueprintId`'s fields. `FOR
 * UPDATE` closes it: it locks `blueprintId`'s OWN row (`id = ?`, the same row
 * the link-creation transition locks at
 * routes-blueprint-fields.js's `targetLock` query) and every row CURRENTLY
 * linking to it (`linked_blueprint_id = ?`). An unlink is an ordinary
 * `UPDATE hierarchy_nodes SET ... WHERE id = ?` (crud-factory's generic PUT,
 * `updateSql` in crud-factory.js), which takes the very same row's lock — so a
 * concurrent unlink either commits before this SELECT (and is excluded, having
 * already left the scope) or blocks until this transaction ends (and is
 * included, having not yet left). Either way, no answer this rename writes was
 * outside its scope at the instant it was written.
 *
 * `forUpdate: false` (the preview) is a plain read outside any transaction —
 * intentionally not locked. A count an operator reads before deciding whether
 * to rename is a preview, not a commitment, and holding a lock across an HTTP
 * response for a value nothing downstream depends on would serialize every
 * concurrent link edit behind every open preview tab for no correctness this
 * endpoint needs.
 */
async function resolveEffectiveBlueprintIds(conn, blueprintId, { forUpdate = false } = {}) {
  const rows = await conn.query(
    `SELECT id FROM \`${t(TABLES.HIERARCHY_NODES)}\`
      WHERE id = ? OR linked_blueprint_id = ?${forUpdate ? ' FOR UPDATE' : ''}`,
    [blueprintId, blueprintId],
  );
  return [...new Set([blueprintId, ...rows.map((row) => row.id)])];
}

/**
 * One statement per key site: copy the value from the old key to the new one and
 * drop the old, scoped to every blueprint `resolveEffectiveBlueprintIds` names.
 *
 * The `IS NOT NULL` on the extracted old key is load-bearing, not a filter for
 * speed: JSON_EXTRACT of an absent path returns NULL, and JSON_SET would then
 * write a null-valued NEW key into every row of the blueprint. It also makes a
 * column holding unparseable text a no-op instead of a wipe, because MariaDB
 * answers NULL there too.
 */
function buildKeyRenameUpdate(site, oldKey, newKey, blueprintIds) {
  if (!isSafeColumnName(site.column)) {
    throw new Error(`[rename]: ${site.column} fails column whitelist`);
  }
  const path = (key) => `${site.container}."${key}"`;
  const col = `\`${site.column}\``;
  const placeholders = blueprintIds.map(() => '?').join(', ');
  return {
    sql: `UPDATE \`${t(TABLES.USER_TEMPLATES)}\`
         SET ${col} = JSON_SET(
           JSON_REMOVE(${col}, ?),
           ?, JSON_EXTRACT(${col}, ?)
         )
         WHERE blueprint_id IN (${placeholders})
           AND ${col} IS NOT NULL
           AND JSON_EXTRACT(${col}, ?) IS NOT NULL`,
    params: [path(oldKey), path(newKey), path(oldKey), ...blueprintIds, path(oldKey)],
  };
}

function register(router) {

/**
 * GET /impact/:fieldId — count templates affected by a field (delete warning).
 * Returns { template_count, template_names }.
 */
router.get('/impact/:fieldId', async (req, res) => {
  // NOTE: editors can reach Schema Builder and pre-check impact counts
  // before renaming. Admin-only would silently break the rename UX for
  // editors; allow read of the impact count for both roles.
  if (!requireAdminOrEditor(req, res)) return;
  try {
    // Two pure SELECTs — impact preview → pool.ro.
    const conn = await pool.ro.getConnection();
    try {
      // Look up the field to get blueprint_id + field_key
      const fields = await conn.query(
        `SELECT blueprint_id, field_key FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\` WHERE id = ?`,
        [req.params.fieldId],
      );
      if (!fields.length) {
        return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Field not found' });
      }
      const { blueprint_id, field_key } = fields[0];

      // Defensive: reject malformed field_key from DB to prevent JSON path issues
      if (!isValidFieldKey(field_key)) {
        return sendError(req, res, null, { status: 500, code: 'INTERNAL_ERROR', reason: 'Field has invalid key format in database' });
      }

      // Find templates whose payload contains this field key, scoped by every
      // blueprint resolveEffectiveBlueprintIds names — the SAME resolution the
      // rename below uses, via the same call, so this count (what an operator
      // reads before choosing to rename) can never disagree with how many
      // records the rename actually touches, MODULO a link edit racing this
      // read. Deliberately unlocked (forUpdate omitted/false): this is a
      // preview outside any transaction, not the write, and the write is what
      // the locking below guards — see resolveEffectiveBlueprintIds' own
      // comment for why the preview does not also need to serialize with one.
      const impactBlueprintIds = await resolveEffectiveBlueprintIds(conn, blueprint_id);
      const impactPlaceholders = impactBlueprintIds.map(() => '?').join(', ');
      const templates = await conn.query(
        `SELECT id, name FROM \`${t(TABLES.USER_TEMPLATES)}\`
         WHERE blueprint_id IN (${impactPlaceholders})
           AND payload IS NOT NULL
           AND JSON_EXTRACT(payload, ?) IS NOT NULL`,
        [...impactBlueprintIds, `$."${field_key}"`],
      );

      res.json(apiOk({
        template_count: templates.length,
        template_names: templates.map(tpl => tpl.name || tpl.id),
      }));
    } finally {
      conn.release();
    }
  } catch (err) {
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { fieldId: req.params.fieldId } });
  }
});


/**
 * POST /rename/:fieldId — rename a field key across all template payloads.
 * Body: { old_key: string, new_key: string }
 *
 * Both keys are validated against the field key format regex before any SQL
 * execution to prevent JSON path injection.
 */
router.post('/rename/:fieldId', async (req, res) => {
  // NOTE: editors need this endpoint to migrate template payloads when
  // renaming a field, so the role gate admits them. Ownership of the blueprint
  // the field belongs to is checked separately, below, inside the write
  // transaction — it used to be left to the PUT this call accompanies, which
  // made it a property of how the client sequenced two requests.
  if (!requireAdminOrEditor(req, res)) return;
  const { old_key, new_key } = req.body || {};

  // Input validation
  if (!old_key || !new_key) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'old_key and new_key are required' });
  }
  if (!isValidFieldKey(old_key)) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'old_key has invalid format' });
  }
  if (!isValidFieldKey(new_key)) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'new_key has invalid format' });
  }
  if (old_key === new_key) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'old_key and new_key must be different' });
  }

  try {
    // SELECT guard + UPDATE of user_templates payloads on same conn → pool.rw.
    const conn = await pool.rw.getConnection();
    try {
      // Look up the field to get blueprint_id and verify it exists
      const fields = await conn.query(
        `SELECT blueprint_id, field_key FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\` WHERE id = ?`,
        [req.params.fieldId],
      );
      if (!fields.length) {
        return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Field not found' });
      }
      const { blueprint_id, field_key: dbFieldKey } = fields[0];

      // Security: verify old_key matches the actual DB field key to prevent
      // an admin from using an arbitrary fieldId as a blueprint-scope anchor
      // to rename unrelated keys across all templates.
      // byte-compare: the stored key is resolved by a JAVASCRIPT reader here and
      // in every statement below, which builds a JSON path out of the caller's
      // spelling — folding two spellings into one would migrate the answers of a
      // path no record holds.
      if (dbFieldKey !== old_key) {
        return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'old_key does not match the current field key' });
      }

      // A column absent from this DB (a target that warn-skipped an additive
      // ALTER) is skipped rather than named in a statement that would 1054 the
      // whole rename — the same tolerance the CRUD write path and the
      // cross-environment sync already apply to these columns. A null probe
      // result means "could not tell", which keeps every site.
      const colSet = await getActualColumnSet(conn, t(TABLES.USER_TEMPLATES));
      const sites = [PAYLOAD_KEY_SITE, ...metadataKeySitesPresentIn(colSet)];

      // One transaction over all of them: a rename that moved the values but not
      // the metadata leaves the row describing choices about keys that no longer
      // exist, which is the state this endpoint is supposed to be repairing.
      const migrated = {};
      await conn.beginTransaction();
      try {
        // Resolved INSIDE the transaction, locking (forUpdate: true), before any
        // row of user_templates is touched. Resolving this as a plain read ahead
        // of the transaction reopened the TOCTOU the old COALESCE-JOIN closed by
        // resolving atomically inside the UPDATE: a concurrent PUT unlinking a
        // blueprint from this one, landing between an unlocked read and the
        // write below, would still have that blueprint's templates rewritten
        // after they had already left scope. See resolveEffectiveBlueprintIds'
        // own comment for the row-lock argument this depends on.
        const blueprintIds = await resolveEffectiveBlueprintIds(conn, blueprint_id, { forUpdate: true });
        // The role gate at the top of this handler is not an authorization check.
        // The endpoint takes a fieldId and rewrites every template under whatever
        // blueprint that field belongs to, so an editor can name a field under a
        // blueprint they do not own. The route's own comment called the ownership
        // check implicit in the PUT the rename is issued alongside — an assumption
        // about how a client sequences two calls, not an invariant of this one.
        // Same helper, same message and same in-transaction placement the sibling
        // structural endpoints use.
        // `blueprint_id` here IS the field's own (and therefore EFFECTIVE) blueprint
        // — `blueprintIds` above widens the write to every template whose
        // effective blueprint resolves to it, including one reached only through
        // a link, and this field's home blueprint is the schema authority for
        // every one of those rows. Same authority `editorOwnsTemplateBlueprint`
        // in routes-orphans.js checks, not the borrowing blueprint's own owner.
        if (!(await editorMayWriteBlueprint(conn, req, blueprint_id))) {
          await conn.rollback();
          return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Not allowed: blueprint is not owned by you and is not shared' });
        }
        // A destination a SIBLING field already owns is not a rename, it is a
        // merge: the statements below copy this field's answer onto the
        // destination path in every record of the blueprint, and the value that
        // was there is stored nowhere else. Asked in the same transaction as the
        // statements, and asked the way the column compares.
        if (await fieldKeyTaken(conn, blueprint_id, new_key, req.params.fieldId)) {
          await conn.rollback();
          return sendError(req, res, null, { status: FIELD_KEY_TAKEN.status, code: FIELD_KEY_TAKEN.code, reason: FIELD_KEY_TAKEN.message });
        }
        for (const site of sites) {
          const { sql, params } = buildKeyRenameUpdate(site, old_key, new_key, blueprintIds);
          const result = await conn.query(sql, params);
          migrated[site.column] = (migrated[site.column] || 0) + (result.affectedRows || 0);
        }
        await conn.commit();
      } catch (txErr) {
        // Best-effort, so a rollback that fails cannot replace the error that
        // actually explains the failure.
        try { await conn.rollback(); } catch { /* best effort */ }
        throw txErr;
      }

      req.log.info(
        { fieldId: req.params.fieldId, old_key, new_key, migrated },
        'Renamed field key in template payloads',
      );

      res.json(apiOk({
        // Unchanged meaning: the number of records whose ANSWERS moved. The
        // metadata counts are logged rather than returned because a record can
        // carry a marker for a field it holds no value for, and reporting a
        // larger number here would read as more records edited.
        migrated_count: migrated.payload || 0,
      }));
    } finally {
      conn.release();
    }
  } catch (err) {
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { fieldId: req.params.fieldId, old_key, new_key } });
  }
});
}

module.exports = { register };
