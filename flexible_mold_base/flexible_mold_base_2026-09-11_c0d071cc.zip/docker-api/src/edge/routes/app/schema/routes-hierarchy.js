const {
  TABLES,
  VARIANT_OVERRIDE_ACTIONS,
  pool,
  t,
  getDynamicPool,
  apiOk,
  apiError,
  requireAuth,
  requireAdmin,
  requireAdminOrEditor,
  isOwnerOrAdmin,
  uuidv4,
  UUID_RE,
  mapRowFromDb,
  mapRowsFromDb,
  mapRowToDb,
  previewCascade,
  cascadeDeleteNode,
  collectDescendantIds,
  tableExistsInCurrentSchema,
  buildVariantOverrideUpdateExistsClause,
  buildVariantOverrideInsertExistsClause,
  buildDuplicateActionTripleNotExistsClause,
  applyOwnerChange,
  enrichOwnerNames,
  validateComputeRule,
  detectCycle,
  invalidChoiceConfigShape,
  resolveAncestors,
  restampTemplates,
  countAffectedTemplates,
  isValidBlueprintParent,
  HIERARCHY_OWNER_AUDIT_EVENT,
  USER_TEMPLATE_OWNER_AUDIT_EVENT,
  resolveOwnershipRwPool,
  cascadeBlueprintOwnerToVariants,
  SAFE_COL_RE,
  isSafeColumnName,
  SLUG_KEY_PATTERN,
  isValidSlugKey,
  isBlueprintLinked,
  isBlueprintLinkedLocked,
  isLinkedParentLocked,
  auditSchemaClearFailed,
  validateLinkConstraints,
  resolveLinkCheckBlueprintId,
  _columnSetCache,
  getConnDatabaseName,
  getActualColumnSet,
  _historyTableCache,
  isCodeVersionHistoryAvailable,
  gateKeysByColumnSet,
  TABLE_VALUES,
  validateCodeVersioning,
  isMissingTableOrColumn,
  _codeVersioningDegraded,
  warnCodeVersioningDegradedOnce,
  validateAndPrepareParentOwnership,
  validateAndPrepareParentRepend,
  buildChainSelectSql,
  buildChainExistsForRow,
  ENCRYPTION_GATE_422,
  runSerializeWrite,
  editorMayWriteBlueprint,
  MAX_BATCH_FIELD_IDS,
  MAX_BATCH_BLUEPRINT_IDS,
} = require('./helpers');
const { resolveCanonicalUserId, sameStoredValue, ownerTargetRejection } = require('./write-value');
const { sendError } = require('../../../../shared/lib/send-error');
const { callerHasBlueprintGrant } = require('../../../lib/delegated-grants');
const { markReadOnly } = require('../../../../shared/middleware/route-markers');


// Owner-aware authorization for the two destructive hierarchy endpoints
// (cascade-preview + DELETE). Composes the existing owner boolean
// `isOwnerOrAdmin` — it does NOT fork a parallel ownership rule.
//
// SECURITY: the owner branch applies ONLY to blueprint / variant nodes, which
// carry a meaningful `owner_id` via the inherit + cascade invariant (variants
// inherit their parent blueprint's owner through `inheritOwnerFromParent`, and
// every transfer cascades to variants under `cascadeBlueprintOwnerToVariants`
// above). Structural nodes (category / release) carry `owner_id = NULL`, and
// the app-wide "NULL owner = shared, editor may act" convention (isOwnerOrAdmin)
// must NOT extend to cascade-deleting a structural subtree — those stay
// admin-only. Fails closed — for EVERY role — on a missing row or an unknown
// node_type. (Both handlers 404 a missing node before calling this; the null
// check here is defense in depth so a caller that skips that guard denies
// rather than letting an admin through on a null row.) Returns true iff the
// caller may act on the node.
async function mayActOnHierarchyNode(conn, req, node) {
  if (!req.user) return false;
  if (!node) return false;
  if (req.user.role === 'admin') return true;
  if (node.node_type === 'blueprint') {
    return isOwnerOrAdmin(conn, TABLES.HIERARCHY_NODES, req, node);
  }
  if (node.node_type === 'variant') {
    // spec §6.1: a blueprint-scope grant covers the variant subtree, so a
    // grantee may act on (delete, and preview that delete) a variant under a
    // blueprint they hold a grant on — the destructive twin of the create/rename
    // grant arm the factory carries. The owner arm is asked first (owns/shared
    // via the inherit+cascade invariant); then the grant, keyed on the variant's
    // parent blueprint id. callerHasBlueprintGrant re-asserts node_type='blueprint'
    // on that parent, the grant-eligible role floor, and grant dormancy on a
    // shared (owner NULL) blueprint, so this arm cannot admit through a
    // non-blueprint parent or a plain user.
    if (await isOwnerOrAdmin(conn, TABLES.HIERARCHY_NODES, req, node)) return true;
    return callerHasBlueprintGrant(conn, req.user.id, node.parent_id, req.user.role);
  }
  return false;
}


// Loads + validates a blueprint move under the caller's transaction. Returns
// { error } (shaped like apiError) or { node, parent }. Editors may move only
// own/shared blueprints; targets are admin-managed shared structural nodes
// with no owner check needed on them.
async function validateReparent(conn, req, nodeId, newParentId) {
  if (typeof newParentId !== 'string' || newParentId.length === 0) {
    return { error: apiError('newParentId must be a non-empty string id', 'BAD_REQUEST', 400) };
  }
  // A cheap pre-filter only. It cannot be the self-move guard on its own,
  // because the two spellings that name the same row need not be the same
  // string — see the canonical check below, which is the one that decides.
  if (newParentId === nodeId) {
    return { error: apiError('Cannot reparent a node under itself', 'BAD_REQUEST', 400) };
  }
  const nodeRows = await conn.query(
    `SELECT id, node_type, owner_id, parent_id FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ? FOR UPDATE`,
    [nodeId],
  );
  if (!nodeRows.length) return { error: apiError('Not found', 'NOT_FOUND', 404) };
  const node = nodeRows[0];
  if (node.node_type !== 'blueprint') {
    return { error: apiError('Only blueprint nodes can be reparented', 'BAD_REQUEST', 400) };
  }
  const isAdmin = req.user && req.user.role === 'admin';
  // collation-compare: "may this editor move this blueprint" is the same
  // question the CRUD write scope asks with `AND (owner_id IS NULL OR
  // owner_id = ?)`, and that predicate folds case. Compared byte-wise, a row
  // whose `owner_id` holds another spelling of the caller's id is refused to
  // its own owner while remaining writable to them by every other route.
  const callerOwnsNode = node.owner_id != null
    && await sameStoredValue(conn, t(TABLES.HIERARCHY_NODES), 'owner_id', node.owner_id, req.user && req.user.id);
  if (!isAdmin && node.owner_id != null && !callerOwnsNode) {
    return { error: apiError('You can only move a blueprint you own', 'FORBIDDEN', 403) };
  }
  const parentRows = await conn.query(
    `SELECT id, node_type, is_active FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ?`,
    [newParentId],
  );
  if (!parentRows.length) return { error: apiError('Target parent not found', 'BAD_REQUEST', 400) };
  const parent = parentRows[0];
  if (!isValidBlueprintParent(parent.node_type)) {
    return { error: apiError('Target must be a Release', 'BAD_REQUEST', 400) };
  }
  if (parent.is_active === 0 || parent.is_active === false) {
    return { error: apiError('Target is inactive', 'BAD_REQUEST', 400) };
  }
  // ONE TRANSACTION, ONE NORMALISATION. From here down every identity is the
  // STORED one — `node.id` and `parent.id` as the rows above returned them —
  // and the caller binds `parent.id` into the UPDATE. The client's spelling is
  // not used again.
  //
  // byte-compare, and that is only correct BECAUSE both sides are now stored
  // values: `collectDescendantIds` walks `parent_id` and returns the ids the
  // rows hold, so an exact match resolves them precisely. Asked of the client's
  // spelling instead, the same `includes` silently answered "not a descendant"
  // for a target that is one, because a respelling is a different string to
  // JavaScript and the same row to the engine.
  if (node.id === parent.id) {
    return { error: apiError('Cannot reparent a node under itself', 'BAD_REQUEST', 400) };
  }
  const descendants = await collectDescendantIds(conn, t, node.id);
  if (descendants.includes(parent.id)) {
    return { error: apiError('Cannot move a node under its own descendant', 'BAD_REQUEST', 400) };
  }
  return { node, parent };
}


// Joins a node's ancestor name chain (top → leaf) for the confirm dialog.
async function pathLabel(conn, leafId) {
  const names = [];
  let cur = leafId;
  for (let i = 0; i < 64 && cur; i += 1) {
    const rows = await conn.query(
      `SELECT name, parent_id FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ?`,
      [cur],
    );
    if (!rows.length) break;
    names.unshift(rows[0].name);
    cur = rows[0].parent_id;
  }
  return names.join(' › ');
}

function register(router) {

// Cascade-preview + cascade-delete for hierarchy_nodes. Registered BEFORE
// the generic CRUD mount so Express matches these exact paths first;
// the sub-router has no GET /:id/cascade-preview or DELETE /:id behavior
// that would conflict.
router.get('/hierarchy_nodes/:id/cascade-preview', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const dynamicDb = req.body && req.body.db;
  let conn;
  try {
    if (dynamicDb) {
      const dynamicPool = await getDynamicPool(dynamicDb);
      conn = await dynamicPool.ro.getConnection();
    } else {
      conn = await pool.ro.getConnection();
    }
    // Owner gate: resolve the target node's own node_type + owner_id and apply
    // the admin-or-owner rule. Read-only preview → no row lock needed. A missing
    // node 404s BEFORE the owner check (mirroring the DELETE handler) so a
    // nonexistent id never yields a bogus 200 for admins or a misleading 403
    // for editors.
    const nodeRows = await conn.query(
      `SELECT id, node_type, owner_id, parent_id FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ?`,
      [req.params.id],
    );
    if (!nodeRows.length) {
      return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
    }
    if (!(await mayActOnHierarchyNode(conn, req, nodeRows[0]))) {
      return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'You can only delete a blueprint you own' });
    }
    const counts = await previewCascade(conn, t, req.params.id);
    res.json(apiOk(counts));
  } catch (err) {
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { nodeId: req.params.id } });
  } finally {
    if (conn) conn.release();
  }
});


router.post('/hierarchy_nodes/:id/reparent-preview', markReadOnly, async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const { newParentId } = req.body || {};
  if (!UUID_RE.test(req.params.id) || typeof newParentId !== 'string' || !UUID_RE.test(newParentId)) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'id and newParentId must be valid UUIDs' });
  }
  let conn;
  try {
    conn = await (await resolveOwnershipRwPool(req)).getConnection();
    await conn.beginTransaction();
    const v = await validateReparent(conn, req, req.params.id, newParentId);
    // lint-allow: logger-discipline two-step consumes a helper-built apiError-shaped result, not a direct apiError call at this site
    if (v.error) { await conn.rollback(); return res.status(v.error.status).json(v.error.body); }
    // The same stored ids the write path uses, so the path this preview shows
    // is the path that move would produce rather than one resolved a second,
    // different way.
    const affected = await countAffectedTemplates(conn, t, v.node.id);
    const oldPath = await pathLabel(conn, v.node.id);
    const newParentPath = await pathLabel(conn, v.parent.id);
    const bpName = oldPath.split(' › ').pop();
    await conn.rollback(); // read-only preview — never persist
    res.json(apiOk({
      affectedTemplates: affected.count,
      affectedTemplateList: affected.templates,
      oldPath,
      newPath: `${newParentPath} › ${bpName}`,
    }));
  } catch (err) {
    // lint-allow: logger-discipline logs the rollback error, sendError carries the original
    if (conn) { try { await conn.rollback(); } catch (e) { req.log.warn({ err: e }, 'reparent-preview rollback failed'); } }
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { nodeId: req.params.id } });
  } finally {
    if (conn) conn.release();
  }
});


router.post('/hierarchy_nodes/:id/reparent', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const { newParentId } = req.body || {};
  if (!UUID_RE.test(req.params.id) || typeof newParentId !== 'string' || !UUID_RE.test(newParentId)) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'id and newParentId must be valid UUIDs' });
  }
  let conn;
  try {
    conn = await (await resolveOwnershipRwPool(req)).getConnection();
    await conn.beginTransaction();
    const v = await validateReparent(conn, req, req.params.id, newParentId);
    // lint-allow: logger-discipline two-step consumes a helper-built apiError-shaped result, not a direct apiError call at this site
    if (v.error) { await conn.rollback(); return res.status(v.error.status).json(v.error.body); }
    // The STORED ids the validation resolved, not the spellings the request
    // carried. `parent_id` is read back by the front end as `.find(n => n.id
    // === node.parent_id)`, so a column holding a spelling no node's id
    // carries drops the whole branch out of the tree — while every SQL reader,
    // including the ancestor walk two lines down, goes on resolving it and
    // reports the move as a success.
    const nodeId = v.node.id;
    const parentId = v.parent.id;
    await conn.query(
      `UPDATE \`${t(TABLES.HIERARCHY_NODES)}\` SET parent_id = ? WHERE id = ?`,
      [parentId, nodeId],
    );
    const { topId, releaseId } = await resolveAncestors(conn, t, parentId);
    const restamped = await restampTemplates(conn, t, nodeId, { topId, releaseId });
    await conn.query(
      `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata)
       VALUES (?, ?, ?, ?)`,
      [uuidv4(), 'blueprint.reparent', req.user && req.user.id,
        JSON.stringify({ node_id: nodeId, old_parent_id: v.node.parent_id, new_parent_id: parentId, restamped })],
    );
    await conn.commit();
    res.json(apiOk({ ok: true, parent_id: parentId, restamped }));
  } catch (err) {
    // lint-allow: logger-discipline logs the rollback error, sendError carries the original
    if (conn) { try { await conn.rollback(); } catch (e) { req.log.warn({ err: e }, 'reparent rollback failed'); } }
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { nodeId: req.params.id } });
  } finally {
    if (conn) conn.release();
  }
});


router.delete('/hierarchy_nodes/:id', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const dynamicDb = req.body && req.body.db;
  let conn;
  try {
    if (dynamicDb) {
      const dynamicPool = await getDynamicPool(dynamicDb);
      conn = await dynamicPool.rw.getConnection();
    } else {
      conn = await pool.rw.getConnection();
    }
    await conn.beginTransaction();
    // Owner gate — resolve ownership INSIDE the write transaction under the same
    // FOR UPDATE lock the cascade relies on, so ownership cannot change between
    // this check and cascadeDeleteNode (mirrors validateReparent). A missing
    // node still 404s below; a node the caller may not delete gets an explicit
    // 403 before any DELETE statement runs, so a denied delete mutates nothing.
    const nodeRows = await conn.query(
      `SELECT id, node_type, owner_id, parent_id FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ? FOR UPDATE`,
      [req.params.id],
    );
    if (!nodeRows.length) {
      await conn.rollback();
      return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
    }
    if (!(await mayActOnHierarchyNode(conn, req, nodeRows[0]))) {
      await conn.rollback();
      return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'You can only delete a blueprint you own' });
    }
    // B3: refuse to delete a blueprint that other blueprints link to — the
    // referrers would become dangling (data entry would render a blank form
    // with no error). The delete CASCADES the whole subtree, so check referrers
    // for EVERY id being cascaded (a borrower could link to a descendant
    // blueprint of the node being deleted, not just the node itself), excluding
    // borrowers that are themselves inside the cascade (they're going away too).
    const cascadeIds = await collectDescendantIds(conn, t, req.params.id);
    if (cascadeIds.length) {
      const inPh = cascadeIds.map(() => '?').join(', ');
      const referrers = await conn.query(
        `SELECT id, name FROM \`${t(TABLES.HIERARCHY_NODES)}\`
           WHERE node_type = 'blueprint'
             AND linked_blueprint_id IN (${inPh}) AND id NOT IN (${inPh})`,
        [...cascadeIds, ...cascadeIds],
      );
      if (referrers.length) {
        await conn.rollback();
        const names = referrers.map((r) => r.name).filter(Boolean).join(', ');
        const e = apiError(
          `Cannot delete: ${referrers.length} blueprint(s) link to this one or its descendants${names ? ` (${names})` : ''}. Unlink them first.`,
          'LINK_SOURCE_IN_USE', 409,
        );
        // lint-allow: logger-discipline response body is assembled at the call site (augmented apiError body or a bespoke shape); the responder owns its body and cannot delegate to sendError — the request-log access line covers the request
        return res.status(e.status).json({ ...e.body, details: { dependents: referrers.map((r) => ({ id: r.id, name: r.name })) } });
      }
    }
    const applied = await cascadeDeleteNode(conn, t, req.params.id);
    if (applied.nodes === 0) {
      await conn.rollback();
      return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
    }
    await conn.commit();
    res.json(apiOk({ ok: true, applied }));
  } catch (err) {
    if (conn) {
      try { await conn.rollback(); } catch (rbErr) {
        req.log.warn({ err: rbErr }, 'rollback after cascade delete failed');
      }
    }
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { nodeId: req.params.id } });
  } finally {
    if (conn) conn.release();
  }
});


// PATCH /:id/owner — admin transfer to any user (or null = shared).
// Admin-only gate: a soon-to-leave editor cannot reroute rows to a
// fake account by hitting this path. Only blueprint rows carry
// ownership semantics.
router.patch('/hierarchy_nodes/:id/owner', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const { new_owner_id } = req.body || {};
  if (new_owner_id !== null && (typeof new_owner_id !== 'string' || new_owner_id.length === 0)) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'new_owner_id must be a string id or null' });
  }
  let conn;
  try {
    conn = await (await resolveOwnershipRwPool(req)).getConnection();
    await conn.beginTransaction();

    const typeRows = await conn.query(
      `SELECT node_type FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ?`,
      [req.params.id],
    );
    if (!typeRows.length) {
      await conn.rollback();
      return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
    }
    if (typeRows[0].node_type !== 'blueprint') {
      await conn.rollback();
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'Ownership only applies to blueprint nodes' });
    }

    // Pre-validate target user (if non-null): must exist with admin or editor role.
    // Done before applyOwnerChange so the 400 response stays explicit.
    //
    // collation-compare: the shared resolver asks the column which row this
    // spelling names, because `users.id` folds case and the client's spelling
    // is not the stored one. `ownerId` below is that STORED spelling, and it is
    // what the UPDATE binds — resolving without rebinding would leave every
    // JavaScript reader of `owner_id` unable to find the new owner.
    let ownerId = new_owner_id;
    if (new_owner_id !== null) {
      const target = await resolveCanonicalUserId(conn, t(TABLES.USERS), new_owner_id);
      if (!target.ok) {
        await conn.rollback();
        // One mapping for every route that asks the shared resolver, so an
        // administrator gets the same sentence whichever record they transfer —
        // including the banned-account refusal, which is not "no such user".
        const rejection = ownerTargetRejection(target.reason);
        return sendError(req, res, null, { status: rejection.status, code: rejection.code, reason: rejection.message });
      }
      if (target.role !== 'admin' && target.role !== 'editor') {
        await conn.rollback();
        return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'Owner must be admin or editor' });
      }
      ownerId = target.id;
    }

    const result = await applyOwnerChange(conn, TABLES.HIERARCHY_NODES, req.params.id, ownerId, {
      actor: req.user,
      action: new_owner_id === null ? 'make_shared' : 'transfer',
      requireCondition: 'any',
      auditEventType: HIERARCHY_OWNER_AUDIT_EVENT,
      t,
    });

    if (result.conflict_reason === 'NOT_FOUND') {
      await conn.rollback();
      return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
    }
    if (result.unchanged_same_owner) {
      // E-M1: 200 with {changed:false}, no audit row was written.
      await conn.commit();
      return res.json(apiOk({ owner_id: result.new_owner, changed: false }));
    }
    const cascadedCount = await cascadeBlueprintOwnerToVariants(conn, req.params.id, result.new_owner, {
      actor: req.user,
      action: new_owner_id === null ? 'make_shared' : 'transfer',
    });
    await conn.commit();
    res.json(apiOk({
      owner_id: result.new_owner,
      old_owner_id: result.prior_owner,
      changed: true,
      cascaded_variants: cascadedCount,
    }));
  } catch (err) {
    if (conn) {
      try { await conn.rollback(); } catch (rbErr) {
        req.log.warn({ err: rbErr }, 'rollback after blueprint owner transfer failed');
      }
    }
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { rowId: req.params.id } });
  } finally {
    if (conn) conn.release();
  }
});


// PATCH /user_templates/:id/owner — reassign a template to a real user.
// Two callers: admin (transfers any template) and the current owner (transfers
// their own). The original driving case is a template seeded from another
// environment whose owner_id points at a user id that does not exist here;
// admin repairs it. Owners can also hand a template to a colleague. No shared
// (null) semantic and no claim/release: templates are personal, not a pool.
router.patch('/user_templates/:id/owner', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const { new_owner_id } = req.body || {};
  if (typeof new_owner_id !== 'string' || new_owner_id.length === 0) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'new_owner_id must be a non-empty string id' });
  }
  const isAdmin = req.user && req.user.role === 'admin';
  let conn;
  try {
    conn = await (await resolveOwnershipRwPool(req)).getConnection();
    await conn.beginTransaction();

    // collation-compare: same resolver, same reason as the blueprint transfer
    // above — the column decides which row the spelling names, and the STORED
    // spelling is what gets bound.
    const target = await resolveCanonicalUserId(conn, t(TABLES.USERS), new_owner_id);
    if (!target.ok) {
      await conn.rollback();
      // One mapping for every route that asks the shared resolver, so an
      // administrator gets the same sentence whichever record they transfer —
      // including the banned-account refusal, which is not "no such user".
      const rejection = ownerTargetRejection(target.reason);
      return sendError(req, res, null, { status: rejection.status, code: rejection.code, reason: rejection.message });
    }

    const result = await applyOwnerChange(conn, TABLES.USER_TEMPLATES, req.params.id, target.id, {
      actor: req.user,
      action: 'transfer',
      // admin reassigns any template; a plain owner only their own row.
      requireCondition: isAdmin ? 'any' : 'self',
      auditEventType: USER_TEMPLATE_OWNER_AUDIT_EVENT,
      t,
    });

    if (result.conflict_reason === 'NOT_FOUND') {
      await conn.rollback();
      return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
    }
    if (result.conflict_reason === 'NOT_SELF') {
      await conn.rollback();
      return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'You can only reassign a template you own' });
    }
    if (result.unchanged_same_owner) {
      await conn.commit();
      return res.json(apiOk({ owner_id: result.new_owner, changed: false }));
    }
    await conn.commit();
    res.json(apiOk({
      owner_id: result.new_owner,
      old_owner_id: result.prior_owner,
      changed: true,
    }));
  } catch (err) {
    if (conn) {
      try { await conn.rollback(); } catch (rbErr) {
        req.log.warn({ err: rbErr }, 'rollback after user_template owner transfer failed');
      }
    }
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { rowId: req.params.id } });
  } finally {
    if (conn) conn.release();
  }
});


// POST /:id/claim — editor or admin claims a NULL-owned BLUEPRINT row.
// Same-actor (already-owner) returns 200 {claimed:false} (idempotent).
// Only blueprint rows carry ownership semantics; this endpoint refuses
// to claim a category / release / variant directly so editors cannot
// escalate by privatising a row that should inherit from its parent blueprint.
router.post('/hierarchy_nodes/:id/claim', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  if (!req.user || !req.user.id) {
    return sendError(req, res, null, { status: 401, code: 'UNAUTHORIZED', reason: 'Authenticated user required' });
  }
  let conn;
  try {
    conn = await (await resolveOwnershipRwPool(req)).getConnection();
    await conn.beginTransaction();
    // Verify node_type before we touch the row. Failing fast here keeps
    // the audit log clean and the 400 response explicit.
    // FOR UPDATE locks the row at the type-check so the read and the
    // subsequent applyOwnerChange UPDATE see one consistent row — a concurrent
    // writer can't slip a node_type change between them (TOCTOU fence).
    const typeRows = await conn.query(
      `SELECT node_type FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ? FOR UPDATE`,
      [req.params.id],
    );
    if (!typeRows.length) {
      await conn.rollback();
      return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
    }
    if (typeRows[0].node_type !== 'blueprint') {
      await conn.rollback();
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'Ownership only applies to blueprint nodes' });
    }
    const result = await applyOwnerChange(conn, TABLES.HIERARCHY_NODES, req.params.id, req.user.id, {
      actor: req.user,
      action: 'claim',
      requireCondition: 'null',
      auditEventType: HIERARCHY_OWNER_AUDIT_EVENT,
      t,
    });
    if (result.conflict_reason === 'NOT_FOUND') {
      await conn.rollback();
      return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
    }
    if (result.conflict_reason === 'NOT_NULL') {
      // SECURITY: do not leak the current owner's UUID to a non-owner caller.
      // `already_owned: true` is enough for the client toast; admin who needs
      // the owner can hit GET /hierarchy_nodes/:id directly.
      await conn.rollback();
      const e = apiError('Already owned by another user', 'ALREADY_OWNED', 409);
      e.body.already_owned = true;
      // lint-allow: logger-discipline two-step consumes a helper-built apiError-shaped result, not a direct apiError call at this site
      return res.status(e.status).json(e.body);
    }
    if (result.idempotent_same_actor) {
      await conn.commit();
      return res.json(apiOk({ owner_id: result.new_owner, claimed: false }));
    }
    // Cascade ownership change to variant children before commit.
    const cascadedCount = await cascadeBlueprintOwnerToVariants(conn, req.params.id, result.new_owner, {
      actor: req.user,
      action: 'claim',
    });
    await conn.commit();
    res.json(apiOk({ owner_id: result.new_owner, claimed: true, cascaded_variants: cascadedCount }));
  } catch (err) {
    if (conn) {
      try { await conn.rollback(); } catch (rbErr) {
        req.log.warn({ err: rbErr }, 'rollback after blueprint claim failed');
      }
    }
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { rowId: req.params.id } });
  } finally {
    if (conn) conn.release();
  }
});


// POST /:id/release — editor or admin releases a self-owned BLUEPRINT
// row back to shared. Editors can hand a row back to the shared pool
// without admin help. Blueprint-only — same rationale as the claim guard.
router.post('/hierarchy_nodes/:id/release', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  if (!req.user || !req.user.id) {
    return sendError(req, res, null, { status: 401, code: 'UNAUTHORIZED', reason: 'Authenticated user required' });
  }
  let conn;
  try {
    conn = await (await resolveOwnershipRwPool(req)).getConnection();
    await conn.beginTransaction();
    // FOR UPDATE: same TOCTOU fence as claim — lock the row at the type-check so
    // the read and the applyOwnerChange UPDATE act on one consistent row.
    const typeRows = await conn.query(
      `SELECT node_type FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ? FOR UPDATE`,
      [req.params.id],
    );
    if (!typeRows.length) {
      await conn.rollback();
      return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
    }
    if (typeRows[0].node_type !== 'blueprint') {
      await conn.rollback();
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'Ownership only applies to blueprint nodes' });
    }
    const result = await applyOwnerChange(conn, TABLES.HIERARCHY_NODES, req.params.id, null, {
      actor: req.user,
      action: 'release',
      requireCondition: 'self',
      auditEventType: HIERARCHY_OWNER_AUDIT_EVENT,
      t,
    });
    if (result.conflict_reason === 'NOT_FOUND') {
      await conn.rollback();
      return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
    }
    if (result.conflict_reason === 'NOT_SELF') {
      // SECURITY: same as claim 409 — do not leak the current owner UUID.
      await conn.rollback();
      return sendError(req, res, null, { status: 403, code: 'NOT_OWNER', reason: 'Only the current owner may release' });
    }
    if (result.unchanged_same_owner) {
      // Defensive: shouldn't fire on release-of-self when prior was self
      // (priorOwner === actor.id === newOwnerId=null is impossible), but
      // keeps the branch explicit.
      await conn.commit();
      return res.json(apiOk({ owner_id: result.new_owner, changed: false }));
    }
    const cascadedCount = await cascadeBlueprintOwnerToVariants(conn, req.params.id, null, {
      actor: req.user,
      action: 'release',
    });
    await conn.commit();
    res.json(apiOk({ owner_id: null, released: true, cascaded_variants: cascadedCount }));
  } catch (err) {
    if (conn) {
      try { await conn.rollback(); } catch (rbErr) {
        req.log.warn({ err: rbErr }, 'rollback after blueprint release failed');
      }
    }
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { rowId: req.params.id } });
  } finally {
    if (conn) conn.release();
  }
});
}

module.exports = { register };
