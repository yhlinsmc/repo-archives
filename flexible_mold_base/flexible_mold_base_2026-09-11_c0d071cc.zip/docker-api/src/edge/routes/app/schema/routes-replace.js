const { sendError } = require('../../../../shared/lib/send-error');
const {
  TABLES,
  VARIANT_OVERRIDE_ACTIONS,
  pool,
  t,
  getDynamicPool,
  apiOk,
  apiError,
  requireAuth,
  requireAdmin,
  requireAdminOrEditor,
  isOwnerOrAdmin,
  uuidv4,
  UUID_RE,
  mapRowFromDb,
  mapRowsFromDb,
  mapRowToDb,
  previewCascade,
  cascadeDeleteNode,
  collectDescendantIds,
  tableExistsInCurrentSchema,
  buildVariantOverrideUpdateExistsClause,
  buildVariantOverrideInsertExistsClause,
  buildDuplicateActionTripleNotExistsClause,
  applyOwnerChange,
  enrichOwnerNames,
  validateComputeRule,
  detectCycle,
  invalidChoiceConfigShape,
  resolveAncestors,
  restampTemplates,
  countAffectedTemplates,
  isValidBlueprintParent,
  HIERARCHY_OWNER_AUDIT_EVENT,
  USER_TEMPLATE_OWNER_AUDIT_EVENT,
  resolveOwnershipRwPool,
  cascadeBlueprintOwnerToVariants,
  SAFE_COL_RE,
  isSafeColumnName,
  SLUG_KEY_PATTERN,
  isValidSlugKey,
  isBlueprintLinked,
  isBlueprintLinkedLocked,
  isLinkedParentLocked,
  auditSchemaClearFailed,
  validateLinkConstraints,
  resolveLinkCheckBlueprintId,
  _columnSetCache,
  getConnDatabaseName,
  getActualColumnSet,
  _historyTableCache,
  isCodeVersionHistoryAvailable,
  gateKeysByColumnSet,
  TABLE_VALUES,
  validateCodeVersioning,
  isMissingTableOrColumn,
  _codeVersioningDegraded,
  warnCodeVersioningDegradedOnce,
  validateAndPrepareParentOwnership,
  validateAndPrepareParentRepend,
  buildChainSelectSql,
  buildChainExistsForRow,
  ENCRYPTION_GATE_422,
  runSerializeWrite,
  editorMayWriteBlueprint,
  MAX_BATCH_FIELD_IDS,
  MAX_BATCH_BLUEPRINT_IDS,
} = require('./helpers');

function register(router) {


// Optimistic-lock replace endpoint for blueprint_output_order. Closes the
// lost-update race in OutputOrderPanel.tsx persistOrder() (delete-all then
// re-create with no transaction). Body shape:
//   { blueprint_id, expected: [{output_key, sort_order}, ...],
//     next: [{output_key, sort_order}, ...], db?: {...} }
// expected is the row set the client believed was current. The server
// snapshots the actual current state inside a transaction, compares, and
// returns 409 STALE_REVISION if another session changed it since the
// client's last fetch. Otherwise computes a delta and applies
// INSERT → UPDATE → DELETE in one transaction.
//
// Registered BEFORE the `/blueprint_output_order` CRUD mount so Express
// matches this exact path first; the sub-router below has no POST /:id
// handler so paths like POST /blueprint_output_order/<uuid> still 404.
router.post('/blueprint_output_order/replace', async (req, res) => {
  // NOTE: editors' OutputOrderPanel save calls this optimistic-lock replace
  // endpoint. Admin-only would 403. Blueprint_id ownership is validated
  // inline below for editors.
  if (!requireAdminOrEditor(req, res)) return;
  const { blueprint_id, expected, next } = req.body || {};

  if (typeof blueprint_id !== 'string' || !blueprint_id) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'blueprint_id required' });
  }
  if (!Array.isArray(expected) || !Array.isArray(next)) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'expected and next must be arrays' });
  }
  // Only enforce the column's storage contract here (VARCHAR(255), non-empty,
  // integer sort_order). Stricter identifier syntax (^[A-Za-z][A-Za-z0-9_]*$)
  // is a panel-level rule for NEW keys only — applying it server-side would
  // lock legacy rows out of replace if they stored a hyphenated or >64-char
  // key under the old generic CRUD.
  const isValidItem = (it) =>
    it && typeof it === 'object'
    && typeof it.output_key === 'string'
    && it.output_key.length > 0
    && it.output_key.length <= 255
    && Number.isInteger(it.sort_order);
  if (!expected.every(isValidItem) || !next.every(isValidItem)) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'expected/next items malformed' });
  }
  const seenNext = new Set();
  for (const it of next) {
    if (seenNext.has(it.output_key)) {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'Duplicate output_key in next' });
    }
    seenNext.add(it.output_key);
  }
  const seenExpected = new Set();
  for (const it of expected) {
    if (seenExpected.has(it.output_key)) {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'Duplicate output_key in expected' });
    }
    seenExpected.add(it.output_key);
  }

  const dynamicDb = req.body && req.body.db;
  const tableName = t(TABLES.BLUEPRINT_OUTPUT_ORDER);

  let conn;
  try {
    if (dynamicDb) {
      const dynamicPool = await getDynamicPool(dynamicDb);
      conn = await dynamicPool.rw.getConnection();
    } else {
      conn = await pool.rw.getConnection();
    }
    await conn.beginTransaction();

    // S1/S2: a linked blueprint borrows the source's output order, so a
    // replace here would never render — block it for every role.
    if (await isBlueprintLinked(conn, blueprint_id)) {
      await conn.rollback();
      return sendError(req, res, null, { status: 409, code: 'LINKED_BLUEPRINT_READONLY', reason: 'Cannot edit the schema of a linked blueprint; edit the source blueprint instead' });
    }

    // Editor must own (or share) the parent blueprint before replacing
    // its output order.
    if (req.user?.role === 'editor') {
      const parentRows = await conn.query(
        `SELECT owner_id FROM \`${t(TABLES.HIERARCHY_NODES)}\`
          WHERE id = ? AND node_type = 'blueprint'`,
        [blueprint_id],
      );
      if (!(await isOwnerOrAdmin(conn, TABLES.HIERARCHY_NODES, req, parentRows[0]))) {
        await conn.rollback();
        return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Not allowed: blueprint is not owned by you and is not shared' });
      }
    }

    const currentRows = await conn.query(
      `SELECT id, output_key, sort_order FROM \`${tableName}\`
       WHERE blueprint_id = ? FOR UPDATE`,
      [blueprint_id],
    );

    const sortByKey = (a, b) => a.output_key.localeCompare(b.output_key);
    const currentSorted = currentRows
      .map((r) => ({ output_key: r.output_key, sort_order: r.sort_order }))
      .sort(sortByKey);
    const expectedSorted = [...expected]
      .map((it) => ({ output_key: it.output_key, sort_order: it.sort_order }))
      .sort(sortByKey);

    const matches = currentSorted.length === expectedSorted.length
      && currentSorted.every(
        (c, i) => c.output_key === expectedSorted[i].output_key
          && c.sort_order === expectedSorted[i].sort_order,
      );

    if (!matches) {
      await conn.rollback();
      const e = apiError(
        'Output order modified by another session',
        'STALE_REVISION',
        409,
      );
      // lint-allow: logger-discipline response body is assembled at the call site (augmented apiError body or a bespoke shape); the responder owns its body and cannot delegate to sendError — the request-log access line covers the request
      return res.status(e.status).json({ ...e.body, current: currentSorted });
    }

    const currentByKey = new Map(currentRows.map((r) => [r.output_key, r]));
    const nextByKey = new Map(next.map((it) => [it.output_key, it]));

    const toInsert = [];
    const toUpdate = [];
    const toDelete = [];
    for (const [key, item] of nextByKey) {
      const cur = currentByKey.get(key);
      if (!cur) toInsert.push(item);
      else if (cur.sort_order !== item.sort_order) {
        toUpdate.push({ id: cur.id, sort_order: item.sort_order });
      }
    }
    for (const [key, cur] of currentByKey) {
      if (!nextByKey.has(key)) toDelete.push(cur.id);
    }

    for (const item of toInsert) {
      await conn.query(
        `INSERT INTO \`${tableName}\` (id, blueprint_id, output_key, sort_order)
         VALUES (?, ?, ?, ?)`,
        [uuidv4(), blueprint_id, item.output_key, item.sort_order],
      );
    }
    for (const upd of toUpdate) {
      await conn.query(
        `UPDATE \`${tableName}\` SET sort_order = ? WHERE id = ?`,
        [upd.sort_order, upd.id],
      );
    }
    if (toDelete.length) {
      const placeholders = toDelete.map(() => '?').join(', ');
      await conn.query(
        `DELETE FROM \`${tableName}\` WHERE id IN (${placeholders})`,
        toDelete,
      );
    }

    await conn.commit();
    res.json(apiOk({
      ok: true,
      applied: {
        inserted: toInsert.length,
        updated: toUpdate.length,
        deleted: toDelete.length,
      },
    }));
  } catch (err) {
    if (conn) {
      try { await conn.rollback(); } catch (rbErr) {
        req.log.warn({ err: rbErr }, 'rollback after replace failed');
      }
    }
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { blueprint_id } });
  } finally {
    if (conn) conn.release();
  }
});


// Optimistic-lock replace for blueprint_sections. Closes the lost-update
// window in FmbSchemaBuilder.handleReorderSections (delete-all then
// re-create with no transaction — a failed re-create wiped every section).
// Body: { blueprint_id, expected: [{section_key, display_label, sort_order}],
//         next: [...], db? }. Keys on section_key so a reorder preserves the
// existing row id (only sort_order/display_label change).
//
// Registered BEFORE the `/blueprint_sections` CRUD mount so Express matches
// this exact path first; the sub-router has no POST /:id handler.
router.post('/blueprint_sections/replace', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const { blueprint_id, expected, next } = req.body || {};

  if (typeof blueprint_id !== 'string' || !blueprint_id) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'blueprint_id required' });
  }
  if (!Array.isArray(expected) || !Array.isArray(next)) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'expected and next must be arrays' });
  }
  const isValidItem = (it) =>
    it && typeof it === 'object'
    && typeof it.section_key === 'string'
    && it.section_key.length > 0
    && it.section_key.length <= 255
    && (it.display_label == null
      || (typeof it.display_label === 'string' && it.display_label.length <= 255))
    // sort_order is INT NULL — a legacy/imported row can be null, and the
    // client snapshot echoes that null in `expected`; accept it (the reconcile
    // writes the normalized index).
    && (it.sort_order == null || Number.isInteger(it.sort_order));
  if (!expected.every(isValidItem) || !next.every(isValidItem)) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'expected/next items malformed' });
  }
  const dupKey = (arr, label) => {
    const seen = new Set();
    for (const it of arr) {
      if (seen.has(it.section_key)) return label;
      seen.add(it.section_key);
    }
    return null;
  };
  const dup = dupKey(next, 'next') || dupKey(expected, 'expected');
  if (dup) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: `Duplicate section_key in ${dup}` });
  }

  const tableName = t(TABLES.BLUEPRINT_SECTIONS);
  // display_label is a nullable column the API serializer coalesces to '' on
  // read, so the client only ever sees '' (never null). Coalesce both sides
  // to '' here too, or a legacy NULL row would false-trip STALE_REVISION
  // against the client's ''.
  const normLabel = (v) => (v == null ? '' : v);
  let conn;
  try {
    const dynamicDb = req.body && req.body.db;
    conn = dynamicDb
      ? await (await getDynamicPool(dynamicDb)).rw.getConnection()
      : await pool.rw.getConnection();
    await conn.beginTransaction();

    // Locked probe (FOR UPDATE) so a concurrent link-transition PUT — which
    // locks the blueprint before setting linked_blueprint_id — serializes
    // with this save instead of racing it (else schema rows could land on a
    // just-linked blueprint the UI won't render).
    if (await isBlueprintLinkedLocked(conn, blueprint_id)) {
      await conn.rollback();
      return sendError(req, res, null, { status: 409, code: 'LINKED_BLUEPRINT_READONLY', reason: 'Cannot edit the schema of a linked blueprint; edit the source blueprint instead' });
    }
    if (!(await editorMayWriteBlueprint(conn, req, blueprint_id))) {
      await conn.rollback();
      return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Not allowed: blueprint is not owned by you and is not shared' });
    }

    const currentRows = await conn.query(
      `SELECT id, section_key, display_label, sort_order FROM \`${tableName}\`
       WHERE blueprint_id = ? FOR UPDATE`,
      [blueprint_id],
    );

    const byKey = (a, b) => a.section_key.localeCompare(b.section_key);
    const currentCmp = currentRows
      .map((r) => ({ section_key: r.section_key, display_label: normLabel(r.display_label), sort_order: r.sort_order }))
      .sort(byKey);
    const expectedCmp = [...expected]
      .map((it) => ({ section_key: it.section_key, display_label: normLabel(it.display_label), sort_order: it.sort_order }))
      .sort(byKey);
    const matches = currentCmp.length === expectedCmp.length
      && currentCmp.every((c, i) =>
        c.section_key === expectedCmp[i].section_key
        && c.display_label === expectedCmp[i].display_label
        && c.sort_order === expectedCmp[i].sort_order);
    if (!matches) {
      await conn.rollback();
      const e = apiError('Sections modified by another session', 'STALE_REVISION', 409);
      // lint-allow: logger-discipline response body is assembled at the call site (augmented apiError body or a bespoke shape); the responder owns its body and cannot delegate to sendError — the request-log access line covers the request
      return res.status(e.status).json({ ...e.body, current: currentCmp });
    }

    const currentByKey = new Map(currentRows.map((r) => [r.section_key, r]));
    const nextByKey = new Map(next.map((it) => [it.section_key, it]));
    let inserted = 0; let updated = 0; let deleted = 0;
    // Delete outgoing rows FIRST. The (blueprint_id, section_key) UNIQUE is
    // case-insensitive (utf8mb4_general_ci), so a case-only key change
    // (Overview -> overview) is an INSERT of a NEW key that collides with the
    // still-live outgoing row unless that row is removed first (else 1062 →
    // 500). Keys compare case-SENSITIVELY here, matching the UI's key identity.
    // byte-compare, on purpose, and it is a DIFFERENT question from the guard
    // that reads its output ten lines down — so both now say which they are
    // (RC-1). WHICH ROWS MUST THIS STATEMENT REMOVE is a question about the
    // caller's own list: `Overview` and `overview` are two keys to the Schema
    // Builder, and a case-only key change is expressed here as a delete of the
    // old row plus an insert of the new one. Folding them would make the
    // rename a no-op, and the UNIQUE index — which DOES fold them — would then
    // refuse the insert against a row nothing removed (1062 → 500). So the
    // delete set is keyed exactly as the UI keys it.
    const toDelete = [];
    const deletedKeys = [];
    for (const [key, cur] of currentByKey) {
      if (!nextByKey.has(key)) { toDelete.push(cur.id); deletedKeys.push(key); }
    }
    // INVARIANT, ADOPTED FROM THE GROUPS LANE BELOW RATHER THAN INVENTED HERE.
    // A field names its section BY STRING (`blueprint_fields.section` joins
    // `blueprint_sections.section_key`), so dropping a key a field still names
    // destroys that section's metadata — its label, icon, description, layout
    // and order — and leaves the field naming a section that has none. Because a
    // metadata-less section still renders, nothing afterwards tells an operator
    // the label they wrote is gone. Reject when any departing key still has
    // referencing fields and point the caller at the routes that exist for it;
    // removing an EMPTY section here stays legal, and the reorder the Schema
    // Builder performs never drops a key at all.
    //
    // collation-compare: `IN (…)` is resolved by the engine under the column's
    // own collation, which is how every other reader resolves this reference —
    // a field holding a legacy `Overview` is in the section `overview` and would
    // be stranded just the same.
    //
    // AND THAT IS THE OPPOSITE COMPARISON FROM THE ONE THAT BUILT `deletedKeys`
    // JUST ABOVE, WHICH IS INTENDED. The two ask different questions of
    // different parties: "which row does this statement remove" is about the
    // caller's list and is keyed as the caller keys it; "would any field be
    // stranded" is about a reference the ENGINE resolves. The visible
    // consequence of holding both is that a case-only key change on a section
    // that still has fields is refused — the old key departs by the first
    // comparison and is still referenced by the second.
    //
    // THE REFUSAL MIRRORS THE GROUPS LANE; THE REMEDY DOES NOT, and saying
    // otherwise was this comment's own error. The groups lane refuses the same
    // act and points at `blueprint_groups/rename-with-cascade`, which performs
    // it — re-pointing every field in one transaction. Sections HAVE NO SUCH
    // ENDPOINT, so for a section a field names there is no request that re-cases
    // the key: this reconcile refuses it and `delete-with-reassign` refuses a
    // target its own collation calls the source. The remedy is the missing
    // sections mirror of rename-with-cascade, which is a new endpoint and is
    // tracked on its own; until it exists the sentence below states only acts
    // that are actually available.
    //
    // NO COLUMN-SET PROBE, and that is the one deliberate difference from the
    // groups mirror: `group_key` and `matrix_row_key` are additive columns whose
    // guarded ALTER an operator may have skipped, so that lane must survive
    // their absence. `section` is in this table's own CREATE and has never been
    // additive, so a probe here would declare a degradation that cannot happen.
    if (deletedKeys.length) {
      const referenced = await conn.query(
        `SELECT DISTINCT \`section\` AS k FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\`
          WHERE blueprint_id = ? AND \`section\` IN (${deletedKeys.map(() => '?').join(', ')})`,
        [blueprint_id, ...deletedKeys],
      );
      const inUse = referenced.map((r) => r.k).filter((k) => k != null);
      if (inUse.length) {
        await conn.rollback();
        return sendError(req, res, null, { status: 409, code: 'SECTION_KEY_IN_USE', reason: `Cannot remove section(s) still referenced by fields: ${inUse.join(', ')}. `
          + 'Move those fields into a different section, or delete them, via '
          + 'delete-with-reassign first; that endpoint refuses a target that differs '
          + 'from the section being removed only in capitalisation.' });
      }
    }
    if (toDelete.length) {
      const ph = toDelete.map(() => '?').join(', ');
      await conn.query(`DELETE FROM \`${tableName}\` WHERE id IN (${ph})`, toDelete);
      deleted = toDelete.length;
    }
    for (const [key, item] of nextByKey) {
      const cur = currentByKey.get(key);
      if (!cur) {
        // Slug shape is enforced only on a genuinely NEW key (present in next,
        // absent from current). A reorder/rename that preserves an existing
        // (possibly legacy/imported) key is untouched, so this never hard-fails
        // on data that predates validation.
        if (!isValidSlugKey(key)) {
          await conn.rollback();
          return sendError(req, res, null, { status: 400, code: 'INVALID_KEY_FORMAT', reason: 'section_key must start with a lowercase letter and contain only lowercase letters, digits, and underscores' });
        }
        await conn.query(
          `INSERT INTO \`${tableName}\` (id, blueprint_id, section_key, display_label, sort_order)
           VALUES (?, ?, ?, ?, ?)`,
          [uuidv4(), blueprint_id, item.section_key, normLabel(item.display_label), item.sort_order],
        );
        inserted += 1;
      } else if (normLabel(cur.display_label) !== normLabel(item.display_label) || cur.sort_order !== item.sort_order) {
        await conn.query(
          `UPDATE \`${tableName}\` SET display_label = ?, sort_order = ? WHERE id = ?`,
          [normLabel(item.display_label), item.sort_order, cur.id],
        );
        updated += 1;
      }
    }

    await conn.commit();
    res.json(apiOk({ ok: true, applied: { inserted, updated, deleted } }));
  } catch (err) {
    if (conn) {
      try { await conn.rollback(); } catch (rbErr) {
        req.log.warn({ err: rbErr }, 'rollback after blueprint_sections replace failed');
      }
    }
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { blueprint_id } });
  } finally {
    if (conn) conn.release();
  }
});


// Optimistic-lock replace for blueprint_groups (color groups). Clone of the
// blueprint_sections/replace reconcile above, keyed on group_key, comparing
// {group_key, display_label, color_key, sort_order}. Body:
//   { blueprint_id, expected: [{group_key, display_label, color_key,
//     sort_order}], next: [...], db? }. Keys on group_key so a reorder preserves
// the existing row id (only sort_order/label/color change).
//
// Registered BEFORE the `/blueprint_groups` CRUD mount so Express matches this
// exact path first; the sub-router has no POST /:id handler.
router.post('/blueprint_groups/replace', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const { blueprint_id, expected, next } = req.body || {};

  if (typeof blueprint_id !== 'string' || !blueprint_id) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'blueprint_id required' });
  }
  if (!Array.isArray(expected) || !Array.isArray(next)) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'expected and next must be arrays' });
  }
  const isValidItem = (it) =>
    it && typeof it === 'object'
    && typeof it.group_key === 'string'
    && it.group_key.length > 0
    && it.group_key.length <= 255
    && (it.display_label == null
      || (typeof it.display_label === 'string' && it.display_label.length <= 255))
    && (it.color_key == null
      || (typeof it.color_key === 'string' && it.color_key.length <= 255))
    // sort_order is INT NULL — a legacy/imported row can be null, and the
    // client snapshot echoes that null in `expected`; accept it (the reconcile
    // writes the normalized index).
    && (it.sort_order == null || Number.isInteger(it.sort_order));
  if (!expected.every(isValidItem) || !next.every(isValidItem)) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'expected/next items malformed' });
  }
  const dupKey = (arr, label) => {
    const seen = new Set();
    for (const it of arr) {
      if (seen.has(it.group_key)) return label;
      seen.add(it.group_key);
    }
    return null;
  };
  const dup = dupKey(next, 'next') || dupKey(expected, 'expected');
  if (dup) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: `Duplicate group_key in ${dup}` });
  }

  const tableName = t(TABLES.BLUEPRINT_GROUPS);
  // display_label and color_key are nullable columns the API serializer
  // coalesces to '' on read, so the client only ever sees '' (never null).
  // Coalesce both sides to '' here too, or a legacy NULL row would false-trip
  // STALE_REVISION against the client's ''.
  const normLabel = (v) => (v == null ? '' : v);
  let conn;
  try {
    const dynamicDb = req.body && req.body.db;
    conn = dynamicDb
      ? await (await getDynamicPool(dynamicDb)).rw.getConnection()
      : await pool.rw.getConnection();
    await conn.beginTransaction();

    // Locked probe (FOR UPDATE) so a concurrent link-transition PUT — which
    // locks the blueprint before setting linked_blueprint_id — serializes
    // with this save instead of racing it (else schema rows could land on a
    // just-linked blueprint the UI won't render).
    if (await isBlueprintLinkedLocked(conn, blueprint_id)) {
      await conn.rollback();
      return sendError(req, res, null, { status: 409, code: 'LINKED_BLUEPRINT_READONLY', reason: 'Cannot edit the schema of a linked blueprint; edit the source blueprint instead' });
    }
    if (!(await editorMayWriteBlueprint(conn, req, blueprint_id))) {
      await conn.rollback();
      return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Not allowed: blueprint is not owned by you and is not shared' });
    }

    const currentRows = await conn.query(
      `SELECT id, group_key, display_label, color_key, sort_order FROM \`${tableName}\`
       WHERE blueprint_id = ? FOR UPDATE`,
      [blueprint_id],
    );

    const byKey = (a, b) => a.group_key.localeCompare(b.group_key);
    const currentCmp = currentRows
      .map((r) => ({ group_key: r.group_key, display_label: normLabel(r.display_label), color_key: normLabel(r.color_key), sort_order: r.sort_order }))
      .sort(byKey);
    const expectedCmp = [...expected]
      .map((it) => ({ group_key: it.group_key, display_label: normLabel(it.display_label), color_key: normLabel(it.color_key), sort_order: it.sort_order }))
      .sort(byKey);
    const matches = currentCmp.length === expectedCmp.length
      && currentCmp.every((c, i) =>
        c.group_key === expectedCmp[i].group_key
        && c.display_label === expectedCmp[i].display_label
        && c.color_key === expectedCmp[i].color_key
        && c.sort_order === expectedCmp[i].sort_order);
    if (!matches) {
      await conn.rollback();
      const e = apiError('Groups modified by another session', 'STALE_REVISION', 409);
      // lint-allow: logger-discipline response body is assembled at the call site (augmented apiError body or a bespoke shape); the responder owns its body and cannot delegate to sendError — the request-log access line covers the request
      return res.status(e.status).json({ ...e.body, current: currentCmp });
    }

    const currentByKey = new Map(currentRows.map((r) => [r.group_key, r]));
    const nextByKey = new Map(next.map((it) => [it.group_key, it]));
    let inserted = 0; let updated = 0; let deleted = 0;
    // Delete outgoing rows FIRST — the (blueprint_id, group_key) UNIQUE is
    // case-insensitive (utf8mb4_general_ci), so a case-only key change
    // (Material -> material) inserts a NEW key that collides with the still-live
    // outgoing row unless it is removed first (else 1062 → 500). Mirrors the
    // blueprint_sections/replace ordering above.
    // byte-compare, for the reason the comment above gives and the sections
    // mirror repeats: a case-only key change is a delete plus an insert here,
    // and the UNIQUE index that DOES fold the two is why the delete has to
    // happen first. The guard below asks the engine instead — the same
    // deliberate pair, stated at both ends (RC-1).
    const toDelete = [];
    const deletedKeys = [];
    for (const [key, cur] of currentByKey) {
      if (!nextByKey.has(key)) { toDelete.push(cur.id); deletedKeys.push(key); }
    }
    // INVARIANT: group_key can only CHANGE through rename-with-cascade. A replace
    // that drops a key from the list (a rename-via-replace surfaces as delete-old
    // + insert-new, and a delete-via-replace of a non-empty group) would leave
    // blueprint_fields rows referencing the vanished key — the exact orphaning the
    // cascade route prevents. Reject when any departing key still has referencing
    // fields (group_key OR matrix_row_key), pointing callers at the cascade/
    // reassign routes. Removing an EMPTY group here stays legal (label/color/order
    // edits and adds never drop a referenced key). Column-set gated so a no-ALTER
    // operator DB (missing those columns) has no references to check.
    //
    // collation-compare: `IN (…)` is resolved by the engine under the column's
    // own collation, so a field holding a legacy `Material` is in the group
    // `material` and would be stranded just the same — the opposite comparison
    // from the byte-keyed delete set above, and deliberately so. Together they
    // refuse a case-only rename of a group fields still name, which is this
    // invariant's own sentence: the key is renamed through the endpoint that
    // moves the fields with it.
    if (deletedKeys.length) {
      const fieldColSet = await getActualColumnSet(conn, t(TABLES.BLUEPRINT_FIELDS));
      const refCols = ['group_key', 'matrix_row_key'].filter((c) => !fieldColSet || fieldColSet.has(c));
      const referenced = new Set();
      for (const col of refCols) {
        const rows = await conn.query(
          `SELECT DISTINCT \`${col}\` AS k FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\`
            WHERE blueprint_id = ? AND \`${col}\` IN (${deletedKeys.map(() => '?').join(', ')})`,
          [blueprint_id, ...deletedKeys],
        );
        for (const r of rows) if (r.k != null) referenced.add(r.k);
      }
      if (referenced.size) {
        await conn.rollback();
        return sendError(req, res, null, { status: 409, code: 'GROUP_KEY_IN_USE', reason: `Cannot remove group(s) still referenced by fields: ${[...referenced].join(', ')}. `
          + 'Rename the key via rename-with-cascade, or delete via delete-with-reassign.' });
      }
    }
    if (toDelete.length) {
      const ph = toDelete.map(() => '?').join(', ');
      await conn.query(`DELETE FROM \`${tableName}\` WHERE id IN (${ph})`, toDelete);
      deleted = toDelete.length;
    }
    for (const [key, item] of nextByKey) {
      const cur = currentByKey.get(key);
      if (!cur) {
        // Slug shape is enforced only on a genuinely NEW group_key (present in
        // next, absent from current). A reorder/rename/recolor that preserves an
        // existing (possibly legacy/imported) key is untouched, so this never
        // hard-fails on data that predates validation.
        if (!isValidSlugKey(key)) {
          await conn.rollback();
          return sendError(req, res, null, { status: 400, code: 'INVALID_KEY_FORMAT', reason: 'group_key must start with a lowercase letter and contain only lowercase letters, digits, and underscores' });
        }
        await conn.query(
          `INSERT INTO \`${tableName}\` (id, blueprint_id, group_key, display_label, color_key, sort_order)
           VALUES (?, ?, ?, ?, ?, ?)`,
          [uuidv4(), blueprint_id, item.group_key, normLabel(item.display_label), normLabel(item.color_key), item.sort_order],
        );
        inserted += 1;
      } else if (
        normLabel(cur.display_label) !== normLabel(item.display_label)
        || normLabel(cur.color_key) !== normLabel(item.color_key)
        || cur.sort_order !== item.sort_order
      ) {
        await conn.query(
          `UPDATE \`${tableName}\` SET display_label = ?, color_key = ?, sort_order = ? WHERE id = ?`,
          [normLabel(item.display_label), normLabel(item.color_key), item.sort_order, cur.id],
        );
        updated += 1;
      }
    }

    await conn.commit();
    res.json(apiOk({ ok: true, applied: { inserted, updated, deleted } }));
  } catch (err) {
    if (conn) {
      try { await conn.rollback(); } catch (rbErr) {
        req.log.warn({ err: rbErr }, 'rollback after blueprint_groups replace failed');
      }
    }
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { blueprint_id } });
  } finally {
    if (conn) conn.release();
  }
});
}

module.exports = { register };
