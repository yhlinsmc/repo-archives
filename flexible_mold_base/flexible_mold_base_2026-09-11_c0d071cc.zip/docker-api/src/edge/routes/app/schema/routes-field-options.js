const {
  TABLES,
  VARIANT_OVERRIDE_ACTIONS,
  pool,
  t,
  getDynamicPool,
  apiOk,
  apiError,
  requireAuth,
  requireAdmin,
  requireAdminOrEditor,
  isOwnerOrAdmin,
  uuidv4,
  UUID_RE,
  mapRowFromDb,
  mapRowsFromDb,
  mapRowToDb,
  previewCascade,
  cascadeDeleteNode,
  collectDescendantIds,
  tableExistsInCurrentSchema,
  buildVariantOverrideUpdateExistsClause,
  buildVariantOverrideInsertExistsClause,
  buildDuplicateActionTripleNotExistsClause,
  applyOwnerChange,
  enrichOwnerNames,
  validateComputeRule,
  detectCycle,
  invalidChoiceConfigShape,
  resolveAncestors,
  restampTemplates,
  countAffectedTemplates,
  isValidBlueprintParent,
  HIERARCHY_OWNER_AUDIT_EVENT,
  USER_TEMPLATE_OWNER_AUDIT_EVENT,
  resolveOwnershipRwPool,
  cascadeBlueprintOwnerToVariants,
  SAFE_COL_RE,
  isSafeColumnName,
  SLUG_KEY_PATTERN,
  isValidSlugKey,
  isBlueprintLinked,
  isBlueprintLinkedLocked,
  isLinkedParentLocked,
  auditSchemaClearFailed,
  validateLinkConstraints,
  resolveLinkCheckBlueprintId,
  _columnSetCache,
  getConnDatabaseName,
  getActualColumnSet,
  _historyTableCache,
  isCodeVersionHistoryAvailable,
  gateKeysByColumnSet,
  TABLE_VALUES,
  validateCodeVersioning,
  isMissingTableOrColumn,
  _codeVersioningDegraded,
  warnCodeVersioningDegradedOnce,
  validateAndPrepareParentOwnership,
  validateAndPrepareParentRepend,
  buildChainSelectSql,
  buildChainExistsForRow,
  ENCRYPTION_GATE_422,
  runSerializeWrite,
  editorMayWriteBlueprint,
  MAX_BATCH_FIELD_IDS,
  MAX_BATCH_BLUEPRINT_IDS,
  MAX_REPLACE_OPTIONS,
} = require('./helpers');
const { firstDuplicateStoredValue } = require('./write-value');
const { sendError } = require('../../../../shared/lib/send-error');
const { fieldTypeViolation, FIELD_TYPES } = require('./field-type-domain');
const { markReadOnly } = require('../../../../shared/middleware/route-markers');

function register(router) {

// Optimistic-lock replace for field_options. Closes the lost-update window in
// FieldOptionsPanel.saveAll (delete-many then upsert with no transaction — a
// failed upsert dropped the deletions AND the new/updated rows). Body:
//   { field_id, expected: [{id, option_label, option_value, sort_order,
//     valid_parent_values}], next: [{id?, ...}], db? }
// Keys on row id (NOT option_value) so the duplicate-value-alias semantics
// — options sharing a value under distinct labels — are preserved; a next
// item without an id is a fresh insert.
//
// Registered BEFORE the `/field_options` CRUD mount.
router.post('/field_options/replace', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const { field_id, expected, next } = req.body || {};

  if (typeof field_id !== 'string' || !field_id) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'field_id required' });
  }
  if (!Array.isArray(expected) || !Array.isArray(next)) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'expected and next must be arrays' });
  }
  // THE LENGTH OF THIS ARRAY IS NOW THE SIZE OF A QUERY, which it was not
  // before: the duplicate-value guard below asks the COLUMN, and that probe
  // builds one `UNION ALL` branch per distinct value. Unbounded, a body under
  // the 10MB limit builds a statement with six figures of branches. Bounded
  // here, before the per-item validation, so a hostile body is refused without
  // being walked.
  //
  // AND THE BOUND IS ON `next` ALONE, because `next` is the write. `expected` is
  // the optimistic-lock echo of what the server ALREADY holds: it is compared
  // row-for-row in process, never bound to a statement, and the probe above is
  // built from `next` only. Capping it made a field that already carries more
  // options than the bound UNSHRINKABLE — the honest echo of its rows was
  // refused 400 however short `next` was, a truncated echo was refused 409
  // STALE_REVISION, and no request the endpoint accepts was left. Such fields
  // are reachable: the measurement that produced this bound stored 20,000
  // options through this same route, before it existed.
  if (next.length > MAX_REPLACE_OPTIONS) {
    return sendError(req, res, null, { status: 400, code: 'TOO_MANY_OPTIONS', reason: `A field may carry at most ${MAX_REPLACE_OPTIONS} options; `
      + `this save sends ${next.length}.` });
  }
  const isValidStr = (v, max) => typeof v === 'string' && v.trim().length > 0 && v.length <= max;
  // expected is a never-persisted optimistic-lock echo of current server
  // state (not a write), so it must tolerate a pre-existing empty/whitespace
  // OR NULL row (the column is nullable and the serializer does not coalesce
  // it) — otherwise a legacy dirty row can never be dropped from next.
  const isValidBoundedStr = (v, max) => v == null || (typeof v === 'string' && v.length <= max);
  const validVpv = (v) => v == null || (Array.isArray(v) && v.every((x) => typeof x === 'string'));
  const isValidNext = (it) =>
    it && typeof it === 'object'
    && (it.id == null || typeof it.id === 'string')
    && isValidStr(it.option_label, 255)
    && isValidStr(it.option_value, 255)
    // sort_order is INT NULL — accept a null from a legacy row's snapshot.
    && (it.sort_order == null || Number.isInteger(it.sort_order))
    && validVpv(it.valid_parent_values);
  const isValidExpected = (it) =>
    it && typeof it === 'object'
    && typeof it.id === 'string'
    && isValidBoundedStr(it.option_label, 255)
    && isValidBoundedStr(it.option_value, 255)
    && (it.sort_order == null || Number.isInteger(it.sort_order))
    && validVpv(it.valid_parent_values);
  if (!next.every(isValidNext) || !expected.every(isValidExpected)) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'expected/next items malformed' });
  }
  // WHAT THE RULE TRIMMED IS WHAT THE STATEMENT BINDS. `isValidStr` decides
  // emptiness on `v.trim()` and every INSERT/UPDATE below bound the untrimmed
  // string, so `'  Red'` passed the rule and persisted with its spaces —
  // measured, the bytes really are stored, the collation merely pads them away
  // when comparing. `option_value` is an identity token: a checkbox answer is
  // stored BY it and resolved by string, so SQL calls two spellings one option
  // and JavaScript calls them two. The factory declares the same rule for the
  // same two columns (`trimmedNonEmptyColumns`) and normalises there; this
  // endpoint builds its own statements and must not be a second answer.
  for (const it of next) {
    it.option_label = it.option_label.trim();
    it.option_value = it.option_value.trim();
  }
  // Distinct ids in next (rows with an id) + in expected.
  const dupId = (arr) => {
    const seen = new Set();
    for (const it of arr) {
      if (it.id == null) continue;
      if (seen.has(it.id)) return true;
      seen.add(it.id);
    }
    return false;
  };
  if (dupId(next) || dupId(expected)) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'Duplicate id in expected/next' });
  }

  const tableName = t(TABLES.FIELD_OPTIONS);
  // valid_parent_values is a TEXT column holding a JSON string (mirrors the
  // dto-mapper json handling); normalise both sides to a comparable string.
  const normVpv = (v) => (v == null ? null : (typeof v === 'string' ? v : JSON.stringify(v)));
  // Parse a stored JSON string back to an array for the response payload.
  const parseVpv = (v) => {
    if (v == null) return null;
    if (Array.isArray(v)) return v;
    try { return JSON.parse(v); } catch { return null; }
  };
  let conn;
  try {
    const dynamicDb = req.body && req.body.db;
    conn = dynamicDb
      ? await (await getDynamicPool(dynamicDb)).rw.getConnection()
      : await pool.rw.getConnection();
    await conn.beginTransaction();

    // The row's OWN id comes back with it, and every statement below binds that
    // rather than the caller's spelling. This lookup is resolved by the engine
    // under the column's collation, so a `field_id` sent in another case finds
    // the field and passes every gate — and the INSERT then wrote the caller's
    // alias into `field_options.field_id`, leaving option rows that name their
    // field in bytes no JavaScript reader resolves to it. The options panel keys
    // its lists by field id, the export walks fields and collects their options
    // by exact match, and `delete-renormalize` removes options by the field id
    // it read from the field row. Each of those reads a different field from the
    // one the engine reads.
    const fieldRows = await conn.query(
      `SELECT id, blueprint_id, field_type FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\` WHERE id = ?`,
      [field_id],
    );
    if (fieldRows.length === 0) {
      await conn.rollback();
      return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Field not found' });
    }
    const fieldId = fieldRows[0].id;
    const blueprintId = fieldRows[0].blueprint_id;
    const storedType = fieldRows[0].field_type;

    // Locked probe (FOR UPDATE) so a concurrent link-transition PUT — which
    // locks the blueprint before setting linked_blueprint_id — serializes
    // with this save instead of racing it (else schema rows could land on a
    // just-linked blueprint the UI won't render).
    if (await isBlueprintLinkedLocked(conn, blueprintId)) {
      await conn.rollback();
      return sendError(req, res, null, { status: 409, code: 'LINKED_BLUEPRINT_READONLY', reason: 'Cannot edit the schema of a linked blueprint; edit the source blueprint instead' });
    }
    if (!(await editorMayWriteBlueprint(conn, req, blueprintId))) {
      await conn.rollback();
      return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Not allowed: blueprint is not owned by you and is not shared' });
    }

    // THE PRECONDITION THE BRANCH BELOW RESTS ON. That branch decides what this
    // save is allowed to contain by comparing the STORED `field_type` against a
    // literal, and a comparison by identity can only be trusted on a value
    // already known to be identically a member of the column's domain — which
    // this column, a plain VARCHAR, does not declare for itself (see
    // field-type-domain.js, the same declaration both write paths consult).
    //
    // The write path now refuses to STORE a spelling outside that domain, but
    // rows that predate the refusal are still in the table, and this endpoint
    // reads one of them. A legacy 'Checkbox' is the same value as 'checkbox' to
    // the engine and is nothing at all to every reader that draws a form, so
    // there is no reading of such a row that is not a guess: saved as a
    // multi-select it may be a single-select whose aliases are refused, saved as
    // a single-select it may be a multi-select whose answers stop resolving.
    // Refuse, and say what to repair. `null` is NOT such a value — the column is
    // nullable and the shared gate declares presence and null are not violations
    // — so a field with no type keeps saving its options unjudged.
    //
    // Runs after the ownership gate so a non-owner never learns the field shape.
    if (fieldTypeViolation({ field_type: storedType })) {
      await conn.rollback();
      return sendError(req, res, null, { status: 409, code: 'UNDECLARED_FIELD_TYPE', reason: `This field's stored type is not one this application declares `
        + `(expected one of: ${FIELD_TYPES.join(', ')}). `
        + 'Repair the field type before editing its options.' });
    }

    // Checkbox (multi-select) stores its value by option_value, so values must
    // be unique within the field (select permits duplicate-value aliases; a DB
    // unique key can't distinguish the two field types on the shared table).
    //
    // collation-compare: "are these two the same option" is a question about a
    // COLUMN. `option_value` is `VARCHAR(255)` under a collation that folds case
    // and pads trailing spaces, a checkbox answer is stored BY this value, and
    // every predicate that resolves an answer back to an option is evaluated by
    // the engine. A JavaScript `Set` called 'Red' and 'red' two options, stored
    // both, and left every stored answer resolving to two rows with nothing able
    // to say which one was chosen. Asked of the column, the two are one option
    // and the second is refused.
    if (storedType === 'checkbox') {
      // The answer is a VERDICT, and the caller reads its shape rather than its
      // value: the probe's previous "here is the offending operand, or null for
      // all clear" collapsed those two meanings the moment the operand itself
      // was null.
      const verdict = await firstDuplicateStoredValue(
        conn, tableName, 'option_value', next.map((it) => it.option_value),
      );
      if (!verdict.ok) {
        await conn.rollback();
        const e = verdict.reason === 'duplicate'
          ? apiError(
            `Option values must be unique for a multi-select field; `
            + `'${verdict.value}' appears twice (capitalisation and trailing spaces are ignored)`,
            'DUPLICATE_OPTION_VALUE', 400,
          )
          : apiError(
            'Every option value must be text; one of them is not, so the values cannot be '
            + 'compared for uniqueness.',
            'INVALID_OPTION_VALUE', 400,
          );
        // lint-allow: logger-discipline two-step consumes a helper-built apiError-shaped result, not a direct apiError call at this site
        return res.status(e.status).json(e.body);
      }
    }

    // An operator-mode install may have skipped the valid_parent_values ADD
    // COLUMN; probe the live column set and omit the column when absent so the
    // save degrades instead of failing with ER_BAD_FIELD_ERROR (the generic
    // CRUD path this replaces gated columns the same way).
    const optColSet = await getActualColumnSet(conn, tableName);
    const hasVpv = !optColSet || optColSet.has('valid_parent_values');
    const selectCols = hasVpv
      ? 'id, option_label, option_value, sort_order, valid_parent_values'
      : 'id, option_label, option_value, sort_order';

    const currentRows = await conn.query(
      `SELECT ${selectCols} FROM \`${tableName}\` WHERE field_id = ? FOR UPDATE`,
      [fieldId],
    );

    const byId = (a, b) => a.id.localeCompare(b.id);
    const snapshot = (r) => ({
      id: r.id,
      option_label: r.option_label,
      option_value: r.option_value,
      sort_order: r.sort_order,
      // With the column absent both sides collapse to null so the
      // optimistic-lock comparison never trips on it.
      valid_parent_values: hasVpv ? normVpv(r.valid_parent_values) : null,
    });
    const currentCmp = currentRows.map(snapshot).sort(byId);
    const expectedCmp = [...expected].map(snapshot).sort(byId);
    const matches = currentCmp.length === expectedCmp.length
      && currentCmp.every((c, i) =>
        c.id === expectedCmp[i].id
        && c.option_label === expectedCmp[i].option_label
        && c.option_value === expectedCmp[i].option_value
        && c.sort_order === expectedCmp[i].sort_order
        && c.valid_parent_values === expectedCmp[i].valid_parent_values);
    if (!matches) {
      await conn.rollback();
      const e = apiError('Options modified by another session', 'STALE_REVISION', 409);
      // lint-allow: logger-discipline response body is assembled at the call site (augmented apiError body or a bespoke shape); the responder owns its body and cannot delegate to sendError — the request-log access line covers the request
      return res.status(e.status).json({ ...e.body, current: currentCmp });
    }

    const currentById = new Map(currentRows.map((r) => [r.id, r]));
    const nextWithId = next.filter((it) => it.id != null);
    const nextIds = new Set(nextWithId.map((it) => it.id));
    // Every id in next must exist in current (can't update/keep a row that
    // isn't there — guards against a client sending a stale or foreign id).
    for (const it of nextWithId) {
      if (!currentById.has(it.id)) {
        await conn.rollback();
        const e = apiError('Options modified by another session', 'STALE_REVISION', 409);
        // lint-allow: logger-discipline response body is assembled at the call site (augmented apiError body or a bespoke shape); the responder owns its body and cannot delegate to sendError — the request-log access line covers the request
        return res.status(e.status).json({ ...e.body, current: currentCmp });
      }
    }

    let inserted = 0; let updated = 0; let deleted = 0;
    const toDelete = [];
    for (const r of currentRows) {
      if (!nextIds.has(r.id)) toDelete.push(r.id);
    }
    if (toDelete.length) {
      const ph = toDelete.map(() => '?').join(', ');
      await conn.query(`DELETE FROM \`${tableName}\` WHERE id IN (${ph})`, toDelete);
      deleted = toDelete.length;
    }
    for (const it of next) {
      const vpv = it.valid_parent_values == null ? null : JSON.stringify(it.valid_parent_values);
      if (it.id == null) {
        if (hasVpv) {
          await conn.query(
            `INSERT INTO \`${tableName}\` (id, field_id, option_label, option_value, sort_order, valid_parent_values)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [uuidv4(), fieldId, it.option_label, it.option_value, it.sort_order, vpv],
          );
        } else {
          await conn.query(
            `INSERT INTO \`${tableName}\` (id, field_id, option_label, option_value, sort_order)
             VALUES (?, ?, ?, ?, ?)`,
            [uuidv4(), fieldId, it.option_label, it.option_value, it.sort_order],
          );
        }
        inserted += 1;
      } else {
        if (hasVpv) {
          await conn.query(
            `UPDATE \`${tableName}\` SET option_label = ?, option_value = ?, sort_order = ?, valid_parent_values = ?
             WHERE id = ?`,
            [it.option_label, it.option_value, it.sort_order, vpv, it.id],
          );
        } else {
          await conn.query(
            `UPDATE \`${tableName}\` SET option_label = ?, option_value = ?, sort_order = ?
             WHERE id = ?`,
            [it.option_label, it.option_value, it.sort_order, it.id],
          );
        }
        updated += 1;
      }
    }

    // Re-read the reconciled rows (new rows now carry server-assigned ids) and
    // return them so the client can update its `expected` snapshot without a
    // refetch round-trip — otherwise a rapid second save would send null ids
    // for the just-inserted rows and the backend would reject it as malformed.
    const reconciled = await conn.query(
      `SELECT ${selectCols} FROM \`${tableName}\` WHERE field_id = ? ORDER BY sort_order ASC, id ASC`,
      [fieldId],
    );
    await conn.commit();
    const rows = reconciled.map((r) => ({
      id: r.id,
      option_label: r.option_label,
      option_value: r.option_value,
      sort_order: r.sort_order,
      valid_parent_values: hasVpv ? parseVpv(r.valid_parent_values) : null,
    }));
    res.json(apiOk({ ok: true, applied: { inserted, updated, deleted }, rows }));
  } catch (err) {
    if (conn) {
      try { await conn.rollback(); } catch (rbErr) {
        req.log.warn({ err: rbErr }, 'rollback after field_options replace failed');
      }
    }
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { field_id } });
  } finally {
    if (conn) conn.release();
  }
});


// Batch read of field_options for a set of field ids. The FE fan-out used one
// GET per select field because a repeated `?field_id=a&field_id=b` array filter
// matches zero rows through the deployed topology — the infra→edge proxy folds
// repeated GET query params into a single scalar. A POST carries the id list in
// the body, which survives the proxy. Read-only; mirrors the generic list
// path's auth (requireAuth — any authenticated user reads schema options) and
// RO routing. No ownership scoping on read, same as the per-id GET it replaces.
//
// Registered BEFORE the `/field_options` CRUD mount so `by-fields` is not
// parsed as `/field_options/:id`. Body: { field_ids: string[], db? }.
router.post('/field_options/by-fields', markReadOnly, async (req, res) => {
  if (!requireAuth(req, res)) return;
  const { field_ids } = req.body || {};
  if (!Array.isArray(field_ids)) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'field_ids must be an array' });
  }
  if (field_ids.length === 0) return res.json(apiOk([]));
  if (field_ids.length > MAX_BATCH_FIELD_IDS) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: `field_ids exceeds ${MAX_BATCH_FIELD_IDS} limit` });
  }
  if (!field_ids.every((id) => typeof id === 'string' && id.length > 0)) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'field_ids must be non-empty strings' });
  }

  const tableName = t(TABLES.FIELD_OPTIONS);
  const dynamicDb = req.body && req.body.db;
  let conn;
  try {
    conn = dynamicDb
      ? await (await getDynamicPool(dynamicDb)).ro.getConnection()
      : await pool.ro.getConnection();
    const placeholders = field_ids.map(() => '?').join(', ');
    // sort_order is INT NULL — NULLs sort last so a legacy null-order option
    // doesn't jump to the top. Grouped by field_id so each field's options stay
    // contiguous in render order; the FE filters by field_id, so cross-field
    // order does not matter but within-field sort_order is the dropdown order.
    const rows = await conn.query(
      `SELECT * FROM \`${tableName}\`
         WHERE field_id IN (${placeholders})
         ORDER BY field_id, sort_order IS NULL, sort_order`,
      field_ids,
    );
    res.json(apiOk(mapRowsFromDb(TABLES.FIELD_OPTIONS, rows)));
  } catch (err) {
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed' });
  } finally {
    if (conn) conn.release();
  }
});
}

module.exports = { register };
