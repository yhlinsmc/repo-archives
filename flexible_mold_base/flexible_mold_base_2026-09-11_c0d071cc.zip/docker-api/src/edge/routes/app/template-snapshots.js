'use strict';

/**
 * template-snapshots.js — fmb_template_snapshots mount (U10).
 *
 *   GET    /:templateId/snapshots              list, newest first
 *   DELETE /:templateId/snapshots/:snapshotId    delete one snapshot
 *
 * SNAPSHOT CREATION IS RETIRED (spec §4.2, D8) — there is no
 * POST here any more; a new checkpoint is saved as a `fmb_template_versions`
 * row instead (`template-versions.js`'s own POST), which carries the
 * server-side restore/browse lifecycle a bare snapshot never had. GET/
 * DELETE stay so rows already on this table (from before the retirement)
 * keep listing — with the `legacy` badge, spec §6 — and stay
 * admin-deletable.
 *
 * WHY THIS IS NOT A RUN. A snapshot is a manual, unexecuted checkpoint of the
 * form's own values — dispatch, `flow_recipe_runs`, and the flow engine are
 * never touched by any route below. Restoring a snapshot into the live form is
 * entirely a client-side act (the client already holds the snapshot document
 * once it has read it back from GET) — there is no server-side "restore"
 * endpoint, because restoring writes nothing durable until the operator saves
 * the template through the ordinary save route, same as typing over a field.
 *
 * WHO MAY READ AND WRITE. GET follows the same rule as
 * `template-activity.js`'s trail: the record's owner, anyone they delegated
 * to, and an administrator. Unlike the trail, a snapshot can hold the form's
 * answers verbatim, so — unlike the trail's public dispatch-history baseline
 * — there is no wider public read here at all. DELETE is narrower still —
 * ADMIN ONLY (design spec §6's "admin cleanup entry point"): a legacy
 * snapshot predates the versions feature's own restorable/browsable
 * lifecycle, so pruning it is an administrative act, not an owner-level one
 * the way editing/deleting a manual version is.
 */
const router = require('express').Router();
const { sendError } = require('../../../shared/lib/send-error');
const { pool, t } = require('../../db');
const {
  apiOk, requireAuth, UUID_RE,
} = require('../../../shared/helpers');
const { TABLES } = require('../../../shared/constants');
const { normalizeTimestamp } = require('../../lib/dto-mapper');
const { callerMayWriteTemplate } = require('../../lib/delegated-grants');
const { tableExistsInCurrentSchema } = require('../../lib/table-exists');
const { isKnownPresent, rememberPresent } = require('../../lib/table-presence-cache');
const { parsePageRequest } = require('./schema/list-query');
const { logger: rootLogger } = require('../../../shared/lib/logger');

const logger = rootLogger.child({ module: 'template-snapshots-route' });

// SECURITY: authentication for the whole router, so a route added later
// inherits it rather than having to remember it.
router.use((req, res, next) => { if (requireAuth(req, res)) next(); });

// M6 (review r1): the page a caller gets when they ask for no particular
// page — same `resolvePage`/`DEFAULT_PAGE_SIZE` contract
// `template-activity.js` uses, so this list (an operator's saved checkpoints
// on ONE record, not the whole table, but still unbounded before this fix)
// cannot grow into an unbounded response. The FE picker renders a flat list,
// not a pager, so the size is chosen generously (50) rather than paged.
const DEFAULT_PAGE_SIZE = 50;

const dbError = (req, res, err, fields) => sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields });
const notFound = (req, res, message = 'Not found') => sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: message });

async function safeRollback(conn) {
  if (!conn) return;
  try { await conn.rollback(); } catch (err) { logger.error({ err }, 'template-snapshots rollback failed'); }
}

/**
 * May this caller read and write this record's snapshots?
 *
 * Reuses `callerMayWriteTemplate` — the SAME rule the template's own write
 * path enforces (ownership, a grant, ownership of the blueprint, or being an
 * administrator) — rather than restating it, so this route cannot drift from
 * what "may edit this record" already means everywhere else. A snapshot can
 * hold the form's answers verbatim, so — unlike `template-activity.js`'s
 * trail, which has a public dispatch-history baseline — there is no wider
 * public read here at all: every route below is gated by this same check.
 */
async function callerMaySeeSnapshots(conn, user, templateId) {
  const rows = await conn.query(
    `SELECT id, owner_id, blueprint_id FROM \`${t(TABLES.USER_TEMPLATES)}\` WHERE id = ?`,
    [templateId],
  );
  if (!rows.length) return false;
  return callerMayWriteTemplate(conn, user, rows[0]);
}

/**
 * Is the snapshots table there to be read or written? The 3.2.856 CREATE is
 * severity 'warning' (an operator account without DDL privilege may never
 * run it), so the table can be legitimately absent while the rest of the app
 * boots and runs fine. Only the positive is remembered, and it is remembered
 * per DATABASE — both properties, and the reasons for them, live in
 * `table-presence-cache.js` (the same cache `delegated-grants.js`'s
 * `grantsTableAvailable` and `template-activity.js`'s `activityTableAvailable`
 * use for their own optional tables).
 */
async function snapshotsTableAvailable(conn) {
  const physical = t(TABLES.TEMPLATE_SNAPSHOTS);
  if (isKnownPresent(conn, physical)) return true;
  try {
    const present = await tableExistsInCurrentSchema(conn, physical);
    if (present) rememberPresent(conn, physical);
    return present;
  } catch (err) {
    logger.warn({ err }, 'could not probe for the template snapshots table — snapshots are reported unavailable');
    return false;
  }
}

/**
 * Refuses the write in progress and writes the response itself when the
 * table is not there — same contract `delegated-grants.js`'s
 * `requireGrantsTable` uses, so a caller need only check the return value.
 */
async function requireSnapshotsTable(req, conn, res) {
  if (await snapshotsTableAvailable(conn)) return true;
  sendError(req, res, null, {
    status: 503,
    code: 'SNAPSHOTS_UNAVAILABLE',
    reason: 'Snapshots are not available on this database schema: the snapshots table has not been created. '
      + 'An administrator can see the outstanding schema steps under schema status.',
  });
  return false;
}

const LIST_COLUMNS = 'id, template_id, name, note, blueprint_id, variant_id, snapshot, actor_id, created_at';

/** Same shape `template-activity.js`'s own `resolvePage` returns — a
 *  request with no page bound gets the first (bounded) page rather than
 *  everything, an explicit `limit`/`offset` is validated (and a
 *  too-large `limit` is REJECTED — `parsePageRequest`'s own contract, not
 *  silently clamped) before it can reach the driver. */
function resolvePage(query) {
  const q = query || {};
  if (q.offset === undefined && q.limit === undefined) {
    return { paginated: true, limit: DEFAULT_PAGE_SIZE, offset: 0 };
  }
  return parsePageRequest({ ...q, offset: q.offset === undefined ? '0' : q.offset });
}

function presentRow(row) {
  if (!row) return row;
  let snapshot = row.snapshot;
  // The driver may hand back the JSON-shaped LONGTEXT column as a string or
  // (depending on driver settings) an already-parsed value; hand the caller a
  // parsed document either way, same convention `capacity/versions.js` reads
  // its own snapshot column through.
  if (typeof snapshot === 'string') {
    try { snapshot = JSON.parse(snapshot); } catch { /* leave raw — a corrupt row still lists */ }
  }
  return {
    id: row.id,
    template_id: row.template_id,
    name: row.name,
    note: row.note ?? null,
    blueprint_id: row.blueprint_id ?? null,
    variant_id: row.variant_id ?? null,
    snapshot,
    actor_id: row.actor_id ?? null,
    created_at: normalizeTimestamp(row.created_at),
  };
}

/**
 * @openapi
 * /edge/app/templates/{templateId}/snapshots:
 *   get:
 *     tags: [App - Template Snapshots]
 *     summary: List a record's saved snapshots, newest first (owner/delegate/admin).
 *     parameters:
 *       - { name: templateId, in: path, required: true, schema: { type: string } }
 *     responses:
 *       200: { description: "Snapshot list — `{ items, unavailable }`; `items` is empty and `unavailable` is true on a schema where the table was never created" }
 *       404: { description: No such record, or not the caller's to see }
 * /edge/app/templates/{templateId}/snapshots/{snapshotId}:
 *   delete:
 *     tags: [App - Template Snapshots]
 *     summary: Delete one snapshot (admin only — spec §6's admin cleanup entry point).
 *     responses:
 *       200: { description: Deleted }
 *       403: { description: Caller can see the record (owner/delegate/admin) but is not an admin }
 *       404: { description: No such record/snapshot, or not the caller's to see at all }
 *       503: { description: The snapshots table has not been created on this schema }
 */
router.get('/:templateId/snapshots', async (req, res) => {
  const templateId = String(req.params.templateId);
  if (!UUID_RE.test(templateId)) return notFound(req, res);
  const page = resolvePage(req.query);
  if (page.error) {
    return sendError(req, res, null, { status: 400, code: page.error.code, reason: page.error.message });
  }
  let conn;
  try {
    conn = await pool.ro.getConnection();
    if (!(await callerMaySeeSnapshots(conn, req.user, templateId))) return notFound(req, res);
    // A database whose operator account could not create the table has no
    // snapshots. An empty list is the truth there — `unavailable` is what
    // tells the caller (and the FE picker) that apart from "nothing saved
    // yet", same distinction `template-activity.js`'s own `available` flag
    // draws for its trail.
    if (!(await snapshotsTableAvailable(conn))) {
      return res.json(apiOk({
        items: [],
        unavailable: true,
        reason: 'Snapshots are not available on this database schema: the snapshots table has not been created.',
      }));
    }
    const rows = await conn.query(
      `SELECT ${LIST_COLUMNS} FROM \`${t(TABLES.TEMPLATE_SNAPSHOTS)}\`
        WHERE template_id = ? ORDER BY created_at DESC, id DESC
        LIMIT ? OFFSET ?`,
      [templateId, page.limit, page.offset],
    );
    return res.json(apiOk({ items: rows.map(presentRow), unavailable: false }));
  } catch (err) {
    return dbError(req, res, err, { templateId });
  } finally {
    if (conn) conn.release();
  }
});

// POST /:templateId/snapshots (snapshot CREATION) is RETIRED
// (spec §4.2, D8) — a new checkpoint is saved as a
// `fmb_template_versions` row now (`template-versions.js`'s own POST),
// which has the server-side restore/browse lifecycle a bare snapshot never
// had. This route only ever 404s a POST here on (no route matches
// `/snapshots` for that method); GET/DELETE below are unchanged so rows
// already on this table stay readable and admin-deletable.

// DELETE is ADMIN ONLY (spec §6 decision 5) — narrower than the
// owner/delegate/admin rule GET above uses. `callerMaySeeSnapshots`
// still gates whether the record is visible at all (a stranger gets 404,
// the existence-leak-safe answer every other route in this family gives);
// only once that passes does the role check narrow further, so a non-admin
// owner/delegate gets an honest 403 rather than being told the record does
// not exist. Explicit transaction around the FOR UPDATE read + DELETE — the
// FOR UPDATE lock is only load-bearing inside a transaction; on autocommit
// it releases the instant the SELECT completes, before the DELETE it exists
// to serialize against ever runs (same idiom `template-versions.js`'s own
// PUT/DELETE routes use for the identical shape).
router.delete('/:templateId/snapshots/:snapshotId', async (req, res) => {
  const templateId = String(req.params.templateId);
  const snapshotId = String(req.params.snapshotId);
  if (!UUID_RE.test(templateId) || !UUID_RE.test(snapshotId)) return notFound(req, res);

  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();
    if (!(await callerMaySeeSnapshots(conn, req.user, templateId))) { await safeRollback(conn); return notFound(req, res); }
    if (req.user?.role !== 'admin') {
      await safeRollback(conn);
      return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Only an administrator may delete a legacy snapshot' });
    }
    if (!(await requireSnapshotsTable(req, conn, res))) { await safeRollback(conn); return undefined; }

    const existing = await conn.query(
      `SELECT id FROM \`${t(TABLES.TEMPLATE_SNAPSHOTS)}\` WHERE id = ? AND template_id = ? FOR UPDATE`,
      [snapshotId, templateId],
    );
    if (!existing.length) { await safeRollback(conn); return notFound(req, res, 'Snapshot not found'); }

    await conn.query(
      `DELETE FROM \`${t(TABLES.TEMPLATE_SNAPSHOTS)}\` WHERE id = ? AND template_id = ?`,
      [snapshotId, templateId],
    );
    await conn.commit();
    return res.json(apiOk({ id: snapshotId, deleted: true }));
  } catch (err) {
    await safeRollback(conn);
    return dbError(req, res, err, { templateId, snapshotId });
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
module.exports.__test__ = {
  callerMaySeeSnapshots, presentRow, resolvePage, DEFAULT_PAGE_SIZE, snapshotsTableAvailable,
};
