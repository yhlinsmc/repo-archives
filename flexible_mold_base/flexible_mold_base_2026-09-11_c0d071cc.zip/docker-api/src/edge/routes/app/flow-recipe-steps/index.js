/**
 * flow-recipe-steps/index.js — router assembly for Flow Recipe Steps.
 *
 * Steps are child records of a flow_recipe; ownership resolves via the parent
 * recipe's owner_id. Steps have no ownerColumn of their own — ownership is
 * inherited from the parent recipe through the parentOwnership chain.
 *
 * Middleware order:
 *   1. requireAdminOrEditor gate
 *   2. URL guard (POST/PUT: stored url must be absolute http(s))
 *   3. HTTP-method allowlist (POST/PUT: stored method must be a valid verb)
 *   4. read-scope gate (GET non-admin: list requires ?recipe_id ownership check;
 *      GET /:id resolves ownership via the step's own recipe_id in DB)
 *   5. createCrudRoutes factory (CRUD + parentOwnership via recipe_id +
 *      parentRepend — the parent recipe re-pend now runs atomically inside the
 *      factory write transaction, FOR UPDATE on the parent row)
 */
const express = require('express');
const { createCrudRoutes } = require('../schema');
const { enumColumnsFor } = require('../../../lib/schema-manifest');
const { requireAdminOrEditor } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { pool, t } = require('../../../db');
const { logger } = require('../../../../shared/lib/logger');
const { sendError } = require('../../../../shared/lib/send-error');
const { serializeWrite, serializeRead } = require('./serializer');
// One shared predicate answers "may this caller read this recipe" for the read
// gate below AND the forward runs_on conflict gate — a second copy is how one
// path widens and another stays strict.
const { callerMayReadRecipe, RECIPE_NOT_YOURS } = require('../flow-recipes/recipe-access');
const { PARENT_REPEND_FROM } = require('../../../lib/review-status');
// The ONE primitive that decides both step-write invariants (I1 compare⇒GET,
// I2 step-mode⊆recipe-mode) on the effective row. Every writer on this mount —
// the two pre-transaction gates below and the in-transaction create/update
// hooks — calls it, so a new path cannot re-diverge by re-implementing a copy.
const { assertStepInvariants } = require('../../../../shared/lib/flow-step-invariants');
// Shared url guard: absolute http(s) with NO embedded credentials. The compute
// sentinel (https://compute.invalid/) carries no userinfo, so it still passes.
const { isStorableHttpUrl } = require('../../../../shared/lib/portable-url-redaction');

// The body/row column that binds a step to its parent recipe — the SAME key the
// crud-factory parentOwnership chain resolves ownership through (declared once,
// used both here and in the createCrudRoutes options below). A PUT that changes
// it REPARENTS the step, and reparenting a single-mode step under a recipe with
// a different single mode diverges the pair (I2) with no other field touched —
// so this key arms the mode gate and the in-tx re-check exactly as the trigger
// fields do.
const PARENT_VIA = 'recipe_id';

const router = express.Router();

// Admin/editor gate — steps are not accessible to plain data-entry users.
router.use((req, res, next) => {
  if (!requireAdminOrEditor(req, res)) return;
  next();
});

// SECURITY: pin the stored url to an absolute http(s) URL (no userinfo) at the
// write boundary (the step url is executed at dispatch time). Mirrors the
// api-connectors url guard; no /import path to skip here.
router.use((req, res, next) => {
  if ((req.method === 'POST' || req.method === 'PUT')
      && req.body && Object.prototype.hasOwnProperty.call(req.body, 'url')) {
    if (!isStorableHttpUrl(req.body.url)) {
      return res.status(400).json({ ok: false, error: { code: 'BAD_REQUEST', message: 'url must be an absolute http(s) URL' } });
    }
  }
  next();
});

// HTTP-method allowlist: enforce a valid HTTP verb on the step's target
// endpoint. Case-insensitive input; normalised to uppercase before storage.
const ALLOWED_METHODS = new Set(['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS']);
router.use((req, res, next) => {
  if ((req.method === 'POST' || req.method === 'PUT')
      && req.body && Object.prototype.hasOwnProperty.call(req.body, 'method')) {
    const m = String(req.body.method).toUpperCase();
    if (!ALLOWED_METHODS.has(m)) {
      return res.status(400).json({ ok: false, error: 'INVALID_METHOD' });
    }
    req.body.method = m;
  }
  next();
});

// step_type + before_code/after_code write guard. step_type pins the closed enum;
// the JS slots run in the browser sandbox at dispatch, so the only write-boundary
// concern is a bounded, string-typed payload. 32 KB mirrors the recipe-level
// payload_transform_code ceiling (real authored code is a few hundred bytes).
const MAX_CODE_BYTES = 32 * 1024;
const ALLOWED_STEP_TYPES = new Set(['api', 'compute']);
const CODE_FIELDS = ['before_code', 'after_code'];
router.use(async (req, res, next) => {
  if (req.method !== 'POST' && req.method !== 'PUT') return next();
  const body = req.body;
  if (!body || typeof body !== 'object') return next();

  if (Object.prototype.hasOwnProperty.call(body, 'step_type')) {
    if (!ALLOWED_STEP_TYPES.has(body.step_type)) {
      return res.status(400).json({ ok: false, error: { code: 'BAD_REQUEST', message: "step_type must be 'api' or 'compute'" } });
    }
  }

  for (const field of CODE_FIELDS) {
    if (!Object.prototype.hasOwnProperty.call(body, field)) continue;
    const v = body[field];
    if (v === null || v === '') continue; // clearing the slot is valid
    if (typeof v !== 'string') {
      return res.status(400).json({ ok: false, error: { code: 'BAD_REQUEST', message: `${field} must be a string` } });
    }
    if (Buffer.byteLength(v, 'utf8') > MAX_CODE_BYTES) {
      return res.status(413).json({ ok: false, error: { code: 'PAYLOAD_TOO_LARGE', message: `${field} exceeds ${MAX_CODE_BYTES} bytes` } });
    }
  }

  // preset_config shape guard, via the one write primitive (I3): a whole JSON
  // column is always replaced (never merged), so a body that names the field
  // carries the complete new value — no stored-row read is needed the way the
  // method/step_type/step_runs_on triple below needs one for a partial PUT.
  if (Object.prototype.hasOwnProperty.call(body, 'preset_config')) {
    const shapeVerdict = assertStepInvariants({ recipe: {}, step: { preset_config: body.preset_config } });
    if (shapeVerdict) {
      return res.status(400).json({ ok: false, error: { code: shapeVerdict.code, message: shapeVerdict.message } });
    }
  }

  // A compare step performs a read-only pass, so its request must be a GET — the
  // contract the step_runs_on DDL comment promises ("validated on save") and did
  // not enforce. A compute step issues no HTTP request (its url is the compute
  // sentinel), so method is meaningless for it and left unconstrained. On a POST
  // the method column defaults to POST, so a compare api step that does not name
  // GET is refused rather than silently stored as a mutating POST. method has
  // already been upper-cased by the allowlist above.
  //
  // On a PUT the body is a PARTIAL edit — it may name only one of the three
  // fields that jointly decide this rule (method / step_type / step_runs_on).
  // Judging the body alone let a caller flip a stored compare step's method
  // away from GET (name only `method`), or flip a stored GET step's
  // step_runs_on to 'compare' (name only `step_runs_on`), each a one-field PUT
  // that never carries the full triple to check. So when a PUT names at least
  // one of the three but not all of them, read the stored row (same table,
  // same access predicate the runs_on-conflict gate below already applies to
  // this same path) and fill in whichever fields the body left unnamed — the
  // EFFECTIVE post-write triple, not just what this one call happened to send.
  let effMethod = body.method;
  let effStepType = body.step_type;
  let effRunsOn = body.step_runs_on;
  if (req.method === 'PUT') {
    const namesMethod = Object.prototype.hasOwnProperty.call(body, 'method');
    const namesStepType = Object.prototype.hasOwnProperty.call(body, 'step_type');
    const namesRunsOn = Object.prototype.hasOwnProperty.call(body, 'step_runs_on');
    // The check below only ever fires when the EFFECTIVE step_runs_on is
    // 'compare' — a body that names step_runs_on to anything else has already
    // answered that question without a read: skip the stored-row fetch
    // entirely rather than pay for it on every ordinary partial edit.
    const compareRuledOut = namesRunsOn && body.step_runs_on !== 'compare';
    if (!compareRuledOut
      && (namesMethod || namesStepType || namesRunsOn) && !(namesMethod && namesStepType && namesRunsOn)) {
      const singleIdMatch = req.path.match(/^\/([^/]+)\/?$/);
      const stepId = singleIdMatch ? singleIdMatch[1] : null;
      if (stepId) {
        try {
          let rows;
          try {
            rows = await pool.ro.query(
              `SELECT recipe_id, method, step_type, step_runs_on FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\` WHERE id = ?`,
              [stepId],
            );
          } catch (colErr) {
            // A supported no-ALTER install may still be missing step_runs_on
            // (the migration that adds it is a warning, not a hard fail).
            // Retry without the column and treat it as the pre-column
            // default 'both' — the guard below still runs on method/step_type.
            if (!(colErr && colErr.errno === 1054)) throw colErr;
            rows = await pool.ro.query(
              `SELECT recipe_id, method, step_type FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\` WHERE id = ?`,
              [stepId],
            );
            if (rows.length) rows[0].step_runs_on = 'both';
          }
          // SECURITY: the stored-triple probe's 400-vs-fall-through outcome
          // discloses whether a FOREIGN step is a compare+api step. Resolve the
          // caller's access to the step's parent recipe (the SAME predicate the
          // mode gate below applies) BEFORE any verdict and defer a non-owner to
          // the CRUD factory, whose foreign-id posture (404 on update) adds no
          // signal. Admin sees every recipe.
          if (rows.length && req.user?.role !== 'admin') {
            const recipeRows = await pool.ro.query(
              `SELECT owner_id FROM \`${t(TABLES.FLOW_RECIPES)}\` WHERE id = ?`,
              [rows[0].recipe_id],
            );
            if (recipeRows.length && !(await callerMayReadRecipe(recipeRows[0].owner_id, req))) {
              return next();
            }
          }
          if (rows.length) {
            if (!namesMethod) effMethod = rows[0].method;
            if (!namesStepType) effStepType = rows[0].step_type;
            if (!namesRunsOn) effRunsOn = rows[0].step_runs_on;
          }
        } catch (err) {
          // SECURITY: fail-closed on an absent steps table — same posture as
          // every other probe on this router.
          if (err && err.errno === 1146) {
            return res.status(403).json({ ok: false, error: { code: 'FORBIDDEN', message: 'Not allowed: recipe scope cannot be verified' } });
          }
          return sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Recipe scope probe failed' });
        }
      }
    }
  }

  // The verdict comes from the ONE primitive, not a copy of the rule here. This
  // gate owns only I1 (compare⇒GET) and the unknown-trigger check; recipe mode
  // (I2) is the next middleware's job, so recipe.runs_on is passed as 'both' to
  // keep I2 inert here. The primitive is authoritative; this gate only shapes
  // the friendly 400 (its historical code stays BAD_REQUEST for the compare
  // rule). The in-transaction hook is the backstop if this pre-tx read was stale.
  const verdict = assertStepInvariants({
    recipe: { runs_on: 'both' },
    step: { step_runs_on: effRunsOn, method: effMethod, step_type: effStepType },
  });
  if (verdict) {
    if (verdict.code === 'FLOW_STEP_TRIGGER_INVALID') {
      return res.status(400).json({ ok: false, error: { code: verdict.code, message: verdict.message } });
    }
    if (verdict.code === 'FLOW_COMPARE_STEP_NOT_GET') {
      // On a PUT an absent effective method means the stored row was not found
      // (or a no-ALTER degrade left it unknown) — fall through to the CRUD 404
      // rather than invent a 400, preserving the pre-C1B PUT posture. On a POST
      // the method column defaults to POST, so an absent method IS a violation.
      const methodKnown = effMethod !== undefined && effMethod !== null;
      if (req.method === 'POST' || methodKnown) {
        return res.status(400).json({ ok: false, error: { code: 'BAD_REQUEST', message: verdict.message } });
      }
    }
  }
  next();
});

// runs_on conflict gate: a step's own trigger is only meaningful once the
// recipe itself runs in both modes — a recipe already narrowed to a single
// mode decides the question for every one of its steps. Only a step value
// that DIVERGES from its recipe's mode (a different single mode, e.g.
// 'update' under a 'create' recipe) would silently fire (or silently never
// fire) on a mode its recipe does not declare it supports; a step value that
// MATCHES its recipe's mode is redundant, not a conflict.
// `step_runs_on: 'both'` is always accepted (it never diverges from anything).
//
// The EFFECTIVE pair this write commits to is what is judged, not just what the
// body names. Two bodies reach the divergence: one that SETS step_runs_on, and
// one that REPARENTS the step (PUT changing recipe_id) — the latter moves the
// STORED trigger under a recipe whose single mode may differ, with no
// step_runs_on in the body at all. So the gate fires for either, resolves the
// effective (trigger, parent), and applies the same read-access check to the
// NEW parent before probing it.
router.use(async (req, res, next) => {
  if (req.method !== 'POST' && req.method !== 'PUT') return next();
  const body = req.body;
  if (!body || typeof body !== 'object') return next();
  const namesRunsOn = Object.prototype.hasOwnProperty.call(body, 'step_runs_on');
  const bodyRecipeId = typeof body.recipe_id === 'string' ? body.recipe_id : null;
  // A reparent is only possible on PUT (a POST always names its initial parent
  // and is judged through namesRunsOn); a PUT that changes recipe_id can newly
  // diverge the stored trigger even with no step_runs_on in the body.
  const reparents = req.method === 'PUT' && bodyRecipeId != null;
  if (!namesRunsOn && !reparents) return next();
  // An explicit step_runs_on='both' can never diverge, whatever the parent.
  if (namesRunsOn && body.step_runs_on === 'both') return next();

  const singleIdMatch = req.path.match(/^\/([^/]+)\/?$/);
  const stepId = singleIdMatch ? singleIdMatch[1] : null;

  try {
    // Effective parent: the body's recipe_id (POST create, PUT reparent) if
    // present, else the stored step's. Effective trigger: the body's
    // step_runs_on if named, else the stored step's.
    let effRecipeId = bodyRecipeId;
    let effRunsOn = namesRunsOn ? body.step_runs_on : undefined;
    if ((effRunsOn === undefined || !effRecipeId) && stepId) {
      try {
        const stepRows = await pool.ro.query(
          `SELECT recipe_id, step_runs_on FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\` WHERE id = ?`,
          [stepId],
        );
        if (stepRows.length) {
          if (!effRecipeId) effRecipeId = stepRows[0].recipe_id;
          if (effRunsOn === undefined) effRunsOn = stepRows[0].step_runs_on;
        }
      } catch (colErr) {
        // A no-ALTER install may still lack step_runs_on. Retry for the parent
        // alone and treat the stored trigger as the pre-column default 'both'
        // (inert) — only the effective trigger degrades, not the reparent.
        if (!(colErr && colErr.errno === 1054)) throw colErr;
        if (!effRecipeId) {
          const parentRows = await pool.ro.query(
            `SELECT recipe_id FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\` WHERE id = ?`,
            [stepId],
          );
          if (parentRows.length) effRecipeId = parentRows[0].recipe_id;
        }
        if (effRunsOn === undefined) effRunsOn = 'both';
      }
    }
    // A 'both' (or pre-column absent) effective trigger diverges from nothing.
    if (effRunsOn == null || effRunsOn === 'both') return next();
    if (!effRecipeId) return next(); // no parent to check against → CRUD answers normally

    const recipeRows = await pool.ro.query(
      `SELECT owner_id, runs_on FROM \`${t(TABLES.FLOW_RECIPES)}\` WHERE id = ?`,
      [effRecipeId],
    );
    // SECURITY: resolve the caller's access to the EFFECTIVE (possibly NEW)
    // parent recipe BEFORE the runs_on probe. The probe's 400-vs-pass outcome is
    // a disclosure of that recipe's own mode, so a caller who cannot read it must
    // never reach it — they fall through to the CRUD factory, whose
    // parentOwnership answers a foreign recipe_id with its usual posture (403 on
    // create, 404 on update) and adds no new signal here. Admin sees every recipe.
    if (req.user?.role !== 'admin'
      && recipeRows.length
      && !(await callerMayReadRecipe(recipeRows[0].owner_id, req))) {
      return next();
    }
    const recipeRunsOn = recipeRows.length ? (recipeRows[0].runs_on || 'both') : 'both';
    // I2 verdict from the ONE primitive. This gate knows the parent recipe but
    // not the step's method/step_type (a separate middleware above owns I1),
    // so it calls the primitive WITHOUT method/step_type — an omission, not a
    // narrowing of the effective row, so I1's own check must never be allowed
    // to fire off that omission: FLOW_COMPARE_STEP_NOT_GET is excluded below
    // on purpose (a fabricated "method missing" would 400 every compare step
    // this gate sees, correct or not; the earlier middleware already judged
    // I1 with the real method/step_type and would have 400ed first if it was
    // actually violated). ANY OTHER non-null verdict blocks, not only
    // MODE_CONFLICT — a recipe row whose stored runs_on falls outside the
    // known enum (a no-ALTER/degraded install) makes the primitive return
    // FLOW_RECIPE_MODE_INVALID, and treating only MODE_CONFLICT as offending
    // let that case fall through to CRUD and rely on the in-tx hook's generic
    // 500 to stop it. Mirrors the reverse gate's ANY-non-null posture
    // (flow-recipes/index.js `.filter((x) => x.v != null)`). The step's own
    // trigger is already validated by the middleware above (that mount owns
    // I1/unknown-trigger), so FLOW_STEP_TRIGGER_INVALID cannot reach here —
    // if it ever does, this handles it the same way rather than
    // special-casing it away.
    const verdict = assertStepInvariants({
      recipe: { runs_on: recipeRunsOn },
      step: { step_runs_on: effRunsOn },
    });
    if (verdict && verdict.code !== 'FLOW_COMPARE_STEP_NOT_GET') {
      const message = verdict.code === 'FLOW_STEP_MODE_CONFLICT'
        ? "Set the recipe's Runs for to Both to choose per step"
        : verdict.message;
      return res.status(400).json({
        ok: false,
        error: { code: verdict.code, message },
      });
    }
  } catch (err) {
    // SECURITY: fail-closed on an absent recipes table — the same posture the
    // read-scope gate below takes for the identical 1146 case.
    if (err && err.errno === 1146) {
      return res.status(403).json({ ok: false, error: { code: 'FORBIDDEN', message: 'Not allowed: recipe scope cannot be verified' } });
    }
    return sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Recipe mode-conflict probe failed' });
  }
  next();
});

// `callerMayReadRecipe` / `RECIPE_NOT_YOURS` are imported from
// flow-recipes/recipe-access — the same predicate this read gate, the forward
// conflict gate above, and the reverse gate on the recipes mount all decide by.

// SECURITY: non-admin editors may only read steps scoped to a recipe they can
// access. The enforcement path differs by route shape so a caller cannot supply
// a recipe_id they own to bypass the gate and read a step from a foreign recipe:
//   GET /        — list; caller must supply ?recipe_id and the middleware verifies
//                  ownership before the CRUD factory's recipe_id filter applies.
//   GET /:id     — single step; middleware resolves the owning recipe via the step
//                  row itself, ignoring any caller-supplied ?recipe_id entirely.
router.use(async (req, res, next) => {
  if (req.method !== 'GET' || req.user?.role === 'admin') return next();

  // Detect a single-id path (e.g. /abc-123 or /abc-123/).
  // router.use middleware does not populate req.params, so parse from req.path.
  const singleIdMatch = req.path.match(/^\/([^/]+)\/?$/);
  const stepId = singleIdMatch ? singleIdMatch[1] : null;

  if (stepId) {
    // Single-step path: resolve ownership from the step's own recipe — a spoofed
    // ?recipe_id in the query string cannot influence this path.
    try {
      const stepRows = await pool.ro.query(
        `SELECT recipe_id FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\` WHERE id = ?`,
        [stepId],
      );
      if (!stepRows.length) return next(); // step absent → CRUD returns 404
      const recipeId = stepRows[0].recipe_id;
      const recipeRows = await pool.ro.query(
        `SELECT owner_id FROM \`${t(TABLES.FLOW_RECIPES)}\` WHERE id = ?`,
        [recipeId],
      );
      if (recipeRows.length
        && !(await callerMayReadRecipe(recipeRows[0].owner_id, req))) {
        return res.status(403).json(RECIPE_NOT_YOURS);
      }
      // recipe not found or accessible → fall through to CRUD
    } catch (err) {
      // SECURITY: fail-closed. If the recipes table is absent we cannot verify
      // the caller owns/shares the parent recipe, so denying is the safe default
      // — a partially-migrated DB (steps present, recipes dropped) must not let a
      // caller read another owner's steps unscoped.
      if (err && err.errno === 1146) {
        return res.status(403).json({ ok: false, error: { code: 'FORBIDDEN', message: 'Not allowed: recipe scope cannot be verified' } });
      }
      return sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Recipe read-scope probe failed', entity_id: stepId });
    }
    return next();
  }

  // List path: require an explicit recipe_id to keep reads parent-scoped.
  const recipeId = req.query?.recipe_id;
  if (!recipeId || typeof recipeId !== 'string') {
    return res.status(400).json({ ok: false, error: { code: 'RECIPE_ID_REQUIRED', message: 'recipe_id query is required' } });
  }
  try {
    const rows = await pool.ro.query(
      `SELECT owner_id FROM \`${t(TABLES.FLOW_RECIPES)}\` WHERE id = ?`,
      [recipeId],
    );
    if (rows.length && !(await callerMayReadRecipe(rows[0].owner_id, req))) {
      return res.status(403).json(RECIPE_NOT_YOURS);
    }
    // recipe not found → fall through; the CRUD list simply returns no rows.
  } catch (err) {
    // SECURITY: fail-closed (see the /:id branch above) — an absent recipes
    // table means scope cannot be established, so deny rather than list every
    // step unscoped.
    if (err && err.errno === 1146) {
      return res.status(403).json({ ok: false, error: { code: 'FORBIDDEN', message: 'Not allowed: recipe scope cannot be verified' } });
    }
    return sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Recipe read-scope probe failed', entity_id: recipeId });
  }
  next();
});

// In-tx enforcement of BOTH step invariants (I1 compare⇒GET, I2 mode) via the
// shared primitive. The router-level gates above read the effective triple and
// the parent recipe's runs_on via pool.ro BEFORE the
// (lines ~132-191) reads the parent recipe's runs_on via pool.ro BEFORE the
// CRUD factory opens its own write transaction — unlocked snapshots, taken
// only for the friendly 400 message. Between those reads and this write's
// commit, a concurrent PUT on the recipe (the reverse gate on the recipes
// mount, same race, opposite direction) can narrow the parent's runs_on out
// from under it: each write's own pre-check passed against the OTHER write's
// stale value, and both commit a divergent pair neither check ever saw.
// FOR UPDATE on the parent row is what closes it — a concurrent recipe write
// that narrows runs_on must itself acquire a lock on this same row to commit
// its own UPDATE (parentRepend already takes it further down this same path),
// INVARIANT: a divergent recipe/step pair never commits — the FOR UPDATE
// re-check either sees the counterpart's committed state or the inverted lock
// order deadlocks (1213) and InnoDB rolls one side back; the loser gets a 500.
//
// Split across `transformCreateInTx` (POST) + `postUpdateInTx` (PUT) rather
// than one `preWriteInTx` for both verbs: `preWriteInTx` on THIS mount would
// unconditionally turn on crud-factory's editor-only ownership pre-check
// (`if (preWriteInTx && parentOwnership && … role === 'editor')`) for EVERY
// PUT, including a plain rename that never touches step_runs_on — measured
// against nonowner-write-scoping.test.js, which does not script that extra
// query and 500s. Neither alternate hook can return a shaped 400 (thrown
// errors surface as a generic 500 on both verbs here) — accepted per the
// brief: the pre-transaction gate above still answers the common, non-race
// case with the friendly 400; this is only reached when that gate's unlocked
// read was already stale.
async function assertStepInvariantsInTx(conn, recipeId, step) {
  // Fast path: a step whose effective trigger is 'both' can violate neither
  // invariant (never compare, never diverges), so the locked recipe read is
  // skipped — this keeps an ordinary PUT/POST that never touches these columns
  // free of an extra FOR UPDATE query.
  const on = step.step_runs_on == null ? 'both' : step.step_runs_on;
  if (on === 'both') return;
  let recipeRunsOn = 'both';
  if (recipeId) {
    try {
      const recipeRows = await conn.query(
        `SELECT runs_on FROM \`${t(TABLES.FLOW_RECIPES)}\` WHERE id = ? FOR UPDATE`,
        [recipeId],
      );
      recipeRunsOn = recipeRows.length ? (recipeRows[0].runs_on || 'both') : 'both';
    } catch (err) {
      // A no-ALTER target missing the recipe-level runs_on column, or an absent
      // recipes table, has no divergence to detect — I2 goes inert (I1 still runs).
      if (err && (err.errno === 1054 || err.code === 'ER_BAD_FIELD_ERROR' || err.errno === 1146)) {
        recipeRunsOn = 'both';
      } else {
        throw err;
      }
    }
  }
  const verdict = assertStepInvariants({ recipe: { runs_on: recipeRunsOn }, step });
  if (verdict) {
    // A thrown error here rolls the whole transaction back (crud-factory's outer
    // catch surfaces a generic 500 — it cannot read err.status). The pre-tx gate
    // above already answered the common case with the friendly 400; reaching
    // this throw means that gate's unlocked read was stale (a concurrent write).
    throw new Error(`${verdict.code}: ${verdict.message}`);
  }
}

async function recheckStepInvariantsOnCreate(conn, req, data) {
  await assertStepInvariantsInTx(
    conn,
    typeof data.recipe_id === 'string' ? data.recipe_id : null,
    { step_runs_on: data.step_runs_on, method: data.method, step_type: data.step_type },
  );
  return data;
}

async function recheckStepInvariantsOnUpdate(conn, req, data) {
  // Only a PUT that touches one of the fields that jointly decide the
  // invariants can newly violate them; a PUT that names none leaves a
  // previously-valid row valid (a concurrent write to the SAME row serialises
  // on its row lock). Skip the re-read otherwise. PARENT_VIA (recipe_id) is on
  // this list because REPARENTING alone diverges the stored trigger under a
  // new recipe's mode (I2) — the FOR UPDATE re-read below sees the post-write
  // recipe_id and judges the pair under the new parent. (crud-factory keeps a
  // lawful recipe_id in `data` for admin, and for an editor only on a real
  // change; an unchanged/stripped recipe_id means the parent did not move.)
  const touches = ['step_runs_on', 'method', 'step_type', PARENT_VIA]
    .some((k) => Object.prototype.hasOwnProperty.call(data, k));
  if (!touches) return;
  // Re-read the EFFECTIVE post-write row FOR UPDATE (the UPDATE already applied)
  // so a partial PUT that named only `method` is judged against the stored
  // step_runs_on, and two concurrent partial PUTs cannot assemble a compare+POST
  // step between them: whichever commits second re-reads the combined state.
  let stepRow;
  try {
    const rows = await conn.query(
      `SELECT recipe_id, method, step_type, step_runs_on FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\` WHERE id = ? FOR UPDATE`,
      [req.params.id],
    );
    stepRow = rows.length ? rows[0] : null;
  } catch (err) {
    // No-ALTER install missing the step_runs_on column: re-read without it and
    // treat the effective trigger as the pre-column default 'both' (invariants
    // inert), the same degrade the pre-tx probe takes.
    if (!(err && (err.errno === 1054 || err.code === 'ER_BAD_FIELD_ERROR'))) throw err;
    const rows = await conn.query(
      `SELECT recipe_id, method, step_type FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\` WHERE id = ? FOR UPDATE`,
      [req.params.id],
    );
    stepRow = rows.length ? { ...rows[0], step_runs_on: 'both' } : null;
  }
  if (!stepRow) return;
  await assertStepInvariantsInTx(conn, stepRow.recipe_id, {
    step_runs_on: stepRow.step_runs_on, method: stepRow.method, step_type: stepRow.step_type,
  });
}

router.use('/', createCrudRoutes('flow_recipe_steps', {
  allowedRoles: ['admin', 'editor'],
  // Ownership resolves via the parent recipe. Steps have no owner_id of
  // their own — ownerColumn is intentionally omitted.
  parentOwnership: {
    via: PARENT_VIA,
    chain: [{ table: TABLES.FLOW_RECIPES, match: 'id', readOwner: 'owner_id' }],
  },
  // SECURITY: editing a step of an approved/rejected recipe must force re-review.
  // The factory re-pends the parent recipe to 'pending' (clearing approval) in
  // the SAME transaction as the step write, with the parent row locked FOR
  // UPDATE — atomic, so a concurrent admin approve cannot leave an approved
  // recipe carrying a swapped step. Non-admin callers only re-pend a recipe they
  // own or that is shared (owner_id NULL); admins re-pend unconditionally.
  parentRepend: {
    table: TABLES.FLOW_RECIPES,
    via: PARENT_VIA,
    statusCol: 'status',
    // ownerCol names the parent table's owner column for the non-admin re-pend
    // owner-gate. flow_recipes owns rows under `owner_id`; declared explicitly so
    // a future adopter whose parent uses a different name can't silently inherit
    // a wrong default and have the owner-gate SELECT swallow an errno-1054.
    ownerCol: 'owner_id',
    clearCols: ['approved_by', 'approved_at'],
    // NULL is on this list. Editing a step IS a change to what the parent
    // recipe dispatches, and a grandfathered parent DOES dispatch — so leaving
    // NULL off meant a step could be swapped under a recipe that went on
    // dispatching the new step unreviewed. The list is review-status.js's.
    repandFrom: PARENT_REPEND_FROM,
  },
  filterableColumns: [PARENT_VIA],
  // TOCTOU close: see assertStepInvariantsInTx's doc-comment above for why
  // this is two verb-specific hooks rather than one preWriteInTx.
  transformCreateInTx: recheckStepInvariantsOnCreate,
  postUpdateInTx: recheckStepInvariantsOnUpdate,
  // The same DDL-derived domain the connector mount declares, and for the same
  // reason — see that mount for why the whole table is asked rather than a list
  // of columns kept here. This mount carries the additional shape: a PUT naming
  // only `auth_type` reaches a serializer branch that cleans the STORED config
  // against the new type, so an unresolved spelling destroys a credential
  // through a request that carries no credential at all.
  enumColumns: enumColumnsFor(TABLES.FLOW_RECIPE_STEPS),
  serializeWrite,
  // Same mask-preserve read as the connector mount, and the same move onto the
  // write connection under the row's own lock. This mount already ran its write
  // inside a transaction (parentRepend), but the serializer ran BEFORE that
  // transaction opened, so the read was outside it either way.
  serializeWriteInTx: true,
  serializeRead,
}));

module.exports = router;
