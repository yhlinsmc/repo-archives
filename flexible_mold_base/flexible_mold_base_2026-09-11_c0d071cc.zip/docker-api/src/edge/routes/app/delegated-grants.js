'use strict';

/**
 * delegated-grants.js — granting and revoking delegated access.
 *
 *   GET    /?scope_type=&scope_id=  who currently holds access to one subject
 *   GET    /mine                    the subjects the CALLER may work on — the
 *                                   ones granted to them, and the blueprints
 *                                   they own, which reach every record under
 *                                   them without any grant existing
 *   GET    /people?q=               a bounded directory for the person picker
 *   POST   /                        grant one person access to one subject
 *   DELETE /:id                     revoke one grant
 *
 * WHO MAY GRANT: the subject's owner, and an administrator. Nobody else, and in
 * particular not a grantee — a grant conveys working on the record, never
 * handing that on. The check is ownership of the SUBJECT, so it is the same
 * check for a blueprint and for a single template, which is why one route
 * serves both.
 *
 * WHY A FOREIGN SUBJECT ANSWERS 404 RATHER THAN 403. The same reason the write
 * path does: "not yours" over an identifier confirms the subject exists. A
 * caller who owns nothing learns nothing here.
 *
 * THE PERSON PICKER IS ITS OWN ENDPOINT, and deliberately not the existing
 * assignable-users directory — it needs role in the row, which that one does
 * not carry. R-3-P4: gated to editor/admin, same as the surface it feeds. A
 * plain-user owner cannot grant at all (`callerOwnsSubject` above, spec §7.1),
 * so a plain user has no use left for this directory. It carries kc_username
 * + role, same as assignable-users, so the UserRow the caller sees here
 * (grantee list, person picker) matches the one they would see in a
 * transfer-owner picker — but never an email address: the never-return-email
 * rule applies here as everywhere, and kc_username is domain-stripped the
 * same way display_name is.
 */
const router = require('express').Router();
const { sendError } = require('../../../shared/lib/send-error');
const { pool, t } = require('../../db');
const {
  apiOk, requireAuth, requireAdminOrEditor, uuidv4, UUID_RE,
} = require('../../../shared/helpers');
const { TABLES } = require('../../../shared/constants');
const { mapRowsFromDb } = require('../../lib/dto-mapper');
const { attachOwnerNames, stripEmailDomain } = require('../../lib/owner-name-enrichment');
const { normalizeRows } = require('../../../shared/serializers/normalize-nullable');
const { escapeLikePattern } = require('../../lib/sql-like');
const { GRANT_SCOPES, grantsTableAvailable, grantEligibleRole } = require('../../lib/delegated-grants');
const { resolveCanonicalUserId, sameStoredValue } = require('./schema/write-value');
const { logger: rootLogger } = require('../../../shared/lib/logger');

const logger = rootLogger.child({ module: 'delegated-grants' });

// SECURITY: authentication for the whole router rather than per handler, so a
// route added later inherits it instead of having to remember it.
router.use((req, res, next) => { if (requireAuth(req, res)) next(); });

/** How many people the picker returns at most. A directory read has to be
 *  bounded by something, and an unbounded one is the same defect as an unbounded
 *  list anywhere else. */
const MAX_PEOPLE = 200;

/** How many grants one subject may carry in a single response. Far above any
 *  plausible number of delegates; present so the response has a ceiling. */
const MAX_GRANTS = 500;

const dbError = (req, res, err, fields) => sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields });

const notFound = (req, res) => sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });

const badRequest = (req, res, message, code = 'BAD_REQUEST') => sendError(req, res, null, { status: 400, code, reason: message });

/**
 * A database whose operator account could not create the table has no grants.
 * Every read here answers empty and every write is refused with a cause the
 * operator can act on, rather than a 500 naming a missing table.
 */
async function requireGrantsTable(req, conn, res) {
  if (await grantsTableAvailable(conn)) return true;
  sendError(req, res, null, {
    status: 503,
    code: 'GRANTS_UNAVAILABLE',
    reason: 'Delegated access is unavailable on this database: the grants table has not been created. '
      + 'An administrator can see the outstanding schema steps under schema status.',
  });
  return false;
}

// Which table holds the owner of each subject tier. One map rather than a
// branch per reader, so the ownership question and the ownership READ can never
// end up asking about different tables.
const SUBJECT_OWNER_TABLE = Object.freeze({
  blueprint: TABLES.HIERARCHY_NODES,
  template: TABLES.USER_TEMPLATES,
});

/**
 * Who owns the subject a request names.
 *
 * @returns {Promise<string|null|undefined>} the owner's id, `null` for a subject
 *   nobody owns, and `undefined` for one that does not exist or is the wrong
 *   tier. Three answers rather than two because the callers below need to tell
 *   "nobody owns it" from "there is no such thing", and they say different
 *   things about them.
 */
async function subjectOwnerId(conn, scopeType, scopeId) {
  if (scopeType === 'blueprint') {
    const rows = await conn.query(
      `SELECT owner_id FROM \`${t(SUBJECT_OWNER_TABLE.blueprint)}\`
        WHERE id = ? AND node_type = 'blueprint'`,
      [scopeId],
    );
    return rows.length > 0 ? rows[0].owner_id ?? null : undefined;
  }
  const rows = await conn.query(
    `SELECT owner_id FROM \`${t(SUBJECT_OWNER_TABLE.template)}\` WHERE id = ?`,
    [scopeId],
  );
  return rows.length > 0 ? rows[0].owner_id ?? null : undefined;
}

/**
 * May this caller grant and revoke over that subject?
 *
 * An administrator does not own it and does not need to — but the subject still
 * has to exist, or the grant would be a row over nothing that nobody could ever
 * see or revoke. For everyone else it is ownership, and a subject nobody owns
 * answers false: nobody can delegate a record nobody owns.
 *
 * OWNERSHIP IS ASKED OF THE COLUMN. `owner_id` is `CHAR(36)` under a
 * case-folding collation, so the enforcement side of delegated access — the
 * EXISTS predicate that decides whether a grant lets somebody work on a record —
 * resolves the owner for any spelling of their id. Compared byte-wise here, a
 * record whose column holds another spelling of the caller's id was theirs
 * everywhere except at the one gate that decides whether they may delegate it,
 * and they were answered 404 over their own record. This PR does not rewrite
 * such rows, so the reader answers for them.
 *
 * FAIL-CLOSED, in three places: a scope tier this route does not know has no
 * table to ask about and is refused; `sameStoredValue` answers `false` for an
 * operand it cannot ask the engine about; and a probe that throws leaves the
 * caller's own catch to refuse. None of the three admits a stranger.
 */
async function callerOwnsSubject(conn, scopeType, user, ownerId) {
  if (!user) return false;
  if (ownerId === undefined) return false;
  if (user.role === 'admin') return true;
  // SECURITY spec §7.1: an owner may grant only when their role is editor or
  // above. A plain-user owner is refused here — before ownership is even asked —
  // so the server, not the FE menu (spec §7.2), is the authority. This guards
  // GET (view holders) and DELETE (revoke) as well as POST (grant): a plain-user
  // owner could never have minted a grant, so they have none to view or revoke.
  if (user.role === 'user') return false;
  if (ownerId == null) return false;
  const table = SUBJECT_OWNER_TABLE[scopeType];
  if (!table) return false;
  // collation-compare: this is the same "does this column name the caller"
  // the grant-enforcement EXISTS asks, and it must not answer differently.
  return sameStoredValue(conn, t(table), 'owner_id', ownerId, user.id);
}

/** The subject a request names, or null when it is not one this route knows. */
function readSubject(source) {
  const scopeType = source && source.scope_type;
  const scopeId = source && source.scope_id;
  if (!GRANT_SCOPES.includes(scopeType)) return null;
  if (typeof scopeId !== 'string' || !UUID_RE.test(scopeId)) return null;
  return { scopeType, scopeId };
}

/**
 * @openapi
 * /api/delegated-grants:
 *   get:
 *     summary: Who holds delegated access to one subject
 *     tags: [App - Delegated Grants]
 *     parameters:
 *       - { name: scope_type, in: query, required: true, schema: { type: string, enum: [blueprint, template] } }
 *       - { name: scope_id, in: query, required: true, schema: { type: string } }
 *     responses:
 *       200: { description: Grant list }
 *       404: { description: Not the caller's subject, or no such subject }
 *   post:
 *     summary: Grant one person access to one subject
 *     tags: [App - Delegated Grants]
 *     responses:
 *       201: { description: Granted }
 *       404: { description: Not the caller's subject }
 */

// ── The caller's own access ─────────────────────────────────────────────────

/**
 * Which subjects the caller may work on, as two lists of identifiers.
 *
 * WHAT THIS IS FOR, and what it is emphatically not. The browser uses it to
 * decide whether to OFFER editing — a screen that hides its controls from
 * someone who may in fact write is as wrong as one that shows controls that
 * will fail. It is not a permission: every write is decided again in SQL at the
 * point of writing, and a caller who forged this response would gain nothing.
 */
router.get('/mine', async (req, res) => {
  let conn;
  try {
    conn = await pool.ro.getConnection();
    // The blueprints the caller OWNS, over records under them owned by someone
    // else — the same delegated reach `buildTemplateAccessExists`' blueprint-
    // owner arm grants, so it carries the identical role floor: a blueprint
    // owned while an editor still names that owner_id after a demotion to
    // plain user, and this list must not offer editing that arm no longer
    // grants. Skipped entirely (not read then filtered) for an ineligible
    // caller — same choice as the grants-table read below, so a demoted
    // owner's match is never even fetched, let alone shown.
    const eligible = grantEligibleRole(req.user.role);
    const ownedRows = eligible ? await conn.query(
      `SELECT id FROM \`${t(TABLES.HIERARCHY_NODES)}\`
        WHERE node_type = 'blueprint' AND owner_id = ?
        ORDER BY id LIMIT ?`,
      [req.user.id, MAX_GRANTS],
    ) : [];
    const ownedBlueprintIds = ownedRows.map((r) => r.id);
    // R-3-P1: a grant naming this caller as grantee is not honoured unless
    // the caller is CURRENTLY an editor or an administrator — the same floor
    // callerHasTemplateAccess / callerHasBlueprintGrant apply at write time.
    // Skipping the read entirely (rather than reading and filtering) is the
    // same choice the write-time resolvers make: a plain user's grant rows
    // are never even consulted, so this list can never show access the
    // caller cannot in fact use.
    if (!eligible || !(await grantsTableAvailable(conn))) {
      return res.json(apiOk({
        blueprint_ids: [], template_ids: [], owned_blueprint_ids: ownedBlueprintIds,
      }));
    }
    // A grant stands in for the blueprint's owner, and an unowned
    // blueprint has none to stand in for — every write-side resolver arm
    // (callerHasBlueprintGrant et al.) is dormant while owner_id IS NULL, so
    // this listing has to ask the same question or it would offer editing a
    // write would then refuse. Template-scope rows carry no such condition
    // (a template's own dormancy is decided elsewhere, at write time), so the
    // LEFT JOIN is scoped to the blueprint arm only, mirroring
    // callerHasTemplateAccess's identical two-arm shape.
    const rows = await conn.query(
      `SELECT dg.scope_type, dg.scope_id FROM \`${t(TABLES.DELEGATED_GRANTS)}\` dg
        LEFT JOIN \`${t(TABLES.HIERARCHY_NODES)}\` hn
          ON hn.\`id\` = dg.\`scope_id\` AND dg.\`scope_type\` = 'blueprint'
        WHERE dg.\`grantee_id\` = ?
          AND (dg.\`scope_type\` <> 'blueprint' OR hn.\`owner_id\` IS NOT NULL)
        ORDER BY dg.created_at DESC LIMIT ?`,
      [req.user.id, MAX_GRANTS],
    );
    return res.json(apiOk({
      blueprint_ids: rows.filter((r) => r.scope_type === 'blueprint').map((r) => r.scope_id),
      template_ids: rows.filter((r) => r.scope_type === 'template').map((r) => r.scope_id),
      // Kept apart from the granted list rather than merged into it: they are
      // different facts about the reader, and a screen that wants to say WHY a
      // control is offered cannot recover the difference once they are one list.
      owned_blueprint_ids: ownedBlueprintIds,
    }));
  } catch (err) {
    return dbError(req, res, err);
  } finally {
    if (conn) conn.release();
  }
});

// ── The person picker ───────────────────────────────────────────────────────

// R-3-P4: a plain-user owner can never grant (callerOwnsSubject, spec §7.1),
// so a plain user has no use for this directory — gated the same as the
// screen that is its only consumer.
router.get('/people', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const q = typeof req.query.q === 'string' ? req.query.q.trim().slice(0, 100) : '';
  let conn;
  try {
    conn = await pool.ro.getConnection();
    const params = [];
    // R-3-P2: role-filtered AT THE SOURCE, not by the picker in the browser —
    // spec §13 D-3 only ever honours a grant whose grantee is editor/admin, so
    // a plain-user row is not a candidate this directory should ever have
    // offered. This route has exactly one consumer (DelegatedAccessDialog's
    // grantee picker); a second consumer that needed every role would need
    // its own endpoint, not a flag on this one.
    let where = "WHERE banned = 0 AND role IN ('editor', 'admin')";
    if (q) {
      // MATCHED ON WHAT IS SHOWN, which is the whole rule and the only one that
      // does not surprise somebody: the caller reads a name in the list, types
      // it, and finds that person. Both sides are the domain-stripped form, so
      // typing an address matches nothing and cannot be used to confirm one —
      // the never-return-email rule holds on the way in as well as out.
      where += ' AND (SUBSTRING_INDEX(display_name, \'@\', 1) LIKE ? ESCAPE \'|\''
        + ' OR SUBSTRING_INDEX(kc_username, \'@\', 1) LIKE ? ESCAPE \'|\')';
      const like = `%${escapeLikePattern(q)}%`;
      params.push(like, like);
    }
    // One row over the ceiling, so "there are more than these" is a fact rather
    // than a guess. A directory read has to be bounded by something, and a list
    // that silently stops is how a picker comes to say "no matching person"
    // about somebody who is standing right there.
    const rows = await conn.query(
      `SELECT id, display_name, kc_username, role FROM \`${t(TABLES.USERS)}\`
       ${where}
       ORDER BY COALESCE(NULLIF(display_name, ''), kc_username) IS NULL,
                COALESCE(NULLIF(display_name, ''), kc_username)
       LIMIT ?`,
      [...params, MAX_PEOPLE + 1],
    );
    const truncated = rows.length > MAX_PEOPLE;
    return res.json(apiOk({
      // SECURITY: resolved through the same helper every other surface uses, so
      // a display name that IS an address — which is exactly what the token
      // mapper leaves when no display name is mapped — arrives as its local
      // part and never as an address. Resolving it the same way is also what
      // stops one person being named one thing in the picker and another thing
      // in the row they end up in.
      people: rows.slice(0, MAX_PEOPLE).map((r) => ({
        id: r.id,
        display_name: stripEmailDomain(r.display_name || r.kc_username || '') || '',
        // SECURITY: kc_username is a username, not the email — domain-stripped
        // by the same helper so the never-return-email rule holds (spec §8.2
        // D-4). Distinct from display_name so a caller who wants "the name" and
        // a caller who wants "the handle" both have their own field.
        kc_username: stripEmailDomain(r.kc_username || '') || '',
        role: r.role || '',
      })),
      limit: MAX_PEOPLE,
      /** True when the directory has more people than were returned. The picker
       *  says so rather than letting the absent ones read as non-existent. */
      truncated,
    }));
  } catch (err) {
    return dbError(req, res, err);
  } finally {
    if (conn) conn.release();
  }
});

// ── One subject's grants ────────────────────────────────────────────────────

/**
 * The subject's owner, in the shape the shared UserRow draws (spec §8.1):
 * `null` for a subject nobody owns OR whose owner id names no row. Those two
 * causes read alike here on purpose — this is the identity for display, not
 * the ownership fact: a template whose owner_id names a deleted account is
 * still owned as far as granting goes, so a caller deciding whether to offer
 * a grant needs the raw column, not this. `GET /` sends `owner_id` alongside
 * this for exactly that reason — the one value that tells the two apart.
 *
 * RESOLVED HERE, not by the screen that already read `subjectOwnerId` out of
 * a directory page. Both directory pages this dialog could have used are
 * narrower than "every user": `/people` is editor/admin-only (R-3-P4) and
 * `/assignable` (users.js) excludes a banned account — so a directory-page
 * lookup answers "not on this page" for an owner who is real, current, and
 * simply outside that page's filter (Codex r2 R-3-P5). This route already
 * ran `subjectOwnerId` to decide the caller's own access, so it is the one
 * place the answer cannot be a stale or filtered copy.
 */
async function ownerIdentity(conn, ownerId) {
  if (!ownerId) return null;
  const rows = await conn.query(
    `SELECT id, display_name, kc_username, role FROM \`${t(TABLES.USERS)}\` WHERE id = ?`,
    [ownerId],
  );
  if (rows.length === 0) return null;
  const row = rows[0];
  return {
    id: row.id,
    display_name: stripEmailDomain(row.display_name || row.kc_username || '') || '',
    kc_username: stripEmailDomain(row.kc_username || '') || '',
    role: row.role || '',
  };
}

router.get('/', async (req, res) => {
  const subject = readSubject(req.query);
  if (!subject) return badRequest(req, res, 'A subject is required: scope_type and scope_id');

  let conn;
  try {
    conn = await pool.ro.getConnection();
    if (!(await requireGrantsTable(req, conn, res))) return undefined;
    const ownerId = await subjectOwnerId(conn, subject.scopeType, subject.scopeId);
    if (!(await callerOwnsSubject(conn, subject.scopeType, req.user, ownerId))) {
      return notFound(req, res);
    }
    const owner = await ownerIdentity(conn, ownerId);
    // `owner_id` rides alongside `owner` so the two questions `owner` alone
    // conflated stay answerable apart: "does this subject have an owner"
    // (this field, the raw column) and "does that owner still resolve to a
    // person" (`owner`, null for both no id and a dangling one). A template
    // whose owner_id names a deleted account is owned as far as granting is
    // concerned — the enforcement EXISTS still matches it — so a caller that
    // only had `owner` could not tell it apart from a subject with no owner
    // at all.
    const rows = await conn.query(
      `SELECT id, scope_type, scope_id, grantee_id, granted_by, created_at
         FROM \`${t(TABLES.DELEGATED_GRANTS)}\`
        WHERE scope_type = ? AND scope_id = ?
        ORDER BY created_at DESC
        LIMIT ?`,
      [subject.scopeType, subject.scopeId, MAX_GRANTS],
    );
    const mapped = mapRowsFromDb(TABLES.DELEGATED_GRANTS, rows);
    // Two people per row, resolved through the shared enrichment so neither can
    // arrive as an email address.
    await attachActorNames(conn, mapped, 'grantee_id', 'grantee');
    await attachActorNames(conn, mapped, 'granted_by', 'granter');
    return res.json(apiOk({
      owner,
      owner_id: ownerId,
      grants: normalizeRows(mapped, ['granted_by']),
      total: mapped.length,
      limit: MAX_GRANTS,
    }));
  } catch (err) {
    return dbError(req, res, err);
  } finally {
    if (conn) conn.release();
  }
});

/** Rename the shared owner enrichment's output to the person it was run for. A
 *  grantee is not an owner, and leaving the field called `owner_name` on a row
 *  with no owner column invites a reader to act on it as one.
 *
 *  A `<prefix>_removed` flag rides along, because an account that has been
 *  deleted is a FACT the server knows and the screen cannot recover: the name
 *  it would otherwise get is a word, and a row that renders it as an ordinary
 *  person says something false about who has access. */
async function attachActorNames(conn, rows, column, prefix) {
  await attachOwnerNames(conn, rows, column, `\`${t(TABLES.USERS)}\``, { unresolved: null });
  for (const row of rows) {
    if (!row) continue;
    row[`${prefix}_removed`] = row[column] != null && row.owner_name == null;
    row[`${prefix}_name`] = row.owner_name ?? '';
    row[`${prefix}_username`] = row.owner_username ?? '';
    delete row.owner_name;
    delete row.owner_username;
  }
  return rows;
}

// ── Granting ────────────────────────────────────────────────────────────────

router.post('/', async (req, res) => {
  const subject = readSubject(req.body);
  if (!subject) return badRequest(req, res, 'A subject is required: scope_type and scope_id');
  const granteeId = req.body && req.body.grantee_id;
  if (typeof granteeId !== 'string' || !UUID_RE.test(granteeId)) {
    return badRequest(req, res, 'A person is required: grantee_id');
  }

  let conn;
  try {
    conn = await pool.rw.getConnection();
    if (!(await requireGrantsTable(req, conn, res))) return undefined;
    const ownerId = await subjectOwnerId(conn, subject.scopeType, subject.scopeId);
    if (!(await callerOwnsSubject(conn, subject.scopeType, req.user, ownerId))) {
      return notFound(req, res);
    }
    // A subject nobody owns cannot be delegated — BOTH scopes (widened
    // this from template-only to blueprint too), and that holds for an
    // administrator too, not as a restriction on them but because no enforcement
    // point would honour the grant. Every arm of delegated access requires the
    // subject to have an owner (see `lib/delegated-grants.js`: a blueprint grant
    // now goes dormant while the blueprint's owner_id IS NULL), so storing this
    // would be storing a promise the screen would go on displaying and nothing
    // would ever keep. Asked independently of `callerOwnsSubject`'s admin
    // bypass, so an administrator granting on an unowned blueprint is refused
    // here just as an owner is.
    if (ownerId == null) {
      return badRequest(req, res,
        'That record has no owner, so there is no access to delegate. Claim it first.',
        'UNOWNED_SUBJECT',
      );
    }
    // The person has to exist and be able to sign in. A grant to an account that
    // cannot is not harmful — nothing will ever match it — but it is a promise
    // the screen would go on displaying, so it is refused where it is made.
    //
    // collation-compare: which person a spelling names is the column's
    // question, and `users.id` folds case. `person.id` is the STORED spelling
    // and it is what the INSERT binds — the enforcement path reads this value
    // back through `WHERE grantee_id = ?` (which folds) while the screen and
    // the revoke list read it in JavaScript (which does not), so storing the
    // caller's spelling produces a grant that enforces for somebody the UI
    // cannot name.
    // EVERY REASON GETS ONE SENTENCE HERE, and that is this route's own choice
    // rather than an oversight — unlike an ownership transfer, a grant is made
    // TO somebody the caller names, so distinguishing "no such person" from
    // "that person is banned" would answer questions about accounts the caller
    // may know nothing about. The shared `ownerTargetRejection` map deliberately
    // does the opposite for the transfer routes, where the target is a user the
    // administrator is already looking at.
    //
    // Signing in is no longer asked separately. `resolveCanonicalUserId` refuses
    // a banned account itself, so the follow-up `WHERE id = ? AND banned = 0`
    // that used to sit here could only ever match — a guard whose refusal has
    // become unreachable, reading to the next person as if it were still the
    // thing keeping a banned grantee out.
    const person = await resolveCanonicalUserId(conn, t(TABLES.USERS), granteeId);
    if (!person.ok) {
      return person.reason === 'ambiguous'
        ? badRequest(req, res, 'That person cannot be granted access', 'AMBIGUOUS_GRANTEE')
        : badRequest(req, res, 'That person cannot be granted access', 'UNKNOWN_GRANTEE');
    }
    // spec §13 D-3 (owner-confirmed 2026-09-03): a grant is effective only for
    // editor/admin grantees. The picker (DelegatedAccessDialog, spec §8.2)
    // already offers only editor/admin candidates, which makes this the
    // SECOND authority on the same question — server-authoritative, since a
    // client that skips or is not the shipped picker (a hand-built request,
    // a stale build) is not otherwise stopped from naming a plain-user id.
    if (person.role !== 'editor' && person.role !== 'admin') {
      return badRequest(req, res, 'Grants apply to editors and admins only.', 'GRANTEE_NOT_ELIGIBLE');
    }
    // Granting to yourself is refused rather than silently stored: it would
    // appear in the list as an access somebody could revoke, and revoking it
    // would take nothing away.
    //
    // collation-compare, and this one is a security boundary rather than a
    // tidiness rule. The invariant is the UNIQUE index `uq_delegated_grant`,
    // which folds case, so a refusal that compares any other way admits a row
    // the index considers the same grant. A self-grant that gets stored
    // OUTLIVES the ownership it was made under: hand the record on, and the
    // former owner still holds write and dispatch over a record they no longer
    // own. So the refusal is asked of the column the index is built on, not of
    // JavaScript — even though both operands are canonical by the line above,
    // because a guard that is only correct while its inputs happen to be
    // normalised is one refactor from being no guard.
    if (await sameStoredValue(conn, t(TABLES.DELEGATED_GRANTS), 'grantee_id', person.id, req.user.id)) {
      return badRequest(req, res, 'That person already has access', 'ALREADY_HAS_ACCESS');
    }
    const id = uuidv4();
    try {
      await conn.query(
        `INSERT INTO \`${t(TABLES.DELEGATED_GRANTS)}\`
           (id, scope_type, scope_id, grantee_id, granted_by) VALUES (?, ?, ?, ?, ?)`,
        [id, subject.scopeType, subject.scopeId, person.id, req.user.id],
      );
    } catch (err) {
      // The same person granted the same subject twice is one grant. A second
      // submission is answered as the success it effectively is rather than as
      // a fault, so a double-click does not produce an error the operator has to
      // interpret.
      if (err && (err.errno === 1062 || err.code === 'ER_DUP_ENTRY')) {
        return res.status(200).json(apiOk({ id: null, already_granted: true }));
      }
      throw err;
    }
    return res.status(201).json(apiOk({ id, already_granted: false }));
  } catch (err) {
    return dbError(req, res, err);
  } finally {
    if (conn) conn.release();
  }
});

// ── Revoking ────────────────────────────────────────────────────────────────

router.delete('/:id', async (req, res) => {
  if (!UUID_RE.test(String(req.params.id))) return notFound(req, res);
  let conn;
  try {
    conn = await pool.rw.getConnection();
    if (!(await requireGrantsTable(req, conn, res))) return undefined;
    // Read the grant to learn its subject, then ask the same ownership question
    // granting asked. Revoking is not a weaker act than granting and is not
    // gated more loosely: only the subject's owner and an administrator may do
    // either.
    const rows = await conn.query(
      `SELECT scope_type, scope_id FROM \`${t(TABLES.DELEGATED_GRANTS)}\` WHERE id = ?`,
      [req.params.id],
    );
    if (!rows.length) return notFound(req, res);
    const ownerId = await subjectOwnerId(conn, rows[0].scope_type, rows[0].scope_id);
    if (!(await callerOwnsSubject(conn, rows[0].scope_type, req.user, ownerId))) {
      return notFound(req, res);
    }
    const result = await conn.query(
      `DELETE FROM \`${t(TABLES.DELEGATED_GRANTS)}\` WHERE id = ?`,
      [req.params.id],
    );
    // A grant that was revoked by somebody else between the read and the delete
    // is reported as revoked: the caller asked for it to be gone, and it is.
    return res.json(apiOk({ revoked: Number(result.affectedRows || 0) > 0 }));
  } catch (err) {
    return dbError(req, res, err);
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
module.exports.__test__ = {
  callerOwnsSubject, subjectOwnerId, readSubject, MAX_PEOPLE, MAX_GRANTS,
};
