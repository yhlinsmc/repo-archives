/**
 * Import / export / clone handlers for cross-environment transformer migration.
 *
 *   POST /import         import transformer from a JSON export payload
 *   GET  /:id/export     export transformer as a JSON payload
 *   POST /:id/clone      duplicate an existing transformer
 */
const { pool, t } = require('../../../db');
const { sendError } = require('../../../../shared/lib/send-error');
const { apiOk, apiError, requireAdmin, requireAdminOrEditor, uuidv4 } = require('../../../../shared/helpers');
const { MAX_CODE_SIZE } = require('./_shared');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { TABLES } = require('../../../../shared/constants');
// SECURITY: the import and clone responses re-read the created row with
// `SELECT *`, so they carry the same `created_by` / `updated_by` email the CRUD
// surfaces stopped returning. One rule, every emitter.
const {
  stripEmailColumns, AUTHOR_EMAIL_COLUMNS,
} = require('../../../lib/owner-name-enrichment');
const withoutAuthorEmails = (rows) => stripEmailColumns(rows, AUTHOR_EMAIL_COLUMNS);

const logger = rootLogger.child({ module: 'transformers:io' });

// A test case's `payload` / `expectedOutput` are stored (and read by the editor's
// safeParseTestCases) as JSON STRINGS. The readable export path expands those
// strings into nested objects (deepJsonStringify), so an export→import round trip
// hands them back as objects — which the editor silently drops to '', destroying
// every test case. Re-encode any object/array-typed value back to a JSON string
// at the import boundary so the stored shape matches what the editor expects.
// Robust to hand-edited files too. Plain-string and scalar values pass through.
const TEST_CASE_JSON_STRING_FIELDS = ['payload', 'expectedOutput'];
function normalizeImportedTestCases(testCases) {
  if (!Array.isArray(testCases)) return testCases;
  return testCases.map((tc) => {
    if (!tc || typeof tc !== 'object') return tc;
    const out = { ...tc };
    for (const field of TEST_CASE_JSON_STRING_FIELDS) {
      const v = out[field];
      if (v !== null && typeof v === 'object') out[field] = JSON.stringify(v);
    }
    return out;
  });
}

module.exports = function register(router) {
  // POST /import — import transformer from JSON
  router.post('/import', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    const { transformer } = req.body;

    if (!transformer || !transformer.name || !transformer.code) {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'Invalid import data: name and code are required' });
    }
    if (transformer.name.length > 255) {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'name exceeds 255 characters' });
    }
    if (Buffer.byteLength(transformer.code, 'utf8') > MAX_CODE_SIZE) {
      return sendError(req, res, null, { status: 400, code: 'CODE_TOO_LARGE', reason: `Code exceeds ${MAX_CODE_SIZE / 1024}KB limit` });
    }

    const id = uuidv4();
    const user = req.user?.email || req.user?.id || 'system';
    let conn;
    try {
      conn = await pool.rw.getConnection();
      await conn.beginTransaction();

      // NOTE: stamp owner_id on import so the new row participates in the
      // ownership model. Without this, imports default to NULL (shared) and
      // bypass the create-as-self policy. The import payload's owner_id (if
      // any) is ignored; the server is the sole authority.
      const ownerId = req.user?.id || null;
      const testCasesJson = transformer.test_cases
        ? JSON.stringify(normalizeImportedTestCases(transformer.test_cases))
        : null;
      await conn.query(
        `INSERT INTO \`${t(TABLES.TRANSFORMERS)}\`
         (id, name, description, code, input_schema, output_keys, test_cases, is_active, version, code_size, created_by, updated_by, owner_id)
         VALUES (?, ?, ?, ?, ?, ?, ?, TRUE, 1, ?, ?, ?, ?)`,
        [
          id,
          transformer.name,
          transformer.description || null,
          transformer.code,
          transformer.input_schema ? JSON.stringify(transformer.input_schema) : null,
          transformer.output_keys ? JSON.stringify(transformer.output_keys) : null,
          testCasesJson,
          Buffer.byteLength(transformer.code, 'utf8'),
          user, user, ownerId,
        ],
      );

      await conn.query(
        `INSERT INTO \`${t(TABLES.TRANSFORMER_VERSIONS)}\`
         (id, transformer_id, version, code, input_schema, output_keys, test_cases, change_note, action, created_by)
         VALUES (?, ?, 1, ?, ?, ?, ?, 'Imported', 'import', ?)`,
        [
          uuidv4(), id, transformer.code,
          transformer.input_schema ? JSON.stringify(transformer.input_schema) : null,
          transformer.output_keys ? JSON.stringify(transformer.output_keys) : null,
          testCasesJson,
          user,
        ],
      );

      await conn.commit();

      const rows = await conn.query(
        `SELECT * FROM \`${t(TABLES.TRANSFORMERS)}\` WHERE id = ?`, [id],
      );
      res.status(201).json(apiOk(withoutAuthorEmails(rows)[0]));
    } catch (err) {
      if (conn) await conn.rollback();
      sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { transformerId: id, name: transformer.name } });
    } finally {
      if (conn) conn.release();
    }
  });

  // GET /:id/export — export transformer as JSON (for cross-env migration)
  router.get('/:id/export', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    let conn;
    try {
      conn = await pool.ro.getConnection();
      const rows = await conn.query(
        `SELECT name, description, code, input_schema, output_keys, test_cases
         FROM \`${t(TABLES.TRANSFORMERS)}\` WHERE id = ?`,
        [req.params.id],
      );
      if (!rows.length) {
        return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Transformer not found' });
      }

      const row = rows[0];
      const exported = {
        name: row.name,
        description: row.description,
        code: row.code,
        input_schema: typeof row.input_schema === 'string' ? JSON.parse(row.input_schema) : row.input_schema,
        output_keys: typeof row.output_keys === 'string' ? JSON.parse(row.output_keys) : row.output_keys,
        test_cases: typeof row.test_cases === 'string' ? JSON.parse(row.test_cases) : row.test_cases,
        exported_at: new Date().toISOString(),
      };
      res.json(apiOk(exported));
    } catch (err) {
      sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { transformerId: req.params.id } });
    } finally {
      if (conn) conn.release();
    }
  });

  // POST /:id/clone — clone a transformer
  router.post('/:id/clone', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    const user = req.user?.email || req.user?.id || 'system';
    let conn;
    try {
      // NOTE: source SELECT is inside the transaction so the clone is atomic
      // against a concurrent delete of the source row. A SELECT outside the
      // tx would let a concurrent DELETE produce a clone-of-nothing instead of
      // a clean "not found" response.
      conn = await pool.rw.getConnection();
      await conn.beginTransaction();

      const rows = await conn.query(
        `SELECT * FROM \`${t(TABLES.TRANSFORMERS)}\` WHERE id = ? FOR UPDATE`,
        [req.params.id],
      );
      if (!rows.length) {
        await conn.rollback();
        return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Transformer not found' });
      }

      const source = rows[0];
      const newId = uuidv4();
      const newName = `${source.name} (Copy)`;
      // Clone stamps owner_id on the new row (same reason as the import path).
      // The clone's owner is the actor performing the clone — never the
      // source's owner.
      const ownerId = req.user?.id || null;

      await conn.query(
        `INSERT INTO \`${t(TABLES.TRANSFORMERS)}\`
         (id, name, description, code, input_schema, output_keys, test_cases, is_active, version, code_size, created_by, updated_by, owner_id)
         VALUES (?, ?, ?, ?, ?, ?, ?, TRUE, 1, ?, ?, ?, ?)`,
        [
          newId, newName, source.description, source.code,
          source.input_schema, source.output_keys, source.test_cases,
          source.code_size, user, user, ownerId,
        ],
      );

      await conn.query(
        `INSERT INTO \`${t(TABLES.TRANSFORMER_VERSIONS)}\`
         (id, transformer_id, version, code, input_schema, output_keys, test_cases, change_note, action, created_by)
         VALUES (?, ?, 1, ?, ?, ?, ?, ?, 'create', ?)`,
        [
          uuidv4(), newId, source.code,
          source.input_schema, source.output_keys, source.test_cases,
          `Cloned from "${source.name}"`,
          user,
        ],
      );

      await conn.commit();

      const result = await conn.query(
        `SELECT * FROM \`${t(TABLES.TRANSFORMERS)}\` WHERE id = ?`, [newId],
      );
      res.status(201).json(apiOk(withoutAuthorEmails(result)[0]));
    } catch (err) {
      if (conn) await conn.rollback();
      sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { sourceId: req.params.id } });
    } finally {
      if (conn) conn.release();
    }
  });
};
