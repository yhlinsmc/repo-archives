/**
 * Version history and rollback handlers for transformers.
 *
 *   GET /:id/versions             list all versions newest-first
 *   GET /:id/versions/:versionId  fetch a specific version snapshot
 *   PUT /:id/rollback/:ver        restore a previous version as a new entry
 */
const { pool, t } = require('../../../db');
const { sendError } = require('../../../../shared/lib/send-error');
const { apiOk, apiError, requireAdminOrEditor, uuidv4 } = require('../../../../shared/helpers');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { TABLES } = require('../../../../shared/constants');
// SECURITY: every version row records its author as `req.user.email`. The same
// never-return-email rule the transformer surfaces apply is applied here, so a
// version list does not become the way to read what the transformer list stopped
// showing.
const {
  stripEmailColumns, AUTHOR_EMAIL_COLUMNS,
} = require('../../../lib/owner-name-enrichment');
const withoutAuthorEmails = (rows) => stripEmailColumns(rows, AUTHOR_EMAIL_COLUMNS);

const logger = rootLogger.child({ module: 'transformers:versions' });

module.exports = function register(router) {
  // GET /:id/versions — version history
  router.get('/:id/versions', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    let conn;
    try {
      conn = await pool.ro.getConnection();
      const rows = await conn.query(
        `SELECT id, version, change_note, action, created_by, created_at
         FROM \`${t(TABLES.TRANSFORMER_VERSIONS)}\`
         WHERE transformer_id = ?
         ORDER BY version DESC`,
        [req.params.id],
      );
      res.json(apiOk(withoutAuthorEmails(rows)));
    } catch (err) {
      sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { transformerId: req.params.id } });
    } finally {
      if (conn) conn.release();
    }
  });

  // GET /:id/versions/:versionId — get specific version snapshot
  router.get('/:id/versions/:versionId', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    let conn;
    try {
      conn = await pool.ro.getConnection();
      const rows = await conn.query(
        `SELECT * FROM \`${t(TABLES.TRANSFORMER_VERSIONS)}\`
         WHERE transformer_id = ? AND id = ?`,
        [req.params.id, req.params.versionId],
      );
      if (!rows.length) {
        return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Version not found' });
      }
      res.json(apiOk(withoutAuthorEmails(rows)[0]));
    } catch (err) {
      sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { transformerId: req.params.id, versionId: req.params.versionId } });
    } finally {
      if (conn) conn.release();
    }
  });

  // DELETE /:id/versions/:versionId
  // Lets admin remove a specific historical version row. Refuses to delete
  // the row that holds the live `transformer.version` pointer (would orphan
  // the transformer's snapshot) and refuses to delete the last remaining row
  // (would leave `transformer_versions` empty; future rollback impossible).
  // Audit row records the deletion so the prune sequence is reconstructable.
  router.delete('/:id/versions/:versionId', async (req, res) => {
    // Version-history pruning is owner-gated (mirrors the transformer DELETE and
    // rollback routes): an editor may prune the versions of a transformer they
    // own or one that is shared (owner_id NULL); a non-owner editor gets 404
    // (existence-leak parity). Admin bypasses the owner check.
    if (!requireAdminOrEditor(req, res)) return;
    // lint-allow: write-path-shapes recorded as the actor who pruned a
    // version. Same single-derivation change as the audit lines, deferred with them.
    const userId = req.user?.id || req.user?.sub || null;
    let conn;
    try {
      conn = await pool.rw.getConnection();
      await conn.beginTransaction();

      // Lock the version row to delete + read context fields.
      const targetRows = await conn.query(
        `SELECT id, transformer_id, version FROM \`${t(TABLES.TRANSFORMER_VERSIONS)}\`
          WHERE id = ? AND transformer_id = ? FOR UPDATE`,
        [req.params.versionId, req.params.id],
      );
      if (!targetRows.length) {
        await conn.rollback();
        return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Version not found' });
      }
      const target = targetRows[0];

      // FOR UPDATE locks the parent so a concurrent ownership transfer cannot
      // slip between the owner check and the delete. owner_id resolves the
      // editor gate: only the owner (or a shared row, owner_id NULL) may prune.
      const transformer = await conn.query(
        `SELECT id, version, owner_id FROM \`${t(TABLES.TRANSFORMERS)}\` WHERE id = ? FOR UPDATE`,
        [req.params.id],
      );
      if (!transformer.length) {
        await conn.rollback();
        return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Transformer not found' });
      }
      // Owner check first (mirrors the rollback route), before the
      // current/last-version integrity guards below. A non-owner editor gets
      // 404, not 403, to avoid leaking the row's existence.
      if (req.user?.role === 'editor'
          && transformer[0].owner_id != null
          && transformer[0].owner_id !== req.user?.id) {
        await conn.rollback();
        return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Transformer not found' });
      }
      if (transformer[0].version === target.version) {
        await conn.rollback();
        return sendError(req, res, null, { status: 409, code: 'VERSION_IS_CURRENT', reason: `Cannot delete the current version (${target.version}); roll back first if you want this row gone.` });
      }

      const remaining = await conn.query(
        `SELECT COUNT(*) AS n FROM \`${t(TABLES.TRANSFORMER_VERSIONS)}\` WHERE transformer_id = ?`,
        [req.params.id],
      );
      if (Number(remaining[0]?.n ?? 0) <= 1) {
        await conn.rollback();
        return sendError(req, res, null, { status: 409, code: 'LAST_VERSION', reason: 'Cannot delete the only remaining version' });
      }

      await conn.query(
        `DELETE FROM \`${t(TABLES.TRANSFORMER_VERSIONS)}\` WHERE id = ?`,
        [req.params.versionId],
      );
      await conn.query(
        `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata)
         VALUES (?, 'transformer.version.delete', ?, ?)`,
        [
          uuidv4(),
          userId,
          JSON.stringify({
            transformer_id: req.params.id,
            version_id: req.params.versionId,
            version_number: target.version,
          }),
        ],
      );
      await conn.commit();
      res.json(apiOk({ deleted: true, version: target.version }));
    } catch (err) {
      if (conn) {
        try { await conn.rollback(); } catch (rbErr) {
          req.log.warn({ err: rbErr }, 'rollback after delete-version failed');
        }
      }
      sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { transformerId: req.params.id, versionId: req.params.versionId } });
    } finally {
      if (conn) conn.release();
    }
  });

  // PUT /:id/rollback/:ver — rollback to a specific version number
  router.put('/:id/rollback/:ver', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    const targetVersion = parseInt(req.params.ver, 10);
    if (isNaN(targetVersion) || targetVersion < 1) {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'Invalid version number' });
    }

    const user = req.user?.email || req.user?.id || 'system';
    let conn;
    try {
      conn = await pool.rw.getConnection();
      await conn.beginTransaction();

      // Get target version snapshot
      const snapshots = await conn.query(
        `SELECT * FROM \`${t(TABLES.TRANSFORMER_VERSIONS)}\`
         WHERE transformer_id = ? AND version = ?`,
        [req.params.id, targetVersion],
      );
      if (!snapshots.length) {
        await conn.rollback();
        return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: `Version ${targetVersion} not found` });
      }

      const snapshot = snapshots[0];

      // Get current version for incrementing.
      // FOR UPDATE locks the row and the owner_id pre-check fail-closes
      // editor rollback when the row is owned by an admin or another
      // editor. Without this the rollback path bypasses the PUT/DELETE/
      // toggle ownership guards.
      const current = await conn.query(
        `SELECT version, owner_id FROM \`${t(TABLES.TRANSFORMERS)}\` WHERE id = ? FOR UPDATE`, [req.params.id],
      );
      if (!current.length) {
        await conn.rollback();
        return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Transformer not found' });
      }
      if (req.user?.role === 'editor'
          && current[0].owner_id != null
          && current[0].owner_id !== req.user?.id) {
        await conn.rollback();
        return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Transformer not found' });
      }

      const newVersion = current[0].version + 1;

      // Restore full snapshot to transformer
      await conn.query(
        `UPDATE \`${t(TABLES.TRANSFORMERS)}\`
         SET code = ?, input_schema = ?, output_keys = ?, test_cases = ?,
             version = ?, code_size = ?, updated_by = ?
         WHERE id = ?`,
        [
          snapshot.code,
          snapshot.input_schema,
          snapshot.output_keys,
          snapshot.test_cases,
          newVersion,
          Buffer.byteLength(snapshot.code, 'utf8'),
          user,
          req.params.id,
        ],
      );

      // Record rollback as a new version entry
      await conn.query(
        `INSERT INTO \`${t(TABLES.TRANSFORMER_VERSIONS)}\`
         (id, transformer_id, version, code, input_schema, output_keys, test_cases, change_note, action, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'rollback', ?)`,
        [
          uuidv4(), req.params.id, newVersion,
          snapshot.code, snapshot.input_schema, snapshot.output_keys, snapshot.test_cases,
          `Rolled back to version ${targetVersion}`,
          user,
        ],
      );

      await conn.commit();

      const rows = await conn.query(
        `SELECT * FROM \`${t(TABLES.TRANSFORMERS)}\` WHERE id = ?`, [req.params.id],
      );
      res.json(apiOk(withoutAuthorEmails(rows)[0]));
    } catch (err) {
      if (conn) await conn.rollback();
      sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { transformerId: req.params.id, targetVersion } });
    } finally {
      if (conn) conn.release();
    }
  });
};
