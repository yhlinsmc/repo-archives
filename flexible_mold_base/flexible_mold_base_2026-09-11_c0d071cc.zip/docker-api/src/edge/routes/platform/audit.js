const { TABLES } = require('../../../shared/constants');
const { sendError } = require('../../../shared/lib/send-error');

const router = require('express').Router();
const { pool, t } = require('../../db');
const { apiOk, apiError } = require('../../../shared/helpers');
const { logger: rootLogger } = require('../../../shared/lib/logger');
const logger = rootLogger.child({ module: 'audit' });

/**
 * @openapi
 * /edge/platform/audit/audit-log:
 *   post:
 *     summary: Record a login event
 *     tags: [Platform - Audit]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [username]
 *             properties:
 *               username: { type: string }
 *               success: { type: boolean, default: true }
 *               reason: { type: string }
 *               ip_address: { type: string }
 *               user_agent: { type: string }
 *     responses:
 *       200: { description: Audit log recorded, content: { application/json: { schema: { $ref: '#/components/schemas/ApiResponse' } } } }
 *       401: { description: Unauthorized }
 */
router.post('/audit-log', async (req, res) => {
  // In edge context, auth is handled by S2S — req.user is set by s2s-verify.
  // The original route required auth, but edge trusts infra's forwarded identity.
  if (!req.user) {
    return sendError(req, res, null, { status: 401, code: 'UNAUTHORIZED', reason: 'Unauthorized' });
  }

  const { username, success = true, reason, ip_address, user_agent } = req.body;

  if (!username) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'username is required' });
  }

  let conn;
  try {
    // NOTE: login_audit INSERT — explicit pool.rw (writer).
    conn = await pool.rw.getConnection();
    await conn.query(
      `INSERT INTO \`${t(TABLES.LOGIN_AUDIT)}\` (id, username, auth_provider, reason, ip_address, user_agent, success)
       VALUES (UUID(), ?, 'LOCAL', ?, ?, ?, ?)`,
      [username, reason || null, ip_address || null, user_agent || null, success ? 1 : 0]
    );
    res.json(apiOk(null));
  } catch (err) {
    if (err.message.includes("doesn't exist") || err.message.includes('Table')) {
      return res.json(apiOk(null));
    }
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { username } });
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
