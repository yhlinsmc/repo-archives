const { TABLES } = require('../../../shared/constants');
const { sendError } = require('../../../shared/lib/send-error');

/**
 * access-check.js — S2S access check endpoint (edge-side).
 *
 * Called by infra-side accessCheckMiddleware on every authenticated request
 * (when auth_mode is keycloak and user is not admin). Returns allow/deny
 * decision based on the access_rules table.
 *
 * Query priority: user rule (email) > deptid rule > deny.
 *
 * No cache layer — latency benchmarks will gate any future cache addition.
 * If p95 > 50ms, a flat 30s TTL cache will be added as a follow-up.
 */

const router = require('express').Router();
const { pool, t } = require('../../db');
const { apiOk, apiError } = require('../../../shared/helpers');
const { logger: rootLogger } = require('../../../shared/lib/logger');
const { markReadOnly } = require('../../../shared/middleware/route-markers');
const logger = rootLogger.child({ module: 'access-check' });

/**
 * POST /edge/platform/access-check
 *
 * Body: { email, deptid, role }
 * Returns: { allowed: true/false, reason: string }
 *
 * Called via S2S from infra accessCheckMiddleware.
 * The S2S verify middleware on edge already authenticated the request.
 */
router.post('/', markReadOnly, async (req, res) => {
  const { email, deptid, role } = req.body;

  // Admins always pass
  if (role === 'admin') {
    return res.json(apiOk({ allowed: true, reason: 'admin_bypass' }));
  }

  try {
    // NOTE: access-check runs on every authenticated non-admin request;
    // pure SELECT path → pool.ro keeps the hot path off the writer.
    const conn = await pool.ro.getConnection();
    try {
      // Check user-level rule first (higher priority) — matches by email
      if (email) {
        const userRules = await conn.query(
          `SELECT role FROM \`${t(TABLES.ACCESS_RULES)}\`
           WHERE rule_type = 'user' AND rule_value = ? AND enabled = TRUE`,
          [email]
        );
        if (userRules.length) {
          return res.json(apiOk({ allowed: true, reason: 'user_rule' }));
        }
      }

      // Check deptid-level rule
      if (deptid) {
        const deptidRules = await conn.query(
          `SELECT role FROM \`${t(TABLES.ACCESS_RULES)}\`
           WHERE rule_type = 'deptid' AND rule_value = ? AND enabled = TRUE`,
          [deptid]
        );
        if (deptidRules.length) {
          return res.json(apiOk({ allowed: true, reason: 'deptid_rule' }));
        }
      }

      // Default deny
      return res.json(apiOk({ allowed: false, reason: 'no_matching_rule' }));
    } finally {
      conn.release();
    }
  } catch (err) {
    // Fail closed — deny on error
    sendError(req, res, err, { status: 500, code: 'ACCESS_CHECK_ERROR', reason: 'Access check failed' });
  }
});

module.exports = router;
