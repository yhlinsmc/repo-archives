/**
 * promote-first-admin.js — POST /api/setup/promote-first-admin
 *
 * One-shot admin-recovery promotion. Unlocks when four gates pass:
 *   1. Session gate — caller has an authenticated session (req.user.id)
 *   2. Mode-reachability gate — within SELECT FOR UPDATE on the
 *      system_settings._promote_lock sentinel row, verify that zero users
 *      are reachable as admin under the currently active auth mode
 *   3. Cryptographic gate — timingSafeEqual of HKDF(submitted) against
 *      HKDF(SETTINGS_ENCRYPTION_KEY), both domain-separated by
 *      info='admin-recovery-v1' (see shared/lib/recovery-token.js)
 *   4. Self-promote gate — the UPDATE targets session.keycloak_sub (or
 *      session.user.id for local mode); never an attacker-controlled field
 *
 * Response posture:
 *   Every gate failure returns a byte-identical 403 body with Cache-Control:
 *   no-store. Operator triage is via pino logs (info-level gate outcomes);
 *   the wire-visible response reveals nothing about which gate failed.
 *
 * Transaction shape:
 *   BEGIN
 *     SELECT 1 FROM system_settings WHERE key='_promote_lock' FOR UPDATE
 *     (upsert the sentinel if missing — handles deployments without the lock row)
 *     recheck admin count inside the lock
 *     UPDATE users SET role='admin' WHERE <session target column>=<value>
 *     INSERT INTO feature_audit (...)
 *   COMMIT
 *
 * After commit, a logger.warn outside the transaction provides a
 * tamper-evident record that captures the promotion even if the new admin
 * later deletes the feature_audit row.
 *
 * Rate limiting: dedicated recoveryLimiter (5 attempts / 15 min) mounted
 * on infra dispatcher — NOT the shared passwordLimiter. Review-driven
 * decision: sharing with /api/auth/login would let a login storm exhaust
 * the recovery budget mid-incident, and let an attacker DoS recovery by
 * hammering login. Separate buckets keep the same attack-budget profile.
 *
 * Threat model invariant (operator responsibility):
 *   The edge process port MUST NOT be externally reachable. Edge trusts
 *   req.user reconstructed from X-Forwarded-User-* headers after S2S key
 *   verification in s2s-verify.js. If an attacker could reach edge
 *   directly with a compromised S2S_API_KEY, they could forge
 *   X-Forwarded-User-kc-sub pointing at any user and pass the session
 *   + self-promote gates with the correct token. NetworkPolicy / service-
 *   mesh policy must enforce this. Documented in ENV_PLACEMENT.md.
 */
'use strict';

const { pool, t, isPoolReady } = require('../../../db');
const { apiOk, apiError } = require('../../../../shared/helpers');
const { resolveAuthModeAsync } = require('../../../../shared/config');
const { verifyRecoveryToken } = require('../../../../shared/lib/recovery-token');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { TABLES } = require('../../../../shared/constants');

const logger = rootLogger.child({ module: 'setup:promote-first-admin' });

// Byte-identical 403 response body for every gate failure. Defined as a
// constant so any accidental drift (extra field, different code) is visible
// in code review and caught by the unit-test byte-identity assertion.
const GATE_FAIL = apiError('Not available', 'FORBIDDEN', 403);

function sendGateFail(res) {
  res.setHeader('Cache-Control', 'no-store');
  // SECURITY: this stays a literal two-step, not sendError. sendError calls
  // apiError fresh per response, and apiError's body carries `meta.timestamp
  // = new Date().toISOString()` — a second call at a different wall-clock
  // moment would produce a different byte sequence. GATE_FAIL is built once
  // at module load specifically so every gate failure (including a genuine
  // backend fault, deliberately downgraded to this same body below) is
  // byte-identical over the life of the process; the unit test enforces this
  // with a raw Buffer.compare. Routing through sendError would also start
  // logging a real app-error line for a backend fault that this route
  // intentionally reports as an ordinary gate failure.
  // lint-allow: logger-discipline byte-identical frozen response required by the admin-recovery timing/enumeration-safety invariant above; a two-step through sendError would recompute a fresh body (and, for a caught error, start emitting an app-error line) and break byte identity
  return res.status(GATE_FAIL.status).json(GATE_FAIL.body);
}

module.exports = function register(router) {
  router.post('/promote-first-admin', async (req, res) => {
    // Content-Type guard (review MED): any non-JSON / missing body path
    // returns the SAME uniform 403, so body-parser rejection / oversized
    // body / wrong Content-Type cannot be distinguished from a gate-fail
    // via status code + response time. express.json() upstream has
    // already rejected truly malformed bodies, but defence-in-depth.
    const ct = String(req.headers['content-type'] || '').toLowerCase();
    if (!ct.startsWith('application/json')) {
      req.log.info({ gate: 'content_type', outcome: 'fail' }, 'recovery promote gate failed');
      return sendGateFail(res);
    }

    // Extract-then-scrub the token. `delete` rather than `= undefined`
    // (review MED): pino serializers that snapshot req.body eagerly
    // would still capture the undefined property name; delete removes
    // the key entirely. Ordered BEFORE the first logger call so any
    // subsequent request serializer sees a token-free body.
    const submittedToken = typeof req.body?.token === 'string' ? req.body.token : '';
    if (req.body && 'token' in req.body) delete req.body.token;

    // Gate 1: session required. 403 (not 401) so every failure is uniform.
    if (!req.user || !req.user.id) {
      req.log.info({ gate: 'session', outcome: 'fail' }, 'recovery promote gate failed');
      return sendGateFail(res);
    }

    if (!isPoolReady()) {
      req.log.info({ gate: 'pool', outcome: 'fail' }, 'recovery promote gate failed');
      return sendGateFail(res);
    }

    // Runtime fold: resolveAuthMode() returns a stale in-memory cache that
    // defaults to 'local' on the edge process (edge never boots the OIDC
    // middleware that populates it). In a keycloak-mode deployment this
    // caused the target branch + mode_reachability gate to both evaluate
    // in the wrong mode: target.col='id' (not keycloak_sub), and the gate
    // counted local-admins (users with password_hash) rather than
    // keycloak-reachable admins. Result: SSO-provisioned recovery user
    // had no password_hash, was not counted, and the gate permitted
    // unlimited replays. Use the async variant so mode is always read
    // from system_settings DB inside the same request.
    const activeMode = await resolveAuthModeAsync(pool, t);

    // Gate 4 target resolution. Mode-aware: keycloak mode targets
    // keycloak_sub (IdP-bound), local mode targets the user id (password-
    // bound). In either case the value comes from the session, never
    // from the request body, so there is no cross-user promote vector.
    const target = activeMode === 'keycloak'
      ? { col: 'keycloak_sub', val: req.user.keycloak_sub }
      : { col: 'id',           val: req.user.id };

    if (!target.val) {
      req.log.info(
        { gate: 'self_promote_target_missing', outcome: 'fail', mode: activeMode },
        'recovery promote gate failed'
      );
      return sendGateFail(res);
    }

    // Gate 3: cryptographic. Runs BEFORE taking the row lock so a wrong
    // token doesn't block legitimate concurrent DB work by holding the
    // sentinel lock. Still constant-time vs. a right-length token.
    const tokenOk = verifyRecoveryToken(submittedToken);
    if (!tokenOk) {
      req.log.info({ gate: 'token', outcome: 'fail' }, 'recovery promote gate failed');
      return sendGateFail(res);
    }

    let conn;
    try {
      // beginTransaction + FOR UPDATE + UPDATE users → pool.rw.
      conn = await pool.rw.getConnection();

      // Sentinel upsert OUTSIDE the transaction (review finding HIGH).
      // Running INSERT IGNORE inside an open transaction takes gap locks
      // on system_settings even when the row already exists, which can
      // conflict with concurrent inserts into adjacent rows under default
      // InnoDB isolation. The upsert is also a pre-condition to the
      // FOR UPDATE lock, not part of the atomic block it guards, so
      // keeping it out of the transaction matches the design intent.
      // Idempotent via the UNIQUE constraint on `key`.
      await conn.query(
        `INSERT IGNORE INTO \`${t(TABLES.SYSTEM_SETTINGS)}\` (\`key\`, value, description)
         VALUES ('_promote_lock', JSON_OBJECT(), 'Sentinel row for admin-recovery promotion lock')`
      );

      await conn.beginTransaction();

      // Take the row lock. All concurrent recovery attempts serialize here.
      await conn.query(
        `SELECT 1 FROM \`${t(TABLES.SYSTEM_SETTINGS)}\` WHERE \`key\` = '_promote_lock' FOR UPDATE`
      );

      // Gate 2 (inside lock): re-check admin count now that no other
      // promotion can interleave. The same predicate as /recovery-status.
      const modeClause = activeMode === 'keycloak'
        ? 'keycloak_sub IS NOT NULL'
        : 'password_hash IS NOT NULL';
      const countRows = await conn.query(
        `SELECT COUNT(*) AS cnt FROM \`${t(TABLES.USERS)}\`
          WHERE role = 'admin' AND banned = 0 AND ${modeClause}`
      );
      const reachableAdmins = Number(countRows[0]?.cnt || 0);
      if (reachableAdmins > 0) {
        await conn.rollback();
        req.log.info({ gate: 'mode_reachability', outcome: 'fail' }, 'recovery promote gate failed');
        return sendGateFail(res);
      }

      // Perform the promotion.
      const updateResult = await conn.query(
        `UPDATE \`${t(TABLES.USERS)}\` SET role = 'admin' WHERE \`${target.col}\` = ?`,
        [target.val]
      );
      // mysql2 may return an OkPacket or an array depending on the build; normalise.
      const affected = Number(updateResult?.affectedRows ?? updateResult?.[0]?.affectedRows ?? 0);
      if (affected !== 1) {
        await conn.rollback();
        req.log.info(
          { gate: 'self_promote_affected', outcome: 'fail', affected },
          'recovery promote gate failed'
        );
        return sendGateFail(res);
      }

      // In-transaction audit row. This survives together with the role
      // change; if the INSERT fails, the whole promotion rolls back.
      await conn.query(
        `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (event_type, user_id, metadata)
         VALUES (?, ?, ?)`,
        [
          'first_admin_promoted_via_recovery_key',
          req.user.id,
          JSON.stringify({
            active_mode: activeMode,
            target_column: target.col,
            email: req.user.email,
          }),
        ]
      );

      await conn.commit();

      // Tamper-evident warn outside the transaction. Captures the
      // promotion even if the new admin later deletes the audit row.
      req.log.warn(
        {
          event: 'first_admin_promoted_via_recovery_key',
          user_id: req.user.id,
          email: req.user.email,
          active_mode: activeMode,
          target_column: target.col,
        },
        'admin recovery promotion committed'
      );

      res.setHeader('Cache-Control', 'no-store');
      return res.json(apiOk({ promoted: true, active_mode: activeMode }));
    } catch (err) {
      if (conn) {
        try { await conn.rollback(); } catch (rbErr) {
          req.log.warn({ err: rbErr }, 'rollback failed on promote-first-admin');
        }
      }
      req.log.error({ err }, 'promote-first-admin transaction failed');
      // Return the same uniform 403 on any backend error so attackers
      // can't distinguish DB-fault from gate-fail via status code.
      return sendGateFail(res);
    } finally {
      if (conn) conn.release();
    }
  });
};
