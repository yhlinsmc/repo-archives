/**
 * POST /api/setup/seed — Security-critical seed data import.
 *
 * Accepts raw SQL or a server-side file path, enforces an INSERT/REPLACE
 * allowlist, rejects MySQL conditional-comment smuggling, replaces
 * __PREFIX__ with the configured table prefix, and executes within a
 * single transaction that rolls back on the first failed statement.
 *
 * Defence-in-depth layers (all must hold):
 *   1. Auth: allowed during first-run (no users) OR admin-authenticated.
 *   2. Input source: either { sql } or { path | useServerPath }, never both.
 *   3. Path traversal: file path must resolve under docker-api/ or the
 *      project root or /workspace (DevContainer workspace mount).
 *   4. Size cap: 10 MiB.
 *   5. Conditional comments: /\*! is rejected because MariaDB would
 *      still execute the contents even though the allowlist only inspects
 *      visible statements.
 *   6. Statement allowlist: INSERT (with optional IGNORE) and REPLACE
 *      INTO are the only keywords accepted. Any other statement fails
 *      the whole batch before a single query runs.
 *   7. Transactional execution: beginTransaction → loop → commit on
 *      success, rollback on first failure.
 *
 * If any layer changes, update e2e/setup-api.spec.ts test [10/10] so the
 * PR 3a safety net catches a regression.
 */
const { pool, t, getDbConfig } = require('../../../db');
const { sendError } = require('../../../../shared/lib/send-error');
const { apiOk, apiError, uuidv4 } = require('../../../../shared/helpers');
const { splitSqlStatements } = require('../../../../sql-utils');
const { requirePrefix } = require('../../../../shared/lib/db-errors');
const { logger: rootLogger } = require('../../../../shared/lib/logger');

const { TABLES } = require('../../../../shared/constants');
const logger = rootLogger.child({ module: 'setup-seed-data' });

module.exports = function register(router) {
  router.post('/seed', async (req, res) => {
    // Auth check: allow during first-run or require admin.
    let conn;
    try {
      conn = await pool.rw.getConnection();
      const rows = await conn.query(`SELECT COUNT(*) AS cnt FROM \`${t(TABLES.USERS)}\``);
      const count = Number(rows[0].cnt);
      if (count > 0 && (!req.user || req.user.role !== 'admin')) {
        return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Admin required' });
      }
    } catch (err) {
      const isTableMissing = err && (err.code === 'ER_NO_SUCH_TABLE' || err.errno === 1146);
      if (!isTableMissing) {
        req.log.warn({ err }, 'setup seed — user table probe failed (non-table-missing); proceeding as first-run');
      }
    } finally {
      if (conn) conn.release();
    }

    let sqlContent = '';

    if (req.body?.sql) {
      sqlContent = req.body.sql;
    } else if (req.body?.useServerPath || req.body?.path) {
      const fs = require('fs');
      const path = require('path');
      // useServerPath reads from SEED_SQL_PATH env var (path never exposed to client)
      const rawPath = req.body.useServerPath ? process.env.SEED_SQL_PATH : req.body.path;
      if (!rawPath) {
        return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'SEED_SQL_PATH environment variable is not configured' });
      }
      const filePath = path.resolve(rawPath);
      // Basic path traversal protection.
      // __dirname is now .../edge/routes/platform/setup/ — one level deeper
      // than the old setup.js location, so the '..' counts must increase
      // by one to reach docker-api/ and the project root.
      const allowedDirs = [
        path.resolve(__dirname, '..', '..', '..', '..', '..'),       // docker-api/
        path.resolve(__dirname, '..', '..', '..', '..', '..', '..'), // project root
        '/workspace',                                                 // DevContainer workspace
      ];
      const isAllowed = allowedDirs.some((dir) =>
        filePath.startsWith(dir + path.sep) || filePath === dir,
      );
      if (!isAllowed) {
        return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'Path not allowed. Must be under project directory or /workspace.' });
      }
      try {
        sqlContent = fs.readFileSync(filePath, 'utf-8');
      } catch (err) {
        return sendError(req, res, err, { status: 400, code: 'FILE_ERROR', reason: `Cannot read file: ${err.message}` });
      }
    } else {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'Provide { sql: string } or { path: string }' });
    }

    // Size limit: 10MB
    if (sqlContent.length > 10 * 1024 * 1024) {
      return sendError(req, res, null, { status: 413, code: 'TOO_LARGE', reason: 'SQL content exceeds 10MB limit' });
    }

    // Allowlist: only INSERT and REPLACE INTO are permitted in seed SQL.
    // SET NAMES is already filtered by splitSqlStatements.
    const allowedPattern = /^\s*(INSERT\s+(IGNORE\s+)?INTO|REPLACE\s+INTO)\b/i;

    // Replace __PREFIX__ placeholder with actual table prefix (consistent with sync-schema export)
    const config2 = getDbConfig();
    const actualPrefix = requirePrefix(config2?.tablePrefix, 'seed-data:actualPrefix');
    sqlContent = sqlContent.replace(/__PREFIX__/g, actualPrefix);

    // Reject MySQL/MariaDB conditional comments (/*! ... */) before splitting.
    // These are executed by the server but would be stripped by the allowlist check,
    // enabling an attacker to smuggle arbitrary SQL past the INSERT-only allowlist.
    if (/\/\*!/g.test(sqlContent)) {
      return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Seed SQL contains MySQL conditional comments (/*! ... */), which are not permitted.' });
    }

    // SQL-aware split: respects string literals containing semicolons.
    // splitSqlStatements already filters comments, SET NAMES, and transaction wrappers.
    const execStatements = splitSqlStatements(sqlContent);

    // Validate all remaining statements against allowlist.
    // Strip SQL comments before checking — comments may precede INSERT statements.
    const rejected = execStatements.filter((s) => {
      const stripped = s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/--[^\n]*/g, '').trim();
      return stripped && !allowedPattern.test(stripped);
    });
    if (rejected.length > 0) {
      const sample = rejected[0].substring(0, 80);
      return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: `Seed SQL contains disallowed statements. Only INSERT/REPLACE INTO are permitted. First rejected: "${sample}..."` });
    }

    conn = null;
    try {
      conn = await pool.rw.getConnection();
      await conn.beginTransaction();

      let executed = 0;
      let rowsAffected = 0;
      const errors = [];

      for (const stmt of execStatements) {
        try {
          const result = await conn.query(stmt);
          executed++;
          if (result?.affectedRows) rowsAffected += Number(result.affectedRows);
        } catch (err) {
          errors.push(`Statement ${executed + 1}: ${err.message.substring(0, 200)}`);
          // Rollback on first error
          await conn.rollback();
          // Cross-version import into a schema-behind target: the dump
          // references a column (1054) or table (1146) the target lacks. This
          // is operator schema-drift, not a malformed seed — return an
          // actionable 422 instead of an opaque 500. db_message names the
          // identifier (admin-only / first-run path, so not a leak). Any other
          // errno keeps the existing 500 SEED_ERROR.
          if (err && (err.errno === 1054 || err.errno === 1146)) {
            const dbMessage = String(err.message).substring(0, 200);
            // Fold db_message into the message itself, not only details: the
            // first-run Setup wizard renders error.message and discards
            // error.details, so the identifier must live in the message to stay
            // actionable. Admin-only / first-run path, so echoing it is safe.
            return sendError(req, res, err, { status: 422, code: 'SEED_SCHEMA_MISMATCH', reason: `Seed failed at statement ${executed + 1}: target schema is missing a referenced ${err.errno === 1054 ? 'column' : 'table'} — ${dbMessage}`, details: {
                  errno: err.errno,
                  statement_index: executed + 1,
                  db_message: dbMessage,
                }, hint: 'Run the target database migration (or align the schema/prefix) before importing, then re-run the seed.' });
          }
          return sendError(req, res, err, { status: 500, code: 'SEED_ERROR', reason: `Seed failed at statement ${executed + 1}: ${err.message}` });
        }
      }

      // SAFETY: cross-env seed dumps typically embed `owner_id` UUIDs that
      // belong to the *source* env's users table. Without remapping, every
      // imported template lands as an orphan (owner_id NOT IN this env's
      // users). Stamp them to the importer atomically inside the seed
      // transaction so a successful seed implies coherent ownership.
      // owner_id IS NULL is preserved — "unowned" is a valid by-design state.
      // NOTE: scope is "all orphans in user_templates", not "only rows
      // inserted this batch". Pre-existing orphans on re-run get
      // re-stamped to the current importer — surfaced explicitly in the
      // audit row via the `scope` field so post-hoc reconstruction is
      // unambiguous.
      let ownerRemapped = 0;
      const importerId = req.user?.id ?? null;
      if (!importerId) {
        req.log.info('seed import owner remap skipped — anonymous (no req.user.id)');
      } else {
        const tmplTable = t(TABLES.USER_TEMPLATES);
        const usersTable = t(TABLES.USERS);
        try {
          const colProbe = await conn.query(
            `SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
              WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME = ?
                AND COLUMN_NAME = 'owner_id'
              LIMIT 1`,
            [tmplTable],
          );
          if (colProbe.length === 0) {
            // INVARIANT: operator-mode without ALTER may skip the owner_id
            // ADD COLUMN migration. Skip the remap rather than crashing the
            // seed — schema_status already surfaces the drift elsewhere.
            req.log.warn({ table: tmplTable }, 'seed import owner remap skipped — owner_id column missing (operator-mode drift)');
          } else {
            const remapResult = await conn.query(
              `UPDATE \`${tmplTable}\`
                  SET owner_id = ?
                WHERE owner_id IS NOT NULL
                  AND owner_id NOT IN (SELECT id FROM \`${usersTable}\`)`,
              [importerId],
            );
            ownerRemapped = Number(remapResult?.affectedRows ?? 0);
            if (ownerRemapped > 0) {
              await conn.query(
                `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata)
                 VALUES (?, ?, ?, ?)`,
                [
                  uuidv4(),
                  'seed_import.owner_stamp',
                  importerId,
                  JSON.stringify({
                    table: tmplTable,
                    remapped_count: ownerRemapped,
                    scope: 'all_orphans',
                  }),
                ],
              );
            }
            req.log.info({ ownerRemapped, importerId, table: tmplTable }, 'seed import owner remap complete');
          }
        } catch (remapErr) {
          // SAFETY: ER_NO_SUCH_TABLE (1146) on `fmb_users` or
          // `fmb_user_templates` itself must NOT crash an otherwise-successful
          // seed import. The colProbe handles missing column, but the NOT IN
          // subquery still references `fmb_users` directly — guard the whole
          // remap block. Other errnos rethrow to the outer catch so partial
          // inserts with orphaned ownership cannot ship.
          if (remapErr && (remapErr.code === 'ER_NO_SUCH_TABLE' || remapErr.errno === 1146)) {
            ownerRemapped = 0;
            req.log.warn({ err: remapErr, table: tmplTable }, 'seed import owner remap skipped — referenced table missing (degraded schema)');
          } else {
            throw remapErr;
          }
        }
      }

      await conn.commit();
      res.json(apiOk({
        statements_executed: executed,
        rows_affected: rowsAffected,
        owner_remapped: ownerRemapped,
        errors,
      }));
    } catch (err) {
      if (conn) try { await conn.rollback(); } catch {}
      sendError(req, res, err, { status: 500, code: 'SEED_ERROR', reason: err.message });
    } finally {
      if (conn) conn.release();
    }
  });
};
