/**
 * recovery-status.js — GET /api/setup/recovery-status
 *
 * Authenticated probe to decide whether the Setup Wizard should show the
 * admin-recovery step. Returns `true` when, under the currently active auth
 * mode, zero users exist who can log in as admin — i.e. the tenant is locked
 * out of admin access via this mode.
 *
 * Why authenticated (401 if no session):
 *   The lockout state is a sensitive signal — an attacker who knew the
 *   tenant was mid-recovery could time attacks or probe for a stale
 *   SETTINGS_ENCRYPTION_KEY. Gate it behind an authenticated session so
 *   only a logged-in user (via whichever mode is currently active) can
 *   see the flag. The SSO user is the expected caller: they can log in
 *   (JIT-provisioned as role=user) but can't do anything useful until
 *   promoted, so they are the right actor to see this signal.
 *
 * Cache posture:
 *   Per-route `Cache-Control: no-store` so the 200 response (with the
 *   sensitive boolean) is never cached by intermediaries. Must be set
 *   per-route rather than app-wide (plan #4: avoid `app.disable('etag')`
 *   leaking into other handlers).
 */
'use strict';

const { pool, t, isPoolReady } = require('../../../db');
const { apiOk, apiError } = require('../../../../shared/helpers');
const { resolveAuthModeAsync } = require('../../../../shared/config');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { TABLES } = require('../../../../shared/constants');

const logger = rootLogger.child({ module: 'setup:recovery-status' });

module.exports = function register(router) {
  router.get('/recovery-status', async (req, res) => {
    // 401 if not authenticated — never a public beacon.
    if (!req.user || !req.user.id) {
      const err = apiError('Authentication required', 'UNAUTHENTICATED', 401);
      res.setHeader('Cache-Control', 'no-store');
      // lint-allow: logger-discipline two-step consumes a helper-built apiError-shaped result, not a direct apiError call at this site
      return res.status(err.status).json(err.body);
    }

    res.setHeader('Cache-Control', 'no-store');

    if (!isPoolReady()) {
      // DB not ready — can't compute. Treat as "no recovery needed" so
      // the UI doesn't flash the step during pool-init races.
      return res.json(apiOk({ mode_reachable_admin_exists: true }));
    }

    // NOTE: resolveAuthModeAsync opens its own pool.ro connection. Resolve
    // mode first, then acquire rw just for the COUNT, so the rw conn isn't
    // held idle during the ro round-trip. Hoist `mode` out of the try block
    // so the catch's logger.warn can reference it without a ReferenceError.
    let mode;
    let conn;
    try {
      // NOTE: Read mode from DB per request (not in-memory cache) — edge
      // never boots the OIDC middleware that populates the cache, so sync
      // resolveAuthMode() on edge returns stale default 'local'.
      mode = await resolveAuthModeAsync(pool, t);

      // Recovery-status precedes a write-destructive admin promote flow —
      // pool.rw keeps the guard read source-of-truth.
      conn = await pool.rw.getConnection();

      // Mode-reachability predicate: admins able to authenticate under
      // the currently active mode. keycloak mode requires keycloak_sub;
      // local mode requires password_hash.
      const modeClause = mode === 'keycloak'
        ? 'keycloak_sub IS NOT NULL'
        : 'password_hash IS NOT NULL';
      const rows = await conn.query(
        `SELECT COUNT(*) AS cnt FROM \`${t(TABLES.USERS)}\`
          WHERE role = 'admin' AND banned = 0 AND ${modeClause}`
      );
      const count = Number(rows[0]?.cnt || 0);
      return res.json(apiOk({ mode_reachable_admin_exists: count > 0 }));
    } catch (err) {
      req.log.warn({ err, mode }, 'recovery-status probe failed');
      // Fail-safe: pretend an admin is reachable so the UI doesn't offer
      // the recovery path on an unknown state.
      return res.json(apiOk({ mode_reachable_admin_exists: true }));
    } finally {
      if (conn) conn.release();
    }
  });
};
