/**
 * DbConnect wizard step — handlers that the first-run DbConnect screen
 * drives through:
 *
 *   POST /api/setup/test-db      — validate a set of DB credentials
 *   POST /api/setup/configure-db — persist credentials and open the pool
 *   GET  /api/setup/db-status    — read-only pool state for the UI
 */
const mariadb = require('mariadb');
const { sendError } = require('../../../../shared/lib/send-error');
const { isPoolReady, getDbConfig, getDbConfigFull, configurePool, saveConfig, setConfigSource, pool, t } = require('../../../db');
const { apiOk, apiError, uuidv4 } = require('../../../../shared/helpers');
const { resolvePassword, DecryptError } = require('../../../../shared/lib/decrypt-password');
const { PreflightError } = require('../../../../shared/lib/preflight-grants');
const { TABLES } = require('../../../../shared/constants');
const { hintCodeForCredentialsRole, sanitizeConfigureError } = require('../../../../shared/lib/pool-diagnostic');
// NOTE: log saveConfig fallback as warn so operators see degraded disk-persist status in kubectl logs.
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { markReadOnly } = require('../../../../shared/middleware/route-markers');
const logger = rootLogger.child({ module: 'db-connect' });

// NOTE: Map decrypt-helper error codes to admin-facing UI copy.
// Each entry is (problem, cause, fix) in one sentence per field. The handler
// sends the code + code-specific message so the frontend can render them
// uniformly without string-sniffing.
const DECRYPT_UI_COPY = Object.freeze({
  DECRYPT_KEY_MISSING: 'Server has no SETTINGS_ENCRYPTION_KEY configured — ask an operator to set it in docker-api/.env (dev) or Vault (prod) and restart api-edge.',
  DECRYPT_MALFORMED:   'Password does not look like enc:v1:<iv>:<tag>:<ct>. Regenerate with docker-api/scripts/encrypt-env-value.js or untick the "encrypted" checkbox if pasting plaintext.',
  DECRYPT_AUTH_FAIL:   'Decryption failed — the server\'s SETTINGS_ENCRYPTION_KEY does not match the key used to produce this ciphertext, or the value was tampered. Re-encrypt with the current server key.',
  DECRYPT_LOOKS_ENCRYPTED: 'Password starts with enc:v1: but the "encrypted" checkbox is off. Tick the checkbox, or paste the plaintext instead.',
});

// NOTE: Collapsed response for unauthenticated callers on a pool-ready server.
// Prevents the DECRYPT_KEY_MISSING vs DECRYPT_AUTH_FAIL split from acting as a
// SETTINGS_ENCRYPTION_KEY presence side-channel on endpoints that intentionally
// skip auth (first-run wizard). Admin-authenticated callers still get the
// granular codes; first-run (no pool) callers also get granular codes since the
// server state isn't a secret at that point.
const DECRYPT_FAILED_GENERIC = Object.freeze({
  code: 'DECRYPT_FAILED',
  message: 'Failed to process the encrypted password. An admin can retrieve the detailed reason from the server logs.',
});

function shapeDecryptError(err, req, poolReady, readEndpointPrefix = '') {
  if (!(err instanceof DecryptError)) return null;
  // Pool-ready + non-admin caller → collapse to a single generic code.
  // Pool-ready + admin or !pool-ready → keep granular codes.
  const callerIsAdmin = req.user && req.user.role === 'admin';
  const collapseForLeakGuard = poolReady && !callerIsAdmin;
  if (collapseForLeakGuard) {
    return {
      code: DECRYPT_FAILED_GENERIC.code,
      message: readEndpointPrefix + DECRYPT_FAILED_GENERIC.message,
    };
  }
  return {
    code: err.code,
    message: readEndpointPrefix + (DECRYPT_UI_COPY[err.code] || err.message),
  };
}

// SECURITY: Sanitise MariaDB probe errors before they reach the UI toast.
// The raw `err.message` on auth failure includes the attempted user + source
// host (e.g., "Access denied for user 'appuser_rw'@'10.0.1.14'"), which echoes
// the setup-form input back over the wire. The admin running the wizard would
// see the same info via CLI anyway, but a code-level allowlist keeps the UI
// boundary tight and prevents incidental log / screenshot leaks from exposing
// account usernames.
const PROBE_ERROR_MAP = Object.freeze({
  // MariaDB driver codes (string constants off `err.code`)
  ER_ACCESS_DENIED_ERROR:   'Access denied — check user and password',
  ER_DBACCESS_DENIED_ERROR: 'Access denied to database — check grants',
  ER_BAD_DB_ERROR:          'Database not found',
  ER_HOST_NOT_PRIVILEGED:   'Host not allowed to connect (MariaDB user@host ACL)',
  ER_HOST_IS_BLOCKED:       'Host is blocked (exceeded max_connect_errors — run FLUSH HOSTS)',
  // libuv / OS-level codes (also off `err.code`)
  ECONNREFUSED:             'Connection refused — nothing listening on host:port',
  EHOSTUNREACH:             'Host unreachable — routing or firewall blocks traffic',
  ENETUNREACH:              'Network unreachable — no route to host',
  ENOTFOUND:                'Host not found',
  EAI_AGAIN:                'Host DNS lookup temporarily failed',
  ETIMEDOUT:                'Connection timed out',
  ETIMEOUT:                 'Connection timed out',
});

function sanitiseProbeError(err) {
  // MariaDB + libuv surface errors on `err.code` (string). `err.errno` is
  // typically numeric on this path and will never hit the string-keyed map,
  // but we accept it as an opaque fallback for error shapes we haven't
  // catalogued yet.
  const code = err && (err.code || err.errno);
  if (typeof code === 'string' && PROBE_ERROR_MAP[code]) {
    return { message: PROBE_ERROR_MAP[code], code };
  }
  // Unknown code: return the code (safe, no user data) but drop the message
  // (which may include user/host echo). Keep an opaque message for the UI.
  if (code) {
    return { message: 'Connection failed', code: String(code) };
  }
  return { message: 'Connection failed', code: 'UNKNOWN' };
}

function buildConfigSwapAuditMetadata({ status, connectionName, diskPersisted, errorCode }) {
  // SECURITY: keep connection endpoints and credentials out of feature_audit.
  return {
    connectionName: connectionName || null,
    status,
    diskPersisted: Boolean(diskPersisted),
    errorCode: errorCode || null,
  };
}

let cachedDbStatus = null;
let cachedDbStatusAt = 0;

function readDbStatusCacheTtlMs() {
  const raw = process.env.DB_STATUS_CACHE_TTL_MS;
  if (raw === undefined || raw === '') return 300;
  const n = Number(raw);
  return Number.isFinite(n) && n >= 0 ? n : 300;
}

function invalidateDbStatusCache() {
  cachedDbStatus = null;
  cachedDbStatusAt = 0;
}

function computeDbStatusBody() {
  if (isPoolReady()) {
    const config = getDbConfig();
    return apiOk({
      configured: true,
      source: config?.source || 'file',
      host: config?.host,
      port: config?.port,
      user: config?.user,
      database: config?.database,
      tablePrefix: config?.tablePrefix,
    });
  }
  return apiOk({ configured: false, source: 'none' });
}

async function auditConfigSwap(req, metadata) {
  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.query(
      `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata)
       VALUES (?, 'db.config_swap', ?, ?)`,
      [
        uuidv4(),
        req.user?.id || null,
        JSON.stringify(metadata),
      ],
    );
  } catch (auditErr) {
    req.log.warn({ err: auditErr }, 'db config swap audit skipped');
  } finally {
    if (conn) conn.release();
  }
}

module.exports = function register(router) {
  /**
   * POST /api/setup/test-db — probe writer and (optionally) reader creds.
   *
   * Body (backward compatible):
   *   { host, port?, user, password?, database?, readConfig? }
   *   readConfig: { host, port?, user?, password?, database? }
   *
   * Response:
   *   { success: boolean, message: string,              // mirrors writer for old clients
   *     writer: { success, message },
   *     reader: { success, message } | null }           // null when no readConfig
   *
   * The old contract (`{success, message}` top-level) is preserved so
   * older callers keep working.
   */
  router.post('/test-db', markReadOnly, async (req, res) => {
    const {
      host, port, user, password, database, readConfig,
      passwordIsEncrypted,
    } = req.body || {};

    if (!host || !user) {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'host and user are required' });
    }

    // NOTE: Resolve encrypted password before probing. If the helper
    // throws, we short-circuit to a 400 with a code the UI knows how to
    // render — we never pass enc:v1:... through as a MariaDB password.
    const poolReady = isPoolReady();
    let resolvedPassword;
    try {
      resolvedPassword = resolvePassword(password, !!passwordIsEncrypted);
    } catch (err) {
      const shaped = shapeDecryptError(err, req, poolReady);
      if (shaped) {
        return sendError(req, res, err, { status: 400, code: shaped.code, reason: shaped.message });
      }
      throw err;
    }

    let resolvedReadPassword;
    if (readConfig && typeof readConfig === 'object' && readConfig.host) {
      try {
        resolvedReadPassword = resolvePassword(
          readConfig.password != null ? readConfig.password : password,
          // Reader can opt in independently; falls back to writer's flag
          // when the caller omits readConfig.passwordIsEncrypted to keep
          // the common "same creds on both endpoints" case simple.
          readConfig.passwordIsEncrypted != null
            ? !!readConfig.passwordIsEncrypted
            : !!passwordIsEncrypted,
        );
      } catch (err) {
        const shaped = shapeDecryptError(err, req, poolReady, 'Read endpoint: ');
        if (shaped) {
          return sendError(req, res, err, { status: 400, code: shaped.code, reason: shaped.message });
        }
        throw err;
      }
    }

    async function probe(cfg, role) {
      // SECURITY: Strip user:pass@ prefix from the logged host so an admin
      // paste of a JDBC-style URL does not bleed the password into ArgoCD
      // logs. The redact pattern keeps the host visible (operations need it)
      // without leaking credentials.
      const safeHost = typeof cfg.host === 'string'
        ? cfg.host.replace(/^[^@\s]+@/, '<redacted>@')
        : cfg.host;
      const logBase = {
        host: safeHost,
        port: cfg.port,
        user: cfg.user,
        db: cfg.database || null,
      };
      req.log.info(logBase, 'setup probe starting');
      const t0 = Date.now();
      let pool;
      try {
        pool = mariadb.createPool({
          host: cfg.host,
          port: parseInt(cfg.port || '3306', 10),
          user: cfg.user,
          password: cfg.password || '',
          database: cfg.database || undefined,
          connectionLimit: 1,
          connectTimeout: 5000,
        });
        const conn = await pool.getConnection();
        conn.release();
        req.log.info({ ...logBase, durationMs: Date.now() - t0 }, 'setup probe ok');
        return { success: true, message: 'Connection successful', hint_code: null };
      } catch (err) {
        const sanitised = sanitiseProbeError(err);
        // Role-aware hint code lets the UI render a credential-specific
        // 3-zone hint card: 'bootstrap' creds map to grants_insufficient_ddl,
        // 'runtime' creds map to grants_insufficient_dml.
        const sanitisedForHint = sanitizeConfigureError(err);
        const hint_code = hintCodeForCredentialsRole(sanitisedForHint, role);
        req.log.warn(
          {
            ...logBase,
            code: err && err.code,
            errno: err && err.errno,
            sanitisedCode: sanitised.code,
            hint_code,
            durationMs: Date.now() - t0,
          },
          'setup probe failed',
        );
        return { success: false, message: sanitised.message, code: sanitised.code, hint_code };
      } finally {
        if (pool) {
          try { await pool.end(); } catch { /* ignore close races */ }
        }
      }
    }

    const writer = await probe({ host, port, user, password: resolvedPassword, database }, 'bootstrap');

    let reader = null;
    if (readConfig && typeof readConfig === 'object' && readConfig.host) {
      // Fall back to writer creds when the readConfig omits user / password
      // (mirrors db.js configurePool) so the UI doesn't force the DBA to
      // re-type the same secret when the reader is just a different host.
      reader = await probe({
        host: readConfig.host,
        port: readConfig.port,
        user: readConfig.user || user,
        password: resolvedReadPassword != null ? resolvedReadPassword : resolvedPassword,
        database: readConfig.database || database,
      }, 'runtime');
    }

    res.json(apiOk({
      // NOTE: Old top-level shape mirrors writer so older callers still
      // render {success, message} without changes.
      success: writer.success,
      message: writer.message,
      writer,
      reader,
    }));
  });

  router.get('/db-status', (_req, res) => {
    const ttl = readDbStatusCacheTtlMs();
    // INVARIANT: TTL=0 disables the cache entirely so an operator can
    // turn it off without redeploying when production reality contradicts
    // the autoplan default.
    if (ttl > 0 && cachedDbStatus && Date.now() - cachedDbStatusAt < ttl) {
      return res.json(cachedDbStatus);
    }
    const fresh = computeDbStatusBody();
    if (ttl > 0) {
      cachedDbStatus = fresh;
      cachedDbStatusAt = Date.now();
    }
    res.json(fresh);
  });

  router.post('/configure-db', async (req, res) => {
    // If pool is already configured, require admin auth to reconfigure
    if (isPoolReady()) {
      if (!req.user || req.user.role !== 'admin') {
        return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Admin required to reconfigure database' });
      }
    }

    const { host, port, user, password, database, tablePrefix, passwordIsEncrypted, persist } = req.body;

    if (!host || !user || !database) {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'host, user, and database are required' });
    }

    // SECURITY: Identifier allowlist on database matches /create-schema
    // (schema-init.js). Without it, a crafted database value would be
    // interpolated verbatim into the grantSqlHint stderr/log line — log
    // injection. Parallel defence-in-depth exists inside buildGrantSqlHint;
    // this gate stops it at the HTTP boundary so the error path never enters
    // the hint builder with a tainted value.
    if (!/^[a-zA-Z0-9_]+$/.test(database)) {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'database must match [a-zA-Z0-9_]+' });
    }

    // SECURITY: Same allowlist on tablePrefix. Without it, a value containing
    // newlines or ANSI escape sequences would be interpolated into the stderr
    // ERROR/CAUSE/FIX banner emitted by preflight, letting an admin-authored
    // tablePrefix spoof adjacent log lines. Admin-only + ops-log-only, but
    // the allowlist costs nothing and keeps the log surface trustworthy.
    //
    // NOTE: tablePrefix is REQUIRED, non-empty, and must match the regex.
    // The previous "optional + only validate when provided" let the silent
    // default sneak through whenever the wizard form omitted it. See LEARN.md §63.
    if (typeof tablePrefix !== 'string' || tablePrefix === '') {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'tablePrefix is required and must be a non-empty string (e.g., "example_app_")' });
    }
    if (!/^[a-zA-Z0-9_]+$/.test(tablePrefix)) {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'tablePrefix must match [a-zA-Z0-9_]+' });
    }
    // NOTE: Reject overlap where prefix equals the schema name. A prefix
    // matching the schema would build table names without a separator
    // underscore — almost certainly an operator typo.
    if (tablePrefix === database) {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: `tablePrefix '${tablePrefix}' must not equal the schema name. Did you mean '${tablePrefix}_'?` });
    }

    // SECURITY: the submitted password may arrive as enc:v1 transport ciphertext;
    // resolve it to the live plaintext for the in-memory pool. configure-db
    // requires admin auth when the pool is ready (checked above), so the
    // side-channel-guard is not needed here — admin callers get the granular
    // error codes. At-rest encryption of the persisted file is handled by
    // saveConfig (encryptConfigSecrets), not here.
    let resolvedPassword;
    try {
      resolvedPassword = resolvePassword(password, !!passwordIsEncrypted);
    } catch (err) {
      if (err instanceof DecryptError) {
        return sendError(req, res, err, { status: 400, code: err.code, reason: DECRYPT_UI_COPY[err.code] || err.message });
      }
      throw err;
    }

    // NOTE: When reconfiguring an already-ready pool and the caller submits
    // a blank password, preserve the currently persisted password instead of
    // overwriting it with ''. The Change Server UI advertises "leave password
    // blank to keep the existing one" — this implements that contract. Without
    // it, an admin following the UI guidance would silently blank the persisted
    // password, breaking the next boot when configurePool reads the file.
    let effectivePassword = resolvedPassword || '';
    if (!effectivePassword && isPoolReady()) {
      // getDbConfig() omits password by design (UI-safe); use
      // getDbConfigFull() for the in-memory live value.
      const current = getDbConfigFull();
      if (current && typeof current.password === 'string' && current.password !== '') {
        effectivePassword = current.password;
      }
    }

    const config = {
      host,
      port: parseInt(port || '3306'),
      user,
      password: effectivePassword,
      database,
      tablePrefix,
    };

    try {
      // Test connection first
      await configurePool(config);
      // INVARIANT: any DB-state mutation invalidates the db-status cache so
      // the next poll observes the fresh config rather than a stale entry.
      invalidateDbStatusCache();

      // NOTE: persistence is opt-in. The default (persist falsy) keeps the new
      // config in memory only — a temporary admin-account switch that reverts
      // on restart, with no filesystem write and therefore no misleading EROFS
      // warning. When the operator opts in, saveConfig writes an encrypted file;
      // a write failure (read-only rootfs / missing key) is reported honestly
      // via diskPersisted rather than as a 500.
      let diskPersisted = false;
      let persistFailed = false;
      if (persist === true) {
        try {
          saveConfig(config, { persist: true });
          diskPersisted = true;
        } catch (err) {
          persistFailed = true;
          invalidateDbStatusCache();
          // Pass raw err so pino's built-in err serializer captures the stack.
          req.log.warn(
            { err, code: err.code },
            'saveConfig failed (read-only fs / permission / missing encryption key) — pool reconfigured in memory only',
          );
        }
      }

      // Reflect the true config origin on the visibility surface: a persisted
      // swap is 'file' (saveConfig already set it); a default/ephemeral or
      // persist-failed swap is live-but-not-on-disk → 'memory'. configurePool
      // ran before the persist outcome was known, so the source is set here.
      setConfigSource(diskPersisted ? 'file' : 'memory');

      // NOTE: the swap itself succeeded (configurePool above). diskPersisted
      // only reflects whether an opted-in file write landed; a default
      // (non-persisted) temporary switch is a success, not a disk failure.
      await auditConfigSwap(req, buildConfigSwapAuditMetadata({
        status: 'success',
        connectionName: database,
        diskPersisted,
        errorCode: persistFailed ? 'DISK_PERSIST_FAILED' : null,
      }));

      res.json(apiOk({
        message: 'Database configured successfully',
        host: config.host,
        port: config.port,
        database: config.database,
        tablePrefix: config.tablePrefix,
        diskPersisted,
      }));
    } catch (err) {
      invalidateDbStatusCache();
      await auditConfigSwap(req, buildConfigSwapAuditMetadata({
        status: 'fail',
        connectionName: database,
        diskPersisted: false,
        errorCode: err?.code || 'DB_CONFIG_ERROR',
      }));

      // NOTE: PreflightError must NOT go through sanitiseProbeError (which
      // keys off driver codes like ER_ACCESS_DENIED_ERROR). Return a safe
      // summary to the HTTP body — the detailed grantSqlHint is already on
      // stderr/pod logs where the DBA can read it, and we don't want it in
      // the JSON body in case a future /configure-db change weakens the
      // admin gate.
      if (err instanceof PreflightError) {
        // PreflightError is the dominant DDL-grant-insufficient path on
        // configure-db. Surface grants_insufficient_ddl so the wizard can
        // render the bootstrap-credential-specific hint card instead of
        // the generic "see server logs" message.
        return sendError(req, res, err, { status: // PREFLIGHT_MISSING_PRIVILEGES | PREFLIGHT_GRANTS_UNAVAILABLE
          400, code: err.code, reason: 'DB service account lacks required privileges. See server logs for the GRANT hint.', details: { hint_code: 'grants_insufficient_ddl' } });
      }
      // Same sanitiser as /test-db — `configurePool` wraps the mariadb
      // connection attempt which raises the same user@host / secret-leaking
      // messages on auth failure.
      const sanitised = sanitiseProbeError(err);
      const sanitisedForHint = sanitizeConfigureError(err);
      const hint_code = hintCodeForCredentialsRole(sanitisedForHint, 'bootstrap');
      sendError(req, res, err, { status: 500, code: 'DB_CONFIG_ERROR', reason: `Failed to configure database: ${sanitised.message}`, details: { code: sanitised.code, hint_code } });
    }
  });
};

// Expose the sanitiser + map for unit testing. Production code routes the
// helper through `probe()` inside the /test-db handler above.
module.exports.sanitiseProbeError = sanitiseProbeError;
module.exports.PROBE_ERROR_MAP = PROBE_ERROR_MAP;
module.exports.DECRYPT_UI_COPY = DECRYPT_UI_COPY;
module.exports.DECRYPT_FAILED_GENERIC = DECRYPT_FAILED_GENERIC;
module.exports.shapeDecryptError = shapeDecryptError;
module.exports.buildConfigSwapAuditMetadata = buildConfigSwapAuditMetadata;
module.exports.invalidateDbStatusCache = invalidateDbStatusCache;
module.exports.readDbStatusCacheTtlMs = readDbStatusCacheTtlMs;
module.exports.computeDbStatusBody = computeDbStatusBody;
