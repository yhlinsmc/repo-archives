/**
 * Infra-table administrative operations:
 *
 *   GET  /api/setup/table-status   — row counts per infrastructure table
 *   POST /api/setup/truncate-table — clear all rows (admin only)
 *   POST /api/setup/drop-table     — drop table (admin only)
 *
 * All three endpoints are admin-gated and restrict the `table` parameter
 * to the `INFRA_TABLE_NAMES` allowlist so callers cannot target the
 * engine schema or arbitrary databases through these endpoints.
 */
const { pool, t, isPoolReady, getDbConfig } = require('../../../db');
const { sendError } = require('../../../../shared/lib/send-error');
const { INFRA_TABLE_NAMES, INFRA_TRUNCATE_DENYLIST } = require('../../../../table-ddls');
const { apiOk, apiError } = require('../../../../shared/helpers');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { parseGrantRows, hasPrivilegeOn } = require('../../../../shared/lib/parse-grants');
const {
  safeInsertAudit,
  truncateOrDeleteWithFallback,
  failAuditMeta,
  INFRA_FALLBACK_ERRNOS,
} = require('../../../lib/clear-table');
const logger = rootLogger.child({ module: 'setup:tables' });

module.exports = function register(router) {
  router.get('/table-status', async (req, res) => {
    if (!req.user || req.user.role !== 'admin') {
      return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Admin required' });
    }
    if (!isPoolReady()) {
      return sendError(req, res, null, { code: 'POOL_NOT_READY', reason: 'Database pool not ready' });
    }

    let conn;
    try {
      // Pure diagnostic COUNT(*) — no downstream writes on same conn → pool.ro.
      conn = await pool.ro.getConnection();
      const tables = {};
      for (const name of INFRA_TABLE_NAMES) {
        try {
          const rows = await conn.query(`SELECT COUNT(*) AS cnt FROM \`${t(name)}\``);
          tables[name] = Number(rows[0]?.cnt ?? 0);
        } catch {
          tables[name] = -1; // table missing
        }
      }
      res.json(apiOk({ tables }));
    } catch (err) {
      sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed' });
    } finally {
      if (conn) conn.release();
    }
  });

  router.post('/truncate-table', async (req, res) => {
    if (!req.user || req.user.role !== 'admin') {
      return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Admin required' });
    }
    const { table } = req.body;
    if (!table || !INFRA_TABLE_NAMES.includes(table)) {
      // SECURITY: do not echo the allowlist in the 400 message — admin-only
      // surface, but no need to disclose the full infra table inventory to
      // a probing or compromised session. UI already renders the list.
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'Invalid table name' });
    }
    if (INFRA_TRUNCATE_DENYLIST.includes(table)) {
      // SECURITY: certain infra tables (notably `feature_audit`) must not
      // be truncatable via this endpoint. Admin who could wipe the audit
      // log itself would be able to erase the trail of their own actions
      // including the wipe. DBA path: direct MariaDB CLI for retention.
      return sendError(req, res, null, { status: 403, code: 'TABLE_NOT_CLEARABLE', reason: `Table "${table}" cannot be cleared via this endpoint. Contact your DBA for direct MariaDB access.` });
    }
    if (!isPoolReady()) {
      return sendError(req, res, null, { code: 'POOL_NOT_READY', reason: 'Database pool not ready' });
    }

    const userId = req.user?.id || null;
    const auditMeta = { table_class: 'infra', table };

    let conn;
    try {
      conn = await pool.rw.getConnection();

      // INVARIANT: attempt audit fires before any DB write so that an admin
      // dashboard can distinguish "we tried but were rejected" from "we never
      // tried" even when the DDL itself fails before terminal audit lands.
      await safeInsertAudit(conn, {
        eventType: 'data_clear.attempt',
        userId,
        metadata: auditMeta,
      }, logger);

      const result = await truncateOrDeleteWithFallback(conn, {
        physicalTable: t(table),
        logicalTable: table,
        tableClass: 'infra',
        errnoSet: INFRA_FALLBACK_ERRNOS,
        userId,
        logger,
      });

      if (result.method === 'TRUNCATE') {
        return res.json(apiOk({ table, action: 'cleared', method: 'TRUNCATE' }));
      }
      // INVARIANT: infra tables carry no FK declarations, so only
      // privilege-denied (errno 1142/1227) triggers fallback. The note
      // is unconditional; engine route distinguishes 1701 because that
      // errno IS reachable on engine tables.
      return res.json(apiOk({
        table,
        action: 'cleared',
        method: 'DELETE',
        note: 'AUTO_INCREMENT not reset — operator-mode (no TRUNCATE privilege)',
      }));
    } catch (err) {
      if (conn) {
        await safeInsertAudit(conn, {
          eventType: 'data_clear.fail',
          userId,
          metadata: { ...auditMeta, ...failAuditMeta(err) },
        }, logger);
      }
      return sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { table } });
    } finally {
      if (conn) conn.release();
    }
  });

  router.post('/drop-table', async (req, res) => {
    if (!req.user || req.user.role !== 'admin') {
      return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Admin required' });
    }
    const { table } = req.body;
    if (!table || !INFRA_TABLE_NAMES.includes(table)) {
      // Same allowlist-non-disclosure principle as truncate-table above.
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'Invalid table name' });
    }
    if (INFRA_TRUNCATE_DENYLIST.includes(table)) {
      // SECURITY: same forensic-integrity argument as truncate-table —
      // dropping the audit table destroys all history (recreated empty
      // on next migration). The downstream SHOW GRANTS preflight is
      // explicitly best-effort and falls through to the DDL on probe
      // failure, so the privilege barrier alone is insufficient. Apply
      // the denylist BEFORE the privilege check.
      return sendError(req, res, null, { status: 403, code: 'TABLE_NOT_CLEARABLE', reason: `Table "${table}" cannot be dropped via this endpoint. Contact your DBA for direct MariaDB access.` });
    }
    if (!isPoolReady()) {
      return sendError(req, res, null, { code: 'POOL_NOT_READY', reason: 'Database pool not ready' });
    }

    let conn;
    try {
      conn = await pool.rw.getConnection();

      // NOTE: Verify the session holds DROP on the target schema before
      // attempting the DDL. The UI already disables the Drop button when
      // privileges are missing, but a scripted caller (or UI regression)
      // could still hit this endpoint — surface a structured 403 with grant
      // SQL rather than a raw MariaDB "command denied" error. Pre-flight is
      // best-effort; SHOW GRANTS failure falls back to letting the DDL run.
      const infraConfig = getDbConfig();
      const schema = infraConfig?.database;
      if (schema) {
        try {
          const grantRows = await conn.query('SHOW GRANTS');
          const parsed = parseGrantRows(grantRows);
          if (!hasPrivilegeOn(parsed, 'DROP', schema, t(table))) {
            return sendError(req, res, null, { status: 403, code: 'MISSING_PRIVILEGES', reason: `DROP privilege required on ${schema}.${t(table)}`, // Review HIGH-1 fix: options.details forwards structured
                // extras to the response body (apiError previously dropped
                // unknown keys). FLUSH PRIVILEGES removed from hint —
                // redundant after GRANT and can cause brief privilege-
                // cache desync on Galera.
                details: {
                  missing_privilege: 'DROP',
                  missing: [table],
                  grant_sql: `GRANT DROP ON \`${schema}\`.* TO '${infraConfig.user || '<your_service_user>'}'@'%';`,
                  docs_ref: 'infrastructure/docs/ONPREM_SOP.md#rw-user-provisioning',
                  run_as: 'DBA',
                } });
          }
        } catch (grantsErr) {
          req.log.warn({ err: grantsErr }, 'SHOW GRANTS pre-flight failed; proceeding with DDL attempt');
        }
      }

      await conn.query(`DROP TABLE IF EXISTS \`${t(table)}\``);
      res.json(apiOk({ table, action: 'dropped' }));
    } catch (err) {
      sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { table } });
    } finally {
      if (conn) conn.release();
    }
  });
};
