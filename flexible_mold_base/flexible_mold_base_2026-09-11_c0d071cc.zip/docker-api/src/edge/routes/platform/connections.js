const { TABLES } = require('../../../shared/constants');
const { sendError } = require('../../../shared/lib/send-error');

const router = require('express').Router();
const mariadb = require('mariadb');
const { pool, t, activateConnection } = require('../../db');
const { apiOk, apiError, requireAdmin, uuidv4 } = require('../../../shared/helpers');
const { invalidateDbStatusCache } = require('./setup/db-connect');
const { logger: rootLogger } = require('../../../shared/lib/logger');
const logger = rootLogger.child({ module: 'connections' });

/**
 * NOTE: Enforce both-or-neither on the read-endpoint pair. A profile with
 * `read_host` but no `read_port` (or vice versa) would silently skip RO pool
 * creation in db.js:configurePool, masking the misconfiguration until a code
 * path explicitly referenced `pool.ro`. Reject at the CRUD boundary instead.
 *
 * @returns {string|null} error message, or null when valid
 */
function validateReadEndpointPair(body) {
  const hasHost = body.read_host != null && body.read_host !== '';
  const hasPort = body.read_port != null && body.read_port !== '';
  if (hasHost !== hasPort) {
    return 'read_host and read_port must be set together (both-or-neither). Unset both to route reads through the writer, or set both to configure a dedicated read endpoint.';
  }
  return null;
}

/**
 * @openapi
 * /edge/platform/connections:
 *   get:
 *     summary: List all DB connection profiles
 *     tags: [Platform - DB Connections]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Array of DB connection records
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *   post:
 *     summary: Create a new DB connection profile
 *     tags: [Platform - DB Connections]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [name, host]
 *             properties:
 *               name:
 *                 type: string
 *               db_type:
 *                 type: string
 *                 default: mariadb
 *               host:
 *                 type: string
 *               port:
 *                 type: integer
 *                 default: 3306
 *               database_name:
 *                 type: string
 *               username:
 *                 type: string
 *               encrypted_password:
 *                 type: string
 *               extra_config:
 *                 type: object
 *               is_active:
 *                 type: boolean
 *     responses:
 *       200:
 *         description: Newly created DB connection record
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/platform/connections/test:
 *   post:
 *     summary: Test a DB connection using provided credentials without persisting anything
 *     tags: [Platform - DB Connections]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [host, username]
 *             properties:
 *               host:
 *                 type: string
 *               port:
 *                 type: integer
 *               username:
 *                 type: string
 *               password:
 *                 type: string
 *               database_name:
 *                 type: string
 *     responses:
 *       200:
 *         description: Connection test result with success flag and message
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/platform/connections/deactivate-all:
 *   post:
 *     summary: Mark all DB connection profiles as inactive
 *     tags: [Platform - DB Connections]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: All connections deactivated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/platform/connections/{id}:
 *   get:
 *     summary: Get a single DB connection profile by ID
 *     tags: [Platform - DB Connections]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: DB connection record or null
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *   put:
 *     summary: Update mutable fields of a DB connection profile
 *     tags: [Platform - DB Connections]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               db_type:
 *                 type: string
 *               host:
 *                 type: string
 *               port:
 *                 type: integer
 *               database_name:
 *                 type: string
 *               username:
 *                 type: string
 *               encrypted_password:
 *                 type: string
 *               extra_config:
 *                 type: object
 *               is_active:
 *                 type: boolean
 *     responses:
 *       200:
 *         description: Updated DB connection record
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *   delete:
 *     summary: Delete a DB connection profile by ID
 *     tags: [Platform - DB Connections]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Connection deleted
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/platform/connections/{id}/activate:
 *   post:
 *     summary: Activate a connection profile and reconfigure the infra pool atomically
 *     tags: [Platform - DB Connections]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Activated connection ID returned
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 */

// GET /api/db-connections
router.get('/', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  try {
    const conn = await pool.ro.getConnection();
    try {
      const rows = await conn.query(`SELECT * FROM \`${t(TABLES.DB_CONNECTIONS)}\` ORDER BY created_at DESC`);
      res.json(apiOk(rows));
    } finally {
      conn.release();
    }
  } catch (err) {
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed' });
  }
});

// GET /api/db-connections/:id
router.get('/:id', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  try {
    const conn = await pool.ro.getConnection();
    try {
      const rows = await conn.query(`SELECT * FROM \`${t(TABLES.DB_CONNECTIONS)}\` WHERE id = ?`, [req.params.id]);
      res.json(apiOk(rows[0] || null));
    } finally {
      conn.release();
    }
  } catch (err) {
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { connectionId: req.params.id } });
  }
});

// POST /api/db-connections
router.post('/', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const b = req.body;
  const readPairError = validateReadEndpointPair(b);
  if (readPairError) {
    return sendError(req, res, null, { status: 400, code: 'INVALID_READ_CONFIG', reason: readPairError });
  }
  const id = uuidv4();
  try {
    // INSERT + read-back SELECT on same conn (w→r) → pool.rw to avoid
    // replication-lag read-your-write hazard.
    const conn = await pool.rw.getConnection();
    try {
      await conn.query(
        `INSERT INTO \`${t(TABLES.DB_CONNECTIONS)}\`
           (id, name, db_type, host, port, database_name, username, encrypted_password,
            read_host, read_port, read_username, read_encrypted_password,
            extra_config, is_active, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          id, b.name, b.db_type || 'mariadb', b.host, b.port || 3306,
          b.database_name || '', b.username || '', b.encrypted_password || '',
          b.read_host || null,
          b.read_port != null && b.read_port !== '' ? parseInt(b.read_port, 10) : null,
          b.read_username || null,
          b.read_encrypted_password || null,
          JSON.stringify(b.extra_config || {}),
          b.is_active || false, req.user.id,
        ]
      );
      const rows = await conn.query(`SELECT * FROM \`${t(TABLES.DB_CONNECTIONS)}\` WHERE id = ?`, [id]);
      res.json(apiOk(rows[0]));
    } finally {
      conn.release();
    }
  } catch (err) {
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { connectionId: id, name: b.name } });
  }
});

// PUT /api/db-connections/:id
//
// NOTE: When the body touches the read_host/read_port pair, the pre-check
// + UPDATE must run inside a single transaction with SELECT ... FOR UPDATE.
// Without the row lock, a concurrent PUT could flip the pair between the
// SELECT and UPDATE, letting a one-sided state land despite both requests
// individually passing the both-or-neither guard. The lock serialises
// concurrent edits to the same profile.
router.put('/:id', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const b = req.body;
  // Whitelist mutable columns — prevents updating immutable fields (id, created_at, created_by)
  const ALLOWED_COLS = new Set([
    'name', 'db_type', 'host', 'port', 'database_name',
    'username', 'encrypted_password',
    'read_host', 'read_port', 'read_username', 'read_encrypted_password',
    'extra_config', 'is_active',
  ]);

  const sets = [];
  const vals = [];
  for (const [k, v] of Object.entries(b)) {
    if (!ALLOWED_COLS.has(k)) continue;
    sets.push(`\`${k}\` = ?`);
    if (k === 'extra_config') {
      vals.push(JSON.stringify(v));
    } else if (k === 'read_port') {
      vals.push(v == null || v === '' ? null : parseInt(v, 10));
    } else if (k === 'read_host' || k === 'read_username' || k === 'read_encrypted_password') {
      vals.push(v == null || v === '' ? null : v);
    } else {
      vals.push(v);
    }
  }
  if (!sets.length) return res.json(apiOk(null));
  vals.push(req.params.id);

  const touchesReadPair = 'read_host' in b || 'read_port' in b;

  try {
    const conn = await pool.rw.getConnection();
    try {
      if (touchesReadPair) {
        await conn.beginTransaction();
        try {
          // SELECT ... FOR UPDATE locks the row so a concurrent PUT has
          // to wait until this transaction commits or rolls back.
          const rows = await conn.query(
            `SELECT read_host, read_port FROM \`${t(TABLES.DB_CONNECTIONS)}\` WHERE id = ? FOR UPDATE`,
            [req.params.id],
          );
          const existing = rows[0] || null;
          const effectiveHost = 'read_host' in b ? b.read_host : existing?.read_host;
          const effectivePort = 'read_port' in b ? b.read_port : existing?.read_port;
          const readPairError = validateReadEndpointPair({
            read_host: effectiveHost,
            read_port: effectivePort,
          });
          if (readPairError) {
            await conn.rollback();
            return sendError(req, res, null, { status: 400, code: 'INVALID_READ_CONFIG', reason: readPairError });
          }
          await conn.query(`UPDATE \`${t(TABLES.DB_CONNECTIONS)}\` SET ${sets.join(', ')} WHERE id = ?`, vals);
          const updated = await conn.query(`SELECT * FROM \`${t(TABLES.DB_CONNECTIONS)}\` WHERE id = ?`, [req.params.id]);
          await conn.commit();
          return res.json(apiOk(updated[0]));
        } catch (txErr) {
          try { await conn.rollback(); } catch {}
          throw txErr;
        }
      }
      // Read pair untouched → no need for the stricter locking path.
      await conn.query(`UPDATE \`${t(TABLES.DB_CONNECTIONS)}\` SET ${sets.join(', ')} WHERE id = ?`, vals);
      const updated = await conn.query(`SELECT * FROM \`${t(TABLES.DB_CONNECTIONS)}\` WHERE id = ?`, [req.params.id]);
      return res.json(apiOk(updated[0]));
    } finally {
      conn.release();
    }
  } catch (err) {
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { connectionId: req.params.id } });
  }
});

// DELETE /api/db-connections/:id
router.delete('/:id', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  try {
    const conn = await pool.rw.getConnection();
    try {
      await conn.query(`DELETE FROM \`${t(TABLES.DB_CONNECTIONS)}\` WHERE id = ?`, [req.params.id]);
      res.json(apiOk(null));
    } finally {
      conn.release();
    }
  } catch (err) {
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { connectionId: req.params.id } });
  }
});

// POST /api/db-connections/:id/activate
// 1. Flip is_active boolean in the table
// 2. Re-configure the infra pool to point to this connection's DB
router.post('/:id/activate', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  try {
    // Step 1: Update is_active flags atomically (beginTransaction → pool.rw).
    const conn = await pool.rw.getConnection();
    try {
      await conn.beginTransaction();
      await conn.query(`UPDATE \`${t(TABLES.DB_CONNECTIONS)}\` SET is_active = FALSE`);
      await conn.query(`UPDATE \`${t(TABLES.DB_CONNECTIONS)}\` SET is_active = TRUE WHERE id = ?`, [req.params.id]);
      await conn.commit();
    } catch (txErr) {
      await conn.rollback();
      throw txErr;
    } finally {
      conn.release();
    }

    // Step 2: Reconfigure infra pool to the activated connection's credentials
    await activateConnection(req.params.id);
    // INVARIANT: pool swap mutates getDbConfig() output; cached db-status
    // would otherwise report the prior host/database for one TTL window.
    invalidateDbStatusCache();

    res.json(apiOk({ activated: req.params.id }));
  } catch (err) {
    invalidateDbStatusCache();
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { connectionId: req.params.id } });
  }
});

// POST /api/db-connections/deactivate-all
router.post('/deactivate-all', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  try {
    const conn = await pool.rw.getConnection();
    try {
      await conn.query(`UPDATE \`${t(TABLES.DB_CONNECTIONS)}\` SET is_active = FALSE`);
      res.json(apiOk(null));
    } finally {
      conn.release();
    }
  } catch (err) {
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed' });
  }
});

/**
 * POST /api/db-connections/test
 * Tests a database connection using provided credentials (no stored data modified).
 *
 * Body: { host, port?, username, password?, database_name? }
 */
router.post('/test', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const { host, port, username, password, database_name } = req.body;

  if (!host || !username) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'host and username are required' });
  }

  let testPool;
  try {
    testPool = mariadb.createPool({
      host,
      port: parseInt(port || '3306'),
      user: username,
      password: password || '',
      database: database_name || undefined,
      connectionLimit: 1,
      connectTimeout: 5000,
    });

    const conn = await testPool.getConnection();
    conn.release();

    res.json(apiOk({ success: true, message: 'Connection successful' }));
  } catch (err) {
    res.json(apiOk({ success: false, message: err.message }));
  } finally {
    if (testPool) {
      try { await testPool.end(); } catch {}
    }
  }
});

module.exports = router;
// Exported for unit tests — not part of the router API.
module.exports._internal = { validateReadEndpointPair };
