const crypto = require('crypto');
const { sendError, logAppError } = require('../../../shared/lib/send-error');

const { TABLES, RATE_LIMIT_SETTINGS } = require('../../../shared/constants');

const router = require('express').Router();
const { pool, t } = require('../../db');
const { apiOk, apiError, requireAdmin, uuidv4 } = require('../../../shared/helpers');
const { encrypt, decrypt, isSensitiveKey, isEncryptionKeyConfigured, maskSensitiveFields } = require('../../../shared/lib/settings-crypto');
const { validateRateLimitSetting } = require('../../../shared/lib/rate-limit-validate');
const { logger: rootLogger } = require('../../../shared/lib/logger');
const { readPublicSystemSettings, PUBLIC_KEYS_ALLOWLIST } = require('../../db/system-settings-public-query');
const logger = rootLogger.child({ module: 'settings' });

/**
 * @openapi
 * /edge/platform/settings:
 *   get:
 *     summary: List all system settings (sensitive values masked)
 *     tags: [Platform - System Settings]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Array of system settings with sensitive fields masked
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *   put:
 *     summary: Bulk upsert system settings (sensitive values encrypted at rest)
 *     tags: [Platform - System Settings]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [settings]
 *             properties:
 *               settings:
 *                 type: array
 *                 items:
 *                   type: object
 *                   required: [key, value]
 *                   properties:
 *                     key:
 *                       type: string
 *                     value: {}
 *               updated_by:
 *                 type: string
 *     responses:
 *       200:
 *         description: Settings saved successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *   post:
 *     summary: Upsert a single system setting by key
 *     tags: [Platform - System Settings]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [key]
 *             properties:
 *               key:
 *                 type: string
 *               value: {}
 *               description:
 *                 type: string
 *     responses:
 *       200:
 *         description: Setting saved successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 */

// GET /api/system-settings — admin only
// Sensitive values are masked ('****') in the response.
// Server-side code that needs the real value should use decrypt() directly.
router.get('/', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  try {
    const conn = await pool.ro.getConnection();
    try {
      const rows = await conn.query(
        `SELECT \`key\`, value, description, updated_by FROM \`${t(TABLES.SYSTEM_SETTINGS)}\` ORDER BY \`key\``
      );
      const settings = rows.map(r => {
        let value = r.value;
        // Decrypt if encrypted, then parse JSON
        if (typeof value === 'string') {
          const decrypted = decrypt(value);
          try { value = JSON.parse(decrypted); } catch { value = decrypted; }
        }
        // Mask sensitive fields in the API response
        if (isSensitiveKey(r.key)) {
          value = maskSensitiveFields(value);
        }
        return { key: r.key, value, description: r.description, updated_by: r.updated_by };
      });
      res.json(apiOk(settings));
    } finally {
      conn.release();
    }
  } catch (err) {
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed' });
  }
});

// PUT /api/system-settings — { settings: [{ key, value }], updated_by }
// Sensitive values are AES-encrypted before storage.
router.put('/', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const { settings, updated_by } = req.body;
  if (!Array.isArray(settings)) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'settings must be an array' });
  }
  for (const s of settings) {
    if (!s.key) {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'key is required in each settings array item' });
    }
  }
  // Preflight rate-limit bounds before the autocommit loop — an out-of-bounds
  // value must 422 with zero partial writes (mirrors the encryption preflight).
  for (const s of settings) {
    const v = validateRateLimitSetting(s.key, s.value);
    if (!v.ok) {
      return sendError(req, res, null, { status: 422, code: 'RATE_LIMIT_OUT_OF_BOUNDS', reason: v.message });
    }
  }
  // Preflight the fail-closed encryption gate BEFORE the autocommit loop: a
  // sensitive key with no SETTINGS_ENCRYPTION_KEY would throw mid-loop, leaving
  // earlier non-sensitive upserts already committed while the client sees a 422.
  if (!isEncryptionKeyConfigured() && settings.some((s) => isSensitiveKey(s.key))) {
    return sendError(req, res, null, { status: 422, code: 'ENCRYPTION_KEY_MISSING', reason: 'Server is missing SETTINGS_ENCRYPTION_KEY; refusing to store a sensitive setting unencrypted. Set the key and retry.' });
  }
  try {
    const conn = await pool.rw.getConnection();
    try {
      for (const s of settings) {
        let serialized = JSON.stringify(s.value);
        // Encrypt sensitive keys before storage
        if (isSensitiveKey(s.key)) {
          serialized = encrypt(serialized);
        }
        await conn.query(
          `INSERT INTO \`${t(TABLES.SYSTEM_SETTINGS)}\` (id, \`key\`, value, updated_by)
           VALUES (UUID(), ?, ?, ?)
           ON DUPLICATE KEY UPDATE value = VALUES(value), updated_by = VALUES(updated_by)`,
          [s.key, serialized, updated_by]
        );
      }
      res.json(apiOk(null));
    } finally {
      conn.release();
    }
  } catch (err) {
    if (err && err.code === 'ENCRYPTION_KEY_MISSING') {
      return sendError(req, res, err, { status: 422, code: 'ENCRYPTION_KEY_MISSING', reason: 'Server is missing SETTINGS_ENCRYPTION_KEY; refusing to store a sensitive setting unencrypted. Set the key and retry.' });
    }
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { keyCount: settings.length } });
  }
});

// POST /api/system-settings — single key upsert { key, value, description }
router.post('/', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const { key, value, description } = req.body;
  if (!key) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'key is required' });
  }
  const rl = validateRateLimitSetting(key, value);
  if (!rl.ok) {
    return sendError(req, res, null, { status: 422, code: 'RATE_LIMIT_OUT_OF_BOUNDS', reason: rl.message });
  }
  try {
    const conn = await pool.rw.getConnection();
    try {
      let serialized = typeof value === 'string' ? value : JSON.stringify(value);
      if (isSensitiveKey(key)) {
        serialized = encrypt(serialized);
      }
      await conn.query(
        `INSERT INTO \`${t(TABLES.SYSTEM_SETTINGS)}\` (id, \`key\`, value, description)
         VALUES (UUID(), ?, ?, ?)
         ON DUPLICATE KEY UPDATE value = VALUES(value), description = VALUES(description)`,
        [key, serialized, description || null]
      );
      res.json(apiOk(null));
    } finally {
      conn.release();
    }
  } catch (err) {
    if (err && err.code === 'ENCRYPTION_KEY_MISSING') {
      return sendError(req, res, err, { status: 422, code: 'ENCRYPTION_KEY_MISSING', reason: 'Server is missing SETTINGS_ENCRYPTION_KEY; refusing to store a sensitive setting unencrypted. Set the key and retry.' });
    }
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { settingKey: key } });
  }
});

// DELETE /:key — admin-only unset of a rate-limit override. Only the rate-limit
// keys are deletable (removing the row reverts that limiter to env/default);
// every other setting has its own lifecycle and is rejected here.
const DELETABLE_KEYS = new Set(RATE_LIMIT_SETTINGS.map((s) => s.settingKey));
router.delete('/:key', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const { key } = req.params;
  if (!DELETABLE_KEYS.has(key)) {
    return sendError(req, res, null, { status: 400, code: 'KEY_NOT_DELETABLE', reason: `Setting '${key}' is not deletable` });
  }
  try {
    await pool.rw.query(`DELETE FROM \`${t(TABLES.SYSTEM_SETTINGS)}\` WHERE \`key\` = ?`, [key]);
    res.json(apiOk(null));
  } catch (err) {
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { settingKey: key } });
  }
});

/**
 * @openapi
 * /edge/platform/settings/public:
 *   get:
 *     summary: Public allowlisted system settings (no auth)
 *     description: |
 *       Returns the small set of `system_settings` rows that are safe to
 *       expose pre-login (e.g. `app_name` for the brand on the login page).
 *       Allowlist is hardcoded in code; sensitive keys filtered by
 *       `isSensitiveKey()` double-gate. ETag + Cache-Control SWR; clients
 *       SHOULD send `If-None-Match` for revalidation.
 *     tags: [Platform - System Settings]
 *     responses:
 *       200:
 *         description: Object map of allowlisted keys → values
 *         headers:
 *           ETag: { schema: { type: string } }
 *           Cache-Control: { schema: { type: string } }
 *       304: { description: Cache valid (matched If-None-Match) }
 */
router.get('/public', async (req, res) => {
  try {
    const { values, maxUpdatedAt } = await readPublicSystemSettings(
      pool,
      t,
      TABLES.SYSTEM_SETTINGS,
      {
        onSensitiveLeak: (key) => {
          req.log.warn(
            { settingKey: key },
            'public-settings allowlist contained a sensitive key — filtered',
          );
        },
      },
    );

    // ETag must change whenever:
    //   - any allowlisted row's value changes (covered by maxUpdatedAt)
    //   - the allowlist itself changes (covered by including PUBLIC_KEYS_ALLOWLIST)
    //   - any row appears or disappears (covered by including the values map)
    const etagInput = JSON.stringify({
      maxUpdatedAt: maxUpdatedAt ? String(maxUpdatedAt) : null,
      allowlist: PUBLIC_KEYS_ALLOWLIST,
      values,
    });
    const etag = '"' + crypto.createHash('sha256').update(etagInput).digest('hex').slice(0, 16) + '"';

    if (req.headers['if-none-match'] === etag) {
      res.set('ETag', etag);
      res.set('Cache-Control', 'public, max-age=0, must-revalidate');
      return res.status(304).end();
    }

    res.set('Cache-Control', 'public, max-age=0, must-revalidate');
    res.set('ETag', etag);
    res.json(values);
  } catch (err) {
    // SECURITY: this route is UNAUTHENTICATED (no requireAdmin gate above) —
    // the apiError envelope (meta.db_type/provider) must never reach an
    // anonymous caller, so this keeps the pre-migration static body instead of
    // routing through sendError. `logAppError` still emits the one app-error
    // line (log-only, never in the response) so the failure stays observable
    // server-side.
    logAppError(req, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Public settings fetch failed' });
    // lint-allow: logger-discipline public unauthenticated endpoint keeps a static body; the app line is emitted by logAppError above
    return res.status(500).json({ error: 'internal' });
  }
});

module.exports = router;
