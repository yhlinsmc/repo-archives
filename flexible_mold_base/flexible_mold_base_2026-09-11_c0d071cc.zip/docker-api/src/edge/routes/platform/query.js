const router = require('express').Router();
const { sendError } = require('../../../shared/lib/send-error');
const { pool, getDynamicPool } = require('../../db');
const { apiOk, apiError, requireAdmin } = require('../../../shared/helpers');

/**
 * @openapi
 * /edge/platform/query:
 *   post:
 *     summary: Execute a raw SQL query (admin only)
 *     tags: [Platform - Query Proxy]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [sql]
 *             properties:
 *               sql:
 *                 type: string
 *                 description: SQL statement to execute (max 10 000 chars)
 *               params:
 *                 type: array
 *                 items: {}
 *                 description: Parameterised query bindings
 *               action:
 *                 type: string
 *                 enum: [execute]
 *                 description: Force DML execution path
 *               db:
 *                 type: object
 *                 deprecated: true
 *                 description: >-
 *                   No longer accepted. Per-request DB credentials in the body are
 *                   rejected with 400 CLIENT_DB_CONFIG_REJECTED (or discarded under
 *                   the DYNAMIC_DB_CLIENT_CONFIG=warn valve). Schema routing is
 *                   header-only (X-Database); the route uses the server-resolved pool.
 *     responses:
 *       200:
 *         description: Query executed successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       400:
 *         description: Invalid SQL or query error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       403:
 *         description: Admin role required
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 */
router.post('/', async (req, res) => {
  if (!requireAdmin(req, res)) return;

  const { sql, params = [], action, db: dbConfig } = req.body;

  if (!sql || typeof sql !== 'string') {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'sql is required' });
  }

  // Basic safety: limit query length
  if (sql.length > 10000) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'Query too long (max 10000 chars)' });
  }

  let conn;
  try {
    // Per-request DB override: use a dynamic pool for the specified credentials.
    // NOTE: This endpoint accepts arbitrary admin SQL (SELECT / DML / DDL),
    // so always acquire the writer connection — a DML statement on a read-only
    // replica would fail in production. A raw SELECT against the writer is
    // also the least surprising behaviour for an admin inspection tool.
    const activePool = dbConfig ? await getDynamicPool(dbConfig) : pool;
    conn = await activePool.rw.getConnection();

    const isSelect = /^\s*(SELECT|SHOW|DESCRIBE|EXPLAIN)/i.test(sql);

    if (isSelect) {
      const rows = await conn.query(sql, params);
      // mariadb driver returns rows + meta; filter meta
      const data = Array.isArray(rows) ? rows.filter(r => typeof r === 'object' && r !== null && !('affectedRows' in r)) : rows;
      res.json(apiOk({
        rows: data,
        rowCount: data.length,
        fields: data.length > 0 ? Object.keys(data[0]) : [],
      }));
    } else {
      // DML / DDL
      const result = await conn.query(sql, params);
      res.json(apiOk({
        affectedRows: result.affectedRows ?? 0,
        insertId: result.insertId?.toString() ?? null,
        warningStatus: result.warningStatus ?? 0,
      }));
    }
  } catch (err) {
    sendError(req, res, err, { status: 400, code: 'QUERY_ERROR', reason: err.message });
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
