/**
 * dto-mapper-debug.js — Diagnostic endpoint for the MariaDB DTO mapping layer.
 *
 * Returns the raw DB row + the mapped frontend DTO + a per-column transform
 * report. Helps a developer figure out why a boolean came back as 0 or a
 * timestamp came back without a Z.
 *
 * Routes:
 *   GET /edge/platform/debug/dto-mapper/:table?row_id=X
 *
 * Gates:
 *   - DEBUG_DTO_MAPPER=1 must be set in the environment (defense in depth
 *     so the endpoint is unreachable in production by default)
 *   - requireAdmin (Sec #2): only admins can run it even when enabled
 *   - The :table param must be in the dto-mapper REGISTRY (no arbitrary table)
 */
const router = require('express').Router();
const { sendError } = require('../../../shared/lib/send-error');
const { pool, t } = require('../../db');
const { apiOk, apiError, requireAdmin } = require('../../../shared/helpers');
const { mapRowFromDb, describeRowMapping, getRegistry } = require('../../lib/dto-mapper');
const { logger: rootLogger } = require('../../../shared/lib/logger');
const logger = rootLogger.child({ module: 'dto-mapper-debug' });

const SAFE_TABLE_RE = /^[a-zA-Z_][a-zA-Z0-9_]*$/;

// Sec review (LOW finding) — even an admin should not see these columns
// in a diagnostic dump. The dto-mapper itself never touches them, so
// returning them adds zero diagnostic value.
const REDACTED_COLUMNS = new Set([
  'password_hash',
  'encrypted_password',
  'read_encrypted_password', // Same redaction as encrypted_password
  'kc_username',     // PII
  'keycloak_sub',    // PII / sub identifier
]);

function redactRow(row) {
  if (!row || typeof row !== 'object') return row;
  const out = {};
  for (const [k, v] of Object.entries(row)) {
    out[k] = REDACTED_COLUMNS.has(k) ? '<<redacted>>' : v;
  }
  return out;
}

router.get('/dto-mapper/:table', async (req, res) => {
  if (process.env.DEBUG_DTO_MAPPER !== '1') {
    return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Diagnostic endpoint disabled. Set DEBUG_DTO_MAPPER=1 to enable.' });
  }
  if (!requireAdmin(req, res)) return;

  const tableName = req.params.table;
  if (!SAFE_TABLE_RE.test(tableName)) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'Invalid table name' });
  }
  const registry = getRegistry();
  if (!registry[tableName]) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: `Unknown table: ${tableName}. Registered: ${Object.keys(registry).join(', ')}` });
  }

  const rowId = req.query.row_id;
  if (!rowId) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'row_id query param required' });
  }

  let conn;
  try {
    // NOTE: Diagnostic SELECT on arbitrary registered table → pool.ro.
    conn = await pool.ro.getConnection();
    const rows = await conn.query(
      `SELECT * FROM \`${t(tableName)}\` WHERE id = ? LIMIT 1`,
      [rowId],
    );
    if (!rows.length) {
      return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Row not found' });
    }
    const raw = rows[0];
    const mapped = mapRowFromDb(tableName, raw);
    const transforms = describeRowMapping(tableName, raw);
    res.json(apiOk({
      table: tableName,
      row_id: rowId,
      raw: redactRow(raw),
      mapped: redactRow(mapped),
      transforms,
      registry: registry[tableName],
    }));
  } catch (err) {
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { table: tableName, rowId } });
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
