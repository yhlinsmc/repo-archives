const { TABLES } = require('../../../shared/constants');
const { sendError } = require('../../../shared/lib/send-error');

/**
 * auth-password.js — Password-based auth routes (edge-side, DB-facing).
 *
 * Handles: login, change-password, is-admin, mode switch, diagnostics/details.
 * These routes all require DB access, so they live on the edge service.
 * Session/identity routes (GET /me, GET /mode, GET /diagnostics) stay on infra.
 *
 * Mounted by index-edge.js at /edge/platform/auth-password.
 * Accessed from infra via S2S forwarding proxy.
 */

const router = require('express').Router();
const { SignJWT } = require('jose');
const bcrypt = require('bcryptjs');
const { pool, t, isPoolReady } = require('../../db');
const { apiOk, apiError, requireAuth, requireAdmin } = require('../../../shared/helpers');
const { JWT_SECRET, resolveAuthMode, resolveAuthModeAsync, getAuthModeSource, setResolvedAuthMode, probeKeycloakDiscovery } = require('../../../shared/config');
const { validatePassword } = require('../../../shared/password-validator');
const { isDegraded, clearDegradation } = require('../../../lib/keycloak-health');
const { logger: rootLogger } = require('../../../shared/lib/logger');
const { markSecurity } = require('../../../shared/middleware/route-markers');
const { logSecurity } = require('../../../shared/lib/log-streams');
const logger = rootLogger.child({ module: 'auth-password' });

/**
 * Write a login audit record (fire-and-forget, non-critical).
 */
function _writeLoginAudit(conn, { username, success, reason, ip, userAgent }) {
  conn.query(
    `INSERT INTO \`${t(TABLES.LOGIN_AUDIT)}\` (username, auth_provider, reason, ip_address, user_agent, success)
     VALUES (?, 'LOCAL', ?, ?, ?, ?)`,
    [username, reason, ip || null, userAgent || null, success ? 1 : 0]
  ).catch(err => logger.warn({ err }, 'audit write failed (non-critical)'));
}

/**
 * @openapi
 * /edge/platform/auth-password/login:
 *   post:
 *     summary: Login with email + password (local mode only)
 *     tags: [Platform - Auth]
 */
router.post('/login', markSecurity, async (req, res) => {
  // Block local login when auth_mode is keycloak
  let currentMode;
  if (isPoolReady()) {
    currentMode = await resolveAuthModeAsync(pool, t);
  } else {
    currentMode = resolveAuthMode();
  }
  if (currentMode === 'keycloak') {
    return sendError(req, res, null, { status: 403, code: 'AUTH_MODE_KEYCLOAK', reason: 'Local login is disabled. Use SSO login.' });
  }

  const { email, password } = req.body;
  try {
    // SELECT + conditional _writeLoginAudit INSERT all on the same conn → pool.rw.
    const conn = await pool.rw.getConnection();
    try {
      const rows = await conn.query(`SELECT * FROM \`${t(TABLES.USERS)}\` WHERE email = ?`, [email]);
      if (!rows.length) {
        _writeLoginAudit(conn, { username: email, success: false, reason: 'user_not_found', ip: req.ip, userAgent: req.headers['user-agent'] });
        logSecurity(req, { event: 'login_fail', level: 'warn', name: email, reason: 'user_not_found', terminal: true }, 'login failed');

        return sendError(req, res, null, { status: 401, code: 'AUTH_ERROR', reason: 'Invalid credentials' });
      }
      const user = rows[0];
      // NOTE: this route reads `user.banned` directly from the raw SELECT
      // result instead of routing the row through dto-mapper's
      // `mapRowFromDb('users', user)`. Intentional: the login hot-path
      // only needs one boolean field and a truthy check, which is
      // identical for raw TINYINT (0/1) and DTO-mapped booleans
      // (false/true). Bypassing the mapper avoids an extra function
      // call on every login. Consistent with auth.js middleware, which
      // also reads raw rows from the OIDC jit-provisioner and the JWT
      // path. Do NOT use the raw-read shortcut for any field that
      // needs decoded JSON, ISO timestamps, or nullable-number
      // semantics — route those through mapRowFromDb first.
      if (user.banned) {
        _writeLoginAudit(conn, { username: email, success: false, reason: 'account_banned', ip: req.ip, userAgent: req.headers['user-agent'] });
        logSecurity(req, { event: 'login_fail', level: 'warn', name: email, reason: 'account_banned', terminal: true }, 'login failed');

        return sendError(req, res, null, { status: 403, code: 'AUTH_ERROR', reason: 'Account banned' });
      }
      if (!user.password_hash) {
        _writeLoginAudit(conn, { username: email, success: false, reason: 'sso_only_account', ip: req.ip, userAgent: req.headers['user-agent'] });
        logSecurity(req, { event: 'login_fail', level: 'warn', name: email, reason: 'sso_only_account', terminal: true }, 'login failed');

        return sendError(req, res, null, { status: 403, code: 'AUTH_ERROR', reason: 'This account uses SSO login only' });
      }
      const valid = await bcrypt.compare(password, user.password_hash);
      if (!valid) {
        _writeLoginAudit(conn, { username: email, success: false, reason: 'invalid_password', ip: req.ip, userAgent: req.headers['user-agent'] });
        logSecurity(req, { event: 'login_fail', level: 'warn', name: email, reason: 'invalid_password', terminal: true }, 'login failed');

        return sendError(req, res, null, { status: 401, code: 'AUTH_ERROR', reason: 'Invalid credentials' });
      }
      // Claim shape stays byte-compatible with the previous jsonwebtoken
      // output: { sub, email, iat, exp }, HS256 header. setExpirationTime('24h')
      // matches the old expiresIn: '24h' (exp = iat + 86400).
      const token = await new SignJWT({ sub: user.id, email: user.email })
        .setProtectedHeader({ alg: 'HS256' })
        .setIssuedAt()
        .setExpirationTime('24h')
        .sign(new TextEncoder().encode(JWT_SECRET));
      _writeLoginAudit(conn, { username: email, success: true, reason: null, ip: req.ip, userAgent: req.headers['user-agent'] });
      logSecurity(req, { event: 'login_ok', level: 'info', name: email, terminal: true }, 'login ok');
      res.json(apiOk({ token, user: { id: user.id, email: user.email, role: user.role } }));
    } finally {
      conn.release();
    }
  } catch (err) {
    // NOTE: email rides in a structured binding (not the msg string), so pino's redact.paths ('email' is in logger.js's redactConfig) actually masks it in the emitted record.
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed' });
  }
});

/**
 * @openapi
 * /edge/platform/auth-password/{id}/is-admin:
 *   get:
 *     summary: Check if a user is admin
 *     tags: [Platform - Auth]
 */
router.get('/:id/is-admin', async (req, res) => {
  if (!requireAuth(req, res)) return;
  try {
    // NOTE: Authorization-gating read must come from the writer. A replica-lag
    // window could otherwise let a freshly-demoted admin keep is_admin=true on
    // direct API calls that bypass SPA caches.
    const conn = await pool.rw.getConnection();
    try {
      const rows = await conn.query(`SELECT role FROM \`${t(TABLES.USERS)}\` WHERE id = ?`, [req.params.id]);
      const isAdmin = rows.length > 0 && rows[0].role === 'admin';
      res.json(apiOk({ is_admin: isAdmin }));
    } finally {
      conn.release();
    }
  } catch (err) {
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { userId: req.params.id } });
  }
});

/**
 * @openapi
 * /edge/platform/auth-password/change-password:
 *   put:
 *     summary: Change own password
 *     tags: [Platform - Auth]
 */
router.put('/change-password', markSecurity, async (req, res) => {
  if (!requireAuth(req, res)) return;
  const { old_password, new_password } = req.body;
  if (!old_password || !new_password) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'old_password and new_password are required' });
  }
  const pwError = validatePassword(new_password);
  if (pwError) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: pwError });
  }
  try {
    // SELECT + UPDATE password_hash + audit INSERT on same conn → pool.rw.
    const conn = await pool.rw.getConnection();
    try {
      const rows = await conn.query(
        `SELECT id, email, password_hash, keycloak_sub FROM \`${t(TABLES.USERS)}\` WHERE id = ?`,
        [req.user.id]
      );
      if (!rows.length) {
        return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'User not found' });
      }
      const user = rows[0];
      if (user.keycloak_sub && !user.password_hash) {
        return sendError(req, res, null, { status: 403, code: 'AUTH_ERROR', reason: 'Password change is not available for Keycloak-only accounts. Change your password in Keycloak.' });
      }
      if (!user.password_hash) {
        return sendError(req, res, null, { status: 403, code: 'AUTH_ERROR', reason: 'No password set for this account' });
      }
      const valid = await bcrypt.compare(old_password, user.password_hash);
      if (!valid) {
        return sendError(req, res, null, { status: 401, code: 'AUTH_ERROR', reason: 'Current password is incorrect' });
      }
      const hash = await bcrypt.hash(new_password, 10);
      await conn.query(
        `UPDATE \`${t(TABLES.USERS)}\` SET password_hash = ? WHERE id = ?`,
        [hash, req.user.id]
      );
      conn.query(
        `INSERT INTO \`${t(TABLES.LOGIN_AUDIT)}\` (username, auth_provider, reason, success)
         VALUES (?, 'LOCAL', 'password_change', TRUE)`,
        [user.email]
      ).catch(err => req.log.warn({ err }, 'audit write failed (non-critical)'));
      res.json(apiOk({ message: 'Password changed successfully' }));
    } finally {
      conn.release();
    }
  } catch (err) {
    sendError(req, res, err, { code: 'DB_ERROR', reason: 'Database error', fields: { userId: req.user?.id } });
  }
});

/**
 * @openapi
 * /edge/platform/auth-password/mode:
 *   put:
 *     summary: Switch auth mode (admin only)
 *     tags: [Platform - Auth]
 */
router.put('/mode', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const { mode } = req.body;
  if (!mode || !['local', 'keycloak'].includes(mode)) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'mode must be "local" or "keycloak"' });
  }

  try {
    if (mode === 'keycloak') {
      const reachable = await probeKeycloakDiscovery();
      if (!reachable) {
        return sendError(req, res, null, { status: 503, code: 'KEYCLOAK_UNREACHABLE', reason: 'Keycloak is not reachable. Verify KEYCLOAK_ISSUER_BASE_URL and connectivity.' });
      }
    }

    if (mode === 'local') {
      // NOTE: Guard read for an about-to-write operation must read from the
      // writer, not a replica. A replication-lag window between the preflight
      // and the system_settings INSERT would otherwise let a concurrent
      // /change-password write race the guard.
      const conn = await pool.rw.getConnection();
      try {
        const rows = await conn.query(
          `SELECT password_hash FROM \`${t(TABLES.USERS)}\` WHERE id = ?`,
          [req.user.id]
        );
        if (rows.length && !rows[0].password_hash) {
          return sendError(req, res, null, { status: 400, code: 'NO_LOCAL_PASSWORD', reason: 'You must set a local password before switching to local mode. Use the password management feature first.' });
        }
      } finally {
        conn.release();
      }
    }

    const conn = await pool.rw.getConnection();
    try {
      await conn.query(
        `INSERT INTO \`${t(TABLES.SYSTEM_SETTINGS)}\` (\`key\`, value, updated_by)
         VALUES ('auth_mode', ?, ?)
         ON DUPLICATE KEY UPDATE value = ?, updated_by = ?`,
        [JSON.stringify(mode), req.user.email, JSON.stringify(mode), req.user.email]
      );
    } finally {
      conn.release();
    }

    await setResolvedAuthMode(mode, 'admin_api');
    if (mode === 'keycloak') {
      clearDegradation();
    }

    pool.rw.getConnection().then(auditConn => {
      auditConn.query(
        `INSERT INTO \`${t(TABLES.LOGIN_AUDIT)}\` (username, auth_provider, reason, success)
         VALUES (?, 'LOCAL', ?, TRUE)`,
        [req.user.email, `auth_mode_switch_to_${mode}`]
      ).catch(err => req.log.warn({ err }, 'audit write failed (non-critical)')).finally(() => auditConn.release());
    }).catch(err => req.log.warn({ err }, 'audit connection failed (non-critical)'));

    res.json(apiOk({
      mode,
      source: getAuthModeSource(),
      message: `Auth mode switched to ${mode}`,
    }));
  } catch (err) {
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { mode } });
  }
});

/**
 * @openapi
 * /edge/platform/auth-password/diagnostics/details:
 *   get:
 *     summary: Full diagnostics (admin only)
 *     tags: [Platform - Auth]
 */
router.get('/diagnostics/details', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  try {
    const authMode = isPoolReady()
      ? await resolveAuthModeAsync(pool, t)
      : resolveAuthMode();

    const issuerUrl = process.env.KEYCLOAK_ISSUER_BASE_URL || null;
    const callbackUrl = process.env.BASE_URL
      ? `${process.env.BASE_URL}/api/auth/callback`
      : `http://localhost:${process.env.PORT || 3200}/api/auth/callback`;
    const caCertPath = process.env.KEYCLOAK_CA_CERT_PATH || null;

    const result = {
      auth_mode: authMode,
      issuer_url_configured: !!issuerUrl,
      issuer_url: issuerUrl,
      callback_url: callbackUrl,
      keycloak_reachable: false,
      keycloak_discovery: null,
      ca_cert_configured: !!caCertPath,
      ca_cert_path: caCertPath,
      ca_cert_valid: null,
      recent_failures: [],
    };

    if (issuerUrl) {
      try {
        const discoveryUrl = `${issuerUrl}/.well-known/openid-configuration`;
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 5000);
        const resp = await fetch(discoveryUrl, { signal: controller.signal });
        clearTimeout(timeout);
        result.keycloak_reachable = resp.ok;
        if (resp.ok) {
          const body = await resp.json();
          result.keycloak_discovery = {
            authorization_endpoint: body.authorization_endpoint || null,
            token_endpoint: body.token_endpoint || null,
            userinfo_endpoint: body.userinfo_endpoint || null,
            end_session_endpoint: body.end_session_endpoint || null,
          };
        } else {
          result.keycloak_discovery = { error: `HTTP ${resp.status}` };
        }
      } catch (err) {
        result.keycloak_reachable = false;
        result.keycloak_discovery = { error: err.message };
      }
    }

    if (caCertPath) {
      try {
        const fs = require('fs');
        fs.accessSync(caCertPath, fs.constants.R_OK);
        const content = fs.readFileSync(caCertPath, 'utf-8');
        result.ca_cert_valid = content.includes('-----BEGIN CERTIFICATE-----');
      } catch {
        result.ca_cert_valid = false;
      }
    }

    if (isPoolReady()) {
      try {
        // Pure diagnostic SELECT → pool.ro.
        const conn = await pool.ro.getConnection();
        try {
          const rows = await conn.query(
            `SELECT username, auth_provider, reason, ip_address, login_at
             FROM \`${t(TABLES.LOGIN_AUDIT)}\`
             WHERE success = FALSE
             ORDER BY login_at DESC
             LIMIT 5`
          );
          result.recent_failures = rows.map(r => ({
            username: r.username,
            auth_provider: r.auth_provider,
            reason: r.reason || null,
            ip_address: r.ip_address || null,
            login_at: r.login_at,
          }));
        } finally {
          conn.release();
        }
      } catch (err) {
        req.log.warn({ err }, 'auth diagnostics — recent_failures query failed; returning empty list');
        result.recent_failures = [];
      }
    }

    res.json(apiOk(result));
  } catch (err) {
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed' });
  }
});

module.exports = router;
