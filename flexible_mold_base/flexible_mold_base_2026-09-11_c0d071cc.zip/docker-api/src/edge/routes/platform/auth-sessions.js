const { TABLES } = require('../../../shared/constants');
const { sendError } = require('../../../shared/lib/send-error');

/**
 * auth-sessions.js — Recent login history endpoint (API-edge).
 *
 * DB access belongs on edge. Identity is trusted via S2S middleware
 * (req.user populated from X-Forwarded-User-* headers).
 */
const router = require('express').Router();
const { pool, t } = require('../../db');
const { normalizeTimestamp } = require('../../lib/dto-mapper');
const { escapeLikePattern } = require('../../lib/sql-like');
const { apiOk, apiError, requireAdmin } = require('../../../shared/helpers');
const { logger: rootLogger } = require('../../../shared/lib/logger');
const logger = rootLogger.child({ module: 'auth-sessions' });

/**
 * @openapi
 * /edge/platform/auth/sessions:
 *   get:
 *     summary: List recent logins (admin only, deduplicated by user)
 *     tags: [Platform - Auth]
 *     parameters:
 *       - { name: page, in: query, schema: { type: integer, default: 1 } }
 *       - { name: limit, in: query, schema: { type: integer, default: 20, maximum: 100 } }
 *       - { name: search, in: query, schema: { type: string }, description: 'Filter by username or department' }
 *     responses:
 *       200:
 *         description: Paginated list of recent logins with stats
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       401: { description: Unauthorized }
 *       403: { description: Admin role required }
 */
router.get('/sessions', async (req, res) => {
  if (!requireAdmin(req, res)) return;

  try {
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit, 10) || 20));
    const search = (req.query.search || '').trim();
    const includeFailures = req.query.include_failures === '1' || req.query.include_failures === 'true';
    const offset = (page - 1) * limit;

    // NOTE: Aggregation over login_audit is pure read → pool.ro.
    const conn = await pool.ro.getConnection();
    try {
      // All providers (KEYCLOAK + LOCAL), successful logins only. The old
      // KEYCLOAK-only filter hid local-auth logins entirely; provider is now
      // surfaced per row so the UI can badge them apart instead.
      let whereClause = 'WHERE success = TRUE';
      const params = [];
      if (search) {
        // Escape SQL LIKE wildcards to prevent pattern injection. ESCAPE '|'
        // (not the default backslash) so the escaping is correct under the
        // NO_BACKSLASH_ESCAPES sql_mode too — see edge/lib/sql-like.js.
        const escaped = escapeLikePattern(search);
        whereClause += ` AND (username LIKE ? ESCAPE '|' OR deptid LIKE ? ESCAPE '|')`;
        params.push(`%${escaped}%`, `%${escaped}%`);
      }

      // Deduplicated query: one row per (user, provider) with latest login.
      // A user who has logged in via both providers shows one row each.
      const dataQuery = `
        SELECT username, deptid, auth_provider,
               MAX(login_at) AS last_login,
               COUNT(*) AS login_count
        FROM \`${t(TABLES.LOGIN_AUDIT)}\`
        ${whereClause}
        GROUP BY username, deptid, auth_provider
        ORDER BY last_login DESC
        LIMIT ? OFFSET ?`;

      // Total count for pagination — counts the SAME (user, dept, provider)
      // tuples the data query groups by, so a dual-provider user contributes
      // the two rows it actually renders. Counting DISTINCT username would
      // under-count totalPages and strand the extra rows behind a disabled
      // Next button.
      const countQuery = `
        SELECT COUNT(DISTINCT username, deptid, auth_provider) AS total
        FROM \`${t(TABLES.LOGIN_AUDIT)}\`
        ${whereClause}`;

      // Today's login count
      const todayQuery = `
        SELECT COUNT(*) AS today_count
        FROM \`${t(TABLES.LOGIN_AUDIT)}\`
        WHERE success = TRUE
          AND login_at >= CURDATE()`;

      const [rows, countRows, todayRows] = await Promise.all([
        conn.query(dataQuery, [...params, limit, offset]),
        conn.query(countQuery, params),
        conn.query(todayQuery),
      ]);

      const sessions = rows.map(r => ({
        username: r.username,
        deptid: r.deptid,
        provider: r.auth_provider,
        // dateStrings:true yields a bare "YYYY-MM-DD HH:mm:ss" UTC string; the
        // browser would parse that in local time and drift the displayed login.
        lastLogin: normalizeTimestamp(r.last_login),
        loginCount: Number(r.login_count),
      }));

      const payload = {
        items: sessions,
        total: Number(countRows[0]?.total || 0),
        todayLogins: Number(todayRows[0]?.today_count || 0),
        page,
        limit,
      };

      if (includeFailures) {
        // Most recent failed attempts (any provider). Not paginated — a small
        // fixed window is enough for the "what went wrong" admin view.
        const failuresQuery = `
          SELECT username, deptid, auth_provider, reason, login_at
          FROM \`${t(TABLES.LOGIN_AUDIT)}\`
          WHERE success = FALSE
          ORDER BY login_at DESC
          LIMIT 50`;
        const failRows = await conn.query(failuresQuery);
        payload.failures = failRows.map(r => ({
          username: r.username,
          deptid: r.deptid,
          provider: r.auth_provider,
          reason: r.reason,
          loginAt: normalizeTimestamp(r.login_at),
        }));
      }

      res.json(apiOk(payload));
    } finally {
      conn.release();
    }
  } catch (err) {
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed' });
  }
});

module.exports = router;
