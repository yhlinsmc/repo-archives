/**
 * export.js — Export engine table data as MariaDB-compatible SQL.
 *
 * GET /api/export/mariadb-sql
 *   Query params:
 *     tablePrefix — override prefix in output (default: server prefix)
 *
 *   Returns a downloadable .sql file with INSERT statements for all 7 engine tables.
 *   Uses {PREFIX} placeholder for configurable table prefix at import time.
 *
 *   Requires admin auth.
 */
const router = require('express').Router();
const { sendError } = require('../../../shared/lib/send-error');
const { pool, t, getDbConfig, isPoolReady } = require('../../db');
const { buildExportFilename, contentDispositionAttachment } = require('../../../shared/lib/export-filename');
const { apiError } = require('../../../shared/helpers');
const { requirePrefix } = require('../../../shared/lib/db-errors');
const { buildEngineSeedSql } = require('../../lib/engine-seed-sql');
const { logger: rootLogger } = require('../../../shared/lib/logger');
const logger = rootLogger.child({ module: 'export' });

/**
 * @openapi
 * /edge/platform/export/mariadb-sql:
 *   get:
 *     summary: Export all engine tables as a downloadable MariaDB SQL seed file
 *     tags: [Platform - Export]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - { name: tablePrefix, in: query, required: false, schema: { type: string }, description: Override table prefix in output SQL }
 *     responses:
 *       200:
 *         description: SQL file with INSERT statements for all engine tables; uses __PREFIX__ placeholder
 *         content:
 *           application/sql:
 *             schema:
 *               type: string
 *               format: binary
 *       403:
 *         description: Admin role required
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       500:
 *         description: Export failed; details in server logs
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 */

router.get('/mariadb-sql', async (req, res) => {
  // Auth: require admin (first-run bypass removed — Setup Wizard creates admin before export)
  if (!req.user || req.user.role !== 'admin') {
    return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Admin required' });
  }

  const config = getDbConfig();
  const serverPrefix = requirePrefix(config?.tablePrefix, 'export:server-prefix');

  let conn;
  try {
    // Pure export dump (SELECT * + INFORMATION_SCHEMA) → pool.ro.
    conn = await pool.ro.getConnection();
    const sql = await buildEngineSeedSql(conn, { database: config?.database, tablePrefix: serverPrefix });
    const filename = buildExportFilename({ kind: 'seed', entity: config?.database || 'export', ext: 'sql' });

    res.setHeader('Content-Type', 'application/sql; charset=utf-8');
    res.setHeader('Content-Disposition', contentDispositionAttachment(filename));
    res.send(sql);
  } catch (err) {
    sendError(req, res, err, { code: 'EXPORT_ERROR', reason: 'Failed to export data. Check server logs for details.' });
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
