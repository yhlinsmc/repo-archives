const { TABLES } = require('../../../shared/constants');
const { sendError } = require('../../../shared/lib/send-error');

/**
 * access-rules.js — CRUD API for Keycloak access rules (default deny + allowlist).
 *
 * Permission model:
 *   - Default deny: all users without a matching rule are denied access
 *   - Rules match by deptid (department-wide) or user (email-based)
 *   - Query priority: user rule > deptid rule > deny
 *
 * All endpoints require admin auth.
 * Self-lockout prevention: admins cannot delete/disable their own access rule.
 */

const router = require('express').Router();
const { pool, t } = require('../../db');
const { apiOk, apiError, requireAdmin, uuidv4 } = require('../../../shared/helpers');
const { logger: rootLogger } = require('../../../shared/lib/logger');
const logger = rootLogger.child({ module: 'access-rules' });

/** Mask email for logging: "ab***@domain.com" */
function maskPii(val) {
  if (typeof val === 'string' && val.includes('@')) {
    return val.replace(/(.{2}).*(@.*)/, '$1***$2');
  }
  return val;
}

/**
 * @openapi
 * /edge/platform/access-rules:
 *   get:
 *     summary: List all access rules
 *     tags: [Platform - Access Rules]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Array of access rule objects
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Admin role required
 *   post:
 *     summary: Create a new access rule
 *     tags: [Platform - Access Rules]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [rule_type, rule_value]
 *             properties:
 *               rule_type:
 *                 type: string
 *                 enum: [deptid, user]
 *               rule_value:
 *                 type: string
 *                 description: Department ID or user email depending on rule_type
 *               role:
 *                 type: string
 *                 enum: [admin, editor, user]
 *                 default: user
 *     responses:
 *       201:
 *         description: Newly created access rule
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       400:
 *         description: Validation error (missing fields or invalid enum value)
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Admin role required
 *       409:
 *         description: Duplicate rule (same type and value already exists)
 * /edge/platform/access-rules/{id}:
 *   put:
 *     summary: Update role or enabled status of an access rule
 *     tags: [Platform - Access Rules]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Access rule UUID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               role:
 *                 type: string
 *                 enum: [admin, editor, user]
 *               enabled:
 *                 type: boolean
 *     responses:
 *       200:
 *         description: Updated access rule
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Admin required or self-lockout prevention triggered
 *       404:
 *         description: Rule not found
 *   delete:
 *     summary: Delete an access rule
 *     tags: [Platform - Access Rules]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Access rule UUID
 *     responses:
 *       200:
 *         description: Deletion confirmed
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Admin required or self-lockout prevention triggered
 *       404:
 *         description: Rule not found
 */

// GET /api/access-rules — list all access rules
router.get('/', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  try {
    // NOTE: Pure read → pool.ro.
    const conn = await pool.ro.getConnection();
    try {
      const rows = await conn.query(
        `SELECT id, rule_type, rule_value, role, enabled, created_by, created_at, updated_at
         FROM \`${t(TABLES.ACCESS_RULES)}\`
         ORDER BY rule_type, rule_value`
      );
      res.json(apiOk(rows));
    } finally {
      conn.release();
    }
  } catch (err) {
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed' });
  }
});

// POST /api/access-rules — create a new access rule
router.post('/', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const { rule_type, rule_value, role = 'user' } = req.body;

  if (!rule_type || !rule_value) {
    return sendError(req, res, null, { status: 400, code: 'VALIDATION_ERROR', reason: 'rule_type and rule_value are required' });
  }
  if (!['deptid', 'user'].includes(rule_type)) {
    return sendError(req, res, null, { status: 400, code: 'VALIDATION_ERROR', reason: 'rule_type must be "deptid" or "user"' });
  }
  if (!['admin', 'editor', 'user'].includes(role)) {
    return sendError(req, res, null, { status: 400, code: 'VALIDATION_ERROR', reason: 'role must be "admin", "editor", or "user"' });
  }

  try {
    // INSERT + read-back SELECT on same conn → pool.rw (w→r).
    const conn = await pool.rw.getConnection();
    try {
      const id = uuidv4();
      await conn.query(
        `INSERT INTO \`${t(TABLES.ACCESS_RULES)}\` (id, rule_type, rule_value, role, created_by)
         VALUES (?, ?, ?, ?, ?)`,
        [id, rule_type, rule_value, role, req.user.id]
      );

      // Audit trail
      req.log.info({ ruleType: rule_type, ruleValue: maskPii(rule_value), role, by: req.user.id }, 'rule created');

      const rows = await conn.query(
        `SELECT * FROM \`${t(TABLES.ACCESS_RULES)}\` WHERE id = ?`,
        [id]
      );
      res.status(201).json(apiOk(rows[0]));
    } finally {
      conn.release();
    }
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') {
      return sendError(req, res, err, { status: 409, code: 'DUPLICATE_RULE', reason: 'A rule with this type and value already exists' });
    }
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { ruleType: rule_type } });
  }
});

// PUT /api/access-rules/:id — update an access rule
router.put('/:id', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const { id } = req.params;
  const { role, enabled } = req.body;

  // Self-lockout prevention: check if this rule matches the current admin.
  // SELECT + UPDATE + read-back SELECT on same conn → pool.rw.
  try {
    const conn = await pool.rw.getConnection();
    try {
      const existing = await conn.query(
        `SELECT * FROM \`${t(TABLES.ACCESS_RULES)}\` WHERE id = ?`,
        [id]
      );
      if (!existing.length) {
        return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Rule not found' });
      }

      const rule = existing[0];
      if (isSelfRule(req.user, rule) && enabled === false) {
        return sendError(req, res, null, { status: 403, code: 'SELF_LOCKOUT', reason: 'Cannot disable your own access rule — this would lock you out' });
      }

      const updates = [];
      const params = [];
      if (role !== undefined && ['admin', 'editor', 'user'].includes(role)) {
        updates.push('role = ?');
        params.push(role);
      }
      if (enabled !== undefined) {
        updates.push('enabled = ?');
        params.push(enabled);
      }

      if (updates.length === 0) {
        return res.json(apiOk(rule));
      }

      params.push(id);
      await conn.query(
        `UPDATE \`${t(TABLES.ACCESS_RULES)}\` SET ${updates.join(', ')} WHERE id = ?`,
        params
      );

      req.log.info({ ruleId: id, updates: updates.join(', '), by: req.user.id }, 'rule updated');

      const updated = await conn.query(
        `SELECT * FROM \`${t(TABLES.ACCESS_RULES)}\` WHERE id = ?`,
        [id]
      );
      res.json(apiOk(updated[0]));
    } finally {
      conn.release();
    }
  } catch (err) {
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { ruleId: id } });
  }
});

// DELETE /api/access-rules/:id — delete an access rule
router.delete('/:id', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const { id } = req.params;

  // SELECT guard + DELETE on same conn → pool.rw.
  try {
    const conn = await pool.rw.getConnection();
    try {
      const existing = await conn.query(
        `SELECT * FROM \`${t(TABLES.ACCESS_RULES)}\` WHERE id = ?`,
        [id]
      );
      if (!existing.length) {
        return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Rule not found' });
      }

      // Self-lockout prevention
      const rule = existing[0];
      if (isSelfRule(req.user, rule)) {
        return sendError(req, res, null, { status: 403, code: 'SELF_LOCKOUT', reason: 'Cannot delete your own access rule — this would lock you out' });
      }

      await conn.query(
        `DELETE FROM \`${t(TABLES.ACCESS_RULES)}\` WHERE id = ?`,
        [id]
      );

      req.log.info({ ruleId: id, ruleType: rule.rule_type, ruleValue: maskPii(rule.rule_value), by: req.user.id }, 'rule deleted');

      res.json(apiOk({ deleted: true }));
    } finally {
      conn.release();
    }
  } catch (err) {
    sendError(req, res, err, { code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { ruleId: id } });
  }
});

/**
 * Check if an access rule matches the current user (self-lockout detection).
 * Matches on: user rule with email (case-insensitive), or deptid rule with user's deptid.
 */
function isSelfRule(user, rule) {
  if (!user || !rule) return false;
  if (rule.rule_type === 'user' && user.email && rule.rule_value.toLowerCase() === user.email.toLowerCase()) return true;
  if (rule.rule_type === 'deptid' && user.deptid && rule.rule_value === user.deptid) return true;
  return false;
}

// ── Access check middleware (exported for use in index.js) ──────────────
/**
 * Middleware that enforces the default-deny + allowlist access model.
 * Mounted on all /api/ routes except exempted paths.
 * Query priority: user rule > deptid rule > deny.
 *
 * Exemptions (handled in index.js, not here):
 *   /health, /api/setup, /api/auth/mode, /api/auth/sso-login, /api/auth/callback, /api/auth/logout
 *
 * @param {import('express').Request} req
 * @param {import('express').Response} res
 * @param {import('express').NextFunction} next
 */
async function accessCheckMiddleware(req, res, next) {
  // Only enforce when auth_mode is keycloak and pool is ready.
  // Use async resolution when pool is ready to include DB system_settings;
  // fall back to sync (env-only) when pool is not available.
  const { resolveAuthMode, resolveAuthModeAsync } = require('../../../shared/config');
  const { isPoolReady: poolReady } = require('../../db');
  let mode;
  if (poolReady()) {
    mode = await resolveAuthModeAsync(pool, t);
  } else {
    mode = resolveAuthMode();
  }
  if (mode !== 'keycloak') return next();

  // Unauthenticated requests are handled by auth guards on individual routes
  if (!req.user) return next();

  // Admins bypass access rules
  if (req.user.role === 'admin') return next();

  try {
    // Hot-path middleware — fires on every authenticated non-admin request
    // when auth_mode=keycloak. Pure SELECTs → pool.ro.
    const conn = await pool.ro.getConnection();
    try {
      // Check user-level rule first (higher priority) — matches by email
      // MariaDB utf8mb4_general_ci collation provides case-insensitive matching by default
      if (req.user.email) {
        const userRules = await conn.query(
          `SELECT role FROM \`${t(TABLES.ACCESS_RULES)}\`
           WHERE rule_type = 'user' AND rule_value = ? AND enabled = TRUE`,
          [req.user.email]
        );
        if (userRules.length) return next();
      }

      // Check deptid-level rule
      if (req.user.deptid) {
        const deptidRules = await conn.query(
          `SELECT role FROM \`${t(TABLES.ACCESS_RULES)}\`
           WHERE rule_type = 'deptid' AND rule_value = ? AND enabled = TRUE`,
          [req.user.deptid]
        );
        if (deptidRules.length) return next();
      }

      // Default deny
      return sendError(req, res, null, { status: 403, code: 'ACCESS_DENIED', reason: 'Access denied. Contact your administrator for access.' });
    } finally {
      conn.release();
    }
  } catch (err) {
    // If access check fails, deny access (fail-closed)
    // Apply maskPii to the email — matches the file-level convention used by
    // the info-level `rule created/deleted` log lines (see lines 200, 313).
    sendError(req, res, err, { status: 500, code: 'ACCESS_CHECK_ERROR', reason: 'Access check failed', fields: { userEmail: maskPii(req.user?.email), userDeptid: req.user?.deptid } });
  }
}

module.exports = router;
module.exports.accessCheckMiddleware = accessCheckMiddleware;
