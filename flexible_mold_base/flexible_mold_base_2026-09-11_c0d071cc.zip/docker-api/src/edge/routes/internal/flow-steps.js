/**
 * flow-steps.js — edge-side flow-step dispatch brain (S2S-only).
 *
 * /prepare is the SOLE dispatch entry. It loads the step, gates on the parent
 * recipe's approval, decrypts auth_config, resolves the request, enforces the
 * egress allow-list + breaker, writes a pending audit, then routes by the
 * step's dispatch_origin (edge → inline execute; infra → SSRF pin + prepared).
 *
 * SECURITY: prepared.headers carries the decrypted secret over the S2S channel
 * only; it is never logged or written to an audit row. Audit rows carry
 * step_id/recipe_id/run_id/host/method/status.
 */
const router = require('express').Router();
const { sendError } = require('../../../shared/lib/send-error');
const { pool } = require('../../db');
const { apiOk, apiError, uuidv4 } = require('../../../shared/helpers');
const { DecryptError } = require('../../../shared/lib/decrypt-error');
const { decryptRow } = require('../app/flow-recipe-steps/serializer');
const { maskRequestSent } = require('../app/flow-recipe-runs/serializer');
const { egressAllowedForUrl } = require('../../../shared/lib/egress-policy');
const { t } = require('../../db');
const { mapRowsFromDb } = require('../../lib/dto-mapper');
const {
  FLOW_EVENT, FLOW_ERROR_STATUS, loadStepRow, loadRecipeGate, writeFlowAudit,
  resolveRequest, runEdgeExecute, breaker, resolveAndPin, DEFAULT_TIMEOUT_MS, DEFAULT_MAX_BYTES,
} = require('../../lib/flow-dispatch');
const { TABLES } = require('../../../shared/constants');
const { buildDispatchContext } = require('../../lib/flow-template-context');
const { verifyCompareToken } = require('../../../shared/lib/compare-token');
const { stepRunsInMode } = require('../../../shared/lib/flow-step-select');
const { logger: rootLogger } = require('../../../shared/lib/logger');
// The same reading of the same column as the connector dispatch gate — one
// module, so the two cannot drift. See review-status.js.
const { dispatchAllowed } = require('../../lib/review-status');

const logger = rootLogger.child({ module: 'edge-flow-steps-internal' });

// SECURITY: clamp per-step dispatch timeouts to the fixed S2S proxy budget
// (125 s). An unbounded timeout lets an editor-stored value hold an outbound
// socket open far past the proxy window → proxy aborts while work continues,
// producing phantom retries and resource exhaustion on the target.
const MAX_STEP_TIMEOUT_MS = 120_000;

function hostOf(url) { try { return new URL(url).host; } catch { return null; } }

router.post('/prepare', async (req, res) => {
  const { step_id: stepId, inputs = {}, run_id: runId = null, compare_token: compareToken = null } = req.body || {};
  const safeInputs = (inputs && typeof inputs === 'object' && !Array.isArray(inputs)) ? inputs : {};
  const isAdmin = req.user?.role === 'admin';

  if (!stepId || typeof stepId !== 'string') {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'step_id required' });
  }

  let conn;
  try {
    conn = await pool.rw.getConnection();
    const rawStep = await loadStepRow(conn, stepId);
    if (!rawStep) { return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Step not found' }); }
    // SAFETY: the MariaDB driver returns JSON columns (auth_config, request_config,
    // …) as raw strings. Map through the dto-mapper here so every
    // downstream consumer — decryptRow, resolveRequest, runEdgeExecute — receives
    // parsed objects, not strings. Without this, resolveRequest reads rc.headers /
    // rc.body off a string (undefined) so custom headers and {{payload}} fills are
    // silently dropped, and decryptAuthConfig's leaf-walk is a no-op on a string.
    const step = mapRowsFromDb('flow_recipe_steps', [rawStep])[0];

    // SECURITY: server-resolved template context (spec 2026-07-11-flow-recipe-
    // template-context). run_id is optional (test-mode /prepare omits it). When
    // present it is a server-minted UUID that binds this dispatch to one run; it
    // is NOT trusted until re-verified here. Mirror run-finalize's binding
    // (flow-recipes-run.js): the run must belong to THIS step's recipe AND to the
    // caller (or an admin). Any mismatch — including a run_id that resolves to no
    // row — is a forbidden cross-run reference → 403 with no bag, so a leaked or
    // guessed id can never pull another run's (or template's) metadata into the
    // outbound request. Only after the binding holds is the context.template.*
    // bag built from the run's server-verified template_id.
    // The dispatch's server-resolved subject: { templateId, blueprintId } for the
    // context.template.* bag. It comes from ONE of two server-authoritative
    // sources, never from client-supplied context — a verified run row, or a
    // verified compare token. compareMode drives the read-only compare pass
    // (GET-only, nothing persisted on the happy path).
    let dispatchSubject = null;
    let compareMode = false;
    if (compareToken != null) {
      // The compare token is the authorization compare-begin already established
      // (owner/delegated/admin template access) and cannot be forged: signature,
      // expiry, and its bound caller + recipe are all checked. A bad/expired/
      // foreign token fails closed here — it never silently degrades to a
      // production or ad-hoc dispatch. A token issued for template A / recipe A
      // presented against a step of recipe B is refused by the recipe binding,
      // and template A is signed in, so the bag can only ever be template A's.
      const v = verifyCompareToken(compareToken, Date.now());
      if (!v.ok || v.claims.userId !== req.user?.id || v.claims.recipeId !== step.recipe_id) {
        return sendError(req, res, null, { status: 403, code: 'COMPARE_TOKEN_INVALID', reason: 'Compare token is not valid for this request' });
      }
      // The token only proves the CALLER may compare against this RECIPE
      // (owner/delegated/admin template access, checked at compare-begin) --
      // it says nothing about which STEP is being dispatched. Without this,
      // a caller holding a valid token for the recipe could /prepare any of
      // the recipe's OTHER GET steps (a create/update/both step's normal
      // read), reaching a live connector response outside the create/update
      // dispatch it was never authorized for, with no run row and no
      // success audit (compareMode skips both). Re-apply the SAME predicate
      // compare-begin's own step list used to decide which steps are
      // compare-eligible in the first place (selectStepsForMode/
      // stepRunsInMode, 'compare' -- see flow-step-select.js) so the two
      // never drift: this token may only ever dispatch a step compare-begin
      // itself would have offered.
      if (!stepRunsInMode(step.step_runs_on, 'compare')) {
        return sendError(req, res, null, { status: 400, code: 'COMPARE_STEP_NOT_SELECTED', reason: 'This step is not a compare step' });
      }
      compareMode = true;
      // blueprintId is filled from the recipe gate below (loaded next), the same
      // binding run-begin stamps onto the run row from the recipe.
      dispatchSubject = { templateId: v.claims.templateId, blueprintId: null };
    } else if (runId) {
      const runRows = await conn.query(
        `SELECT id, recipe_id, template_id, blueprint_id, actor_id FROM \`${t(TABLES.FLOW_RECIPE_RUNS)}\` WHERE id = ?`,
        [runId],
      );
      const run = runRows[0];
      if (!run || run.recipe_id !== step.recipe_id || (!isAdmin && run.actor_id !== req.user?.id)) {
        return sendError(req, res, null, { status: 403, code: 'RUN_FORBIDDEN', reason: 'Run does not belong to you' });
      }
      // Bind only here (security ordering). The run's blueprint/variant NAMES are
      // resolved later at the single context fan-out, after all early-return gates.
      dispatchSubject = { templateId: run.template_id ?? null, blueprintId: run.blueprint_id ?? null };
    }

    const gate = await loadRecipeGate(conn, step.recipe_id);
    if (!gate.found) { return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Recipe not found' }); }

    // The compare pass's subject blueprint is the recipe's bound blueprint (the
    // same value run-begin stamps onto a run row), resolved here now the gate is
    // loaded so context.blueprintName fills identically to a real run.
    if (compareMode) dispatchSubject.blueprintId = gate.blueprint_id;

    // SECURITY: test-authority == CRUD edit-authority CONJUNCTION — the editor must own
    // the recipe row (owner_id IS NULL or equals caller) AND own/share its bound blueprint
    // (blueprint owner IS NULL or equals caller). A blueprint-owner who does NOT own the
    // recipe row cannot test it; the CRUD write-gate requires both conditions ANDed.
    // The role floor is defense-in-depth: user-role callers never enter the ownership
    // branches, so a should-never-exist user-role owner is still denied.
    // Skipped entirely in compareMode: the compare token IS the authorization, so
    // the test-authority computation (and its editor blueprint-owner query) is moot.
    let callerCanManageRecipe = isAdmin;
    if (!compareMode && !callerCanManageRecipe && req.user?.role === 'editor') {
      const ownerOk = gate.owner_id == null || gate.owner_id === req.user?.id;
      if (ownerOk) {
        if (gate.blueprint_id != null) {
          const bpRows = await conn.query(
            `SELECT owner_id FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ?`,
            [gate.blueprint_id],
          );
          if (bpRows.length) {
            const bpOwner = bpRows[0].owner_id;
            callerCanManageRecipe = bpOwner == null || bpOwner === req.user?.id;
          }
        } else {
          callerCanManageRecipe = true;
        }
      }
    }
    const effectiveTest = !compareMode && (req.body || {}).test === true && callerCanManageRecipe;
    // A compare pass and a test dispatch are both read-only: neither trips the
    // breaker, and the recipe active/approval gates were already applied when the
    // compare token was minted (compare-begin), so a mid-window state change on a
    // 5-minute token must not hard-fail a read-only preview.
    const readOnly = effectiveTest || compareMode;

    if (!gate.is_active && !readOnly) { return sendError(req, res, null, { status: 409, code: 'RECIPE_INACTIVE', reason: 'Recipe is inactive' }); }
    if (!readOnly && !dispatchAllowed(gate.status)) {
      return sendError(req, res, null, { status: 422, code: 'RECIPE_NOT_APPROVED', reason: 'Recipe is awaiting admin approval' });
    }

    if (step.dispatch_origin !== 'edge' && step.dispatch_origin !== 'infra') {
      return sendError(req, res, null, { status: 501, code: 'NOT_IMPLEMENTED', reason: 'Unsupported dispatch origin' });
    }

    // Gate the breaker before touching the decrypted secret: an open circuit
    // must not cause a decrypt attempt on a connector that won't be dispatched.
    if (!readOnly && !breaker.canDispatch(step.id)) {
      return sendError(req, res, null, { status: 503, code: 'CONNECTOR_CIRCUIT_OPEN', reason: 'Step temporarily unavailable' });
    }

    let decrypted;
    try { decrypted = decryptRow(step); }
    catch (de) {
      if (de instanceof DecryptError) { return sendError(req, res, de, { status: 422, code: de.code, reason: de.message }); }
      throw de;
    }

    // The server-authoritative context.* bag, built by ONE shared helper from a
    // server-resolved subject (a verified run row or a verified compare token) —
    // never from client-supplied context. Deliberately AFTER every early-return
    // path (binding 403, recipe gate, decrypt) so no query starts before a branch
    // that could abandon it. An absent/unresolvable value is OMITTED → the token
    // fails closed through MISSING_INPUT rather than filling an empty string. On
    // an ad-hoc test (no run, no compare token) the subject is null → only the
    // caller scalars (context.userId / displayName) resolve, exactly as before.
    const contextBag = await buildDispatchContext(conn, {
      templateId: dispatchSubject ? dispatchSubject.templateId : null,
      blueprintId: dispatchSubject ? dispatchSubject.blueprintId : null,
      userId: req.user?.id ?? null,
    });

    // SECURITY: the dispatch fill bag has two provenance classes in DISJOINT key
    // namespaces by construction, so no strip list / alias table is needed:
    //   - client input → renamed to `payload.<k>`, EXCEPT the literal key
    //     `payload` (the whole stage-② message token) which passes through
    //     unchanged. A client key can therefore NEVER produce a `context.*` key.
    //   - server bag (`context.template.*` + context scalars) → the ONLY source
    //     of `context.*` keys, spread LAST.
    // Because client input is structurally unable to fill any `context.*` token,
    // `context.*` is server-authoritative by construction — a spoofed client
    // `context.userId` becomes the harmless `payload.context.userId` and can never
    // shadow the server value (spec: v3.2.417 C1 "client may only relay a signal").
    const dispatchInputs = {};
    for (const key of Object.keys(safeInputs)) {
      const renamed = key === 'payload' ? 'payload' : `payload.${key}`;
      dispatchInputs[renamed] = safeInputs[key];
    }
    // Server context bag, spread last.
    Object.assign(dispatchInputs, contextBag);

    let resolved;
    try { resolved = resolveRequest(decrypted, dispatchInputs); }
    catch (re) {
      if (re.code === 'MISSING_INPUT') { return sendError(req, res, re, { status: 400, code: 'MISSING_INPUT', reason: `Missing input(s): ${re.missing.join(', ')}` }); }
      throw re;
    }

    // THE COMPARE READ-ONLY GUARD AT DISPATCH TIME. compare-begin already refuses
    // a compare-only step whose stored method is not GET, but that is an authoring
    // check on the list it returns; THIS is the check at the one place a broken
    // promise would actually fire an outbound write. A compare token can never
    // dispatch anything but a GET, closing the dispatch-time gap.
    if (compareMode && (resolved.method || 'GET').toUpperCase() !== 'GET') {
      return sendError(req, res, null, { status: 400, code: 'COMPARE_STEP_NOT_READONLY', reason: 'A compare step must be a GET request' });
    }

    const host = hostOf(resolved.url);

    const egress = await egressAllowedForUrl(resolved.url, resolved.method, (sql, params) => conn.query(sql, params), t, { applyDefaultDeny: true });
    if (!egress.ok) {
      await writeFlowAudit(conn, uuidv4(), FLOW_EVENT.failed, req.user?.id, { step_id: step.id, recipe_id: step.recipe_id, run_id: runId, host, method: resolved.method, error_code: 'EGRESS_BLOCKED', reason: egress.reason });
      return sendError(req, res, null, { status: 422, code: 'EGRESS_BLOCKED', reason: 'Step request is not on the admin egress allow-list' });
    }

    const pendingId = uuidv4();
    // A compare pass persists nothing on the happy path: skip the PENDING row
    // (and the SUCCESS row — at the edge closure below, and at infra's own /result
    // hop). Its blocked/failed rows are KEPT — EGRESS_BLOCKED / SSRF_BLOCKED are
    // security events, and a failed compare GET is still worth a trace. A test
    // chain keeps all its audit rows exactly as before. pendingId stays a fresh
    // id so /result's idempotency dedupe still holds if a failure IS reported.
    if (!compareMode) {
      await writeFlowAudit(conn, pendingId, FLOW_EVENT.pending, req.user?.id, { step_id: step.id, recipe_id: step.recipe_id, run_id: runId, host, method: resolved.method });
    }

    if (step.dispatch_origin === 'edge') {
      // Release the rw lease BEFORE the inline outbound call so a slow step
      // cannot exhaust the pool across its timeout window.
      conn.release(); conn = null;
      // Best-effort closing audit: a pool-saturation failure on the short-lived
      // audit lease must NOT turn a successful step execution into a failure.
      const audit = async (kind, meta) => {
        // Compare persists no success row; a failed compare step keeps its trace.
        if (kind === 'success' && compareMode) return;
        let ac;
        try { ac = await pool.rw.getConnection(); }
        catch (acqErr) { req.log.warn({ err: acqErr, stepId }, 'edge closing audit: lease failed (best-effort)'); return; }
        try {
          // runEdgeExecute labels its metadata key connector_id (shared primitive);
          // the flow audit contract uses step_id — rename before writing.
          const m = { ...meta };
          if ('connector_id' in m) { m.step_id = m.connector_id; delete m.connector_id; }
          await writeFlowAudit(ac, uuidv4(), kind === 'success' ? FLOW_EVENT.success : FLOW_EVENT.failed, req.user?.id, { ...m, recipe_id: step.recipe_id, run_id: runId });
        } finally { ac.release(); }
      };
      try {
        const out = await runEdgeExecute({ id: step.id, timeout_ms: step.timeout_ms ? Math.min(step.timeout_ms, MAX_STEP_TIMEOUT_MS) : undefined }, resolved, host, audit, { skipBreaker: readOnly, req });
        // C-1: request_sent is a Test/chain-only field — a production
        // (non-test) dispatch must not carry the key at all, not even null.
        const envelope = effectiveTest
          ? { ...out, request_sent: maskRequestSent({ decrypted, inputs: dispatchInputs, resolveRequest, dispatchedHeaders: resolved.headers, step }) }
          : { ...out };
        return res.json(apiOk({ mode: 'edge', envelope, test: effectiveTest, compare: compareMode }));
      } catch (de) {
        const status = FLOW_ERROR_STATUS[de.code] || 502;
        return sendError(req, res, de, { status: status, code: de.code || 'CONNECTOR_ERROR', reason: 'Step request failed' });
      }
    }

    let pin;
    try { pin = await resolveAndPin(new URL(resolved.url).hostname); }
    catch (pe) {
      if (!readOnly) breaker.recordFailure(step.id);
      await writeFlowAudit(conn, uuidv4(), FLOW_EVENT.failed, req.user?.id, { step_id: step.id, recipe_id: step.recipe_id, run_id: runId, host, method: resolved.method, error_code: 'SSRF_BLOCKED' });
      return sendError(req, res, pe, { status: 422, code: 'SSRF_BLOCKED', reason: 'Step request failed' });
    }
    return res.json(apiOk({
      mode: 'infra', test: effectiveTest, compare: compareMode, dispatch_id: pendingId, step_id: step.id, recipe_id: step.recipe_id, run_id: runId,
      // SECURITY: prepared.headers is the real secret over the S2S channel to
      // infra; request_sent.headers is the masked copy for the browser — the
      // two must not be conflated. C-1: only attached on a test dispatch —
      // never sent, not even as null, on a production (non-test) run.
      ...(effectiveTest ? { request_sent: maskRequestSent({ decrypted, inputs: dispatchInputs, resolveRequest, dispatchedHeaders: resolved.headers, step }) } : {}),
      prepared: {
        method: resolved.method, url: resolved.url, headers: resolved.headers, body: resolved.body,
        pinned_ip: pin.address, family: pin.family,
        timeout_ms: Math.min(step.timeout_ms || DEFAULT_TIMEOUT_MS, MAX_STEP_TIMEOUT_MS), max_bytes: DEFAULT_MAX_BYTES,
        // allowed_hosts is never sent (dropped T8); an older infra
        // treats the absent key as allow-all — matches the enforced policy.
      },
    }));
  } catch (err) {
    sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Dispatch failed', fields: { stepId } });
  } finally {
    if (conn) conn.release();
  }
});

const _settled = new Set();
const _SETTLED_CAP = 5000;

router.post('/result', async (req, res) => {
  const { dispatch_id: rawDispatchId, step_id: stepId, recipe_id: recipeId, run_id: runId, success, upstream_status: upstreamStatus, duration_ms: durationMs, error_code: errorCode, host, method, test } = req.body || {};
  const isTest = test === true;
  if (!stepId || typeof stepId !== 'string') { return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'step_id required' }); }
  const dispatchId = typeof rawDispatchId === 'string' ? rawDispatchId : null;
  if (dispatchId && _settled.has(dispatchId)) return res.json(apiOk({ recorded: false, reason: 'duplicate' }));
  let conn;
  try {
    conn = await pool.rw.getConnection();
    if (success) {
      if (!isTest) breaker.recordSuccess(stepId);
      await writeFlowAudit(conn, uuidv4(), FLOW_EVENT.success, req.user?.id, { step_id: stepId, recipe_id: recipeId || null, run_id: runId || null, host: host || null, method: method || null, upstream_status: upstreamStatus ?? null, duration_ms: durationMs ?? null });
    } else {
      if (!isTest) breaker.recordFailure(stepId);
      await writeFlowAudit(conn, uuidv4(), FLOW_EVENT.failed, req.user?.id, { step_id: stepId, recipe_id: recipeId || null, run_id: runId || null, host: host || null, method: method || null, error_code: errorCode || 'CONNECTOR_ERROR' });
    }
    if (dispatchId) { if (_settled.size >= _SETTLED_CAP) _settled.clear(); _settled.add(dispatchId); }
    return res.json(apiOk({ recorded: true }));
  } catch (err) {
    sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Result record failed', fields: { stepId } });
  } finally { if (conn) conn.release(); }
});

module.exports = router;
