/**
 * machine-token.js — Edge-side machine-token resolution (S2S-only).
 *
 * Mounted at /edge/internal/machine-token behind s2sVerify — only infra reaches
 * it, so this is never a public surface. Infra extracts the customer's
 * app-issued API key (via either carrier — the gateway's `api_key` header or a
 * direct `Authorization: Bearer`) and calls POST /resolve here; edge hashes the
 * key, looks up token_hash, checks is_active, and returns { sub, scope } or a
 * uniform 401. Revocation (is_active=0) is effective on the very next request —
 * no signing, no JWKS, no token cache.
 *
 * SECURITY: unknown-token and inactive-account both return the SAME generic
 * `invalid_token` — no enumeration. A dummy constant-time compare runs on a miss
 * so unknown vs known is timing-indistinguishable. The distinguishing reason is
 * written to login_audit (internal-only); the token and its hash are NEVER
 * logged, returned, or stored in the audit row.
 */
const router = require('express').Router();
const { pool, t } = require('../../db');
const { TABLES } = require('../../../shared/constants');
const { logger: rootLogger } = require('../../../shared/lib/logger');
const { hashToken, verifyTokenHash } = require('../../lib/machine-token-hash');
const { sendAvailability } = require('../../../shared/lib/send-error');

const logger = rootLogger.child({ module: 'machine-token-resolve' });

// Bound the untrusted token before any hashing or DB touch. APISIX opaque
// tokens are short; the cap only guards against pathological input.
const MAX_TOKEN_LEN = 4096;

// SECURITY: a fixed 64-char hex hash to verify against when no row matches, so
// an unknown token takes the same constant-time compare path as a known one.
const DUMMY_TOKEN_HASH = '0'.repeat(64);

function sanitizeAuditInfo(input) {
  const info = input && typeof input === 'object' ? input : {};
  const ip = typeof info.ip === 'string' && info.ip.length <= 64 ? info.ip : null;
  const userAgent = typeof info.userAgent === 'string' && info.userAgent.length <= 512
    ? info.userAgent
    : null;
  return { ip, userAgent };
}

async function writeFailureAudit(reason, audit) {
  // Best-effort: a failed audit write must never change the resolve outcome, but
  // silently dropping it would defeat the brute-force record, so log on failure.
  // SECURITY: username is a fixed empty marker — there is no non-secret identity
  // to record for a failed resolve (the only identifier is the token/hash, which
  // must never be logged).
  const conn = await pool.rw.getConnection().catch((err) => {
    logger.warn({ err }, 'machine_token audit write skipped — rw pool unavailable (non-critical)');
    return null;
  });
  if (!conn) return;
  try {
    await conn.query(
      `INSERT INTO \`${t(TABLES.LOGIN_AUDIT)}\` (id, username, auth_provider, reason, ip_address, user_agent, success)
       VALUES (UUID(), '', 'machine_token', ?, ?, ?, FALSE)`,
      [reason, audit.ip, audit.userAgent]
    ).catch((err) => logger.warn({ err }, 'machine_token audit write failed (non-critical)'));
  } finally {
    conn.release();
  }
}

router.post('/resolve', async (req, res) => {
  const body = req.body || {};
  const token = body.token;
  const audit = sanitizeAuditInfo(body.auditInfo);

  // Untrusted string: type + length bound before any hashing / DB touch. A
  // malformed token never reaches the DB and is not audited (no reason applies).
  const tokenValid = typeof token === 'string' && token.length > 0 && token.length <= MAX_TOKEN_LEN;
  if (!tokenValid) {
    return res.status(401).json({ error: 'invalid_token' });
  }

  const tokenHash = hashToken(token);

  let row;
  try {
    // SECURITY: read the authoritative WRITER, not a read replica. On async
    // replication a just-deactivated account could still read is_active=1 from a
    // stale replica — auth decisions must never race replica lag.
    const conn = await pool.rw.getConnection();
    try {
      const rows = await conn.query(
        `SELECT id, token_hash, scope, is_active FROM \`${t(TABLES.SERVICE_ACCOUNTS)}\` WHERE token_hash = ?`,
        [tokenHash]
      );
      if (rows.length) row = rows[0];
    } finally {
      conn.release();
    }
  } catch (err) {
    return sendAvailability(req, res, {
      target: 'edge:service-accounts-db',
      body: { error: 'temporarily_unavailable' },
      err,
    });
  }

  // SECURITY: constant-time re-verify of the presented token against the row's
  // PERSISTED token_hash (not the just-computed lookup value), so a corrupt/
  // partial stored hash cannot authenticate; a fixed dummy hash on a miss keeps
  // an unknown token on the same timing path as a known one.
  const hashOk = verifyTokenHash(token, row ? row.token_hash : DUMMY_TOKEN_HASH);
  const isActive = !!row && (row.is_active === 1 || row.is_active === true);

  if (!row || !hashOk || !isActive) {
    const reason = (!row || !hashOk) ? 'unknown_token' : 'inactive';
    await writeFailureAudit(reason, audit);
    return res.status(401).json({ error: 'invalid_token' });
  }

  let scope;
  try {
    // MariaDB JSON is LONGTEXT — a corrupt row must not throw inside the async
    // handler (unhandled rejection). Treat a malformed scope as unavailable.
    scope = typeof row.scope === 'string' ? JSON.parse(row.scope) : row.scope;
  } catch (err) {
    return sendAvailability(req, res, {
      target: 'edge:service-accounts-db',
      body: { error: 'temporarily_unavailable' },
      err,
    });
  }

  // Best-effort last_used_at stamp: must not fail a valid resolve.
  try {
    const conn = await pool.rw.getConnection();
    try {
      await conn.query(
        `UPDATE \`${t(TABLES.SERVICE_ACCOUNTS)}\` SET last_used_at = NOW() WHERE id = ?`,
        [row.id]
      );
    } finally {
      conn.release();
    }
  } catch (err) {
    req.log.warn({ err }, 'service_account last_used_at update failed (non-critical)');
  }

  return res.status(200).json({ sub: row.id, scope });
});

module.exports = router;
