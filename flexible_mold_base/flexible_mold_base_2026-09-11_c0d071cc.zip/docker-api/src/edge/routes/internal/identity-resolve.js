/**
 * identity-resolve.js — Edge-side identity resolution (S2S-only).
 *
 * Replaces the direct DB access that infra/middleware/auth.js used to do.
 * Infra never imports the pool; it calls this endpoint via S2S and edge
 * performs the DB lookup + JIT provisioning + banned-audit write.
 *
 * Sources:
 *   - 'oidc'        — claims body, JIT provision via shared/jit-provisioner
 *   - 'jwt-bearer'  — userId body, RO lookup + banned audit
 *
 * Pool not ready: returns user=null + pool_ready=false + auth_mode resolved
 * from env so infra can fall back to JWT-payload identity in setup mode
 * without crashing the wizard.
 */
const router = require('express').Router();
const { sendError } = require('../../../shared/lib/send-error');
const { pool, t, isPoolReady } = require('../../db');
const { apiOk, apiError } = require('../../../shared/helpers');
const { resolveAuthMode, resolveAuthModeAsync } = require('../../../shared/config');
const { TABLES } = require('../../../shared/constants');
const { mapTokenToUser } = require('../../../lib/keycloak-token-mapper');
const { jitProvision } = require('../../../lib/jit-provisioner');
const { logger: rootLogger } = require('../../../shared/lib/logger');

const logger = rootLogger.child({ module: 'identity-resolve' });

function sanitizeAuditInfo(input) {
  if (!input || typeof input !== 'object') return { ip: null, userAgent: null };
  const ip = typeof input.ip === 'string' && input.ip.length <= 64 ? input.ip : null;
  const userAgent = typeof input.userAgent === 'string' && input.userAgent.length <= 512
    ? input.userAgent
    : null;
  return { ip, userAgent };
}

router.post('/identity-resolve', async (req, res) => {
  const body = req.body || {};
  const { source } = body;
  const auditInfo = sanitizeAuditInfo(body.auditInfo);

  if (source !== 'oidc' && source !== 'jwt-bearer') {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: "source must be 'oidc' or 'jwt-bearer'" });
  }

  if (!isPoolReady()) {
    return res.json(apiOk({
      user: null,
      jit_provisioned: false,
      auth_mode: resolveAuthMode(),
      banned: false,
      pool_ready: false,
    }));
  }

  let authMode;
  try {
    authMode = await resolveAuthModeAsync(pool, t);
  } catch (err) {
    req.log.warn({ err }, 'auth_mode resolution failed; using env fallback');
    authMode = resolveAuthMode();
  }

  try {
    if (source === 'oidc') {
      const { claims } = body;
      if (!claims || typeof claims !== 'object') {
        return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'claims object required for oidc source' });
      }
      // Only a genuine interactive login (OIDC callback) sets freshLogin so an
      // already-bound user gets a Recent Logins row. Per-request token
      // re-verification omits it and must never write. Coerce: only literal
      // true counts.
      const freshLogin = body.freshLogin === true;
      const mapped = mapTokenToUser(claims);
      const conn = await pool.rw.getConnection();
      let user;
      try {
        await conn.beginTransaction();
        user = await jitProvision({ mapped, conn, t, auditInfo, freshLogin });
        await conn.commit();
      } catch (txErr) {
        await conn.rollback().catch((rbErr) => req.log.warn({ err: rbErr }, 'rollback failed'));
        throw txErr;
      } finally {
        conn.release();
      }

      if (user.banned) {
        // SAFETY: banned-audit INSERT runs on a fresh connection AFTER the JIT
        // transaction has committed. A constraint/timeout on the audit row
        // must not poison the JIT commit decision, nor leave the original tx
        // in an indeterminate state.
        const auditConn = await pool.rw.getConnection().catch((err) => {
          req.log.warn({ err, userId: user.id }, 'banned audit write skipped — rw pool unavailable (non-critical)');
          return null;
        });
        if (auditConn) {
          try {
            await auditConn.query(
              `INSERT INTO \`${t(TABLES.LOGIN_AUDIT)}\` (username, auth_provider, deptid, reason, ip_address, user_agent, success)
               VALUES (?, 'KEYCLOAK', ?, 'account_banned', ?, ?, FALSE)`,
              [user.kc_username || user.email, user.deptid, auditInfo.ip, auditInfo.userAgent]
            ).catch((auditErr) => req.log.warn({ err: auditErr }, 'banned audit write failed (non-critical)'));
          } finally {
            auditConn.release();
          }
        }
        req.log.warn({ email: user.email, userId: user.id }, 'banned user blocked from OIDC auth');
        return res.json(apiOk({
          user: null,
          jit_provisioned: false,
          auth_mode: authMode,
          banned: true,
          pool_ready: true,
        }));
      }
      // jitProvision may tag the resolved row with a transient collision marker.
      // Strip it OFF the `user` object (which becomes req.user + the cached
      // identity + /api/auth/me's body) and surface it as a sibling response
      // field so infra can quiet the identity-cache drift check without ever
      // exposing the marker to route handlers or the frontend. Undefined when no
      // collision was skipped, so it is omitted from the JSON entirely.
      const { emailResyncSkippedFor, ...userForResponse } = user;
      return res.json(apiOk({
        user: userForResponse,
        jit_provisioned: true,
        auth_mode: authMode,
        banned: false,
        pool_ready: true,
        email_resync_skipped_for: emailResyncSkippedFor,
      }));
    }

    const userId = body.userId;
    if (!userId || typeof userId !== 'string') {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'userId required for jwt-bearer source' });
    }

    const roConn = await pool.ro.getConnection();
    let userRow;
    try {
      const rows = await roConn.query(
        `SELECT id, email, role, deptid, kc_username, user_id, banned FROM \`${t(TABLES.USERS)}\` WHERE id = ?`,
        [userId]
      );
      if (rows.length) userRow = rows[0];
    } finally {
      roConn.release();
    }

    if (!userRow) {
      return res.json(apiOk({
        user: null,
        jit_provisioned: false,
        auth_mode: authMode,
        banned: false,
        pool_ready: true,
      }));
    }

    if (userRow.banned) {
      const rwConn = await pool.rw.getConnection().catch((err) => {
        req.log.warn({ err, userId: userRow.id }, 'banned audit write skipped — rw pool unavailable (non-critical)');
        return null;
      });
      if (rwConn) {
        try {
          await rwConn.query(
            `INSERT INTO \`${t(TABLES.LOGIN_AUDIT)}\` (username, auth_provider, reason, ip_address, user_agent, success)
             VALUES (?, 'LOCAL', 'account_banned', ?, ?, FALSE)`,
            [userRow.email, auditInfo.ip, auditInfo.userAgent]
          ).catch((auditErr) => req.log.warn({ err: auditErr }, 'banned audit write failed (non-critical)'));
        } finally {
          rwConn.release();
        }
      }
      req.log.warn({ email: userRow.email, userId: userRow.id }, 'banned user blocked from JWT Bearer auth');
      return res.json(apiOk({
        user: null,
        jit_provisioned: false,
        auth_mode: authMode,
        banned: true,
        pool_ready: true,
      }));
    }

    return res.json(apiOk({
      user: userRow,
      jit_provisioned: false,
      auth_mode: authMode,
      banned: false,
      pool_ready: true,
    }));
  } catch (err) {
    return sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Identity resolution failed', fields: { source } });
  }
});

module.exports = router;
