const { TABLES, FIELD_KEY_INDEX } = require('../shared/constants');
const { tableExistsInCurrentSchema } = require('./lib/table-exists');
// AR2-Q11 (spec §7 E1): the standby-cluster keep-in-one-site seed step below
// reads the new row's shape from here — "the single source the seed migration
// reads" per that constant's own doc comment (rule-types.js).
const { DEFAULT_RULE_TEMPLATE } = require('../shared/capacity/rule-types');

/**
 * migration-steps — declarative schema-migration registry + baseline constant.
 *
 * a future schema change is three edits — (1) update table-ddls.js,
 * (2) add one entry here, (3) bump PLATFORM_SCHEMA_VERSION. The shared executor
 * (migrations.js `_runMigrationSteps`) handles the table-existence guard,
 * information_schema probe, conditional DDL, error sanitisation, audit, and skip
 * accounting so each entry stays declarative.
 *
 * Entry kinds (executor branch in migrations.js):
 *   add-column   { version, kind: 'add-column', table: TABLES.X, column, ddl, step, severity }
 *                  `ddl` MUST equal the column line in table-ddls.js (Task 6 consistency test).
 *   create-table { version, kind: 'create-table', table: TABLES.Y, step, severity }
 *                  DDL is sourced from the DDL builders by physical table name.
 *   drop-column  { version, kind: 'drop-column', table: TABLES.X, column, step, severity,
 *                  alsoDropIndexes?: string[] }  — for confirmed-dead columns only (spec §4.5).
 *   custom       { version, kind: 'custom', step, severity, run: async (ctx) => {} }
 *                  ctx = { conn, t, TABLES, logger, sanitizeMigrationError }.
 *
 * INVARIANT (Task 6 consistency test): PLATFORM_SCHEMA_VERSION equals the max
 * entry `version`, or BASELINE_SCHEMA_VERSION when the registry is empty. The
 * registry shipped EMPTY after the baseline cleanup (PR1); the first real
 * entries arrived with the destructive batch (PR2, spec §4.6).
 */

// Below this stamp, migrations never run (spec §4.2). A DB stamped lower — or an
// engine-table DB with no stamp at all — is "unsupported": serve degraded, never
// touch the stamp, surface the upgrade path in schema/status.
const BASELINE_SCHEMA_VERSION = '3.2.520';

// The target the executor migrates toward and stamps on full success. Relocated
// here from db.js so registry + version live in one file; db.js re-exports it for
// existing importers.
//
// INVARIANT: this MUST equal the max entry version below (consistency test) AND
// MUST advance whenever a new entry is added — the executor gates the WHOLE run
// on `db_stamp < PLATFORM_SCHEMA_VERSION` (migrations.js), so an entry added
// without bumping this never runs on a database already stamped at the old
// value, which is exactly the population a data backfill must reach.
const PLATFORM_SCHEMA_VERSION = '3.3.11';

// T11: user_templates.created_at and
// flow_recipe_runs.created_at were declared nullable (no code path ever wrote
// NULL — an unintentional gap, table-ddls.js now declares both NOT NULL).
//
// Probe/remediation contract (Codex R2, spec §4.3/§4.7 amendment): a custom
// step carries a read-only `probe(conn, tableFn)` ("already satisfied?") plus a
// `remediationSql(tableFn)` builder of DBA-executable statements. Together they
// make the destructive/custom batch visible to the remediation workflow (the
// missing-structure comparison only sees ADDED tables/columns — a NULL→NOT NULL
// change is invisible to it) and let a re-run converge silently after a DBA has
// applied the SQL out-of-band under a CRUD-only operator account.
//
// `_createdAtSatisfied` is that probe AND the guard the executor `run()` reuses:
// true means nothing to do — the table is absent (fresh-install no-op, mirrors
// the add/drop-column convention for the infra-only-first boot pass, spec §4.2),
// the column is absent (pre-add), or the column is already NOT NULL (idempotent
// — a prior run or a DBA-applied MODIFY already aligned it).
async function _createdAtSatisfied(conn, tableFn, table, column) {
  const physical = tableFn(table);
  if (!(await tableExistsInCurrentSchema(conn, physical))) return true;
  const rows = await conn.query(
    `SELECT IS_NULLABLE FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
    [physical, column],
  );
  if (!rows.length) return true;
  return rows[0].IS_NULLABLE !== 'YES';
}

// Dirty-data-safe: a legacy NULL row is backfilled to NOW() (the row's true
// creation instant is unknowable in retrospect, and NOW() is the same value the
// DDL default would have written) BEFORE the MODIFY, so the ALTER never fails on
// an existing NULL. Idempotent via the shared probe.
async function _backfillCreatedAtNotNull(ctx, table, column) {
  const { conn, t } = ctx;
  if (await _createdAtSatisfied(conn, t, table, column)) return;
  const physical = t(table);
  await conn.query(`UPDATE \`${physical}\` SET \`${column}\` = NOW() WHERE \`${column}\` IS NULL`);
  await conn.query(
    `ALTER TABLE \`${physical}\` MODIFY COLUMN \`${column}\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP`,
  );
}

// The DBA-executable form of the backfill, keyed by the caller's table resolver
// so no physical prefix is ever hardcoded (identifier-via-tables hard rule).
// UPDATE-then-MODIFY, same order + same statement text as `run()` issues at
// boot. Terminated with `;` — the export renders these verbatim.
function _createdAtRemediationSql(tableFn, table, column) {
  const physical = tableFn(table);
  return [
    `UPDATE \`${physical}\` SET \`${column}\` = NOW() WHERE \`${column}\` IS NULL;`,
    `ALTER TABLE \`${physical}\` MODIFY COLUMN \`${column}\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;`,
  ];
}

// Assemble a created_at NOT NULL backfill registry entry with the full custom
// contract: run (executor), probe (short-circuit + read-only derive), and
// remediationSql (DBA export).
function _createdAtBackfillEntry({ table, column, step }) {
  return {
    version: '3.2.579',
    kind: 'custom',
    step,
    severity: 'warning',
    run: (ctx) => _backfillCreatedAtNotNull(ctx, table, column),
    probe: (conn, tableFn) => _createdAtSatisfied(conn, tableFn, table, column),
    remediationSql: (tableFn) => _createdAtRemediationSql(tableFn, table, column),
  };
}

// ── 3.2.598: translating the legacy lock/rule pair into a stated mode ──────
//
// "There is no production data, so no compatibility shim" is a decision about
// the CODE MODEL — the runtime must read one shape, never two, and there is no
// dual-read and no inference fallback. It is NOT a decision that existing ROWS
// need no translation, and reading it that way is what left this batch adding
// `value_source` at its default and then dropping `is_locked` with neither
// legacy state carried across. On any database that already holds fields, that
// silently unlocks every locked field and stops every computed field computing,
// with nothing said. zone-test's demo data is exactly such a database.
//
// THE TRANSLATION, in full, and the reason for each row. `is_locked` and
// `compute_rule` were INDEPENDENT before this batch: the pre-mode resolver read
// `blueprintLock = field.is_locked === true` and `computeLock = rule.overridable
// === false` as separate facts, so a row could be both. The new model cannot say
// "both" — `locked` carries no rule and `calculated` carries one — so the row
// that carries both is the one needing a decision:
//
//   is_locked | rule | becomes                          | what is preserved
//   ----------+------+----------------------------------+---------------------
//   off       | none | 'entered'   (the column default) | exact
//   off       | yes  | 'calculated', rule unchanged     | exact — read-only-ness
//                                                         still comes from the
//                                                         rule's `overridable`
//   on        | none | 'locked'                         | exact
//   on        | yes  | 'calculated', rule forced        | BOTH: the value still
//                                                         `overridable: false`     computes AND cannot
//                                                                                  be edited
//
// The last row is the decision. `locked` would have been the other candidate and
// is worse: `locked` may not carry a rule, so choosing it means deleting the
// authored rule to keep the row coherent. `calculated` + `overridable: false` is
// the faithful reading — a value that is computed and cannot be edited is
// precisely what that pair means in the new model — and it destroys nothing.
//
// WHY NEVER 'copied'. It is a presentation distinction inside the compute-backed
// pair; both run the same way. Nothing before this batch could author a mirror
// (`buildMirrorRule` is new), so no legacy row means one, and inferring intent
// from a rule's shape is the inference this column exists to abolish.
//
// WHAT THIS DOES NOT DO. It does not touch a row whose `value_source` is already
// something other than 'entered' — a re-run after an operator has authored modes
// changes nothing, which is what makes it idempotent, and also means it cannot
// repair a database that already booted this version and lost its locks. It does
// not translate `value_scope` (nothing legacy maps to it). And if `JSON_SET`
// cannot rewrite a stored rule it leaves the document as it was: the row stays
// coherent and the forced lock is the thing lost, not the rule.

/** Is the legacy pair still readable, and is any row still awaiting translation? */
async function _legacyValueSourceTranslated(conn, tableFn) {
  const physical = tableFn(TABLES.BLUEPRINT_FIELDS);
  if (!(await tableExistsInCurrentSchema(conn, physical))) return true;
  const cols = await conn.query(
    `SELECT COLUMN_NAME FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?
        AND COLUMN_NAME IN ('is_locked', 'value_source')`,
    [physical],
  );
  const present = new Set(cols.map((r) => String(r.COLUMN_NAME ?? r.column_name)));
  // No legacy column left to read, or no new column to write into (the ADD was
  // warn-skipped for want of privilege). Either way there is nothing to do, and
  // the drop that follows is itself column-existence guarded.
  if (!present.has('is_locked') || !present.has('value_source')) return true;
  const pending = await conn.query(
    `SELECT 1 FROM \`${physical}\`
      WHERE value_source = 'entered'
        AND (is_locked <> 0 OR compute_rule IS NOT NULL)
      LIMIT 1`,
  );
  return pending.length === 0;
}

/** The three UPDATEs, in DBA-executable form. Same text the executor issues. */
function _legacyValueSourceSql(tableFn) {
  const physical = tableFn(TABLES.BLUEPRINT_FIELDS);
  return [
    `UPDATE \`${physical}\` SET value_source = 'calculated',`
      + " compute_rule = COALESCE(JSON_SET(compute_rule, '$.overridable', false), compute_rule)"
      + " WHERE value_source = 'entered' AND is_locked <> 0 AND compute_rule IS NOT NULL;",
    `UPDATE \`${physical}\` SET value_source = 'calculated'`
      + " WHERE value_source = 'entered' AND (is_locked = 0 OR is_locked IS NULL)"
      + ' AND compute_rule IS NOT NULL;',
    `UPDATE \`${physical}\` SET value_source = 'locked'`
      + " WHERE value_source = 'entered' AND is_locked <> 0 AND compute_rule IS NULL;",
  ];
}

async function _translateLegacyValueSource(ctx) {
  const { conn, t: tableFn, logger: log } = ctx;
  if (await _legacyValueSourceTranslated(conn, tableFn)) return;
  // The three WHERE clauses are mutually exclusive, so order is presentation
  // only; the both-case leads because it is the one carrying a decision.
  const counts = [];
  for (const sql of _legacyValueSourceSql(tableFn)) {
    const res = await conn.query(sql);
    counts.push(Number((res && res.affectedRows) || 0));
  }
  const [lockedAndComputed, computed, locked] = counts;
  if (log && typeof log.info === 'function') {
    log.info(
      { lockedAndComputed, computed, locked },
      'schema migration translated legacy is_locked/compute_rule into value_source',
    );
  }
}

// ── 3.2.629: one field key per blueprint ──────────────────────────────────
//
// The write path probes for a clash inside its own transaction, and that probe
// is the guard on EVERY database — including the ones whose operator account
// cannot run an ALTER. This index is the backstop the probe cannot be: two
// writes claiming one key can both pass their probe, and only the index refuses
// the second.
//
// WHY THIS IS A `custom` ENTRY AND NOT A COLUMN ADD. The registry's structural
// kinds add tables and columns; an index is neither, and the missing-structure
// comparison that drives the remediation workflow cannot see one. So this entry
// carries the pair that convention asks for — a read-only `probe` ("is it
// already there") and a `remediationSql` a DBA can run under a CRUD-only
// account — and the probe is what puts the step in schema/status' pending list.
//
// WHY IT SCANS FIRST. A customer database that already holds duplicate pairs
// cannot take this index, and an unconditional ALTER would raise 1062 on every
// boot there. The step therefore counts the duplicates first and refuses itself
// with the registry's existing deliberate-skip code, which the executor accounts
// as a skip: the version stamp is held back, the audit row says `DATA_GUARD_SKIP`
// rather than an error, and the step stays VISIBLE as pending until a DBA
// resolves the duplicates — at which point the next boot creates the index with
// no further intervention. Returning quietly instead would advance the stamp,
// empty the pending list, and leave the index uncreated forever.

/** Is the index already present (or the table absent, on an infra-only boot)? */
async function _fieldKeyIndexSatisfied(conn, tableFn) {
  const physical = tableFn(TABLES.BLUEPRINT_FIELDS);
  if (!(await tableExistsInCurrentSchema(conn, physical))) return true;
  const rows = await conn.query(
    `SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?
        AND NON_UNIQUE = 0
      LIMIT 1`,
    [physical, FIELD_KEY_INDEX],
  );
  return rows.length > 0;
}

/** The DBA-executable form. Same statement the step issues at boot. */
function _fieldKeyIndexSql(tableFn) {
  const physical = tableFn(TABLES.BLUEPRINT_FIELDS);
  return [
    `ALTER TABLE \`${physical}\` ADD UNIQUE KEY \`${FIELD_KEY_INDEX}\` (blueprint_id, field_key);`,
  ];
}

async function _addFieldKeyUniqueIndex(ctx) {
  const { conn, t: tableFn, logger: log } = ctx;
  if (await _fieldKeyIndexSatisfied(conn, tableFn)) return;
  const physical = tableFn(TABLES.BLUEPRINT_FIELDS);
  // NULL on either side never collides under a UNIQUE index, so those rows are
  // not duplicates and must not hold the index back.
  const rows = await conn.query(
    `SELECT COUNT(*) AS pairs FROM (
       SELECT blueprint_id, field_key FROM \`${physical}\`
        WHERE blueprint_id IS NOT NULL AND field_key IS NOT NULL
        GROUP BY blueprint_id, field_key
       HAVING COUNT(*) > 1
     ) duplicated`,
  );
  const duplicatePairs = Number((rows[0] && rows[0].pairs) || 0);
  if (duplicatePairs > 0) {
    if (log && typeof log.warn === 'function') {
      // The COUNT only — a field key is authored content, and an audit row is
      // not where it belongs.
      log.warn(
        { duplicatePairs, step: 'blueprint_fields_field_key_unique_index' },
        'unique field-key index not created: this database still holds duplicate '
        + '(blueprint_id, field_key) pairs. The write-path probe refuses new ones; '
        + 'a DBA must resolve the existing ones, after which the next boot creates the index.',
      );
    }
    throw Object.assign(
      new Error(`${duplicatePairs} duplicate (blueprint_id, field_key) pairs present`),
      { code: 'DATA_GUARD_SKIP' },
    );
  }
  await conn.query(
    `ALTER TABLE \`${physical}\` ADD UNIQUE KEY \`${FIELD_KEY_INDEX}\` (blueprint_id, field_key)`,
  );
  if (log && typeof log.info === 'function') {
    log.info({ table: physical, index: FIELD_KEY_INDEX }, 'schema migration added unique index');
  }
}

// ── 3.2.900: index backing "which blueprints link to this one" ──────────────
//
// resolveEffectiveBlueprintIds (routes-field-ops.js) filters hierarchy_nodes on
// linked_blueprint_id directly, twice: once as a plain read (the impact
// preview) and once as a `FOR UPDATE` lock (the rename write, which depends on
// the index to lock only the rows its predicate matches — a full scan under
// `FOR UPDATE` locks every row it examines, not only the ones that match).
// PLAIN, not UNIQUE: more than one blueprint may legitimately link to the same
// target, so no data content can ever refuse this ALTER — unlike the
// UNIQUE index above, there is no duplicate-value case to scan for or skip on.
const HIERARCHY_NODES_LINKED_BLUEPRINT_INDEX = 'idx_hierarchy_nodes_linked_blueprint';

/** Is the index already present (or the table absent, on an infra-only boot)? */
async function _hierarchyNodesLinkedBlueprintIndexSatisfied(conn, tableFn) {
  const physical = tableFn(TABLES.HIERARCHY_NODES);
  if (!(await tableExistsInCurrentSchema(conn, physical))) return true;
  const rows = await conn.query(
    `SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?
      LIMIT 1`,
    [physical, HIERARCHY_NODES_LINKED_BLUEPRINT_INDEX],
  );
  return rows.length > 0;
}

/** The DBA-executable form. Same statement the step issues at boot. */
function _hierarchyNodesLinkedBlueprintIndexSql(tableFn) {
  const physical = tableFn(TABLES.HIERARCHY_NODES);
  return [
    `ALTER TABLE \`${physical}\` ADD INDEX \`${HIERARCHY_NODES_LINKED_BLUEPRINT_INDEX}\` (linked_blueprint_id);`,
  ];
}

async function _addHierarchyNodesLinkedBlueprintIndex(ctx) {
  const { conn, t: tableFn, logger: log } = ctx;
  if (await _hierarchyNodesLinkedBlueprintIndexSatisfied(conn, tableFn)) return;
  const physical = tableFn(TABLES.HIERARCHY_NODES);
  await conn.query(
    `ALTER TABLE \`${physical}\` ADD INDEX \`${HIERARCHY_NODES_LINKED_BLUEPRINT_INDEX}\` (linked_blueprint_id)`,
  );
  if (log && typeof log.info === 'function') {
    log.info(
      { table: physical, index: HIERARCHY_NODES_LINKED_BLUEPRINT_INDEX },
      'schema migration added index',
    );
  }
}

// ── 3.2.718: repin a placed VM's data-centre cache to the host it stands on ──
//
// A placed VM's data centre IS its host's; `cap_vms.site_id` is a cache of that
// answer, and every write path now keeps the cache equal to the derivation
// (children.js deriveVmSiteFromHost + syncVmSiteCache, placement-apply.js). A row
// written BEFORE those paths were made consistent can hold a `site_id` its host
// contradicts — and the two readers of that column disagree on it: the rule
// preview derives the site from the host (`rule-preview.ts` siteOfVm), the
// evaluator reads the raw column (`evaluator.ts`), so a stale cache makes a
// VM-level rule preview one membership and the evaluation another. The write
// side is already closed; this is the one-time repair of the rows that predate
// it, the boot-time form of the "re-save the host's Site" remedy those comments
// name. scenario-health already SURFACES the divergence (scenarios.js
// staleVmSiteRows); this converges it.
//
// PLACED ROWS ONLY. An UNPLACED VM (`hypervisor_id IS NULL`) owns its `site_id`
// (the operator's intended data centre, with no host to derive from), so it is
// left untouched — mirroring deriveVmSiteFromHost, which derives only when a
// host is named. `cap_hypervisors.site_id` is NOT NULL (table-ddls.js), so a
// placed VM always has a host site to copy.
//
// IDEMPOTENT + VERIFIABLE. The probe counts placed VMs whose cache disagrees
// with their host; a re-run after convergence finds zero and short-circuits. No
// DDL — a pure data UPDATE, so a CRUD-only operator account can run the
// remediationSql form out-of-band.
//
// BYTE-FOR-BYTE PARITY WITH THE WRITE PATH (_shared.js syncVmSiteCache), and both
// halves matter. The JOIN carries `h.scenario_id = v.scenario_id` so a legacy VM
// whose hypervisor_id names a FOREIGN scenario's host is not repinned to that
// host's data centre (the write path skips it; so must this). The comparison is
// `BINARY ... <=> BINARY ...`, not a bare `<=>`: `cap_vms.site_id` is CHAR(36)
// under a case-folding collation, so a case-RESPELLED id (the shape)
// reads as already-equal to a bare `<=>` and is skipped — invisible to probe,
// run AND remediationSql — while the exact-case readers (capacity-scenario-health
// site-id Set, the evaluator) count it as a dangling reference. Without BINARY
// the stamp would advance and mark this migration complete over rows it never
// touched. The single-source shape below keeps the three statements from
// drifting apart on either predicate.
const _VM_SITE_JOIN_ON = 'h.id = v.hypervisor_id AND h.scenario_id = v.scenario_id';
const _STALE_VM_SITE_PREDICATE = 'v.hypervisor_id IS NOT NULL AND NOT (BINARY v.site_id <=> BINARY h.site_id)';

/** True when nothing awaits repair: the tables are absent (fresh install), or no
 *  placed VM's cached `site_id` disagrees with the host it stands on. */
async function _vmSiteCacheAligned(conn, tableFn) {
  const vms = tableFn(TABLES.CAP_VMS);
  const hvs = tableFn(TABLES.CAP_HYPERVISORS);
  if (!(await tableExistsInCurrentSchema(conn, vms))) return true;
  if (!(await tableExistsInCurrentSchema(conn, hvs))) return true;
  const rows = await conn.query(
    `SELECT COUNT(*) AS n FROM \`${vms}\` v`
    + ` JOIN \`${hvs}\` h ON ${_VM_SITE_JOIN_ON}`
    + ` WHERE ${_STALE_VM_SITE_PREDICATE}`,
  );
  return Number(rows[0] ? rows[0].n : 0) === 0;
}

async function _backfillVmSiteCache(ctx) {
  const { conn, t } = ctx;
  if (await _vmSiteCacheAligned(conn, t)) return;
  const vms = t(TABLES.CAP_VMS);
  const hvs = t(TABLES.CAP_HYPERVISORS);
  await conn.query(
    `UPDATE \`${vms}\` v`
    + ` JOIN \`${hvs}\` h ON ${_VM_SITE_JOIN_ON}`
    + ` SET v.site_id = h.site_id`
    + ` WHERE ${_STALE_VM_SITE_PREDICATE}`,
  );
}

/** DBA-executable form, keyed by the caller's table resolver so no physical
 *  prefix is hardcoded (identifier-via-tables). Same statement text as run(). */
function _backfillVmSiteCacheSql(tableFn) {
  const vms = tableFn(TABLES.CAP_VMS);
  const hvs = tableFn(TABLES.CAP_HYPERVISORS);
  return [
    `UPDATE \`${vms}\` v`
    + ` JOIN \`${hvs}\` h ON ${_VM_SITE_JOIN_ON}`
    + ` SET v.site_id = h.site_id`
    + ` WHERE ${_STALE_VM_SITE_PREDICATE};`,
  ];
}

// T12 (spec §7 E1 / Q11): the `rac_standby` topology
// widens `cap_databases.topology`'s ENUM domain (a fifth member alongside the
// existing four) — additive to the DOMAIN, not a column, so the schema-manifest
// diff (which only sees added tables/columns) cannot see it; this custom step
// is what makes the widen visible to the executor/remediation workflow the same
// way the manifest diff makes an added column visible.
//
// Probe reads the LIVE column's declared members (not table-ddls.js — the whole
// point is "has THIS database already been widened"), so a re-run after either
// the executor's own ALTER or a DBA-applied remediationSql converges silently.
// severity 'warning': a skip (no DDL privilege) leaves every EXISTING topology
// value fully functional — only a NEW rac_standby row is unwritable until a DBA
// applies the remediation SQL, the same "degraded, not failed" shape every other
// purely-additive entry in this registry uses.
//
// D12d amendment: the probe now ALSO recognizes the RENAMED member
// (`rac_multinode_standby`) as satisfying this widen. A database that never
// passed through the old `rac_standby` spelling — a fresh install (table-ddls.js
// now declares the column at its FINAL renamed domain directly) or one that
// already ran the 3.2.784 rename entry below — has a standby-capable RAC
// member under the NEW name only; checking for the OLD literal alone would
// misreport that database as still needing this widen, and `run()` would then
// attempt to ALTER the column back to the OLD five-member domain — actively
// UNDOING the rename. The widen's actual contract ("the domain has a
// standby-capable RAC member") is satisfied by either spelling.
async function _topologyEnumHasRacStandby(conn, tableFn) {
  const physical = tableFn(TABLES.CAP_DATABASES);
  if (!(await tableExistsInCurrentSchema(conn, physical))) return true;
  const rows = await conn.query(
    `SELECT COLUMN_TYPE FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = 'topology'`,
    [physical],
  );
  if (!rows.length) return true; // column absent (pre-baseline/degraded schema) — nothing to widen
  const columnType = String(rows[0].COLUMN_TYPE);
  return /'rac_standby'/.test(columnType) || /'rac_multinode_standby'/.test(columnType);
}

async function _widenTopologyEnumForRacStandby(ctx) {
  const { conn, t } = ctx;
  if (await _topologyEnumHasRacStandby(conn, t)) return;
  const physical = t(TABLES.CAP_DATABASES);
  // MUST stay byte-identical (member list + NOT NULL) to the topology column
  // line in table-ddls.js — this is the ONE other place that ENUM literal is
  // allowed to appear (identifier-via-tables' sibling rule for enum domains).
  await conn.query(
    `ALTER TABLE \`${physical}\` MODIFY COLUMN \`topology\` `
    + `ENUM('single','primary','primary_standby','rac','rac_standby') NOT NULL`,
  );
}

/** DBA-executable form, keyed by the caller's table resolver. Same statement
 *  text as run() (modulo the trailing semicolon a standalone script needs). */
function _topologyEnumRacStandbyRemediationSql(tableFn) {
  const physical = tableFn(TABLES.CAP_DATABASES);
  return [
    `ALTER TABLE \`${physical}\` MODIFY COLUMN \`topology\` `
    + `ENUM('single','primary','primary_standby','rac','rac_standby') NOT NULL;`,
  ];
}

// ── D12d (spec §4): rename the RAC pair's STORED VALUES ──────────
//
// `rac` -> `rac_multinode`, `rac_standby` -> `rac_multinode_standby` (single /
// primary / primary_standby keep their values). Two tables carry the domain —
// `cap_databases.topology` (5-member, NOT NULL) and `cap_bundle_items.topology`
// (4-member, nullable — bundle items never gained the standby-node-count field
// a `rac_multinode_standby` row needs, so that member never joined this table's
// domain and stays absent after the rename too).
//
// EACH table's step is WIDEN -> UPDATE -> NARROW, run as three statements
// inside the ONE custom entry (not three registry entries) so an interrupted
// run always has a safe next statement to retry:
//   1. widen to the UNION of old + new members — redundant (and therefore
//      harmless) to re-issue if a previous run already widened.
//   2. UPDATE the old value to the new one — affects zero rows once no row
//      holds the old value, so a re-run after the first success is a no-op.
//   3. narrow to the new-only member list — by step 2 no row can hold an old
//      value, so the narrow never fails on live data, and redundant re-issue
//      is harmless the same way step 1's is.
// Restart after ANY of the three lands on a state where the SAME three
// statements, re-run from the top, still converge — no branch on "which step
// was I on".
//
// PROBE (pre- AND mid-state, both read "not yet done"): a database that never
// ran ANY topology migration (still the 4-member baseline ENUM, or the T12
// 5-member `rac_standby` widen only) has neither `rac_multinode` nor
// `rac_multinode_standby` as a member — not satisfied. A database mid-run
// (the superset widen has landed, rename/narrow have not) still carries the
// OLD members alongside the new ones — also not satisfied, because the probe
// requires the new members present AND the old members ABSENT. Only the fully
// narrowed end state — new members present, old members gone — reads
// satisfied, which is also the only state a `remediationSql`-only DBA run
// (no boot-time `run()`) converges to, matching the executor's own read.
//
// severity 'warning' (matches every other purely-domain-widening entry in
// this registry): a skip (no DDL privilege) leaves every EXISTING row exactly
// as it reads today — a database whose live rows still say `rac`/`rac_standby`
// is UNCHANGED by a skip, not corrupted by one — and every comparison this
// release ships (isRacMultiNodeDatabase, database-bulk-create.js, wizard.js,
// name-patterns.js) now looks for the NEW spelling only, so a skipped rename
// makes an old-spelled row read as an unrecognized topology (label fns' own
// "Unknown topology" fallback, spec §4 D12) until a DBA applies the
// remediation SQL — degraded, not failed, the same shape severity 'warning'
// already encodes for every other entry here.
async function _capDatabasesTopologyRacRenamed(conn, tableFn) {
  const physical = tableFn(TABLES.CAP_DATABASES);
  if (!(await tableExistsInCurrentSchema(conn, physical))) return true;
  const rows = await conn.query(
    `SELECT COLUMN_TYPE FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = 'topology'`,
    [physical],
  );
  if (!rows.length) return true; // column absent (pre-baseline/degraded schema) — nothing to rename
  const columnType = String(rows[0].COLUMN_TYPE);
  return /'rac_multinode_standby'/.test(columnType)
    && !/'rac_standby'/.test(columnType)
    && !/'rac'/.test(columnType);
}

async function _renameCapDatabasesTopologyRac(ctx) {
  const { conn, t } = ctx;
  if (await _capDatabasesTopologyRacRenamed(conn, t)) return;
  const physical = t(TABLES.CAP_DATABASES);
  await conn.query(
    `ALTER TABLE \`${physical}\` MODIFY COLUMN \`topology\` `
    + `ENUM('single','primary','primary_standby','rac','rac_standby','rac_multinode','rac_multinode_standby') NOT NULL`,
  );
  await conn.query(`UPDATE \`${physical}\` SET topology = 'rac_multinode' WHERE topology = 'rac'`);
  await conn.query(`UPDATE \`${physical}\` SET topology = 'rac_multinode_standby' WHERE topology = 'rac_standby'`);
  // M1 (round 2 review): the pre-narrow COUNT guard alone still left a
  // window — a still-live old-release pod (rolling deploy) can INSERT
  // topology='rac'/'rac_standby' AFTER the final COUNT and BEFORE the NARROW,
  // and MariaDB then silently coerces that row to '' under non-strict sql_mode
  // (its ENUM-domain truncation-warning behaviour). Two layers close it:
  //   (1) Hold a WRITE lock on the physical table across the whole
  //       COUNT->retry->COUNT->NARROW sequence so concurrent writers BLOCK
  //       instead of racing. This is safe because the migration runs on a
  //       single DEDICATED connection — db.js getConnection()/release() bracket
  //       the entire run (edge/db.js:1074 + :1183) and it already holds the
  //       GET_LOCK advisory lock — so this table lock is connection-scoped and
  //       cannot be stranded across steps. LOCK TABLES confines this session to
  //       the locked table, so the `renamed` information_schema probe above MUST
  //       stay OUTSIDE the lock, and UNLOCK MUST run on EVERY path (incl. the
  //       throw path) via finally — otherwise the conn returns to the pool still
  //       holding a lock AND the executor's own audit INSERT (a DIFFERENT table,
  //       written in _runMigrationSteps' catch) would block on it.
  //   (2) Run the NARROW under STRICT_ALL_TABLES so that if any old value
  //       somehow survives the guard the ALTER ERRORS (this step is accounted
  //       skipped, severity 'warning' — retries next boot) instead of silently
  //       truncating. SET SESSION touches no table, so it is legal while LOCK
  //       TABLES is held; sql_mode is captured and restored (restore-then-UNLOCK
  //       ordered so UNLOCK still runs if the restore itself throws) because
  //       this same conn runs LATER migration steps. The retry UPDATE stays as a
  //       belt-and-braces recovery for the (now lock-closed) inter-UPDATE
  //       window; under the lock the first COUNT is normally already 0.
  //   TRADEOFF: an operator account with ALTER but no LOCK TABLES privilege now
  //   fails here (accounted skipped, remediationSql manual path is unaffected —
  //   it runs single-writer in a maintenance window, no lock needed) rather than
  //   silently corrupting live rows — the correct bias for a data-loss race.
  const modeRows = await conn.query('SELECT @@SESSION.sql_mode AS sqlMode');
  const prevSqlMode = modeRows[0].sqlMode;
  try {
    await conn.query(`LOCK TABLES \`${physical}\` WRITE`);
    let stillOld = await conn.query(
      `SELECT COUNT(*) AS n FROM \`${physical}\` WHERE topology IN ('rac', 'rac_standby')`,
    );
    if (Number(stillOld[0].n) > 0) {
      await conn.query(`UPDATE \`${physical}\` SET topology = 'rac_multinode' WHERE topology = 'rac'`);
      await conn.query(`UPDATE \`${physical}\` SET topology = 'rac_multinode_standby' WHERE topology = 'rac_standby'`);
      stillOld = await conn.query(
        `SELECT COUNT(*) AS n FROM \`${physical}\` WHERE topology IN ('rac', 'rac_standby')`,
      );
      if (Number(stillOld[0].n) > 0) {
        throw new Error(
          `cap_databases_topology_rac_rename: ${stillOld[0].n} row(s) still hold an old topology `
          + 'value after a second UPDATE pass — refusing to narrow the ENUM over live data',
        );
      }
    }
    await conn.query("SET SESSION sql_mode = CONCAT_WS(',', @@SESSION.sql_mode, 'STRICT_ALL_TABLES')");
    // MUST stay byte-identical (member list + NOT NULL) to the topology column
    // line in table-ddls.js — this is the ONE other place that ENUM literal is
    // allowed to appear (identifier-via-tables' sibling rule for enum domains).
    await conn.query(
      `ALTER TABLE \`${physical}\` MODIFY COLUMN \`topology\` `
      + `ENUM('single','primary','primary_standby','rac_multinode','rac_multinode_standby') NOT NULL`,
    );
  } finally {
    try {
      await conn.query('SET SESSION sql_mode = ?', [prevSqlMode]);
    } finally {
      await conn.query('UNLOCK TABLES');
    }
  }
}

/** DBA-executable form, keyed by the caller's table resolver. Same three
 *  statements `run()` issues, in the same order (modulo the trailing
 *  semicolons a standalone script needs). M1 (round 1 review): this
 *  static SQL list cannot express the row-count re-check/throw guard `run()`
 *  applies before its own NARROW, nor its WRITE-lock + STRICT_ALL_TABLES
 *  wrapper — a DBA running this by hand is expected to do so during a
 *  maintenance window (no live writers), the same assumption every other
 *  `remediationSql` entry in this registry already makes; the guard and the
 *  lock exist specifically for the boot-time `run()` path's ROLLING-DEPLOY
 *  race, which a manual, serialized single-writer DBA run does not have. */
function _capDatabasesTopologyRacRenameSql(tableFn) {
  const physical = tableFn(TABLES.CAP_DATABASES);
  return [
    `ALTER TABLE \`${physical}\` MODIFY COLUMN \`topology\` `
    + `ENUM('single','primary','primary_standby','rac','rac_standby','rac_multinode','rac_multinode_standby') NOT NULL;`,
    `UPDATE \`${physical}\` SET topology = 'rac_multinode' WHERE topology = 'rac';`,
    `UPDATE \`${physical}\` SET topology = 'rac_multinode_standby' WHERE topology = 'rac_standby';`,
    `ALTER TABLE \`${physical}\` MODIFY COLUMN \`topology\` `
    + `ENUM('single','primary','primary_standby','rac_multinode','rac_multinode_standby') NOT NULL;`,
  ];
}

// cap_bundle_items' own topology column: same WIDEN -> UPDATE -> NARROW shape,
// nullable (not NOT NULL) and 4-member both before and after — the rename
// touches only the `rac` member, `rac_standby` never joined this table's
// domain (see the batch-level doc above) so there is no second UPDATE.
async function _capBundleItemsTopologyRacRenamed(conn, tableFn) {
  const physical = tableFn(TABLES.CAP_BUNDLE_ITEMS);
  if (!(await tableExistsInCurrentSchema(conn, physical))) return true;
  const rows = await conn.query(
    `SELECT COLUMN_TYPE FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = 'topology'`,
    [physical],
  );
  if (!rows.length) return true;
  const columnType = String(rows[0].COLUMN_TYPE);
  return /'rac_multinode'/.test(columnType) && !/'rac'/.test(columnType);
}

async function _renameCapBundleItemsTopologyRac(ctx) {
  const { conn, t } = ctx;
  if (await _capBundleItemsTopologyRacRenamed(conn, t)) return;
  const physical = t(TABLES.CAP_BUNDLE_ITEMS);
  await conn.query(
    `ALTER TABLE \`${physical}\` MODIFY COLUMN \`topology\` `
    + `ENUM('single','primary','primary_standby','rac','rac_multinode') NULL DEFAULT NULL`,
  );
  await conn.query(`UPDATE \`${physical}\` SET topology = 'rac_multinode' WHERE topology = 'rac'`);
  // M1 (round 2 review): same two-layer race close as
  // `_renameCapDatabasesTopologyRac` (see that function's own doc for the full
  // rationale — dedicated conn, LOCK-confines-session, UNLOCK-on-throw, sql_mode
  // capture/restore, and the LOCK-TABLES-privilege tradeoff). WRITE-lock the
  // physical table across COUNT->retry->NARROW so a still-live old-release pod
  // cannot INSERT topology='rac' into the widened ENUM and have the NARROW
  // silently coerce it to '', and NARROW under STRICT_ALL_TABLES as a fail-loud
  // backstop.
  const modeRows = await conn.query('SELECT @@SESSION.sql_mode AS sqlMode');
  const prevSqlMode = modeRows[0].sqlMode;
  try {
    await conn.query(`LOCK TABLES \`${physical}\` WRITE`);
    let stillOld = await conn.query(
      `SELECT COUNT(*) AS n FROM \`${physical}\` WHERE topology = 'rac'`,
    );
    if (Number(stillOld[0].n) > 0) {
      await conn.query(`UPDATE \`${physical}\` SET topology = 'rac_multinode' WHERE topology = 'rac'`);
      stillOld = await conn.query(
        `SELECT COUNT(*) AS n FROM \`${physical}\` WHERE topology = 'rac'`,
      );
      if (Number(stillOld[0].n) > 0) {
        throw new Error(
          `cap_bundle_items_topology_rac_rename: ${stillOld[0].n} row(s) still hold the old topology `
          + 'value after a second UPDATE pass — refusing to narrow the ENUM over live data',
        );
      }
    }
    await conn.query("SET SESSION sql_mode = CONCAT_WS(',', @@SESSION.sql_mode, 'STRICT_ALL_TABLES')");
    // MUST stay byte-identical to the topology column line in table-ddls.js.
    await conn.query(
      `ALTER TABLE \`${physical}\` MODIFY COLUMN \`topology\` `
      + `ENUM('single','primary','primary_standby','rac_multinode') NULL DEFAULT NULL`,
    );
  } finally {
    try {
      await conn.query('SET SESSION sql_mode = ?', [prevSqlMode]);
    } finally {
      await conn.query('UNLOCK TABLES');
    }
  }
}

/** DBA-executable form; same three statements in the same order. M1
 *  (round 1 review): see `_capDatabasesTopologyRacRenameSql`'s own
 *  doc — this static SQL list cannot express `run()`'s row-count guard or its
 *  WRITE-lock + STRICT_ALL_TABLES wrapper; a manual single-writer DBA run
 *  during a maintenance window does not have the rolling-deploy race they exist
 *  for. */
function _capBundleItemsTopologyRacRenameSql(tableFn) {
  const physical = tableFn(TABLES.CAP_BUNDLE_ITEMS);
  return [
    `ALTER TABLE \`${physical}\` MODIFY COLUMN \`topology\` `
    + `ENUM('single','primary','primary_standby','rac','rac_multinode') NULL DEFAULT NULL;`,
    `UPDATE \`${physical}\` SET topology = 'rac_multinode' WHERE topology = 'rac';`,
    `ALTER TABLE \`${physical}\` MODIFY COLUMN \`topology\` `
    + `ENUM('single','primary','primary_standby','rac_multinode') NULL DEFAULT NULL;`,
  ];
}

// ── AR2-Q8: cap_bundle_items joins the +standby topology (bundle parity) ──────
//
// Bundle items historically excluded `rac_multinode_standby` (no standby-count
// field), so the rename step above narrows this column to 4 members. This step
// runs AFTER that rename (later array position; probe-idempotent) and widens
// the domain to the FULL 5-member set. Relative to the rename's POST-state
// (4-member, no 'rac') this is a PURELY ADDITIVE widen (adds a member,
// removes/renames nothing). But the two are SEPARATE registry entries, so the
// rename can skip without this one skipping — and its target domain OMITS the
// pre-rename 'rac' member, so if a 'rac' row survives (rename warn-skipped, or a
// rolling old pod re-inserted one) this ALTER would coerce it to '' under a
// non-STRICT session. run() therefore guards on a `topology = 'rac'` COUNT and
// throws (accounted a skip; holds the version stamp) rather than corrupt data.
// Otherwise same simple shape as `_widenTopologyEnumForRacStandby`.
//
// PROBE: reads the LIVE column's declared members — satisfied once
// `rac_multinode_standby` is present (a fresh install gets the 5-member ENUM
// straight from table-ddls.js; a migrated DB gets it here), so a re-run after
// either the executor's ALTER or a DBA-applied remediationSql converges
// silently. Table/column absent (pre-baseline/degraded schema) also reads
// satisfied — nothing to widen. severity 'warning': a skip (no DDL privilege)
// leaves every existing row functional; only a NEW rac_multinode_standby bundle
// item is unwritable until a DBA applies the remediation SQL.
async function _capBundleItemsTopologyHasStandby(conn, tableFn) {
  const physical = tableFn(TABLES.CAP_BUNDLE_ITEMS);
  if (!(await tableExistsInCurrentSchema(conn, physical))) return true;
  const rows = await conn.query(
    `SELECT COLUMN_TYPE FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = 'topology'`,
    [physical],
  );
  if (!rows.length) return true; // column absent (pre-baseline/degraded schema) — nothing to widen
  return /'rac_multinode_standby'/.test(String(rows[0].COLUMN_TYPE));
}

async function _widenCapBundleItemsTopologyForStandby(ctx) {
  const { conn, t } = ctx;
  if (await _capBundleItemsTopologyHasStandby(conn, t)) return;
  const physical = t(TABLES.CAP_BUNDLE_ITEMS);
  // SAFETY: this widen's target ENUM domain intentionally OMITS the pre-rename
  // 'rac' member (the rename step above collapses 'rac' -> 'rac_multinode').
  // The two steps are separate registry entries, so the rename can be skipped
  // WITHOUT this one skipping too — e.g. it warn-skips on a missing LOCK TABLES
  // privilege (errno 1142 on `LOCK TABLES`, not on the ALTER, so this step still
  // has DDL rights), or a rolling old-release pod re-INSERTs a 'rac' row after
  // the rename's pre-lock UPDATE. In either case a 'rac' row survives while
  // 'rac' is still a live member. Running the widen ALTER now, under a non-STRICT
  // session, would silently coerce every lingering 'rac' value to the empty-string
  // ENUM member ('') — irreversible data corruption. Refuse: throw so the runner
  // (_runMigrationSteps) accounts this a skip (skippedSteps>0 holds the version
  // stamp back), and the next boot re-attempts the rename first, then this widen.
  const lingeringRac = await conn.query(
    `SELECT COUNT(*) AS n FROM \`${physical}\` WHERE topology = 'rac'`,
  );
  if (Number(lingeringRac[0].n) > 0) {
    throw new Error(
      `cap_bundle_items_topology_standby_widen: ${lingeringRac[0].n} row(s) still hold the `
      + "pre-rename 'rac' topology — refusing to widen (the target ENUM omits 'rac'; altering now "
      + "would coerce them to the empty member). The rac rename must apply first; retrying next boot.",
    );
  }
  // MUST stay byte-identical (member list + NULL DEFAULT NULL) to the topology
  // column line in table-ddls.js — the ONE other place this ENUM literal is
  // allowed to appear (identifier-via-tables' sibling rule for enum domains).
  await conn.query(
    `ALTER TABLE \`${physical}\` MODIFY COLUMN \`topology\` `
    + `ENUM('single','primary','primary_standby','rac_multinode','rac_multinode_standby') NULL DEFAULT NULL`,
  );
}

/** DBA-executable form, keyed by the caller's table resolver. Same single
 *  additive-widen statement `run()` issues (modulo the trailing semicolon a
 *  standalone script needs). The final ENUM literal is the full 5-member domain
 *  — the L1 parity test extracts it and compares against table-ddls.js. */
function _capBundleItemsTopologyStandbyWidenSql(tableFn) {
  const physical = tableFn(TABLES.CAP_BUNDLE_ITEMS);
  return [
    `ALTER TABLE \`${physical}\` MODIFY COLUMN \`topology\` `
    + `ENUM('single','primary','primary_standby','rac_multinode','rac_multinode_standby') NULL DEFAULT NULL;`,
  ];
}

// ── AR2-Q11 (spec §7 E1): seed the standby-cluster keep-in-one-site default ──
//
// rule-types.js DEFAULT_RULE_TEMPLATE grew an 8th row (own doc there has the
// requirement + composition rationale). PURELY ADDITIVE to the DOMAIN — both
// 'keep-in-one-site' and 'each_standby_cluster' are already legal ENUM
// members (table-ddls.js), so this is a pure data INSERT, no DDL, no ALTER.
//
// WHY THIS MIGRATION IS NOT OPTIONAL (the C3 gap it absorbs): nothing in the
// JS codebase seeds DEFAULT_RULE_TEMPLATE into a fresh cap_rules table — the
// only prior writer is the test-only `seedRuleTemplate()` helper
// (capacity-write-identity-real-db.test.js). `rulesDifferFromTemplate`
// (_shared.js) compares the STORED global rule count+signature against the
// LIVE `DEFAULT_RULE_TEMPLATE` import, so the moment this release ships an
// 8-row template, every already-seeded (7-row) deployment reads
// `7 !== 8` -> "operator-edited" -> the first-instance config-import gate
// disables. This step restores the invariant for the population it CAN safely
// reach.
//
// SEED-MARKER DESIGN (commander ruling, replaces an earlier frozen-7-row
// byte-match eligibility that had three real problems: (1) it re-ran the
// INSERT on EVERY boot of a no-DDL deployment because a probe built only from
// live row comparison cannot distinguish "never seeded" from "seeded, then
// the operator deliberately deleted the row" — the row would silently come
// back; (2) it demanded all 7 pre-Q11 rows byte-identical, so ANY unrelated
// operator edit — a severity bump, a disabled row, an extra global rule —
// permanently blocked the seed for a real population; (3) an empty-DB
// deployment got ONLY the new 8th row seeded, an orphan rule set with no
// functional gain). A `system_settings` marker (same table/key convention as
// `platform_schema_version` — CRUD-only INSERT … ON DUPLICATE KEY UPDATE,
// works under a no-DDL operator account) written in the SAME step as the
// seed closes all three: it is the one durable "this step has already run"
// fact that survives an operator later deleting the row, and it lets the
// empty-DB branch seed the FULL current template instead of a lone row.
const AR2Q11_SEED_MARKER_KEY = 'migration_seed_ar2q11_standby_rule';

/** The new row this step inserts — read from the live registry (rule-types.js
 *  is "the single source the seed migration reads") rather than restated as a
 *  second literal that could drift from it. */
function _standbyKeepInOneSiteTemplateRow() {
  const row = DEFAULT_RULE_TEMPLATE.find(
    (r) => r.type === 'keep-in-one-site' && r.group_by === 'each_standby_cluster',
  );
  if (!row) throw new Error('cap_rules_seed_standby_keep_in_one_site: DEFAULT_RULE_TEMPLATE no longer carries a keep-in-one-site/each_standby_cluster row');
  return row;
}

function _isStandbyKeepInOneSiteRow(row) {
  return row.type === 'keep-in-one-site' && row.group_by === 'each_standby_cluster';
}

async function _globalCapRulesRows(conn, physical) {
  return conn.query(
    `SELECT type, group_by FROM \`${physical}\` WHERE scenario_id IS NULL`,
  );
}

/** True once the marker row has been written by a prior run of this step (or
 *  a DBA-applied remediationSql) — the durable "already seeded" fact that
 *  survives an operator later deleting the standby row (H1: without this, a
 *  live-row-only probe cannot tell "never seeded" from "seeded then
 *  deliberately deleted", and would re-insert the deleted row every boot). */
async function _ar2q11SeedMarkerPresent(conn, tableFn) {
  const rows = await conn.query(
    `SELECT value FROM \`${tableFn(TABLES.SYSTEM_SETTINGS)}\` WHERE \`key\` = ? LIMIT 1`,
    [AR2Q11_SEED_MARKER_KEY],
  );
  return rows.length > 0;
}

async function _writeAr2q11SeedMarker(conn, tableFn) {
  await conn.query(
    `INSERT INTO \`${tableFn(TABLES.SYSTEM_SETTINGS)}\` (\`key\`, value, description)
     VALUES (?, ?, ?)
     ON DUPLICATE KEY UPDATE value = VALUES(value)`,
    [
      AR2Q11_SEED_MARKER_KEY,
      JSON.stringify(new Date().toISOString()),
      'AR2-Q11 cap_rules_seed_standby_keep_in_one_site seed marker (fmb-1329 custom step) — do not modify',
    ],
  );
}

/** Satisfied (nothing outstanding) when: the table is absent (fresh install —
 *  table-ddls.js seeds nothing here, so there is nothing to repair), the seed
 *  marker is already present (this step ran before — including the case
 *  where the operator has since deleted the row: the marker, not the row,
 *  is what makes this idempotent), or a global standby keep-in-one-site row
 *  already exists (prior run predating the marker, or a DBA-applied
 *  remediationSql). */
async function _capRulesStandbyKeepInOneSiteSeeded(conn, tableFn) {
  const physical = tableFn(TABLES.CAP_RULES);
  if (!(await tableExistsInCurrentSchema(conn, physical))) return true;
  if (await _ar2q11SeedMarkerPresent(conn, tableFn)) return true;
  const rows = await _globalCapRulesRows(conn, physical);
  return rows.some(_isStandbyKeepInOneSiteRow);
}

/** ELIGIBILITY (never clobber operator work): an EMPTY global cap_rules set
 *  seeds the FULL current DEFAULT_RULE_TEMPLATE — otherwise a fresh instance
 *  that started with zero global rules would pick up only the new row, an
 *  orphan rule set with no functional gain (M1). A NON-EMPTY set — touched or
 *  untouched, no more byte-matching the pre-migration shape — seeds ONLY the
 *  new standby row; operator edits to OTHER rows no longer block the seed
 *  (M2). Either branch writes the marker in the same step so a subsequent
 *  operator deletion of the row is never silently re-seeded (H1).
 *
 *  SAFETY: the empty-set branch issues its 8 rows as a SINGLE multi-row
 *  INSERT (one statement, per-statement atomic — all 8 or none). Rows were
 *  previously inserted one-at-a-time in a loop; a transient failure mid-loop
 *  committed a partial set, and the retry's probe then saw a non-empty
 *  `cap_rules` set and took the seed-one-row branch forever, leaving the
 *  default template permanently short. The marker write stays its own
 *  statement AFTER the seed insert: `_capRulesStandbyKeepInOneSiteSeeded`
 *  treats an existing standby row OR the marker as "already seeded", so a
 *  marker-write failure after a successful 8-row insert cannot cause
 *  re-seeding — the next probe finds the standby row already present and
 *  returns satisfied via that path, not the marker. */
async function _seedStandbyKeepInOneSiteRule(ctx) {
  const { conn, t } = ctx;
  if (await _capRulesStandbyKeepInOneSiteSeeded(conn, t)) return;
  const physical = t(TABLES.CAP_RULES);
  const rows = await _globalCapRulesRows(conn, physical);
  const rowsToSeed = rows.length === 0 ? DEFAULT_RULE_TEMPLATE : [_standbyKeepInOneSiteTemplateRow()];
  const valueTuples = rowsToSeed.map(() => '(UUID(), NULL, ?, ?, ?, ?, ?, ?, ?)').join(', ');
  const params = rowsToSeed.flatMap((row) => [
    row.type, row.name, row.level, row.group_by, JSON.stringify(row.params || {}), row.severity, row.enabled ? 1 : 0,
  ]);
  await conn.query(
    `INSERT INTO \`${physical}\` (id, scenario_id, type, name, level, group_by, params, severity, enabled)
     VALUES ${valueTuples}`,
    params,
  );
  await _writeAr2q11SeedMarker(conn, t);
}

/** DBA-executable form, keyed by the caller's table resolver. Mirrors run()'s
 *  two branches in pure SQL (no `conn` is available at generation time, so
 *  the branch decision itself has to travel in the WHERE clause rather than
 *  in JS) — and mirrors run()'s EMPTY-SET-ONLY semantic for the 7
 *  non-standby rows: they are inserted (as one statement, a UNION ALL of all
 *  7 row tuples) ONLY when the global `cap_rules` set is empty. A prior
 *  version guarded each of the 7 rows independently by its own (type,
 *  group_by) identity, which meant it BACKFILLED template rows an operator
 *  had deliberately deleted from a customized (non-empty) set — diverging
 *  from run(), which only ever adds the standby row to a non-empty set. That
 *  per-row-identity guard also had a latent sequential-skip risk: statements
 *  run one at a time by a DBA, so any row-agnostic "is the whole set empty"
 *  guard evaluated per-statement would see the set as non-empty after
 *  statement 1 inserted a row and skip the rest. Folding all 7 rows into ONE
 *  statement removes that risk entirely — the empty-set guard is evaluated
 *  exactly once, against the pre-script state, for the whole tuple set. The
 *  standby row keeps its own (type, group_by) guard (fires in BOTH branches,
 *  same as run()). The marker upsert always runs last, same as run().
 *  Literal values (not a placeholder-driven query) so a CRUD-only operator
 *  account can paste this directly. */
function _seedStandbyKeepInOneSiteRuleSql(tableFn) {
  const physical = tableFn(TABLES.CAP_RULES);
  const settingsPhysical = tableFn(TABLES.SYSTEM_SETTINGS);
  const standbyRow = _standbyKeepInOneSiteTemplateRow();
  const nonStandbyRows = DEFAULT_RULE_TEMPLATE.filter((row) => !_isStandbyKeepInOneSiteRow(row));
  const selects = nonStandbyRows
    .map((row) => {
      const params = JSON.stringify(row.params || {}).replace(/'/g, "''");
      const name = row.name.replace(/'/g, "''");
      return ` SELECT UUID(), NULL, '${row.type}', '${name}', '${row.level}', '${row.group_by}', '${params}', '${row.severity}', ${row.enabled ? 1 : 0}`;
    })
    .join(' UNION ALL');
  const statements = [
    // WHERE on a bare `SELECT a UNION ALL SELECT b ... FROM DUAL WHERE ...`
    // binds ONLY to the last arm of the union, not the whole set — a DBA
    // running this against a non-empty customized set would get the other
    // N-1 rows inserted unconditionally. Wrap the union in a derived table
    // and apply the guard once to the outer SELECT instead. Self-reference
    // to `physical` inside NOT EXISTS from an INSERT...SELECT is already
    // used unguarded by the standby-row statement below (same table, same
    // shape) with no ER_UPDATE_TABLE_USED issue, so no double-wrap needed.
    `INSERT INTO \`${physical}\` (id, scenario_id, type, name, level, group_by, params, severity, enabled)`
    + ` SELECT * FROM (${selects}) AS seed_rows`
    + ` WHERE NOT EXISTS (SELECT 1 FROM \`${physical}\` WHERE scenario_id IS NULL);`,
  ];
  const standbyParams = JSON.stringify(standbyRow.params || {}).replace(/'/g, "''");
  const standbyName = standbyRow.name.replace(/'/g, "''");
  statements.push(
    `INSERT INTO \`${physical}\` (id, scenario_id, type, name, level, group_by, params, severity, enabled)`
    + ` SELECT UUID(), NULL, '${standbyRow.type}', '${standbyName}', '${standbyRow.level}', '${standbyRow.group_by}', '${standbyParams}', '${standbyRow.severity}', ${standbyRow.enabled ? 1 : 0}`
    + ` FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM \`${physical}\` WHERE scenario_id IS NULL AND type = '${standbyRow.type}' AND group_by = '${standbyRow.group_by}');`,
  );
  statements.push(
    `INSERT INTO \`${settingsPhysical}\` (\`key\`, value, description)`
    + ` VALUES ('${AR2Q11_SEED_MARKER_KEY}', '"1"', 'AR2-Q11 cap_rules_seed_standby_keep_in_one_site seed marker (fmb-1329 custom step) - do not modify')`
    + ` ON DUPLICATE KEY UPDATE value = VALUES(value);`,
  );
  return statements;
}

// A general repair for the "template row shipped without a backfill migration"
// class. `keep-apart / each_standby_cluster` (rule-types.js) entered
// DEFAULT_RULE_TEMPLATE in an earlier release with no migration step, so every
// deployment that upgraded through it with a NON-EMPTY global rule set is
// missing that row — the standby keep-in-one-site seed above only ever adds
// ITS own row to a non-empty set, and table-ddls.js seeds nothing here. Rather
// than patch that single row (a fix that would have to grow a new arm for the
// next such gap), this step reconciles the WHOLE template: it inserts any
// DEFAULT_RULE_TEMPLATE global row the deployment is missing, exactly once,
// gated by its own durable system_settings marker.
const DEFAULT_RULE_TEMPLATE_RECONCILE_MARKER_KEY = 'migration_reconcile_default_rule_template';

async function _defaultRuleTemplateReconcileMarkerPresent(conn, tableFn) {
  const rows = await conn.query(
    `SELECT value FROM \`${tableFn(TABLES.SYSTEM_SETTINGS)}\` WHERE \`key\` = ? LIMIT 1`,
    [DEFAULT_RULE_TEMPLATE_RECONCILE_MARKER_KEY],
  );
  return rows.length > 0;
}

async function _writeDefaultRuleTemplateReconcileMarker(conn, tableFn) {
  await conn.query(
    `INSERT INTO \`${tableFn(TABLES.SYSTEM_SETTINGS)}\` (\`key\`, value, description)
     VALUES (?, ?, ?)
     ON DUPLICATE KEY UPDATE value = VALUES(value)`,
    [
      DEFAULT_RULE_TEMPLATE_RECONCILE_MARKER_KEY,
      '"1"',
      'cap_rules default-rule-template reconcile seed marker (custom migration step) — do not modify',
    ],
  );
}

/** Satisfied (nothing outstanding) when the table is absent (fresh install —
 *  nothing to repair yet) OR the reconcile marker is already present. The
 *  marker — NOT the live row set — is the durable "this install has been
 *  offered the full template once" fact. Keying the probe on row presence
 *  instead would leave a complete-but-markerless install able to resurrect a
 *  future operator deletion of ANY default row (the same "seeded, then
 *  deliberately deleted, must not come back" hazard the standby seed step
 *  guards its single row against — generalised here to all template rows). */
async function _defaultRuleTemplateReconciled(conn, tableFn) {
  const physical = tableFn(TABLES.CAP_RULES);
  if (!(await tableExistsInCurrentSchema(conn, physical))) return true;
  return _defaultRuleTemplateReconcileMarkerPresent(conn, tableFn);
}

/** ONE-TIME reconcile: insert every DEFAULT_RULE_TEMPLATE global row the
 *  deployment is missing (matched by (type, group_by) identity), then write the
 *  marker so the offer is never repeated. Because the marker gate is what makes
 *  this durable, an operator deletion AFTER this step has run is permanent (the
 *  probe short-circuits on the marker). The first run cannot distinguish a
 *  never-seeded row from a row deleted before the marker existed — no per-row
 *  provenance is stored anywhere — so it re-offers the complete template exactly
 *  once, the same stance the standby seed's empty-set branch takes, and never
 *  again.
 *
 *  SAFETY: the missing rows travel in a SINGLE multi-row INSERT (one statement,
 *  per-statement atomic — all missing rows or none). The marker write is its own
 *  statement AFTER the insert; a marker-write failure after a successful insert
 *  cannot double-seed, because the next run recomputes `missing` against the
 *  now-present rows (empty) and only writes the marker. */
async function _reconcileDefaultRuleTemplate(ctx) {
  const { conn, t } = ctx;
  const physical = t(TABLES.CAP_RULES);
  if (!(await tableExistsInCurrentSchema(conn, physical))) return;
  if (await _defaultRuleTemplateReconcileMarkerPresent(conn, t)) return;
  const existing = await _globalCapRulesRows(conn, physical);
  const missing = DEFAULT_RULE_TEMPLATE.filter(
    (tpl) => !existing.some((r) => r.type === tpl.type && r.group_by === tpl.group_by),
  );
  if (missing.length > 0) {
    const valueTuples = missing.map(() => '(UUID(), NULL, ?, ?, ?, ?, ?, ?, ?)').join(', ');
    const params = missing.flatMap((row) => [
      row.type, row.name, row.level, row.group_by, JSON.stringify(row.params || {}), row.severity, row.enabled ? 1 : 0,
    ]);
    await conn.query(
      `INSERT INTO \`${physical}\` (id, scenario_id, type, name, level, group_by, params, severity, enabled)
       VALUES ${valueTuples}`,
      params,
    );
  }
  await _writeDefaultRuleTemplateReconcileMarker(conn, t);
}

/** DBA-executable form (no `conn` at generation time). Each template row gets
 *  its OWN (type, group_by)-guarded INSERT — deliberately UNLIKE the standby
 *  seed's seven-row whole-set-empty statement, whose guard must NOT backfill an
 *  operator-deleted row into a customized set: this step's contract is the
 *  opposite, it DOES offer every missing template row once. A per-row identity
 *  guard is sequential-safe by construction — inserting row A never changes row
 *  B's guard — so the per-statement sequential-skip that a whole-set-empty guard
 *  suffers when a DBA runs the statements one at a time cannot occur here. The
 *  marker upsert runs last so a re-derivation after apply reports satisfied.
 *  Literal-valued (not placeholder-driven) so a CRUD-only account can paste it.
 *
 *  Each per-row guard ALSO requires the marker to be absent, matching run()'s
 *  short-circuit on marker presence. Without this, a stale exported script
 *  applied AFTER the marker already exists (e.g. the in-process migration ran
 *  at boot before the operator got around to running the exported SQL) would
 *  re-check only row absence and resurrect a row an operator deliberately
 *  deleted post-reconcile — defeating the same durable-deletion contract the
 *  marker exists to protect (see _defaultRuleTemplateReconciled doc above). */
function _reconcileDefaultRuleTemplateSql(tableFn) {
  const physical = tableFn(TABLES.CAP_RULES);
  const settingsPhysical = tableFn(TABLES.SYSTEM_SETTINGS);
  const statements = DEFAULT_RULE_TEMPLATE.map((row) => {
    const params = JSON.stringify(row.params || {}).replace(/'/g, "''");
    const name = row.name.replace(/'/g, "''");
    return `INSERT INTO \`${physical}\` (id, scenario_id, type, name, level, group_by, params, severity, enabled)`
      + ` SELECT UUID(), NULL, '${row.type}', '${name}', '${row.level}', '${row.group_by}', '${params}', '${row.severity}', ${row.enabled ? 1 : 0}`
      + ` FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM \`${physical}\` WHERE scenario_id IS NULL AND type = '${row.type}' AND group_by = '${row.group_by}')`
      + ` AND NOT EXISTS (SELECT 1 FROM \`${settingsPhysical}\` WHERE \`key\` = '${DEFAULT_RULE_TEMPLATE_RECONCILE_MARKER_KEY}');`;
  });
  statements.push(
    `INSERT INTO \`${settingsPhysical}\` (\`key\`, value, description)`
    + ` VALUES ('${DEFAULT_RULE_TEMPLATE_RECONCILE_MARKER_KEY}', '"1"', 'cap_rules default-rule-template reconcile seed marker (custom migration step) - do not modify')`
    + ` ON DUPLICATE KEY UPDATE value = VALUES(value);`,
  );
  return statements;
}

// ── <PATCH-Y1>: per-step content type — copy the recipe's dialect onto its steps ─
// content_type moved from flow_recipes (one per recipe) to flow_recipe_steps
// (one per step). The three ENUM columns were added above at their DDL defaults
// (application/json, 1.2, plain). A recipe authored as YAML must carry that
// choice onto every step it already has, or the first boot after the move would
// silently re-serialize a YAML recipe's steps as JSON. Only the YAML case needs
// the copy — a JSON recipe's steps already hold the matching default — which is
// also what makes the step idempotent: a re-run finds nothing pending.
async function _perStepContentTypeSatisfied(conn, tableFn) {
  const steps = tableFn(TABLES.FLOW_RECIPE_STEPS);
  const recipes = tableFn(TABLES.FLOW_RECIPES);
  if (!(await tableExistsInCurrentSchema(conn, steps))) return true;
  if (!(await tableExistsInCurrentSchema(conn, recipes))) return true;
  // Either content_type column absent — the step add warn-skipped on a no-ALTER
  // DB, or the recipe column already dropped by the later (<PATCH-Y2>) step — means
  // there is nothing to read from or write to.
  const cols = await conn.query(
    `SELECT TABLE_NAME, COLUMN_NAME FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE() AND COLUMN_NAME = 'content_type'
        AND TABLE_NAME IN (?, ?)`,
    [steps, recipes],
  );
  const have = new Set(cols.map((r) => String(r.TABLE_NAME ?? r.table_name)));
  if (!have.has(steps) || !have.has(recipes)) return true;
  const pending = await conn.query(
    `SELECT 1 FROM \`${steps}\` s JOIN \`${recipes}\` r ON s.recipe_id = r.id
      WHERE r.content_type = 'application/yaml' AND s.content_type = 'application/json'
      LIMIT 1`,
  );
  return pending.length === 0;
}

function _perStepContentTypeSql(tableFn) {
  const steps = tableFn(TABLES.FLOW_RECIPE_STEPS);
  const recipes = tableFn(TABLES.FLOW_RECIPES);
  return [
    `UPDATE \`${steps}\` s JOIN \`${recipes}\` r ON s.recipe_id = r.id`
      + " SET s.content_type = 'application/yaml'"
      + " WHERE r.content_type = 'application/yaml' AND s.content_type = 'application/json';",
  ];
}

async function _copyRecipeContentTypeToSteps(ctx) {
  const { conn, t: tableFn, logger: log } = ctx;
  if (await _perStepContentTypeSatisfied(conn, tableFn)) return;
  for (const sql of _perStepContentTypeSql(tableFn)) await conn.query(sql);
  if (log && typeof log.info === 'function') {
    log.info({ step: 'flow_recipe_steps_content_type_backfill' },
      'schema migration copied recipe content_type onto steps');
  }
}

// ── drop the retired flow_recipes.content_type — destructive step only
// after zero readers are deployed. The code is zero-read of this column on
// the migrated path; the backfill above already copied every YAML recipe's
// dialect onto its steps.
//
// THE PRECONDITION IS NOT "every replica's code is current" — it is
// stronger: every replica's DATABASE must have successfully applied the
// ADD COLUMN that put the three dialect columns on flow_recipe_steps, i.e.
// no replica is running, or ever expected to run, in a permanently-degraded
// no-ALTER state. On such an install flow_recipe_steps never gains the
// three dialect columns, and the legacy tier at run-begin/export/import
// (loadRecipeContentTypeFallback, flow-recipes-run.js + io.js) reads
// flow_recipes.content_type as every step's dialect FOREVER, not just
// mid-rollout — dropping the column there would silently disable that
// fallback with no possible recovery, reintroducing exactly the
// silently-turns-YAML-into-JSON failure the legacy tier exists to prevent.
// So THIS step's probe checks live schema state directly
// (information_schema), never the code version: satisfied — "nothing to
// do", not "failed" — when EITHER (a) the column is already gone, or (b)
// any of the three flow_recipe_steps dialect columns is absent (that
// database is the permanently-supported no-ALTER install and keeps the
// column by design). severity 'warning': a skip here is a deliberate,
// permanent, correct outcome for (b), not a degraded one.
//
// A THIRD, NON-PERMANENT case is deliberately NOT folded into this probe's
// "satisfied" set: the three step columns can be present while the
// <PATCH-Y1> backfill UPDATE (_copyRecipeContentTypeToSteps, above) has not
// actually finished copying every YAML recipe's dialect onto its steps yet
// — e.g. it hit a transient error earlier in the SAME boot (the two steps
// run non-atomically, one after the other, in `_runMigrationSteps`), or its
// step hasn't executed at all on this boot. Reporting "satisfied" here would
// let platform_schema_version bump past 3.2.981 with that recipe's steps
// stuck at the ENUM DEFAULT 'application/json' forever — the only recovery
// source (this very column) about to be dropped. So this probe stays
// structural-only and correctly reports "not satisfied" (falls through to
// `return false`) for that case too; the run below re-checks the data
// completeness itself, right before the ALTER, and REFUSES (throws, not a
// silent no-op) so the executor's catch counts it as skipped and holds the
// stamp — see _dropFlowRecipesContentType.
async function _flowRecipesContentTypeRetired(conn, tableFn) {
  const recipesPhysical = tableFn(TABLES.FLOW_RECIPES);
  if (!(await tableExistsInCurrentSchema(conn, recipesPhysical))) return true;
  const recipeCols = await conn.query(
    `SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = 'content_type'`,
    [recipesPhysical],
  );
  // (a) Already dropped (this run, a prior run, or a DBA-applied remediation).
  if (!recipeCols.length) return true;
  const stepsPhysical = tableFn(TABLES.FLOW_RECIPE_STEPS);
  if (!(await tableExistsInCurrentSchema(conn, stepsPhysical))) return true;
  const stepCols = await conn.query(
    `SELECT COLUMN_NAME FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?
        AND COLUMN_NAME IN ('content_type', 'yaml_version', 'yaml_quoting')`,
    [stepsPhysical],
  );
  // (b) The step dialect columns never landed — Y2.6c's legacy tier reads
  // this recipe column forever on this install. Not this step's job to drop.
  if (stepCols.length < 3) return true;
  return false;
}

async function _dropFlowRecipesContentType(ctx) {
  const { conn, t: tableFn } = ctx;
  // Re-check (a)/(b) here, immediately before the ALTER, not just at the
  // executor's outer probe call — same discipline as drop-column's own
  // column-existence re-check right before its ALTER.
  if (await _flowRecipesContentTypeRetired(conn, tableFn)) return;
  // (c) The structural precondition holds (recipe column + all three step
  // dialect columns present) but <PATCH-Y1>'s backfill hasn't caught every
  // YAML recipe's steps up yet — reuse its OWN probe predicate. Unlike (a)/(b)
  // above this is NOT a permanent by-design skip: it must converge once the
  // data is caught up, or a YAML recipe whose backfill never landed is stuck
  // at the ENUM DEFAULT 'application/json' with the only recovery source
  // (this column) gone. THROW, not a silent return: `_runMigrationSteps`'s
  // catch counts a thrown step as skipped, which holds platform_schema_version
  // below 3.2.981 (see the gate right after `_runMigrationSteps` in
  // migrations.js) so the next boot re-probes and, once the backfill has
  // converged (this boot, from an earlier step in the same run, or a prior
  // boot), the drop proceeds.
  if (!(await _perStepContentTypeSatisfied(conn, tableFn))) {
    throw new Error(
      'flow_recipes_content_type_drop deferred — flow_recipe_steps content_type '
      + 'backfill (<PATCH-Y1>) has not finished for every YAML recipe yet',
    );
  }
  await conn.query(`ALTER TABLE \`${tableFn(TABLES.FLOW_RECIPES)}\` DROP COLUMN \`content_type\``);
}

/** DBA-executable form. The precondition is stated in the SQL comment itself
 *  (spec §4.7's remediation contract: the exported SQL must be safe for an
 *  operator to run without reading this file) — run the <PATCH-Y1> ADD COLUMN
 *  remediation first, AND its data backfill UPDATE (_perStepContentTypeSql /
 *  step 'flow_recipe_steps_content_type_backfill'), not just the column add:
 *  the ADD COLUMN alone leaves every step at the ENUM DEFAULT
 *  'application/json' — a YAML recipe's steps only pick up 'application/yaml'
 *  once the backfill UPDATE has run. A permanently no-ALTER database must NOT
 *  run this at all (it keeps flow_recipes.content_type by design). */
function _flowRecipesContentTypeDropSql(tableFn) {
  const physical = tableFn(TABLES.FLOW_RECIPES);
  return [
    '-- Precondition: flow_recipe_steps must already carry content_type/yaml_version/yaml_quoting'
      + ' (run the 3.2.972 ADD COLUMN remediation first), AND every YAML recipe\'s steps must'
      + ' already have been backfilled onto those columns (run the 3.2.972 data backfill UPDATE'
      + ' — step flow_recipe_steps_content_type_backfill\'s remediation SQL — second, before this).'
      + ' Do NOT run this on a database that keeps flow_recipe_steps permanently without those'
      + ' three columns by design — it relies on flow_recipes.content_type staying present and'
      + ' readable forever.',
    `ALTER TABLE \`${physical}\` DROP COLUMN \`content_type\`;`,
  ];
}

/** @type {ReadonlyArray<object>} */
const MIGRATION_STEPS = Object.freeze([
  // T8 (spec §4.6): allowed_hosts was never enforced — the global
  // egress allow-list (system_settings.connector_host_allowlist) is the single
  // outbound host control. Confirmed dead: every read/write code path (dto-mapper,
  // api-connectors/io.js + clone.js, flow-recipes/io.js, connectors.js,
  // flow-dispatch.js, FE types) was removed in the same commit as this entry.
  {
    version: '3.2.579',
    kind: 'drop-column',
    table: TABLES.API_CONNECTORS,
    column: 'allowed_hosts',
    step: 'api_connectors_allowed_hosts_drop',
    severity: 'warning',
  },
  {
    version: '3.2.579',
    kind: 'drop-column',
    table: TABLES.FLOW_RECIPE_STEPS,
    column: 'allowed_hosts',
    step: 'flow_recipe_steps_allowed_hosts_drop',
    severity: 'warning',
  },
  // T9 (spec §4.6): user_id is superseded by owner_id
  // (backfilled on the earlier ownership migration) — confirmed dead after
  // removing the last read/write surface, sync-schema.js's user_templates
  // TABLE_DEFS.cols entry. idx_user_templates_user_draft is dropped first
  // (composite index on the column being dropped).
  {
    version: '3.2.579',
    kind: 'drop-column',
    table: TABLES.USER_TEMPLATES,
    column: 'user_id',
    step: 'user_templates_user_id_drop',
    severity: 'warning',
    alsoDropIndexes: ['idx_user_templates_user_draft'],
  },
  // T11: see _createdAtBackfillEntry doc above.
  _createdAtBackfillEntry({
    table: TABLES.USER_TEMPLATES,
    column: 'created_at',
    step: 'user_templates_created_at_not_null_backfill',
  }),
  _createdAtBackfillEntry({
    table: TABLES.FLOW_RECIPE_RUNS,
    column: 'created_at',
    step: 'flow_recipe_runs_created_at_not_null_backfill',
  }),
  // Cell-level override targeting + blueprint-level field policy. All three are
  // purely additive: each column's default (NULL / FALSE) reproduces the
  // behaviour an existing row already has, so there is nothing to backfill and a
  // DB that warn-skips the ALTER (no DDL privilege) degrades to today's semantics
  // instead of misreading data. severity 'warning' encodes exactly that — a skip
  // is degraded, not failed.
  // `ddl` is byte-compared (modulo whitespace) against the column line in
  // table-ddls.js by the consistency test, so the two can never drift.
  {
    version: '3.2.586',
    kind: 'add-column',
    table: TABLES.VARIANT_OVERRIDES,
    column: 'cell_targets',
    ddl: 'cell_targets JSON NULL',
    step: 'variant_overrides_cell_targets_add',
    severity: 'warning',
  },
  // The is_locked add-column entry that shipped here at 3.2.586 is GONE rather
  // than paired with the drop below. A DB that never ran it does not want the
  // column, and adding it only to drop it two entries later would leave a DB
  // whose operator account lacks DDL privilege carrying a column nothing reads.
  // The drop at 3.2.598 is what reconciles a DB that did run it.
  {
    version: '3.2.586',
    kind: 'add-column',
    table: TABLES.BLUEPRINT_FIELDS,
    column: 'compute_rule',
    ddl: 'compute_rule JSON NULL',
    step: 'blueprint_fields_compute_rule_add',
    severity: 'warning',
  },
  // Decision tables (shared multi-condition lookup). Purely additive: a DB that
  // warn-skips the CREATE (no DDL privilege) simply has no decision tables, and
  // every consumer degrades to "none authored" — the CRUD list mount declares
  // tolerateMissingTableOnList and the cascade-delete service probes for the
  // table before touching it. severity 'warning' encodes exactly that: a skip is
  // degraded, not failed.
  {
    version: '3.2.590',
    kind: 'create-table',
    table: TABLES.DECISION_TABLES,
    step: 'decision_tables_create',
    severity: 'warning',
  },
  // Deliberate-blank markers, the third sparse metadata channel beside
  // field_option_selection and computed_field_overrides. Purely additive: NULL
  // reproduces exactly what an existing row means today (nothing recorded as
  // deliberately emptied), so there is nothing to backfill, and a DB that
  // warn-skips the ALTER for want of DDL privilege degrades to the previous
  // behaviour — a cleared field re-fills on reload — instead of failing writes.
  // severity 'warning' encodes that: a skip is degraded, not failed.
  {
    version: '3.2.593',
    kind: 'add-column',
    table: TABLES.USER_TEMPLATES,
    column: 'cleared_auto_fills',
    ddl: 'cleared_auto_fills TEXT NULL DEFAULT NULL',
    step: 'user_templates_cleared_auto_fills_add',
    severity: 'warning',
  },
  // One value source per field. `value_source` states which of the four
  // field-owned modes fills a field instead of leaving it to be read back out
  // of whichever payload column happened to be populated; `value_scope` gives
  // the blueprint level the cell-scoped targeting only variant overrides had.
  //
  // Both are additive. `value_scope`'s NULL default genuinely reproduces what a
  // pre-existing row meant (the whole field) and needs no backfill.
  //
  // `value_source`'s DOES NOT, and the earlier version of this comment said it
  // did — "both defaults reproduce what a pre-existing row means today" is the
  // sentence the missing translation hid behind. 'entered' reproduces only a row
  // that carried neither a compute_rule nor is_locked=1. Every other row lands
  // on a mode that contradicts the payload beside it: the rule stops applying,
  // the lock is released, and the next save of that field is refused. The
  // translation step below is what carries the legacy state across, and it is
  // ordered between these adds and the is_locked drop for that reason.
  //
  // A DB that warn-skips either ALTER for want of DDL privilege degrades rather
  // than misreads: without `value_source` every field reads as 'entered', so a
  // stored compute rule stops applying until the column lands — reversibly,
  // because nothing has been written. severity 'warning' encodes that; the
  // translation carries the same severity so a skipped ALTER and a skipped
  // translation both hold the stamp back and retry next boot.
  {
    version: '3.2.598',
    kind: 'add-column',
    table: TABLES.BLUEPRINT_FIELDS,
    column: 'value_source',
    ddl: "value_source VARCHAR(32) NOT NULL DEFAULT 'entered'",
    step: 'blueprint_fields_value_source_add',
    severity: 'warning',
  },
  {
    version: '3.2.598',
    kind: 'add-column',
    table: TABLES.BLUEPRINT_FIELDS,
    column: 'value_scope',
    ddl: 'value_scope JSON NULL',
    step: 'blueprint_fields_value_scope_add',
    severity: 'warning',
  },
  // Carry the legacy state across BEFORE the boolean is dropped — see the long
  // note above the helpers for the mapping and the one decision it contains.
  // Ordered between the adds and the drop, and that order is load-bearing in
  // both directions: the column it writes into must exist, and the column it
  // reads must not be gone yet. A partial run that stops here has gained the
  // translation and still has the original.
  {
    version: '3.2.598',
    kind: 'custom',
    step: 'blueprint_fields_value_source_translate_legacy',
    severity: 'warning',
    run: _translateLegacyValueSource,
    probe: _legacyValueSourceTranslated,
    remediationSql: _legacyValueSourceSql,
  },
  // is_locked said the same thing as value_source='locked'. Two columns for one
  // fact is a pair that can disagree, and nothing decides which one wins, so the
  // boolean goes. Confirmed dead: every read and write of it — resolver,
  // authoring form, decision-table eligibility, policy grid, DTO mapper,
  // blueprint export/import and its fingerprint — was removed in the same
  // commit as this entry. Ordered AFTER the two adds so a run that gets partway
  // through has gained the replacement before losing the original.
  {
    version: '3.2.598',
    kind: 'drop-column',
    table: TABLES.BLUEPRINT_FIELDS,
    column: 'is_locked',
    step: 'blueprint_fields_is_locked_drop',
    severity: 'warning',
  },
  // What the operator entered, recorded on the run. Purely additive, and
  // NULL genuinely reproduces what an existing run row means: nothing was
  // captured for it, which is true of every run recorded before this column and
  // cannot be reconstructed afterwards — the values were never stored anywhere.
  // So there is nothing to backfill, and no translation of the kind the
  // value_source entry above needed.
  //
  // add-column rather than custom for the same reason: the shape question this
  // batch has to answer is "does the column exist", not "does an existing row
  // disagree with it". A DB that warn-skips the ALTER for want of DDL privilege
  // degrades rather than fails — the run-begin INSERT probes for the column and
  // re-issues without it, so flows keep running and only the capture is missing,
  // reversibly, until the column lands. severity 'warning' encodes exactly that.
  {
    version: '3.2.614',
    kind: 'add-column',
    table: TABLES.FLOW_RECIPE_RUNS,
    column: 'input_snapshot',
    ddl: 'input_snapshot LONGTEXT NULL DEFAULT NULL',
    step: 'flow_recipe_runs_input_snapshot_add',
    severity: 'warning',
  },
  // Delegated access and the activity trail. Both are purely additive: a
  // database that warn-skips either CREATE for want of DDL privilege has no
  // grants and no trail, and every consumer degrades to exactly today's
  // behaviour — the write and dispatch gates probe for the grants table and fall
  // back to plain ownership when it is absent, and the activity writer drops its
  // row rather than failing the action it was recording. Nothing is misread and
  // nothing is lost that was ever stored, so severity is 'warning': a skip is
  // degraded, not failed, and the stamp is held back so the next boot retries.
  {
    version: '3.2.626',
    kind: 'create-table',
    table: TABLES.DELEGATED_GRANTS,
    step: 'delegated_grants_create',
    severity: 'warning',
  },
  {
    version: '3.2.626',
    kind: 'create-table',
    table: TABLES.TEMPLATE_ACTIVITY,
    step: 'template_activity_create',
    severity: 'warning',
  },
  // See the long note above the helpers: the index is the backstop for the
  // write-path clash probe, and the step refuses itself (visibly) on a database
  // that already holds duplicates rather than failing its boot. severity
  // 'warning' encodes that: a skip is degraded — the probe still refuses every
  // NEW duplicate — not failed.
  {
    version: '3.2.629',
    kind: 'custom',
    step: 'blueprint_fields_field_key_unique_index',
    severity: 'warning',
    run: _addFieldKeyUniqueIndex,
    probe: _fieldKeyIndexSatisfied,
    remediationSql: _fieldKeyIndexSql,
  },
  // Per-entity-type hostname patterns (spec B5a). Purely additive: NULL means
  // "inherited / built-in defaults", exactly what an existing settings row means
  // today, so nothing backfills and a DB that warn-skips the ALTER (no DDL
  // privilege) degrades to today's built-in names instead of failing writes.
  // severity 'warning' encodes that a skip is degraded, not failed.
  {
    version: '3.2.696',
    kind: 'add-column',
    table: TABLES.CAP_SETTINGS,
    column: 'name_patterns',
    ddl: 'name_patterns JSON NULL',
    step: 'cap_settings_name_patterns_add',
    severity: 'warning',
  },
  // Repin every placed VM's stale data-centre cache to its host (data backfill,
  // no DDL). severity 'warning' encodes that a skip is degraded — the write side
  // stays consistent, only the legacy rows wait — not failed.
  {
    version: '3.2.719',
    kind: 'custom',
    step: 'cap_vms_site_id_backfill_from_host',
    severity: 'warning',
    run: _backfillVmSiteCache,
    probe: _vmSiteCacheAligned,
    remediationSql: _backfillVmSiteCacheSql,
  },
  // cap-renumber-lock (spec D1/D5): a locked host is never renamed by
  // renumber. Purely additive; DEFAULT 0 reproduces exactly what every
  // existing row means today (nothing was ever excluded from renumber), so
  // there is nothing to backfill. severity 'warning' matches the convention
  // for every other purely-additive column in this registry: a skipped ALTER
  // (no DDL privilege) holds the stamp back and retries next boot instead of
  // failing it outright.
  {
    version: '3.2.729',
    kind: 'add-column',
    table: TABLES.CAP_HYPERVISORS,
    column: 'name_locked',
    ddl: 'name_locked TINYINT(1) NOT NULL DEFAULT 0',
    step: 'cap_hypervisors_name_locked_add',
    severity: 'warning',
  },
  {
    version: '3.2.729',
    kind: 'add-column',
    table: TABLES.CAP_VMS,
    column: 'name_locked',
    ddl: 'name_locked TINYINT(1) NOT NULL DEFAULT 0',
    step: 'cap_vms_name_locked_add',
    severity: 'warning',
  },
  // ap-vm-function (PR-2): the renumber {function} token for an AP VM resolves
  // from cap_vms.function_name. Purely additive + nullable, so existing rows
  // read NULL and fall back to 'ap' (no backfill, decision Q13) — nothing to
  // repair. severity 'warning' matches every other purely-additive column here:
  // a skipped ALTER (no DDL privilege) holds the stamp back and retries next
  // boot instead of failing it outright; renumber's read-side degraded-schema
  // guard (readTableRows) drops the column from its SELECT when absent.
  {
    version: '3.2.739',
    kind: 'add-column',
    table: TABLES.CAP_VMS,
    column: 'function_name',
    ddl: 'function_name VARCHAR(255) NULL DEFAULT NULL',
    step: 'cap_vms_function_name_add',
    severity: 'warning',
  },
  // T12 (spec §7 E1 / Q11): rac_standby topology — the
  // ENUM domain widen (see _widenTopologyEnumForRacStandby's own doc above).
  {
    version: '3.2.759',
    kind: 'custom',
    step: 'cap_databases_topology_rac_standby_widen',
    severity: 'warning',
    run: _widenTopologyEnumForRacStandby,
    probe: _topologyEnumHasRacStandby,
    remediationSql: _topologyEnumRacStandbyRemediationSql,
  },
  // rac_standby's independently-overridable standby node count (S). Purely
  // additive + nullable — NULL for every existing row (every topology but
  // rac_standby ignores this column; a rac_standby row created before this
  // migration cannot exist yet, since the topology value itself did not exist
  // until the widen above), so there is nothing to backfill. severity
  // 'warning' matches every other purely-additive column in this registry.
  {
    version: '3.2.759',
    kind: 'add-column',
    table: TABLES.CAP_DATABASES,
    column: 'standby_node_count',
    ddl: 'standby_node_count INT NULL DEFAULT NULL',
    step: 'cap_databases_standby_node_count_add',
    severity: 'warning',
  },
  // (spec §5 C2 / Q7): per-output table-format declaration. Purely
  // additive with a non-null default ('json', matching every pre-migration
  // row's actual behavior — outputs were JSON-only downloads before this
  // feature), so there is nothing to backfill. severity 'warning' matches
  // every other purely-additive column in this registry: a skipped ALTER (no
  // DDL privilege) holds the stamp back and retries next boot instead of
  // failing it outright.
  {
    version: '3.2.763',
    kind: 'add-column',
    table: TABLES.BLUEPRINT_OUTPUT_ORDER,
    column: 'format',
    ddl: "format VARCHAR(16) NOT NULL DEFAULT 'json'",
    step: 'blueprint_output_order_format_add',
    severity: 'warning',
  },
  // D12d (spec §4): the RAC pair's stored-value rename — see the
  // long note above the helpers for the widen/update/narrow shape and the
  // probe's pre-/mid-state contract.
  {
    version: '3.2.784',
    kind: 'custom',
    step: 'cap_databases_topology_rac_rename',
    severity: 'warning',
    run: _renameCapDatabasesTopologyRac,
    probe: _capDatabasesTopologyRacRenamed,
    remediationSql: _capDatabasesTopologyRacRenameSql,
  },
  {
    version: '3.2.784',
    kind: 'custom',
    step: 'cap_bundle_items_topology_rac_rename',
    severity: 'warning',
    run: _renameCapBundleItemsTopologyRac,
    probe: _capBundleItemsTopologyRacRenamed,
    remediationSql: _capBundleItemsTopologyRacRenameSql,
  },
  // AR2-Q8 (bundle parity): additive widen of cap_bundle_items.topology to the
  // full 5-member domain — see _widenCapBundleItemsTopologyForStandby's own
  // doc. MUST stay after the rename entry above (executor runs in array order):
  // the rename narrows to 4 members, this widens to 5.
  {
    version: '3.2.805',
    kind: 'custom',
    step: 'cap_bundle_items_topology_standby_widen',
    severity: 'warning',
    run: _widenCapBundleItemsTopologyForStandby,
    probe: _capBundleItemsTopologyHasStandby,
    remediationSql: _capBundleItemsTopologyStandbyWidenSql,
  },
  // AR2-Q8: the independently-overridable standby node count S for a
  // rac_multinode_standby bundle item. Purely additive + nullable — NULL for
  // every existing row (only rac_multinode_standby reads it, and that value
  // could not exist in this table before the widen above), so nothing to
  // backfill. severity 'warning' matches every other purely-additive column.
  {
    version: '3.2.805',
    kind: 'add-column',
    table: TABLES.CAP_BUNDLE_ITEMS,
    column: 'standby_node_count',
    ddl: 'standby_node_count INT NULL DEFAULT NULL',
    step: 'cap_bundle_items_standby_node_count_add',
    severity: 'warning',
  },
  // AR2-Q11 (spec §7 E1): seed the standby-cluster keep-in-one-site default
  // row DEFAULT_RULE_TEMPLATE grew (rule-types.js). Pure data INSERT, no DDL —
  // see `_seedStandbyKeepInOneSiteRule`'s own doc for the seed-marker
  // eligibility rule (a `system_settings` marker, not a frozen-shape byte
  // match: empty global set seeds the full template, non-empty seeds only
  // the new row, and the marker makes either outcome durable across an
  // operator later deleting the row — never clobbers operator work).
  // severity 'warning' matches every other purely-additive/data-only entry:
  // a skipped INSERT (e.g. no write access) holds nothing back — rules are
  // advisory, and the operator can add the row by hand.
  {
    version: '3.2.807',
    kind: 'custom',
    step: 'cap_rules_seed_standby_keep_in_one_site',
    severity: 'warning',
    run: _seedStandbyKeepInOneSiteRule,
    probe: _capRulesStandbyKeepInOneSiteSeeded,
    remediationSql: _seedStandbyKeepInOneSiteRuleSql,
  },
  // Reconcile the full DEFAULT_RULE_TEMPLATE global set. A template row
  // (`keep-apart / each_standby_cluster`, rule-types.js) shipped in an earlier
  // release with no migration, so a deployment that upgraded through it with a
  // non-empty global set is missing it; the standby-keep-in-one-site seed above
  // only ever adds its own row. This inserts any missing template row once,
  // gated by a durable marker (see _reconcileDefaultRuleTemplate's doc) so an
  // operator deletion after the step ran is never resurrected. Pure data INSERT,
  // no DDL — the structural kinds cannot express it and the missing-structure
  // comparison cannot see it. severity 'warning' matches every other data-only
  // entry: a skipped INSERT holds nothing back (rules are advisory).
  {
    version: '3.2.814',
    kind: 'custom',
    step: 'cap_rules_reconcile_default_template',
    severity: 'warning',
    run: _reconcileDefaultRuleTemplate,
    probe: _defaultRuleTemplateReconciled,
    remediationSql: _reconcileDefaultRuleTemplateSql,
  },
  // post-ar2-residuals P6 (Q13): the dense-placement layout tier config, a
  // per-key override object stored NULL = inherit (name_patterns' own
  // sibling column). Purely additive + nullable — every existing row reads
  // NULL (= built-in defaults) — so there is nothing to backfill. severity
  // 'warning' matches every other purely-additive column: a skipped ALTER
  // (no DDL privilege) holds the stamp back and retries next boot; the
  // degraded-schema column filter (dropAbsentColumns) drops it from any
  // write on an old schema.
  {
    version: '3.2.827',
    kind: 'add-column',
    table: TABLES.CAP_SETTINGS,
    column: 'placement_layout',
    ddl: 'placement_layout JSON NULL',
    step: 'cap_settings_placement_layout_add',
    severity: 'warning',
  },
  // U10: named, manual save of a record's form values for the
  // data-entry in-place compare layer — never executed, never a run. Purely
  // additive (a new table), so severity 'warning' matches every other
  // additive structural entry: a skipped CREATE (no DDL privilege) degrades
  // to "no snapshots" (the feature routes 404/empty rather than 500) and
  // holds the stamp back for the next boot to retry.
  {
    version: '3.2.856',
    kind: 'create-table',
    table: TABLES.TEMPLATE_SNAPSHOTS,
    step: 'template_snapshots_create',
    severity: 'warning',
  },
  // Per-blueprint auto-naming template ({{field_key}} tokens + literal text) a
  // record's name is composed from. Purely additive + nullable — every existing
  // row reads NULL (= no rule) — so there is nothing to backfill. severity
  // 'warning' matches every other purely-additive column: a skipped ALTER (no
  // DDL privilege) holds the stamp back and retries next boot; the degraded-
  // schema column filter (dropAbsentColumns) drops it from any write on an old
  // schema. TEXT so the template length is unbounded (mirrors `description`).
  {
    version: '3.2.871',
    kind: 'add-column',
    table: TABLES.HIERARCHY_NODES,
    column: 'naming_rule',
    ddl: 'naming_rule TEXT NULL DEFAULT NULL',
    step: 'hierarchy_nodes_naming_rule_add',
    severity: 'warning',
  },
  // Dynamic option source (dynamic-field-options design, OPT-E1): a field's
  // option list may name another field of the same blueprint or an API
  // connector fetch instead of the static field_options rows. Purely
  // additive + nullable — NULL reproduces exactly what every existing row
  // already means (static list), so there is nothing to backfill. severity
  // 'warning' matches every other purely-additive column: a DB that
  // warn-skips the ALTER (no DDL privilege) degrades to "no dynamic
  // sources" rather than failing boot, and the degraded-schema column filter
  // (dropAbsentColumns) drops it from any write on an old schema.
  {
    version: '3.2.875',
    kind: 'add-column',
    table: TABLES.BLUEPRINT_FIELDS,
    column: 'options_source',
    ddl: 'options_source JSON NULL',
    step: 'blueprint_fields_options_source_add',
    severity: 'warning',
  },
  // A named, manual save of a template's data-entry state
  // that never runs the build flow — the timeline reads it alongside
  // flow_recipe_runs rows without duplicating either into the other. Purely
  // additive (a new table), so severity 'warning' matches every other
  // additive structural entry: a skipped CREATE (no DDL privilege) degrades
  // to "no versions" (the feature routes 404/empty rather than 500) and
  // holds the stamp back for the next boot to retry.
  {
    version: '3.2.890',
    kind: 'create-table',
    table: TABLES.TEMPLATE_VERSIONS,
    step: 'template_versions_create',
    severity: 'warning',
  },
  // See the long note above the helpers: this backs resolveEffectiveBlueprintIds'
  // two readers of hierarchy_nodes.linked_blueprint_id (the rename's locking
  // variant chief among them). severity 'warning': a skipped ALTER (no DDL
  // privilege) degrades to a full scan, correct but slower — never a failure.
  {
    version: '3.2.900',
    kind: 'custom',
    step: 'hierarchy_nodes_linked_blueprint_index_add',
    severity: 'warning',
    run: _addHierarchyNodesLinkedBlueprintIndex,
    probe: _hierarchyNodesLinkedBlueprintIndexSatisfied,
    remediationSql: _hierarchyNodesLinkedBlueprintIndexSql,
  },
  // "Also usable in" bindings for a connector. Purely additive (a new table),
  // so severity 'warning' matches every other additive structural entry: a
  // skipped CREATE (no DDL privilege) degrades to "no extra bindings" — the
  // usable-list join returns only home-blueprint connectors and the bindings
  // PUT 500s visibly rather than corrupting — and holds the stamp back for the
  // next boot to retry.
  {
    version: '3.2.925',
    kind: 'create-table',
    table: TABLES.API_CONNECTOR_BLUEPRINTS,
    step: 'api_connector_blueprints_create',
    severity: 'warning',
  },
  // Connector source kind (spec §6.1). Purely additive + NOT NULL DEFAULT
  // 'http', so every existing row reads exactly as it did (an http connector).
  // severity 'warning': a no-DDL operator DB warn-skips the ALTER and degrades
  // to "http only" — the /prepare loader treats an absent column as 'http'
  // (ADDITIVE_COLS fallback), never a boot failure.
  {
    version: '3.2.926',
    kind: 'add-column',
    table: TABLES.API_CONNECTORS,
    column: 'source_kind',
    ddl: "source_kind ENUM('http','template','static') NOT NULL DEFAULT 'http'",
    step: 'api_connectors_source_kind_add',
    severity: 'warning',
  },
  {
    version: '3.2.926',
    kind: 'add-column',
    table: TABLES.API_CONNECTORS,
    column: 'source_config',
    ddl: 'source_config JSON NULL DEFAULT NULL',
    step: 'api_connectors_source_config_add',
    severity: 'warning',
  },
  // ── 3.2.972: per-step content type + YAML dialect ────────────────────────
  // Purely additive; each default reproduces exactly what a recipe means today
  // (JSON, and for a YAML recipe the 1.2/plain dialect that `{ lineWidth: 0 }`
  // already emitted). A no-DDL operator DB warn-skips the ALTERs and degrades
  // to "every step JSON" reversibly — nothing has been written. severity 'warning'
  // encodes that a skip is degraded, not failed. `ddl` is byte-compared (modulo
  // whitespace) to the table-ddls.js column line by the consistency test.
  {
    version: '3.2.972',
    kind: 'add-column',
    table: TABLES.FLOW_RECIPE_STEPS,
    column: 'content_type',
    ddl: "content_type ENUM('application/json','application/yaml') NOT NULL DEFAULT 'application/json'",
    step: 'flow_recipe_steps_content_type_add',
    severity: 'warning',
  },
  {
    version: '3.2.972',
    kind: 'add-column',
    table: TABLES.FLOW_RECIPE_STEPS,
    column: 'yaml_version',
    ddl: "yaml_version ENUM('1.2','1.1') NOT NULL DEFAULT '1.2'",
    step: 'flow_recipe_steps_yaml_version_add',
    severity: 'warning',
  },
  {
    version: '3.2.972',
    kind: 'add-column',
    table: TABLES.FLOW_RECIPE_STEPS,
    column: 'yaml_quoting',
    ddl: "yaml_quoting ENUM('plain','double','single') NOT NULL DEFAULT 'plain'",
    step: 'flow_recipe_steps_yaml_quoting_add',
    severity: 'warning',
  },
  // Carry a YAML recipe's dialect onto its steps BEFORE flow_recipes.content_type
  // is dropped (a later patch). Ordered after the adds (writes the column they
  // create) and before that drop (reads the recipe column). A partial run that
  // stops here has gained the copy and still has the source.
  {
    version: '3.2.972',
    kind: 'custom',
    step: 'flow_recipe_steps_content_type_backfill',
    severity: 'warning',
    run: _copyRecipeContentTypeToSteps,
    probe: _perStepContentTypeSatisfied,
    remediationSql: _perStepContentTypeSql,
  },
  // ── 3.2.981: drop the retired flow_recipes.content_type — see the long
  // note above the helpers for the precondition (stronger than "every
  // replica's code is current": every replica's DATABASE must have applied
  // the 3.2.972 ADD COLUMN; a permanently no-ALTER install keeps this
  // column by design and is never a candidate). kind 'custom' (not
  // 'drop-column') because the column's fate is conditional on live schema
  // state the structural drop-column kind cannot express — its probe only
  // checks "is the column gone", never "should it be". severity 'warning':
  // skipping on a permanently no-ALTER install is a correct, permanent
  // outcome, not a degraded one.
  {
    version: '3.2.981',
    kind: 'custom',
    step: 'flow_recipes_content_type_drop',
    severity: 'warning',
    run: _dropFlowRecipesContentType,
    probe: _flowRecipesContentTypeRetired,
    remediationSql: _flowRecipesContentTypeDropSql,
  },
  // ── remote-ref cache + step-level mode trigger. Both purely additive; a
  // warn-skip degrades to today's behaviour rather than failing (see each
  // `severity` comment below).
  {
    version: '3.2.998',
    kind: 'add-column',
    table: TABLES.USER_TEMPLATES,
    column: 'flow_remote_refs',
    ddl: 'flow_remote_refs JSON NULL DEFAULT NULL',
    step: 'user_templates_flow_remote_refs_add',
    // Purely additive: a DB that warn-skips the ALTER has no remote-ref cache and
    // update-mode merges fall back to whatever the after-JS captured live — degraded,
    // not failed. run-finalize probes for the column before writing it.
    severity: 'warning',
  },
  {
    version: '3.2.998',
    kind: 'add-column',
    table: TABLES.FLOW_RECIPE_STEPS,
    column: 'step_runs_on',
    ddl: "step_runs_on ENUM('create','update','both','compare') NOT NULL DEFAULT 'both'",
    step: 'flow_recipe_steps_step_runs_on_add',
    // Default 'both' matches every grandfathered step's current behaviour, so a
    // warn-skip degrades to today (every step runs in both modes).
    severity: 'warning',
  },
  {
    version: '3.3.7',
    kind: 'add-column',
    table: TABLES.FLOW_RECIPE_STEPS,
    column: 'preset_config',
    ddl: 'preset_config JSON NULL DEFAULT NULL',
    step: 'flow_recipe_steps_preset_config_add',
    // Purely additive: NULL = today's behaviour (no Merge-by-key preset; the
    // generated before_code, if any, still runs). A warn-skip only costs the
    // authoring UI its ability to re-drive the rules table — the runtime is
    // unaffected because before_code, not this column, is the runtime truth.
    severity: 'warning',
  },
  {
    version: '3.3.11',
    kind: 'add-column',
    table: TABLES.FLOW_RECIPES,
    column: 'compare_spec',
    ddl: 'compare_spec JSON NULL DEFAULT NULL',
    step: 'flow_recipes_compare_spec_add',
    // Purely additive: NULL = no compare pass authored yet. A warn-skip only
    // costs the Build modal its compare summary/details — the recipe still
    // dispatches create/update exactly as before, and compare-begin degrades
    // to a null compare_spec rather than failing.
    severity: 'warning',
  },
]);

module.exports = {
  MIGRATION_STEPS,
  BASELINE_SCHEMA_VERSION,
  PLATFORM_SCHEMA_VERSION,
};
