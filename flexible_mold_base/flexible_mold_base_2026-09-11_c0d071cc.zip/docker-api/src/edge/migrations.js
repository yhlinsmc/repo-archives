const { v4: uuidv4 } = require('uuid');
const { buildEngineTableDDLs, buildInfraTableDDLs, ENGINE_TABLE_NAMES } = require('../table-ddls');
const { TABLES } = require('../shared/constants');
const { DdlPrivilegeError, preflightDdlGrants } = require('../shared/lib/preflight-grants');
const { sanitizeMigrationError } = require('../shared/lib/migration-sanitizer');
const { tableExistsInCurrentSchema } = require('./lib/table-exists');
const { readSchemaColumns, computeMissing } = require('./lib/schema-comparison');
const { MIGRATION_STEPS, BASELINE_SCHEMA_VERSION } = require('./migration-steps');
const { logger: rootLogger } = require('../shared/lib/logger');
// kind:'sys' on every migration line (spec §7 sys) — bound once on the child
// so each of the 20 existing `logger.info`/`.warn`/`.error` call sites below
// carries it without a per-site edit; messages and levels are unchanged.
const logger = rootLogger.child({ module: 'db', kind: 'sys' });
// lint-allow: file-size cold migration code moved verbatim, tracked

/**
 * migrations.js — schema-migration logic extracted verbatim from edge/db.js
 * (large-file refactor). Behaviour-identical move.
 *
 * MUST NOT require ./db.js (no cycle). The table resolver `t`, the mutable
 * `_tablePrefix` / `_configFull` state, `PLATFORM_SCHEMA_VERSION` and
 * `APP_TABLE_NAMES` are supplied by db.js at call time via the factory's
 * `deps` object, so reassigned state is always read fresh (db.js re-instantiates
 * per call). Function bodies below are byte-identical to their pre-extraction
 * form; only their enclosing scope (this factory) changed.
 */
function createMigrationsModule(deps) {
  const { t, PLATFORM_SCHEMA_VERSION, _configFull, _tablePrefix, APP_TABLE_NAMES } = deps;

  // `t` is fixed for the lifetime of this module instance (db.js re-instantiates
  // the whole factory per call — see the class comment above), so the
  // engine+infra DDL array can be built once per instance and reused across
  // every `create-table` step application in one migration run instead of
  // rebuilding it per step.
  let cachedAllTableDDLs = null;
  function _allTableDDLs() {
    if (!cachedAllTableDDLs) {
      cachedAllTableDDLs = [...buildEngineTableDDLs(t), ...buildInfraTableDDLs(t)];
    }
    return cachedAllTableDDLs;
  }

/**
 * Best-effort audit-log write for schema migration events. Visibility-surface
 * RFC §6 — payload MUST be sanitised by the caller; raw err.message must not
 * leak into feature_audit. Failures are logger-only — a dropped audit row
 * cannot mask the underlying migration outcome (the migration runner already
 * logged the real event), and must not break boot.
 *
 * @param {*} conn
 * @param {string} eventType
 * @param {object} metadata
 */
// A metadata key whose value is a physical table name built via `t()`: the
// literal `table` plus any camelCase `…Table` (e.g. `hierarchyTable`). Used so
// redaction targets table-name fields ONLY — arbitrary data payloads (a
// `sample[].action` value, a row id) are never stripped even if they happen to
// start with the configured prefix.
function _isAuditTableKey(key) {
  return key === 'table' || (typeof key === 'string' && key.endsWith('Table'));
}

// SECURITY: strip the physical table prefix from table-name metadata fields
// before the row is persisted to feature_audit, which admin clients can read.
// `t()` builds `_tablePrefix + logical`; the prefix is an internal deployment
// detail and not part of the audit's information value, so emit the logical name
// only. Keyed on the field name (not the value) so only `table`/`…Table` fields
// are touched — data payload values that merely start with the prefix are left
// intact. Recurses through nested objects so a future nested table-name field
// can't reintroduce the leak; array elements are data, not named table fields,
// so they pass through (key=null). Returns the input by identity when unchanged.
function _redactAuditTableNames(value, prefix = _tablePrefix, key = null) {
  if (!prefix) return value;
  if (typeof value === 'string') {
    return (_isAuditTableKey(key) && value.startsWith(prefix)) ? value.slice(prefix.length) : value;
  }
  if (Array.isArray(value)) {
    let changed = false;
    const out = value.map((v) => {
      const r = _redactAuditTableNames(v, prefix, null);
      if (r !== v) changed = true;
      return r;
    });
    return changed ? out : value;
  }
  if (value && typeof value === 'object') {
    let changed = false;
    const out = {};
    for (const [k, v] of Object.entries(value)) {
      const r = _redactAuditTableNames(v, prefix, k);
      if (r !== v) changed = true;
      out[k] = r;
    }
    return changed ? out : value;
  }
  return value;
}

async function _writeMigrationAudit(conn, eventType, metadata) {
  try {
    const safeMetadata = _redactAuditTableNames(metadata);
    await conn.query(
      `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata)
       VALUES (?, ?, ?, ?)`,
      [uuidv4(), eventType, null, safeMetadata ? JSON.stringify(safeMetadata) : null],
    );
  } catch (err) {
    logger.warn(
      { err: err && err.message, eventType },
      'feature_audit write skipped — schema migration audit row dropped; runtime continues',
    );
  }
}

// Read the platform_schema_version stamp. `hadStamp` is true only when a real
// string version was decoded; `readOk` is false when the SELECT threw, so the
// baseline guard can hold its verdict on a transient read failure instead of
// mis-flagging a healthy DB as unsupported.
async function _readSchemaVersionStamp(conn) {
  let currentVersion = '3.0.0';
  let hadStamp = false;
  let readOk = true;
  try {
    const rows = await conn.query(
      `SELECT value FROM \`${t(TABLES.SYSTEM_SETTINGS)}\` WHERE \`key\` = 'platform_schema_version' LIMIT 1`,
    );
    if (rows.length && rows[0].value) {
      // SAFETY: a MariaDB JSON column the driver already decoded returns a bare
      // string, not JSON text — JSON.parse throws on it, so fall back to the raw
      // value rather than defaulting to the initial version and re-running every
      // boot.
      let parsed;
      try {
        parsed = typeof rows[0].value === 'string' ? JSON.parse(rows[0].value) : rows[0].value;
      } catch {
        parsed = rows[0].value;
      }
      if (typeof parsed === 'string') {
        currentVersion = parsed;
        hadStamp = true;
      }
    }
  } catch (err) {
    readOk = false;
    logger.warn({ err }, 'platform_schema_version read failed; assuming initial install');
  }
  return { currentVersion, hadStamp, readOk };
}

// Baseline guard verdict (spec §4.2). Returns true when migrations MUST NOT run:
//   - stamped below baseline (an older schema this engine cannot safely advance)
//   - no stamp yet engine tables already exist (pre-stamp-era / foreign DB)
// An empty DB with no stamp and no engine tables is a normal fresh install and
// returns false so the executor runs and stamps it.
async function _isUnsupportedBaseline(conn, currentVersion, hadStamp) {
  if (hadStamp) {
    // A persisted stamp below the baseline can never be safely advanced by the
    // post-reset engine (the legacy migration path that would have upgraded it
    // is deleted) — unsupported in EVERY context.
    return _compareVersions(currentVersion, BASELINE_SCHEMA_VERSION) < 0;
  }
  // No stamp. INVARIANT: the stamp is only ever written onto a schema PROVEN
  // current, so an unstamped DB must prove completeness before we run/stamp.
  // Zero engine tables = a fresh install (the executor no-ops on the empty DB;
  // the Setup Wizard creates engine tables next), so allow it. Any engine table
  // present = an existing / partial / foreign DB: supported ONLY when the full
  // expected manifest is already materialised — the Setup Wizard's
  // just-created-everything case (init-db context). Any missing table OR column
  // means we cannot prove it current → unsupported, stamp untouched. The full
  // engine-table set is probed (not a hardcoded pair) so a partial DB carrying
  // only e.g. api_connectors can never masquerade as fresh and get stamped.
  const liveByTable = await readSchemaColumns(conn);
  const engineTablesPresent = ENGINE_TABLE_NAMES.some((base) => liveByTable.has(t(base)));
  if (!engineTablesPresent) return false;
  const { missing_tables, missing_columns } = computeMissing(liveByTable, t);
  return missing_tables.length > 0 || missing_columns.length > 0;
}

// Physical name of the schema this connection is bound to, for the advisory lock
// name. Falls back to the configured database when SELECT DATABASE() is
// unavailable (e.g. a mock connection in tests).
async function _currentDatabaseName(conn) {
  try {
    const rows = await conn.query('SELECT DATABASE() AS db');
    if (rows && rows.length && rows[0].db) return rows[0].db;
  } catch (err) {
    logger.warn({ err }, 'SELECT DATABASE() failed; using configured database for migration lock name');
  }
  return (_configFull && _configFull.database) || '';
}

// GET_LOCK returns 1 on acquire, 0 on timeout, NULL on error. Never throws:
// contention or a driver hiccup degrades to "not acquired" so the caller can
// skip this boot rather than crash it.
async function _acquireMigrationLock(conn, lockName, timeoutSec = 60) {
  try {
    const rows = await conn.query('SELECT GET_LOCK(?, ?) AS locked', [lockName, timeoutSec]);
    return !!(rows && rows.length && Number(rows[0].locked) === 1);
  } catch (err) {
    logger.warn({ err, lockName }, 'migration advisory lock acquire failed; skipping migrations this boot');
    return false;
  }
}

async function _releaseMigrationLock(conn, lockName) {
  try {
    await conn.query('SELECT RELEASE_LOCK(?)', [lockName]);
  } catch (err) {
    // The lock is connection-scoped, so a failed release still frees on close —
    // logger-only, never mask the migration outcome.
    logger.warn({ err, lockName }, 'migration advisory lock release failed; connection close will free it');
  }
}

// Apply one registry entry by kind. Idempotent: each kind probes live state
// before issuing DDL, so a re-run is a no-op. Throws on failure; the executor
// classifies + accounts the skip.
async function _applyMigrationStep(conn, step) {
  switch (step.kind) {
    case 'add-column': {
      const physical = t(step.table);
      if (!(await tableExistsInCurrentSchema(conn, physical))) return;
      const cols = await conn.query(
        `SELECT 1 FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
        [physical, step.column],
      );
      if (cols.length) return;
      await conn.query(`ALTER TABLE \`${physical}\` ADD COLUMN ${step.ddl}`);
      logger.info({ table: physical, column: step.column }, 'schema migration added column');
      return;
    }
    case 'create-table': {
      const physical = t(step.table);
      if (await tableExistsInCurrentSchema(conn, physical)) return;
      const ddl = _allTableDDLs().find((s) => s.includes(`\`${physical}\``));
      if (!ddl) throw new Error(`create-table DDL not found for ${physical}`);
      await conn.query(ddl);
      logger.info({ table: physical }, 'schema migration created table');
      return;
    }
    case 'drop-column': {
      const physical = t(step.table);
      if (!(await tableExistsInCurrentSchema(conn, physical))) return;
      const cols = await conn.query(
        `SELECT 1 FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
        [physical, step.column],
      );
      if (!cols.length) return;
      // Drop companion indexes before the column so a composite index that would
      // otherwise block the column drop is gone first. A missing index (1091,
      // ER_CANT_DROP_FIELD_OR_KEY) is not an error — it may have been dropped
      // already or auto-removed with a prior column.
      for (const indexName of step.alsoDropIndexes || []) {
        try {
          await conn.query(`ALTER TABLE \`${physical}\` DROP INDEX \`${indexName}\``);
          logger.info({ table: physical, index: indexName }, 'schema migration dropped index');
        } catch (err) {
          if (err && err.errno === 1091) continue;
          throw err;
        }
      }
      await conn.query(`ALTER TABLE \`${physical}\` DROP COLUMN \`${step.column}\``);
      logger.info({ table: physical, column: step.column }, 'schema migration dropped column');
      return;
    }
    case 'custom': {
      if (typeof step.run !== 'function') {
        throw new Error(`custom migration step ${step.step} missing run()`);
      }
      // A satisfied probe short-circuits silently — no DDL attempt, no audit
      // row, no skip accounting — mirroring the drop-column column-existence
      // short-circuit above. This lets a re-run converge without a spurious
      // errno-1142 skip once a DBA has applied the remediation SQL out-of-band
      // (or the schema is already aligned). Custom steps without a probe
      // (test fixtures / generic entries) fall straight through to run().
      if (typeof step.probe === 'function' && (await step.probe(conn, t))) return;
      await step.run({ conn, t, TABLES, logger, sanitizeMigrationError });
      return;
    }
    default:
      throw new Error(`unsupported migration step kind: ${String(step.kind)}`);
  }
}

// Declarative-step executor (spec §4.1). Runs each entry with the promoted
// additiveCols semantics — probe → conditional DDL → catch → sanitise → audit →
// skippedSteps += 1. Never throws: a failed step is accounted as skipped so the
// stamp gate holds and the next boot retries. Emits one structured operator-mode
// line when steps were skipped for a missing DDL privilege (errno 1142).
async function _runMigrationSteps(conn, steps) {
  let skippedSteps = 0;
  const privilegeSkips = [];
  for (const step of steps) {
    try {
      await _applyMigrationStep(conn, step);
    } catch (err) {
      skippedSteps += 1;
      const isPrivilege = !!(err && err.errno === 1142);
      const eventType = isPrivilege ? 'schema_migration.alter_skipped' : 'schema_migration.skipped';
      if (isPrivilege) privilegeSkips.push(step.step);
      const sanitized = sanitizeMigrationError(err, step.step);
      await _writeMigrationAudit(conn, eventType, sanitized);
      logger.warn({ err, step: step.step }, 'schema migration step skipped — see audit row for errno-specific recovery path');
    }
  }
  if (privilegeSkips.length) {
    logger.warn(
      { steps: privilegeSkips, schema: _configFull && _configFull.database },
      'schema migration steps skipped — insufficient DDL privilege; see GET /api/platform/schema/status for exportable SQL',
    );
  }
  return { skippedSteps };
}

// Boot entry: wrap the migration run in a MariaDB advisory lock so parallel pods
// serialise (spec §4.7). Lock is connection-scoped, so a crashed pod can never
// strand it. On contention this never throws — GET_LOCK timeout re-reads the
// stamp: already at target → continue boot normally; still behind → skip this
// boot (degraded, retry next boot). RELEASE_LOCK in finally.
async function runSchemaMigrations(conn, opts = {}) {
  const database = await _currentDatabaseName(conn);
  const lockName = `fmb_migrations:${database}:${_tablePrefix || ''}`; // lint-allow: no-hardcoded-prefix GET_LOCK advisory-lock name, not a table identifier (spec §4.7 pins this name)
  const locked = await _acquireMigrationLock(conn, lockName);
  if (!locked) {
    const { currentVersion } = await _readSchemaVersionStamp(conn);
    if (_compareVersions(currentVersion, PLATFORM_SCHEMA_VERSION) >= 0) {
      logger.info({ lockName, currentVersion }, 'migration lock busy but schema already at target — continuing boot');
      return;
    }
    logger.warn(
      { lockName, currentVersion, target: PLATFORM_SCHEMA_VERSION },
      'migration lock busy — schema migrations skipped this boot; retry next boot. Live schema state is visible to admins at GET /api/platform/schema/status.',
    );
    return;
  }
  try {
    return await _runSchemaMigrationsLocked(conn, opts);
  } finally {
    await _releaseMigrationLock(conn, lockName);
  }
}

async function _runSchemaMigrationsLocked(conn, opts = {}) {
  // Only 'boot' gets its own branch here — 'reconfigure' (and any other
  // caller-supplied context) intentionally collapses into 'http'. This is
  // safe because the outer `ensureInfrastructure` preflight in db.js already
  // intercepts a reconfigure-context DdlPrivilegeError before this function
  // is ever reached; 'reconfigure' losing its identity at this layer only
  // matters for a grants change racing between the two preflight checks.
  const context = opts.context === 'boot' ? 'boot' : 'http';
  const steps = Array.isArray(opts.steps) ? opts.steps : MIGRATION_STEPS;
  // The boot/reconfigure caller (ensureInfrastructure in db.js) already ran an
  // identical APP-table DDL-grants preflight and returned early if it failed, so
  // re-running it here is pure duplication — it passes ddlPreflightAlreadyRun to
  // skip the second probe. INVARIANT: any caller that can reach migrations
  // WITHOUT ensureInfrastructure (the Setup Wizard init-db path) omits the flag
  // and still preflights itself here, so operator-mode skip/degrade is preserved
  // on every entry path.
  if (_configFull && _tablePrefix && !opts.ddlPreflightAlreadyRun) {
    try {
      await preflightDdlGrants(
        conn,
        _configFull.database,
        APP_TABLE_NAMES,
        (name) => `${_tablePrefix}${name}`,
        { user: _configFull.user, tablePrefix: _tablePrefix },
      );
    } catch (err) {
      if (err instanceof DdlPrivilegeError && context === 'boot') {
        // INVARIANT: matches the ensureInfrastructure() preflight handling —
        // operator-mode skip MUST be loud (WARN) so log scrapers and humans
        // can see the schema gap. Visibility is surfaced via the admin
        // schema-status endpoint.
        logger.warn(
          {
            user: _configFull.user,
            schema: _configFull.database,
            missingCreate: err.missingCreate,
            missingAlter: err.missingAlter,
          },
          '[ddl_preflight] runSchemaMigrations skipped — operator account lacks DDL privileges; DBA must run pending schema migrations manually (including nullable-batch NOT NULL alignment). Live schema state is visible to admins at GET /api/platform/schema/status.',
        );
        return;
      }
      throw err;
    }
  }

  const { currentVersion, hadStamp, readOk } = await _readSchemaVersionStamp(conn);

  // Baseline guard (spec §4.2). INVARIANT: the stamp is only ever written onto a
  // schema PROVEN current, so this must fire in EVERY context — boot, DB-switch,
  // AND the Setup Wizard's init-db path (a real production non-boot caller;
  // context-gating it let an init-db run against a below-baseline DB fill missing
  // tables, no-op the empty executor, and advance the stamp — permanently masking
  // an unsupported schema, Codex R2 P1a). A stamped-below-baseline DB, or an
  // unstamped DB carrying engine tables that fail the full-manifest completeness
  // check, is unsupported: run nothing, leave the stamp, surface the upgrade path
  // in schema/status. Skipped only on a transient stamp-read failure
  // (readOk=false) so a healthy DB is never mis-flagged. The DdlPrivilegeError
  // skip above stays boot-gated as before (unchanged).
  if (readOk && (await _isUnsupportedBaseline(conn, currentVersion, hadStamp))) {
    logger.warn(
      { currentVersion, baseline: BASELINE_SCHEMA_VERSION, schema: _configFull && _configFull.database },
      'schema below supported baseline — migrations skipped, stamp untouched; upgrade path required. Live schema state is visible to admins at GET /api/platform/schema/status.',
    );
    return { unsupported: true };
  }

  if (_compareVersions(currentVersion, PLATFORM_SCHEMA_VERSION) >= 0) {
    logger.info({ currentVersion }, 'schema version up to date');
    return;
  }

  logger.info({ from: currentVersion, to: PLATFORM_SCHEMA_VERSION }, 'running schema migrations');

  // Declarative registry executor: the sole migration body after
  // the pre-3.2.520 baseline reset. Its skips gate the version bump below.
  const { skippedSteps } = await _runMigrationSteps(conn, steps);

  // ── Bump platform_schema_version ───────────────────────────────────────
  // Only bump when EVERY migration step ran cleanly. If any step returned
  // 'skipped' (transient lock, driver edge, ALTER privilege missing), keep
  // the version where it was so the next boot retries. Without this gate,
  // an operator-mode boot that skipped the hierarchy ALTER would advance
  // the version anyway and the column would stay VARCHAR forever.
  if (skippedSteps > 0) {
    logger.warn(
      { skippedSteps, target: PLATFORM_SCHEMA_VERSION, current: currentVersion },
      'platform_schema_version NOT bumped — at least one migration step was skipped this boot; retry on next boot will re-attempt. Live schema state is visible to admins at GET /api/platform/schema/status.',
    );
    return;
  }
  try {
    await conn.query(
      `INSERT INTO \`${t(TABLES.SYSTEM_SETTINGS)}\` (id, \`key\`, value, description)
       VALUES (UUID(), 'platform_schema_version', ?, 'Schema version stamp set by runSchemaMigrations()')
       ON DUPLICATE KEY UPDATE value = VALUES(value)`,
      [JSON.stringify(PLATFORM_SCHEMA_VERSION)],
    );
    logger.info({ version: PLATFORM_SCHEMA_VERSION }, 'platform_schema_version bumped');
    await _writeMigrationAudit(conn, 'schema_migration.completed', {
      from: currentVersion,
      to: PLATFORM_SCHEMA_VERSION,
    });
  } catch (err) {
    logger.error({ err, version: PLATFORM_SCHEMA_VERSION }, 'Failed to write platform_schema_version=' + PLATFORM_SCHEMA_VERSION + ' — migration tracking inconsistent');
  }
}

/**
 * Lexicographic-safe semantic version comparison for the small set of
 * versions we actually use ("3.0.0", "3.1.0", "3.2.0", "3.2.32"). Returns
 * -1, 0, or 1.
 */
function _compareVersions(a, b) {
  const pa = String(a).split('.').map((n) => parseInt(n, 10) || 0);
  const pb = String(b).split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const ai = pa[i] || 0;
    const bi = pb[i] || 0;
    if (ai < bi) return -1;
    if (ai > bi) return 1;
  }
  return 0;
}

  return {
    _isAuditTableKey,
    _redactAuditTableNames,
    _writeMigrationAudit,
    runSchemaMigrations,
    _runSchemaMigrationsLocked,
    _compareVersions,
    _readSchemaVersionStamp,
    _isUnsupportedBaseline,
    _runMigrationSteps,
    _applyMigrationStep,
    _acquireMigrationLock,
    _releaseMigrationLock,
    _currentDatabaseName,
  };
}

module.exports = { createMigrationsModule };
