/**
 * index-edge.js — API-edge entry point (DB-facing service).
 *
 * API-edge is the only service with direct MariaDB access.
 * It accepts requests exclusively from API-infra via S2S authentication.
 *
 * Architecture:
 *   Browser → Vite → API-infra (:3200) → API-edge (:3201) → MariaDB
 *
 * This file is used when API_ROLE=edge.
 */
require('dotenv').config();
const express = require('express');
const { pool, t, isPoolReady, getPoolDiagnostic, initializeFromConfig, cleanupIdlePools, shutdown, getDbConfig } = require('./edge/db');
const { publishablePool } = require('./shared/lib/pool-diagnostic');
const { TABLES } = require('./shared/constants');
const { apiError } = require('./shared/helpers');
const { sendError } = require('./shared/lib/send-error');
const { s2sVerify } = require('./edge/middleware/s2s-verify');
const { impersonationReadOnly } = require('./edge/middleware/impersonation-readonly');
const { logger: rootLogger } = require('./shared/lib/logger');
const { printBootBanner } = require('./shared/lib/boot-banner');
const { bootLine, sysLog } = require('./shared/lib/log-streams');
const { mountEdgeInternalSpec } = require('./edge/openapi-spec');
const { mountEdgeDocs } = require('./edge/docs-page');
const { createStrictHelmet, createScalarStaticRouter } = require('./shared/security');
const { createRequestId } = require('./shared/middleware/request-id');
const { createRequestLog } = require('./shared/middleware/request-log');
const { handleBootInitError } = require('./edge/boot-guard');
const { installProcessTraps } = require('./shared/lib/install-process-traps');
const logger = rootLogger.child({ module: 'api-edge' });

// Process-level safety net: a rejected promise nobody awaited or a throw
// that escaped every try/catch logs one fatal/kind:sys line then exits(1)
// so k8s restarts the pod. Does not touch SIGTERM/SIGINT — those are
// registered below by this same file.
installProcessTraps(logger);

// ── Fail-fast: S2S_API_KEY required ──────────────────────────────────────────
if (!process.env.S2S_API_KEY) {
  logger.fatal('S2S_API_KEY environment variable is required for API-edge. Exiting.');
  process.exit(1);
}

const app = express();
const PORT = process.env.EDGE_PORT || 3201;

// Adopt the infra-supplied correlation id (format-guarded) so one id spans
// both pods' logs; mint our own for direct/boot-time S2S calls. Mounted first
// (like infra) so every response carries X-Request-Id even if a later guard
// short-circuits.
app.use(createRequestId({ trustInbound: true }));

// ── Security headers ─────────────────────────────────────────────────────────
app.use(createStrictHelmet());

// Access log per request. Skip health + docs assets; downgrade the
// high-frequency internal S2S auth probes to debug (a failure still warns).
// /edge/openapi.json is intentionally NOT skipped (security review LOW,
// v3.2.484): it is now a login-gated, security-relevant surface (see
// s2s-verify.js / openapi-spec.js), so 401s from probing/misuse need an
// access-log line, unlike when the route was fully public and always-200.
app.use(createRequestLog({
  skip: (path) =>
    path === '/edge/health'
    || path.startsWith('/edge/docs')
    || path.startsWith('/edge/scalar-assets')
    || path === '/favicon.ico',
  debug: (path) =>
    path === '/edge/internal/auth/identity-resolve'
    || path === '/edge/internal/system/auth-mode'
    // S2S credential resolution, fired per public-API request — the same
    // per-request chatter as identity-resolve/auth-mode, not a one-off.
    || path === '/edge/internal/machine-token/resolve',
}));

app.use(express.json({ limit: '10mb' })); // ARCH-5: setup/seed needs 10MB

// ── Favicon fallback (prevents 401 noise when browsing edge docs) ───────────
app.get('/favicon.ico', (_req, res) => res.status(204).end());

// ── API Documentation ────────────────────────────────────────────────────────
// Self-hosted Scalar: serve bundle from node_modules, route-scoped relaxed CSP.
// The dev-only /edge/docs UI (inline spec) is disabled in production. The raw
// /edge/openapi.json route is NOT mounted here — it is a login-gated operator
// surface mounted after s2sVerify (see mountEdgeInternalSpec below).
const SCALAR_MOUNT = '/edge/scalar-assets';
app.use(createScalarStaticRouter(SCALAR_MOUNT));
mountEdgeDocs(app, SCALAR_MOUNT);

// ── CSRF guard (defense-in-depth, mirrors infra) ─────────────────────────────
app.use((req, res, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const contentLength = parseInt(req.headers['content-length'] || '0', 10);
  if (contentLength === 0 && !req.headers['content-type']) return next();
  const ct = (req.headers['content-type'] || '').toLowerCase();
  if (ct.startsWith('application/json')) return next();
  // NOTE: YAML round-trip blueprint import accepts text/yaml. Same exception
  // as the infra CSRF guard (rationale documented there). Edge is also S2S-only
  // so this guard is purely defense-in-depth.
  if (
    req.path === '/edge/app/schema/blueprint-import-yaml'
    && (ct.startsWith('text/yaml') || ct.startsWith('application/yaml') || ct.startsWith('application/x-yaml'))
  ) {
    return next();
  }
  return res.status(415).json({ error: { message: 'Content-Type must be application/json', code: 'UNSUPPORTED_MEDIA_TYPE' } });
});

// ── S2S verification (all routes except /edge/health) ────────────────────────
app.use(s2sVerify);

// ── Impersonation read-only gate ─────────────────────────────────────────────
// Must run after s2sVerify so req.user (incl. the impersonated flag
// reconstructed from trusted forwarded headers) is already in place.
app.use(impersonationReadOnly);

// Internal (edge) OpenAPI spec — login-gated operator surface. Mounted AFTER
// s2sVerify so req.user is populated from the forwarded human identity; a
// machine principal or an unidentified caller gets 401 (see mountEdgeInternalSpec).
mountEdgeInternalSpec(app);

// ── X-Database header middleware ─────────────────────────────────────────────
// Mounted BEFORE initializeFromConfig().then() so the validation gate is in
// place before any request reaches the route handlers. The middleware itself
// gates on isPoolReady() — when pool is not ready it short-circuits to next()
// without enforcement, matching the wizard cold-boot contract. Once init
// completes, X-Database validation kicks in for schema-routable paths.
app.use(require('./edge/middleware/x-database-validate'));

// ── Health endpoint (exempt from S2S) ────────────────────────────────────────
// INVARIANT: /edge/health MUST return HTTP 200 unconditionally. The body may
// degrade (db=error, pool_state=setup-required), but the status code is the
// K8s readiness probe target. Pool diagnostic is sanitised at the boundary;
// err.message never reaches here.
// SECURITY: publishablePool() projects onto PUBLISHED_POOL_FIELDS here too —
// not only in infra's re-publication of this same reply. This is the
// unauthenticated body itself (see pool-diagnostic.js module header: "one
// list, applied twice"); a field a future builder change adds for an
// operator must be withheld here by default, not merely by staying off a
// second, downstream copy of this response.
// Health-flip transition guard (spec §7 sys): /edge/health runs on every
// k8s readiness/liveness poll — logging every observation would spam one
// line per poll. null until the first observation; a REPEAT of the same
// probe outcome logs nothing.
let _lastEdgeDbHealthy = null;
function noteEdgeDbHealthTransition(healthy, err) {
  if (_lastEdgeDbHealthy === healthy) return;
  _lastEdgeDbHealthy = healthy;
  sysLog(null, { level: healthy ? 'info' : 'warn', err: healthy ? undefined : err }, healthy ? 'DB health probe recovered' : 'DB health probe failed');
}

app.get('/edge/health', async (_req, res) => {
  const status = {
    api: 'ok',
    role: 'edge',
    db: 'not_configured',
    pool: publishablePool(getPoolDiagnostic()),
  };
  if (isPoolReady()) {
    try {
      // NOTE: probe reader pool (falls back to writer when no separate RO
      // endpoint is configured). On dual-endpoint deployments this also
      // surfaces replica outages that a writer-only probe would miss.
      const conn = await pool.ro.getConnection();
      conn.release();
      status.db = 'ok';
      noteEdgeDbHealthTransition(true);
    } catch (err) {
      // Do NOT embed err.message in the RESPONSE — on dual-endpoint
      // topologies this can leak the internal RO hostname (e.g.
      // "getaddrinfo ENOTFOUND ro-replica-internal.corp") to unauthenticated
      // callers of /edge/health. The full error still reaches the logger
      // (operator-only surface) via noteEdgeDbHealthTransition's `err`.
      noteEdgeDbHealthTransition(false, err);
      status.db = 'error';
    }
  }
  res.json(status);
});

// ── Graceful shutdown ────────────────────────────────────────────────────────
// A container runtime can deliver SIGTERM then SIGINT (or duplicate signals)
// during the same shutdown; without this guard a second signal re-enters the
// handler and logs a second "graceful shutdown" sys line for one shutdown.
let _shuttingDown = false;

async function gracefulShutdown(signal) {
  if (_shuttingDown) return;
  _shuttingDown = true;
  sysLog(null, { level: 'info', fields: { signal } }, 'graceful shutdown');
  clearInterval(_cleanupInterval);
  await shutdown();
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

const _cleanupInterval = setInterval(cleanupIdlePools, 60_000);

// ── Initialize: configure pool → mount routes → listen ───────────────────────
// RESILIENCE: a RECOVERABLE boot-time DB init problem must NEVER crash-loop
// edge. initializeFromConfig degrades every such case to a null pool and
// resolves, so the following `.then()` — which mounts every route and calls
// app.listen() — runs and edge comes up health-probe-green in setup-required
// mode: the pool stays null and DB-dependent routes surface setup-required per
// request until POST /api/setup/configure-db succeeds.
//
// SECURITY: the ONE rejection initializeFromConfig still emits is the
// SKIP_DB_INIT + production fail-fast guard (err.fatalBoot). handleBootInitError
// crashes the pod on that one — a blanket .catch() that degraded it too would
// silently boot edge with no DB pool in production. process.exit terminates
// before the `.then()` runs.
initializeFromConfig().catch((err) => {
  handleBootInitError(err, { logger, exit: process.exit });
}).then(async () => {
  // NOTE: edge owns the canonical auth-mode resolution since infra fetches it
  // from edge via S2S. detectAuthMode reads system_settings if pool is ready,
  // otherwise falls through to env / KC discovery. Without this call, edge's
  // `_resolvedAuthMode` stays at the module default 'local' and
  // Keycloak-configured cold boots would report local to infra.
  const { detectAuthMode } = require('./shared/config');
  try {
    await detectAuthMode(isPoolReady() ? pool : null, isPoolReady() ? t : null);
  } catch (err) {
    logger.warn({ err }, 'edge detectAuthMode at boot failed — staying on default');
  }

  // ── Platform routes (Phase 1) ───────────────────────────────────────────
  app.use('/edge/platform/audit', require('./edge/routes/platform/audit'));
  app.use('/edge/platform/auth', require('./edge/routes/platform/auth-sessions'));
  app.use('/edge/platform/users', require('./edge/routes/platform/users'));
  app.use('/edge/platform/settings', require('./edge/routes/platform/settings'));
  app.use('/edge/platform/connections', require('./edge/routes/platform/connections'));
  app.use('/edge/platform/access-rules', require('./edge/routes/platform/access-rules'));
  app.use('/edge/platform/access-check', require('./edge/routes/platform/access-check'));
  app.use('/edge/platform/auth-password', require('./edge/routes/platform/auth-password'));
  app.use('/edge/platform/export', require('./edge/routes/platform/export'));
  app.use('/edge/platform/query', require('./edge/routes/platform/query'));
  app.use('/edge/platform/setup', require('./edge/routes/platform/setup'));
  app.use('/edge/platform/feature-audit', require('./edge/routes/platform/feature-audit'));
  app.use('/edge/platform/debug', require('./edge/routes/platform/dto-mapper-debug'));
  // DB-layer GRANT/REVOKE UI (admin-only)
  app.use('/edge/platform/privileges', require('./edge/routes/platform/privileges'));
  // Visibility surface admin endpoint (admin-only, live-derived)
  app.use('/edge/platform/schema-status', require('./edge/routes/platform/schema-status'));
  // DBA remediation SQL export for missing schema structure (admin-only, text/plain)
  app.use('/edge/platform/schema-export-sql', require('./edge/routes/platform/schema-export-sql'));
  // Public Integration API admin register/rotate/deactivate (admin-only)
  app.use('/edge/platform/service-accounts', require('./edge/routes/platform/service-accounts'));

  // ── Internal routes — S2S-only consumers of edge state ───────────────
  // See CLAUDE.md §3 RULE infra-talks-to-edge-only for the architectural
  // constraint that all infra→DB access flows through these endpoints.
  app.use('/edge/internal/auth', require('./edge/routes/internal/identity-resolve'));
  app.use('/edge/internal/system', require('./edge/routes/internal/system'));
  app.use('/edge/internal/connectors', require('./edge/routes/internal/connectors'));
  app.use('/edge/internal/flow-steps', require('./edge/routes/internal/flow-steps'));
  app.use('/edge/internal/flow-recipes', require('./edge/routes/internal/flow-recipes-run'));
  app.use('/edge/internal/machine-token', require('./edge/routes/internal/machine-token'));
  // Public Integration API scoped read projections (P2). S2S-only; infra
  // forwards here on the machine-principal contract. Never publicly routed.
  app.use('/edge/internal/public-read', require('./edge/routes/internal/public-read'));
  // Public Integration API template shell-create (P3). S2S-only; infra forwards
  // here on the machine-principal contract. Never publicly routed.
  app.use('/edge/internal/public-write', require('./edge/routes/internal/public-write'));

  // ── App routes (Phase 2) ──────────────────────────────────────────────
  app.use('/edge/app/schema', require('./edge/routes/app/schema'));
  // NOTE: blueprint export/import mounted under /edge/app/schema so the
  // existing /api/schema -> /edge/app/schema forwarder covers it without
  // a new infra proxy entry.
  app.use('/edge/app/schema', require('./edge/routes/app/blueprint-export'));
  app.use('/edge/app/sync-schema', require('./edge/routes/app/sync-schema'));
  app.use('/edge/app/transformers', require('./edge/routes/app/transformers'));
  app.use('/edge/app/api-connectors', require('./edge/routes/app/api-connectors'));
  app.use('/edge/app/flow-recipes', require('./edge/routes/app/flow-recipes'));
  app.use('/edge/app/flow-recipe-steps', require('./edge/routes/app/flow-recipe-steps'));
  app.use('/edge/app/flow-recipe-runs', require('./edge/routes/app/flow-recipe-runs'));
  app.use('/edge/app/capacity', require('./edge/routes/app/capacity'));
  app.use('/edge/app/delegated-grants', require('./edge/routes/app/delegated-grants'));
  app.use('/edge/app/template-activity', require('./edge/routes/app/template-activity'));
  app.use('/edge/app/templates', require('./edge/routes/app/template-snapshots'));
  app.use('/edge/app/templates', require('./edge/routes/app/template-versions'));

  // ── Centralized error handler ──────────────────────────────────────────
  // Logs through req.log when present (joins the request's req_id/actor
  // bindings, spec §6) — falls back to the base logger only for an error
  // raised before request-id.js ran.
  app.use((err, req, res, _next) => {
    const status = err.status || err.statusCode || 500;
    const code = err.code || 'INTERNAL_ERROR';
    // 500 message is masked; a mapped <500 keeps its own message. sendError
    // is the single logger+responder: it logs the app-error line (stack) for a
    // >=500 and responds via apiError — this handler stays the last-resort
    // logger for errors no route caught.
    const reason = status === 500 ? 'Internal server error' : (err.message || 'Unknown error');

    sendError(req, res, err, { status, code, reason });
  });

  app.listen(PORT, () => {
    const dbCfg = getDbConfig();
    const dbMode = isPoolReady() ? 'ready' : 'setup-required';

    // NOTE: edge's external row reports "internal S2S only" — edge has no
    // public-facing path; all traffic is S2S-authenticated.
    try {
      printBootBanner({
        role: 'EDGE',
        port: PORT,
        logger,
        depsSummary: [
          dbCfg
            ? `DB: ${dbMode} (${dbCfg.host}:${dbCfg.port}/${dbCfg.database}, prefix=${dbCfg.tablePrefix})`
            : `DB: ${dbMode}`,
          `S2S: ${process.env.S2S_API_KEY ? 'configured' : 'NOT SET — all requests will fail'}`,
          'Middleware: helmet, json(10mb), s2s-verify',
          'Routes: /edge/health, /edge/platform/audit, /edge/platform/users',
        ],
      });
    } catch (err) {
      logger.error(
        { err: err.message },
        'boot banner failed — check APP_NAME / BASE_URL / FRONTEND_URL env',
      );
      throw err;
    }
    // NOTE: boot-phase env snapshot intentionally omitted — noise on every
    // healthy boot; fail-phase dump on validateConfig error retains the
    // operator observability affordance.
    const { resolveAuthMode } = require('./shared/config');
    bootLine({
      role: 'EDGE',
      port: PORT,
      authMode: resolveAuthMode(),
      // host:port only, never credentials (RULE: no secret in a log line).
      dbHost: dbCfg ? `${dbCfg.host}:${dbCfg.port}` : undefined,
    });
  });
});
