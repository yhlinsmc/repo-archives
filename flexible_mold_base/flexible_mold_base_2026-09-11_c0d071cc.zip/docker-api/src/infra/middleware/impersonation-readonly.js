const { apiError } = require('../../shared/helpers');
const { sendError } = require('../../shared/lib/send-error');
const { logSecurity } = require('../../shared/lib/log-streams');

const READ_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

// SAFETY: read-only data POSTs — SELECT-only batch reads that must use POST
// because the infra→edge proxy folds repeated GET query params into a single
// scalar, so a batched id-list read cannot travel as `?id=a&id=b`. Equivalent
// to the GET reads this gate already allows. Exact match only — sibling write
// POSTs under the same router (e.g. .../replace) stay blocked.
const READONLY_EXEMPT_EXACT = new Set([
  '/api/schema/field_options/by-fields',
  '/api/schema/blueprint_fields/by-blueprints',
  // SELECT-only orphan scan; POST-shaped because forwardToEdge drops the body
  // (and thus req.body.db) on GET. The sibling DELETE clear stays blocked.
  '/api/schema/field-data-orphans',
]);

/**
 * Primary read-only gate for impersonation. When the auth middleware set
 * req.impersonator (real admin viewing as a target user), block every
 * non-read /api/* method before it can forward to edge.
 *
 * Edge carries a defense-in-depth copy of this guard, but infra
 * must stop writes here so they never traverse the S2S boundary in the
 * first place — fail-closed at the earliest possible point.
 */
function impersonationReadOnly(req, res, next) {
  if (!req.path.startsWith('/api/')) return next();
  if (req.impersonator && !READ_METHODS.has(req.method) && !READONLY_EXEMPT_EXACT.has(req.path)) {
    logSecurity(req, { event: 'impersonate_blocked', level: 'warn', reason: 'read_only', terminal: true }, 'impersonated write blocked');
    return sendError(req, res, null, { status: 403, code: 'IMPERSONATION_READ_ONLY', reason: 'This action is not allowed while viewing as another user (read-only).' });
  }
  return next();
}

module.exports = { impersonationReadOnly };
