/**
 * access-check.js — Infra-side access check middleware (S2S to edge).
 *
 * Enforces default-deny + allowlist via a POST to /edge/platform/access-check.
 * Active only when auth_mode=keycloak and the user is not admin.
 *
 * NOTE: auth_mode is fetched from edge via /edge/internal/system/auth-mode
 * rather than importing the pool (infra-talks-to-edge-only rule). When edge
 * is unreachable on the mode probe, we fail closed (treat as denied) — same
 * posture as the access-check S2S failure mode.
 *
 * Exemptions (handled by the caller in index-infra.js, not here):
 *   /health, /api/setup, /api/auth/mode, /api/auth/sso-login,
 *   /api/auth/callback, /api/auth/logout, /api/auth/me, /api/auth/diagnostics
 */

const { logger: rootLogger } = require('../../shared/lib/logger');
const { sendError } = require('../../shared/lib/send-error');
const { apiError } = require('../../shared/helpers');
const { resolveAuthMode } = require('../../shared/config');
const { buildS2sHeaders } = require('../../shared/middleware/s2s-auth');
const { fetchAuthMode, EdgeUnreachable, EdgeTimeout, EdgeAuthFailed, getEdgeBaseUrl } = require('../lib/edge-state-client');

const logger = rootLogger.child({ module: 'access-check-middleware' });

function isEdgeUnreachable(err) {
  return err instanceof EdgeUnreachable || err instanceof EdgeTimeout || err instanceof EdgeAuthFailed;
}

async function accessCheckMiddleware(req, res, next) {
  let mode;
  try {
    const result = await fetchAuthMode(req.user || null, { reqId: req.id });
    mode = result.auth_mode || resolveAuthMode();
  } catch (err) {
    if (isEdgeUnreachable(err)) {
      // Edge unreachable on auth_mode probe — fail closed if route was
      // reaching access-check (would only happen for protected routes
      // that bypassed the pool-gate). 503 preserves k8s observability.
      return sendError(req, res, err, { status: 503, code: 'EDGE_UNREACHABLE', reason: 'Edge unreachable', details: { hint_code: 'edge_unreachable' }, fields: { log_code: err.code, log_msg: 'edge unreachable during access-check auth-mode probe' } });
    }
    logger.warn({ err }, 'access-check auth-mode fallback to env');
    mode = resolveAuthMode();
  }
  if (mode !== 'keycloak') return next();

  if (!req.user) return next();
  if (req.user.role === 'admin') return next();

  try {
    const s2sHeaders = buildS2sHeaders(req.user, { impersonatorId: req.impersonator ? req.impersonator.id : undefined });
    const resp = await fetch(`${getEdgeBaseUrl()}/edge/platform/access-check`, {
      method: 'POST',
      headers: {
        ...s2sHeaders,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: req.user.email || null,
        deptid: req.user.deptid || null,
        role: req.user.role || null,
      }),
      signal: AbortSignal.timeout(5000),
    });

    if (!resp.ok) {
      return sendError(req, res, null, { status: 500, code: 'ACCESS_CHECK_ERROR', reason: 'Access check failed', fields: { log_status: resp.status, log_msg: 'Failed to invoke access-check S2S call status=' + resp.status } });
    }

    const body = await resp.json();
    if (body.data?.allowed) {
      return next();
    }

    return sendError(req, res, null, { status: 403, code: 'ACCESS_DENIED', reason: 'Access denied. Contact your administrator for access.' });
  } catch (err) {
    sendError(req, res, err, { status: 500, code: 'ACCESS_CHECK_ERROR', reason: 'Access check failed', fields: { log_msg: 'Failed to invoke access-check S2S call (exception)' } });
  }
}

module.exports = { accessCheckMiddleware };
