/**
 * keycloak-oidc.js — express-openid-connect middleware with auth_mode gate.
 *
 * This middleware is mounted conditionally in index.js. When auth_mode is
 * 'keycloak', it initialises the OIDC session layer (express-openid-connect)
 * as a stateless encrypted-cookie session. When auth_mode is 'local',
 * this middleware is a no-op pass-through.
 *
 * SESSION STORAGE (why stateless cookies, not a server-side store):
 * The infra pod is single-replica and ArgoCD auto-syncs on every merge, so any
 * in-process store (the former MemoryStore) was wiped on every deploy and every
 * user was forced to re-login. express-openid-connect's default session is a
 * stateless encrypted cookie: the token set (id_token/access_token/refresh_token)
 * is encrypted (dir / A256GCM JWE, key derived from KEYCLOAK_SECRET) and stored
 * client-side, auto-chunked across cookies when it exceeds the 4KB per-cookie
 * limit. Because the encryption key is a stable env var, the session survives
 * pod restarts by construction — no server-side store, no new dependency, and
 * `infra-talks-to-edge-only` is respected (infra reaches no store/DB). Server-side
 * revocation still holds: access tokens are short-lived and every refresh is
 * validated against Keycloak; idpLogout clears the Keycloak session on logout.
 *
 * Middleware ordering (enforced in index.js):
 *   keycloak-oidc.js → auth.js → access-check → routes
 *
 * IMPORTANT: authRequired is set to false (passive mode) so unauthenticated
 * requests pass through to auth.js for JWT handling. Only /api/auth/login
 * triggers the OIDC redirect.
 */

const { auth } = require('express-openid-connect');
const { resolveAuthMode } = require('../../shared/config');
const { logger: rootLogger } = require('../../shared/lib/logger');
const { notifyFreshLogin } = require('../lib/oidc-fresh-login');
const { markSecurity } = require('../../shared/middleware/route-markers');
const logger = rootLogger.child({ module: 'keycloak-oidc' });

// The three routes express-openid-connect auto-registers (below, in
// oidcConfig.routes). Exported as one object so the request-log §5 security
// marker (markOidcSecurityRoutes) reads the SAME literals instead of a
// second hand-copied list that could silently drift out of sync.
const OIDC_ROUTE_PATHS = {
  login: '/api/auth/sso-login',
  logout: '/api/auth/logout',
  callback: '/api/auth/callback',
};

/**
 * express-openid-connect mounts its own login/logout/callback handlers
 * internally (auth(oidcConfig) below) — they never pass through a route
 * this codebase controls, so none of them carries `markSecurity`, and a
 * logout / SSO login / callback would otherwise log at `access`/`debug`
 * (invisible at the default LOG_LEVEL=info). Path-based rather than a real
 * Express route match, because at this point in the stack it is not one.
 * @param {import('express').Request} req
 * @param {import('express').Response} res
 * @param {import('express').NextFunction} next
 */
function markOidcSecurityRoutes(req, res, next) {
  const path = (req.path || req.url || '').split('?')[0];
  if (path === OIDC_ROUTE_PATHS.login || path === OIDC_ROUTE_PATHS.logout || path === OIDC_ROUTE_PATHS.callback) {
    return markSecurity(req, res, next);
  }
  next();
}

/**
 * Validate Keycloak connectivity and CA cert at startup.
 * Runs asynchronously — logs results but does not block startup.
 *
 * @param {string} issuerBaseURL
 */
function validateKeycloakOnInit(issuerBaseURL) {
  const caCertPath = process.env.KEYCLOAK_CA_CERT_PATH;

  // Check CA cert validity (synchronous)
  if (caCertPath) {
    try {
      const fs = require('fs');
      fs.accessSync(caCertPath, fs.constants.R_OK);
      const content = fs.readFileSync(caCertPath, 'utf-8');
      if (content.includes('-----BEGIN CERTIFICATE-----')) {
        // NOTE: `caCertPath` binding (not bare `path`) keeps the operator-known
        // env var visible for TLS/CA debug; intentionally not redacted.
        logger.info({ caCertPath }, 'CA cert is valid and readable');
      } else {
        // NOTE: `caCertPath` binding; intentionally not redacted (operator-known env var).
        logger.error({ caCertPath }, 'Failed to validate Keycloak CA cert (file does not contain a PEM certificate)');
        logger.error('Hint: Ensure the file contains a PEM-encoded certificate starting with -----BEGIN CERTIFICATE-----');
      }
    } catch (err) {
      // NOTE: `caCertPath` binding; intentionally not redacted (operator-known env var).
      logger.error({ caCertPath, err }, 'Failed to read Keycloak CA cert');
      logger.error('Hint: Check that KEYCLOAK_CA_CERT_PATH points to an existing, readable file.');
    }
  }

  // Check issuer URL reachability (async, non-blocking)
  const discoveryUrl = `${issuerBaseURL}/.well-known/openid-configuration`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);

  fetch(discoveryUrl, { signal: controller.signal })
    .then(resp => {
      clearTimeout(timeout);
      if (resp.ok) {
        logger.info({ issuerBaseURL }, 'Keycloak issuer is reachable');
      } else {
        logger.error({ status: resp.status, discoveryUrl }, 'Failed to reach Keycloak issuer discoveryUrl=' + discoveryUrl + ' status=' + resp.status);
        logger.error('Hint: Verify KEYCLOAK_ISSUER_BASE_URL is correct and the Keycloak server is running.');
      }
    })
    .catch(err => {
      clearTimeout(timeout);
      const isTimeout = err.name === 'AbortError';
      if (isTimeout) {
        logger.error({ discoveryUrl }, 'Failed to reach Keycloak issuer discoveryUrl=' + discoveryUrl + ' (timeout after 5s)');
        logger.error('Hint: Check network connectivity to the Keycloak server. In AIRGAP environments, verify the internal DNS/IP is correct.');
      } else {
        logger.error({ err, discoveryUrl }, 'Failed to reach Keycloak issuer discoveryUrl=' + discoveryUrl);
        if (err.code === 'UNABLE_TO_VERIFY_LEAF_SIGNATURE' || err.code === 'CERT_HAS_EXPIRED') {
          logger.error('Hint: TLS certificate issue. Set NODE_EXTRA_CA_CERTS to your CA cert path, or check KEYCLOAK_CA_CERT_PATH.');
        } else if (err.code === 'ECONNREFUSED') {
          logger.error('Hint: Connection refused. Ensure Keycloak is running and the port is correct in KEYCLOAK_ISSUER_BASE_URL.');
        } else if (err.code === 'ENOTFOUND') {
          logger.error('Hint: Hostname not found. Check the domain in KEYCLOAK_ISSUER_BASE_URL and DNS configuration.');
        } else {
          logger.error('Hint: Check KEYCLOAK_ISSUER_BASE_URL, network connectivity, and firewall rules.');
        }
      }
    });
}

/**
 * HIGH-1: Validate a redirect URL to prevent open redirect attacks.
 * Only allows relative paths or URLs whose origin matches FRONTEND_URL/BASE_URL.
 *
 * @param {string|undefined} url
 * @returns {boolean}
 */
function _isSafeRedirectUrl(url) {
  if (!url) return false;
  // Relative paths are always safe
  if (url.startsWith('/') && !url.startsWith('//')) return true;
  try {
    const parsed = new URL(url);
    // Only allow http/https protocols
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return false;
    // Validate against known origins
    const origins = [
      process.env.FRONTEND_URL,
      process.env.BASE_URL,
    ];
    // Only allow localhost origins in non-production (dev/test)
    if (process.env.NODE_ENV !== 'production') {
      const port = process.env.PORT || 3200;
      origins.push(`http://localhost:${port}`, `https://localhost:${port}`);
      origins.push('http://localhost:3000', 'https://localhost:3000');
    }
    const allowedOrigins = origins
      .filter(Boolean)
      .map(u => { try { return new URL(u).origin; } catch { return null; } })
      .filter(Boolean);
    return allowedOrigins.includes(parsed.origin);
  } catch {
    return false;
  }
}

/**
 * Build the post-logout redirect URL.
 * Returns FRONTEND_URL + '/login' if safe, otherwise '/login'.
 */
function _buildPostLogoutUrl() {
  const frontendUrl = process.env.FRONTEND_URL;
  if (frontendUrl && _isSafeRedirectUrl(frontendUrl)) {
    return `${frontendUrl.replace(/\/$/, '')}/login`;
  }
  return '/login';
}

// /login is not a legitimate deep-link return target: honouring it would
// bounce a rate-limited/failed sign-in straight back to the login screen
// instead of the page the caller actually asked for. /setup is NOT excluded
// here: the first-admin wizard's Keycloak completion step legitimately sends
// return_to=/setup?step=N&keycloak=success, and the /setup page itself is
// gated by setup-completion state server-side, so a hand-crafted /setup
// target cannot loop back into itself.
// Matched against the parsed pathname only (see isSameOriginRelativePath) so
// a query/hash suffix such as /login?notice=x cannot smuggle past the check.
const _AUTH_ONLY_PATH_RE = /^\/login(\/|$)/;

// express-openid-connect base64-encodes returnTo into both the authorization
// redirect URL and its signed, cookie-borne transaction state; base64
// inflates size by ~4/3, and common proxy/browser cookie limits sit around
// 4KB per cookie (with other transaction-state fields sharing that budget).
// 1024 raw chars stays comfortably under that ceiling (~1365 encoded bytes)
// so a legitimate-but-long deep link degrades to the FRONTEND_URL fallback
// instead of silently breaking the OIDC callback.
const _MAX_RETURN_TO_LENGTH = 1024;

/**
 * True when `value` is a same-origin relative deep-link path, safe to ride
 * through a query param and be consumed as a redirect target: a single
 * leading slash, no scheme, no `//` / `/\` that a browser would normalise to
 * a cross-origin authority (open-redirect vector), no control characters
 * (`\t`/`\r`/`\n` — a browser strips these before navigating, so the
 * rejected `/\evil` would otherwise slip through as `/\t/evil` and still
 * become the cross-origin `//evil`), not longer than `_MAX_RETURN_TO_LENGTH`
 * (see comment above), and not `/login` (or its sub-paths) — checked
 * against the parsed pathname so a query/hash suffix cannot bypass the
 * auth-only exclusion (`/setup` is deliberately NOT excluded here — see
 * `_AUTH_ONLY_PATH_RE`'s comment). Also re-checked against
 * `_isSafeRedirectUrl` (the open-redirect origin guard) as a
 * defense-in-depth backstop.
 *
 * Shared by every call site that accepts a `return_to`-shaped value from a
 * request so the same-origin rule lives in exactly one place.
 *
 * @param {unknown} value
 * @returns {boolean}
 */
function isSameOriginRelativePath(value) {
  // A repeated query param arrives as an array — only a single string is a
  // legitimate deep link.
  if (typeof value !== 'string' || value.length === 0) return false;
  if (value.length > _MAX_RETURN_TO_LENGTH) return false;
  if (!value.startsWith('/') || value.startsWith('//')) return false;
  if (/[\\\t\r\n]/.test(value)) return false;
  let pathname;
  try {
    // Dummy origin: `value` is already confirmed to be a single-leading-slash,
    // scheme-free, backslash/control-char-free string, so this only parses
    // out path/query/hash — it can never resolve to a different authority.
    pathname = new URL(value, 'http://same-origin.invalid').pathname;
  } catch {
    return false;
  }
  if (_AUTH_ONLY_PATH_RE.test(pathname)) return false;
  return _isSafeRedirectUrl(value);
}

/**
 * Resolve the post-callback redirect target for an sso-login request.
 *
 * The OIDC login state's `returnTo` is consumed verbatim by
 * express-openid-connect as the post-callback `res.redirect(...)` target, so it
 * must carry the frontend origin (dev: app on :3000, API on :3200) — a bare
 * relative path would redirect to the API host, which does not serve the SPA.
 *
 * A caller-supplied `return_to` is honoured only when it passes
 * `isSameOriginRelativePath` (see that function for the full rule). Anything
 * absent or rejected falls back to today's behaviour (FRONTEND_URL).
 *
 * @param {import('express').Request} req
 * @returns {string}
 */
function _resolveSsoReturnTo(req) {
  const frontendUrl = process.env.FRONTEND_URL;
  const frontendSafe = _isSafeRedirectUrl(frontendUrl);
  const fallback = frontendSafe ? frontendUrl : '/';

  const raw = req && req.query ? req.query.return_to : undefined;
  if (!isSameOriginRelativePath(raw)) return fallback;

  // Prepend the frontend origin so the callback lands on the SPA host. When
  // FRONTEND_URL is unset/unsafe (prod same-origin build), the relative path is
  // already same-origin.
  const base = frontendSafe ? frontendUrl.replace(/\/$/, '') : '';
  return `${base}${raw}`;
}

/**
 * Build the OIDC middleware stack (session + auth).
 * Returns an array of middleware functions to mount via app.use().
 *
 * @returns {import('express').RequestHandler[]}
 */
function buildKeycloakMiddleware() {
  const issuerBaseURL = process.env.KEYCLOAK_ISSUER_BASE_URL;
  const clientID = process.env.KEYCLOAK_CLIENT_ID;
  const clientSecret = process.env.KEYCLOAK_CLIENT_SECRET;
  const secret = process.env.KEYCLOAK_SECRET;

  const isProduction = process.env.NODE_ENV === 'production';

  // KEYCLOAK_SECRET is now the sole protector of the cookie-borne encrypted
  // token set, so validate it strictly. Both failure branches fail CLOSED
  // (return [] → no OIDC middleware → no session cookies issued → nobody can
  // log in), so a bad/absent secret can never produce an insecurely-keyed
  // session. In production the log is escalated to error so a misconfigured
  // deploy is loud; in dev it stays a warn (login is simply disabled until the
  // secret is provided — the only dev fallback, and it issues no sessions).
  if (!issuerBaseURL || !clientID || !clientSecret || !secret) {
    const log = isProduction ? logger.error.bind(logger) : logger.warn.bind(logger);
    log('missing KEYCLOAK_* env vars — OIDC middleware not initialised (SSO login disabled)');
    return [];
  }

  // Reject placeholder secrets (same pattern as JWT_SECRET in config.js).
  // Reject any value that looks like a placeholder (case-insensitive, trimmed).
  const lowerSecret = secret.toLowerCase().trim();
  if (lowerSecret.startsWith('change') || lowerSecret === 'secret' || lowerSecret === 'test') {
    logger.error('Failed to initialise OIDC middleware: KEYCLOAK_SECRET is set to a known placeholder. Use a real 32+ char random string. (SSO login disabled)');
    return [];
  }

  // express-openid-connect config
  const oidcConfig = {
    authRequired: false, // passive mode — let auth.js handle unauthenticated
    auth0Logout: false,  // not Auth0 — use standard OIDC logout
    idpLogout: true,     // redirect to Keycloak end_session_endpoint on logout
    issuerBaseURL,
    baseURL: process.env.BASE_URL || `http://localhost:${process.env.PORT || 3200}`,
    clientID,
    clientSecret,
    secret,
    authorizationParams: {
      response_type: 'code',
      scope: 'openid profile email',
    },
    routes: {
      // Custom login path to avoid conflict with POST /api/auth/login (local bcrypt)
      login: OIDC_ROUTE_PATHS.login,
      logout: OIDC_ROUTE_PATHS.logout,
      callback: OIDC_ROUTE_PATHS.callback,
      // Post-logout redirect: FRONTEND_URL/login with open redirect guard
      postLogoutRedirect: _buildPostLogoutUrl(),
    },
    // After OIDC callback, redirect to frontend app (not the API server).
    // In dev, frontend runs on :3000 while API is on :3200.
    // In production (SERVE_STATIC=true), they're the same origin.
    // HIGH-1: validate returnTo against FRONTEND_URL to prevent open redirect.
    // A same-origin `return_to` deep link (path+query+hash) rides through here
    // so the callback lands on the URL the user opened, not FRONTEND_URL.
    getLoginState: (req) => ({
      returnTo: _resolveSsoReturnTo(req),
    }),
    session: {
      // No `store` — stateless encrypted-cookie session (see file header).
      // The token set lives in the client cookie, encrypted with KEYCLOAK_SECRET,
      // so it survives infra pod restarts. express-openid-connect auto-chunks the
      // cookie when the encrypted payload exceeds the 4KB per-cookie limit
      // (measured: ~4.3KB for a typical session → 2 chunks; well within limits).
      rolling: true, // extend session on activity
      absoluteDuration: 8 * 60 * 60, // 8 hours absolute max
      cookie: {
        httpOnly: true,
        // Cookie policy: adapt to baseURL protocol.
        //   HTTPS (prod, or dev with self-signed certs):
        //     SameSite=None + Secure — supports cross-site redirects from
        //     Keycloak when issuer is on a different site (e.g. two Istio
        //     VirtualServices).
        //   HTTP (dev via port-forward, localhost:8143 ↔ localhost:8180):
        //     SameSite=Lax — localhost ports are same-site, Lax survives
        //     top-level GET redirects (which is exactly the Keycloak
        //     callback shape). `SameSite=None; Secure=false` is rejected
        //     outright by browsers — the session cookie would never be
        //     stored, producing an infinite login loop.
        // express-openid-connect validates Secure against baseURL protocol (config.js:108).
        // CSRF surface mitigated by Content-Type enforcement on mutation endpoints.
        sameSite: (process.env.BASE_URL || '').startsWith('https://') ? 'None' : 'Lax',
        secure: (process.env.BASE_URL || '').startsWith('https://'),
      },
    },
    afterCallback: async (req, _res, session) => {
      logger.info('OIDC callback completed');
      // Genuine interactive login — record it so Recent Logins tracks the
      // real last login for already-bound users. Fire-and-forget; never let
      // an audit write delay or fail the post-login redirect.
      notifyFreshLogin({ req, session });
      return session;
    },
  };

  // Log cookie security status
  if ((process.env.BASE_URL || '').startsWith('https://')) {
    logger.info('Session cookie: SameSite=None; Secure=true (HTTPS baseURL)');
  } else {
    logger.warn('Session cookie: SameSite=Lax (HTTP baseURL). Works for same-site localhost; cross-site Keycloak deployments still need HTTPS + SameSite=None.');
  }

  // CA cert trust for AIRGAP — configure via Node.js native env var
  // NODE_EXTRA_CA_CERTS is the supported way; httpOptions is not a valid
  // express-openid-connect config key. The CA cert path is still used
  // for display in the admin UI (KEYCLOAK_CA_CERT_PATH).
  if (process.env.KEYCLOAK_CA_CERT_PATH) {
    // NOTE: `caCertPath` binding keeps the operator-known env var visible for setup verification.
    logger.info({ caCertPath: process.env.KEYCLOAK_CA_CERT_PATH }, 'CA cert configured — ensure NODE_EXTRA_CA_CERTS is set to the same path');
  }

  // ── Startup health check — validate Keycloak reachability & CA cert ──────
  validateKeycloakOnInit(issuerBaseURL);

  try {
    const oidcMiddleware = auth(oidcConfig);
    // markOidcSecurityRoutes must run BEFORE oidcMiddleware so res.locals is
    // set no later than the request-log §5 finish handler reads it.
    return [markOidcSecurityRoutes, oidcMiddleware];
  } catch (err) {
    logger.error({ err }, 'Failed to initialise OIDC middleware');
    logger.error('Hint: Verify KEYCLOAK_ISSUER_BASE_URL, KEYCLOAK_CLIENT_ID, KEYCLOAK_CLIENT_SECRET, and KEYCLOAK_SECRET env vars are correct.');
    return [];
  }
}


/**
 * Conditional middleware — returns OIDC stack when auth_mode is 'keycloak',
 * otherwise returns an empty array (no-op).
 *
 * Called at startup time in index.js.
 *
 * @returns {import('express').RequestHandler[]}
 */
function getKeycloakMiddleware() {
  const mode = resolveAuthMode();
  if (mode !== 'keycloak') {
    logger.info({ mode }, 'OIDC middleware skipped');
    return [];
  }
  logger.info('auth_mode=keycloak — initialising OIDC middleware');
  return buildKeycloakMiddleware();
}

// _isSafeRedirectUrl and isSameOriginRelativePath are exported so
// limiters.js's rate-limited-navigation redirect reuses the SAME
// open-redirect guard and same-origin rule as the OIDC post-logout and
// returnTo redirects above, instead of a second/third copy that could drift.
module.exports = {
  getKeycloakMiddleware,
  buildKeycloakMiddleware,
  _isSafeRedirectUrl,
  _resolveSsoReturnTo,
  isSameOriginRelativePath,
  // Exported for direct unit testing of the security-marker middleware
  // without driving a full express-openid-connect stack.
  OIDC_ROUTE_PATHS,
  markOidcSecurityRoutes,
};
