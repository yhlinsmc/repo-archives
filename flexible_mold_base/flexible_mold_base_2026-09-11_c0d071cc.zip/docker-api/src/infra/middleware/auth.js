const { jwtVerify, errors: joseErrors } = require('jose');
const { JWT_SECRET } = require('../../shared/config');
const { mapTokenToUser } = require('../../lib/keycloak-token-mapper');
const { logger: rootLogger } = require('../../shared/lib/logger');
const { toActor } = require('../../shared/lib/actor');
const { logS2s, logSecurity } = require('../../shared/lib/log-streams');
const edgeClient = require('../lib/edge-state-client');
const {
  EdgeUnreachable,
  EdgeTimeout,
  EdgeAuthFailed,
} = require('../lib/edge-state-client');

const logger = rootLogger.child({ module: 'auth' });

// jose sign/verify take a Uint8Array key, not a string. Encode the HS256
// secret once at load (JWT_SECRET is a module constant). Null in keycloak-only
// mode where JWT_SECRET is unset — the bearer path is guarded by `&& JWT_SECRET`.
const _jwtKey = JWT_SECRET ? new TextEncoder().encode(JWT_SECRET) : null;

/**
 * Classify a jose jwtVerify rejection into the auth decision category.
 *
 * Every category other than 'unexpected' is an EXPECTED invalid-token outcome:
 * req.user stays null and downstream requireAuth returns 401. We keep the
 * categories distinct (never collapse expired / not-before / bad-signature into
 * one bucket) so the rejection reason stays observable and a source guard can
 * prove the discrimination survived the jsonwebtoken → jose migration.
 *
 * jose v6 error-class mapping (verified against the installed package):
 *   - expired token          → errors.JWTExpired (code ERR_JWT_EXPIRED)
 *   - not-yet-valid (nbf)     → errors.JWTClaimValidationFailed, claim === 'nbf'
 *   - bad signature           → errors.JWSSignatureVerificationFailed
 *   - malformed / structural  → errors.JWSInvalid | errors.JWTInvalid
 *   - disallowed alg (none/RS) → errors.JOSEAlgNotAllowed
 *   - other claim failures    → errors.JWTClaimValidationFailed (claim !== nbf)
 *
 * @param {unknown} err
 * @returns {'expired'|'not_before'|'invalid'|'unexpected'}
 */
function classifyJwtVerifyError(err) {
  if (err instanceof joseErrors.JWTExpired) return 'expired';
  if (err instanceof joseErrors.JWTClaimValidationFailed && err.claim === 'nbf') {
    return 'not_before';
  }
  if (
    err instanceof joseErrors.JWSSignatureVerificationFailed ||
    err instanceof joseErrors.JWSInvalid ||
    err instanceof joseErrors.JWTInvalid ||
    err instanceof joseErrors.JWTClaimValidationFailed ||
    err instanceof joseErrors.JOSEAlgNotAllowed
  ) {
    return 'invalid';
  }
  return 'unexpected';
}

// In-memory user cache — the single approved cache (CEO + Eng dual-voice).
// 30s per-`sub`. Caching across the S2S boundary avoids hammering edge for
// repeated requests without widening the freshly-banned-user revocation window.
const USER_CACHE_TTL_MS = 30_000;
const _userCache = new Map();
let _cacheHits = 0;
let _cacheMisses = 0;
let _cacheEvictions = 0;

// Returns the whole cache ENTRY ({ user, emailResyncSkippedFor, expiresAt }) so
// callers that need the transient drift marker can read it without it ever
// living on the `user` object. Increments hit/miss/eviction metrics exactly
// once per call — call this OR getCachedUser per request, not both.
function getCachedEntry(userId) {
  const entry = _userCache.get(userId);
  if (!entry) {
    _cacheMisses += 1;
    return null;
  }
  if (Date.now() > entry.expiresAt) {
    _userCache.delete(userId);
    _cacheEvictions += 1;
    _cacheMisses += 1;
    return null;
  }
  _cacheHits += 1;
  return entry;
}

function getCachedUser(userId) {
  const entry = getCachedEntry(userId);
  return entry ? entry.user : null;
}

// emailResyncSkippedFor: transient (never-DB) marker sibling from
// identity-resolve. Stored on the ENTRY, never merged into `user`, so it stays
// off req.user / the cached identity / API response bodies.
function setCachedUser(userId, user, emailResyncSkippedFor) {
  _userCache.set(userId, { user, emailResyncSkippedFor, expiresAt: Date.now() + USER_CACHE_TTL_MS });
}

function getCacheMetrics() {
  return {
    size: _userCache.size,
    hits: _cacheHits,
    misses: _cacheMisses,
    evictions: _cacheEvictions,
  };
}

/**
 * Decide whether a cached OIDC identity is stale relative to the CURRENT token's
 * claims for the authorization-relevant profile columns. When true the caller
 * bypasses the cache and falls through to identity-resolve, whose edge-side
 * jitProvision re-syncs the users row and returns the fresh values that then
 * re-populate this cache. This closes the window where a Keycloak attribute
 * change is masked for the full 30s TTL because the warm cache short-circuits
 * the edge round-trip (and thus the re-sync) on every hit.
 *
 * SECURITY: access-check authorises on `deptid` (and an enabled `access_rules`
 * row can match a verified `email`), so a deptid/email changed in Keycloak must
 * not keep being served from cache. Present-value only: an absent deptid claim
 * (null) or an unverified / mapper-placeholder (`${sub}@keycloak`) email is NOT
 * drift, so a token that merely omits a scope cannot force a per-request edge
 * round-trip (no cache stampede). Mirrors the email gate in jit-provisioner's
 * resyncBoundUserClaims (verified + non-placeholder). role/banned are not token
 * claims, so this never shortens their intentional 30s revocation window.
 *
 * emailResyncSkippedFor (transient cache-entry marker, never on the user object)
 * carries the still-colliding email whose edge-side re-sync was skipped because
 * the address is already bound to another account. When the live token's email
 * equals that exact value the email-drift signal is suppressed — otherwise the
 * stored (old) email would differ from the colliding token email on every
 * request, permanently bypassing the cache. Value-scoped: a change to any OTHER
 * address no longer matches the marker, so genuine drift still fires. Legacy
 * edge pods omit the sibling field → marker is undefined → a real string
 * mapped.email is never equal to undefined, so behaviour is exactly as before.
 *
 * @param {{deptid?: string|null, email?: string|null}} cached
 * @param {{deptid: string|null, email: string, email_verified: boolean, keycloak_sub: string}} mapped
 * @param {string} [emailResyncSkippedFor]
 * @returns {boolean}
 */
function identityClaimsDrift(cached, mapped, emailResyncSkippedFor) {
  if (mapped.deptid != null && mapped.deptid !== cached.deptid) return true;
  if (
    mapped.email_verified === true &&
    mapped.email !== `${mapped.keycloak_sub}@keycloak` &&
    mapped.email !== cached.email &&
    mapped.email !== emailResyncSkippedFor
  ) {
    return true;
  }
  return false;
}

function _resetCacheForTests() {
  _userCache.clear();
  _cacheHits = 0;
  _cacheMisses = 0;
  _cacheEvictions = 0;
}

function isEdgeUnreachable(err) {
  return err instanceof EdgeUnreachable || err instanceof EdgeTimeout || err instanceof EdgeAuthFailed;
}

// Bind the derived actor onto the per-request child logger once req.user (and
// any impersonation) has settled on this call path. Called at every exit
// point below — an early "return next()" and the two fall-throughs — so no
// path leaves the request line without its actor when one is available.
// Skipped (no setBindings call) when req.user never resolved: an
// unauthenticated request carries no actor binding, not an empty one.
function bindActor(req) {
  const actor = toActor(req.user, req.impersonator);
  if (actor !== undefined) req.log?.setBindings({ actor });
}

/**
 * If the real (already-resolved) user is an admin and the request carries
 * x-impersonate-user-id, resolve the target identity and return it tagged
 * impersonated. Returns null when impersonation does not apply or is refused.
 * Downgrade-only: target must exist, be non-banned, and NOT be admin.
 * Impersonated identities are never cached.
 */
async function resolveImpersonation(req, realUser) {
  const targetId = req.headers['x-impersonate-user-id'];
  if (!targetId || typeof targetId !== 'string') return null;
  if (!realUser || realUser.role !== 'admin') return null;
  if (targetId === realUser.id) return null;

  let result;
  try {
    result = await edgeClient.resolveIdentity({
      source: 'jwt-bearer',
      userId: targetId,
      auditInfo: { ip: req.ip, userAgent: req.headers['user-agent'] },
      reqId: req.id,
    });
  } catch (err) {
    logS2s(req, { target: 'edge:identity-resolve', err }, 'impersonation target resolve failed — ignoring header');
    return null;
  }
  if (!result || !result.pool_ready || result.banned || !result.user) return null;
  if (result.user.role === 'admin') {
    logSecurity(req, { event: 'impersonate_refused', level: 'warn', target_id: targetId, reason: 'target_is_admin' }, 'impersonation refused');
    return null;
  }
  // One choke point for every impersonation success (all 4 call sites below
  // route through here) — an impersonated GET finishes as access/debug,
  // invisible at production LOG_LEVEL=info, so this is the only signal an
  // impersonated request happened at all. Non-terminal: the request still
  // owes its own finish line (audit/access/debug per its own outcome), same
  // as impersonate_refused above. The header rides on EVERY impersonated
  // request (not once per session), so this is one info line per
  // impersonated request, not per impersonation session.
  logSecurity(req, { event: 'impersonate_start', level: 'info', target_id: result.user.id, impersonator_id: realUser.id }, 'impersonation start');
  return { ...result.user, impersonated: true };
}

/**
 * Auth middleware — supports (in priority order):
 *  1. OIDC session (Keycloak via express-openid-connect)
 *  2. JWT Bearer token (local bcrypt login)
 *
 * NOTE: DB ops are handled via edge S2S. When edge is unreachable, req.user
 * stays null on protected routes (downstream pool-gate / requireAuth returns
 * 503 with hint=edge_unreachable). Setup routes bypass auth entirely so the
 * wizard still works during cold boot.
 */
module.exports = async (req, _res, next) => {
  req.user = null;

  logger.debug({
    path: req.path,
    oidc: !!req.oidc?.isAuthenticated(),
    cookie: !!req.headers.cookie,
    jwt: !!req.headers.authorization,
  }, 'auth decision');

  // ── Priority 1: OIDC session (Keycloak) ──────────────────────────────
  if (req.oidc?.isAuthenticated()) {
    try {
      const claims = req.oidc.user;
      const mapped = mapTokenToUser(claims);
      const cacheKey = `kc:${mapped.keycloak_sub}`;
      const entry = getCachedEntry(cacheKey);
      // Serve from cache only when the current token's identity claims still
      // match — otherwise fall through to identity-resolve so edge re-syncs the
      // row and setCachedUser (below) overwrites this entry with fresh values.
      // The transient collision marker lives on the entry (not entry.user), so
      // req.user stays clean.
      if (entry && !identityClaimsDrift(entry.user, mapped, entry.emailResyncSkippedFor)) {
        req.user = entry.user;
        const imp = await resolveImpersonation(req, entry.user);
        if (imp) { req.impersonator = entry.user; req.user = imp; }
        bindActor(req);
        return next();
      }

      try {
        const result = await edgeClient.resolveIdentity({
          source: 'oidc',
          claims,
          auditInfo: { ip: req.ip, userAgent: req.headers['user-agent'] },
          reqId: req.id,
        });
        if (!result.pool_ready) {
          // Pool not configured yet (setup mode) — fall back to claim-only identity
          // so the wizard reaches /api/auth/me without DB.
          req.user = {
            id: mapped.keycloak_sub,
            email: mapped.email,
            role: 'user',
            deptid: mapped.deptid,
            kc_username: mapped.kc_username,
          };
          // No impersonation in setup mode: the hardcoded 'user' role would
          // trivially refuse it anyway, but skip the S2S round-trip explicitly.
        } else if (result.banned) {
          // Intentionally do not cache banned users — forces a DB re-check
          // on the next request so admin unban propagates on the next call.
          // Middleware, not a responder: on a protected route req.user stays
          // null and requireAuth 401s downstream, but on a public route (the
          // diagnostics tier) the request still ends 200 — this code cannot
          // tell which is coming, so it notes the fact (deferred) instead of
          // deciding terminality itself. The finish line folds the note in
          // once the real status is known.
          logSecurity(req, { event: 'login_blocked', level: 'warn', name: mapped.email, reason: 'account_banned', deferred: true }, 'banned user blocked');
        } else if (result.user) {
          req.user = result.user;
          setCachedUser(cacheKey, result.user, result.email_resync_skipped_for);
          // Impersonated identity must never be cached — only req.user is
          // updated here; setCachedUser above stored the real resolved user.
          const imp = await resolveImpersonation(req, result.user);
          if (imp) { req.impersonator = result.user; req.user = imp; }
        }
      } catch (err) {
        if (isEdgeUnreachable(err)) {
          // Fail-closed for protected routes. req.user stays null; downstream
          // pool-gate / requireAuth returns 503 with hint=edge_unreachable.
          // spec §6: an S2S failure is warn/kind:s2s, no stack — the request's
          // own 503 gets its app/error line separately (derivePolicy's finish
          // line already covers a >=500 as access/error).
          logS2s(req, { target: 'edge:identity-resolve', err, fields: { code: err.code } }, 'edge unreachable during OIDC identity-resolve');
        } else {
          // Not a known edge-unreachable shape (e.g. EdgeBadResponse, or a
          // genuine bug in result processing) — keep the full stack, this is
          // not the clean "s2s failure" case.
          logger.error({ err }, 'Failed to process OIDC session');
        }
      }
    } catch (err) {
      logger.error({ err }, 'Failed to process OIDC session');
    }
    bindActor(req);
    return next();
  }

  // ── Priority 2: JWT Bearer token ─────────────────────────────────────
  const authHeader = req.headers.authorization;
  if (authHeader?.startsWith('Bearer ') && JWT_SECRET) {
    try {
      const token = authHeader.slice(7);
      // SECURITY: pin algorithms to HS256 so an attacker-supplied `alg: none`
      // or an `alg: RS256` confusion token is rejected at verify time
      // (jose throws JOSEAlgNotAllowed → classified 'invalid' below).
      const { payload: decoded } = await jwtVerify(token, _jwtKey, { algorithms: ['HS256'] });
      const userId = decoded.sub || decoded.id;
      if (!userId) { bindActor(req); return next(); }

      const cached = getCachedUser(userId);
      if (cached) {
        req.user = cached;
        const imp = await resolveImpersonation(req, cached);
        if (imp) { req.impersonator = cached; req.user = imp; }
        bindActor(req);
        return next();
      }

      try {
        const result = await edgeClient.resolveIdentity({
          source: 'jwt-bearer',
          userId,
          auditInfo: { ip: req.ip, userAgent: req.headers['user-agent'] },
          reqId: req.id,
        });
        if (!result.pool_ready) {
          // SECURITY: in setup mode the DB is not available to validate role.
          // The OIDC fallback already hardcodes 'user'; the JWT-bearer fallback
          // must do the same or a forged/old admin-role JWT could read
          // /api/auth/diagnostics admin-tier output.
          req.user = {
            id: userId,
            email: decoded.email || 'unknown',
            role: 'user',
          };
        } else if (result.banned) {
          // Same reasoning as the OIDC banned-user site above: this
          // middleware cannot tell whether the route ahead is public or
          // protected, so it notes the fact (deferred) rather than deciding.
          logSecurity(req, { event: 'login_blocked', level: 'warn', target_id: userId, reason: 'account_banned', deferred: true }, 'banned user blocked');
        } else if (result.user) {
          req.user = result.user;
          setCachedUser(userId, result.user);
          const imp = await resolveImpersonation(req, result.user);
          if (imp) { req.impersonator = result.user; req.user = imp; }
        }
      } catch (err) {
        if (isEdgeUnreachable(err)) {
          // spec §6: an S2S failure is warn/kind:s2s, no stack.
          logS2s(req, { target: 'edge:identity-resolve', err, fields: { code: err.code } }, 'edge unreachable during JWT identity-resolve');
        } else {
          logger.warn({ err }, 'JWT identity-resolve failed - user stays null');
        }
      }
    } catch (err) {
      const kind = classifyJwtVerifyError(err);
      if (kind === 'unexpected') {
        logger.warn({ err }, 'JWT Bearer auth path threw non-jwt error - user stays null');
      } else {
        // Expected invalid-token outcome (expired / not_before / invalid
        // signature / malformed / disallowed alg) — req.user stays null and
        // downstream requireAuth returns 401. Distinct kinds preserved.
        logger.debug({ kind, code: err && err.code }, 'JWT Bearer token rejected');
      }
    }
  }

  bindActor(req);
  next();
};

module.exports.getCacheMetrics = getCacheMetrics;
module.exports._resetCacheForTests = _resetCacheForTests;
module.exports._classifyJwtVerifyError = classifyJwtVerifyError;
