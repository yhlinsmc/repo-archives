/**
 * public-gate.js — Public Integration API machine-tier gate (infra, namespace
 * /api/public/v1). Mounted OUTSIDE the human auth/RBAC gates: this tier is gated
 * solely by the customer's app-issued API key + scope, not by Keycloak/session
 * identity.
 *
 * Auth v2.1: no token exchange, no JWKS, no local signature check. Every path
 * under /api/public/v1 requires a static API key that edge resolves (via the
 * S2S seam) to { sub, scope }. The key arrives via one of two carriers:
 *   - `api_key` header — injected by the gateway per consumer (takes precedence);
 *   - `Authorization: Bearer <key>` — the direct path.
 * Fail closed: a missing/unresolvable key or an empty scope is 401 invalid_token.
 * On success sets req.machinePrincipal for the P2 read handlers.
 */
const express = require('express');
const { validateMachineToken } = require('../lib/machine-token-verify');
const { isNonEmptyScope } = require('../../shared/lib/machine-scope');

const router = express.Router();

// The whole namespace is key-gated — there is no public token/JWKS endpoint
// to exempt anymore. SECURITY: the outcome depends ONLY on the resolved API
// key; any gateway-injected consumer-identity header is ignored (the app trusts
// the key, not APISIX headers).
router.use(async (req, res, next) => {
  // Carrier precedence: `api_key` header wins. When it is present and non-empty
  // after trim, it is the ONLY carrier validated — there is NO fallback to
  // Authorization. SECURITY: on the gateway path Authorization carries the
  // caller's unverifiable APISIX OAuth2 token, so rescuing an invalid api_key
  // with it would defeat the gate. A blank api_key is not a carrier, so the
  // direct Bearer path still applies.
  const apiKeyHeader = req.headers['api_key'];
  const apiKey = typeof apiKeyHeader === 'string' ? apiKeyHeader.trim() : '';

  let key;
  if (apiKey) {
    key = apiKey;
  } else {
    const authHeader = req.headers['authorization'] || '';
    const match = /^Bearer\s+(.+)$/i.exec(authHeader);
    if (!match) return res.status(401).json({ error: 'invalid_token' });
    key = match[1].trim();
  }

  let principal;
  try {
    principal = await validateMachineToken(key, {
      reqPath: req.originalUrl || req.path,
      auditInfo: { ip: req.ip, userAgent: req.headers['user-agent'] },
      // Threads into forwardToEdge so this hop's own s2s warn (circuit-open/
      // timeout/pre-dispatch) carries req_id/actor instead of the unbound
      // root logger — this is the highest-traffic S2S call in the namespace.
      req,
    });
  } catch {
    // SECURITY: unknown/inactive token, edge-unreachable, or any resolve failure
    // collapses to one generic invalid_token — fail closed, no discriminating
    // detail, never the edge status/body.
    return res.status(401).json({ error: 'invalid_token' });
  }

  if (!principal || !isNonEmptyScope(principal.scope)) {
    return res.status(401).json({ error: 'invalid_token' });
  }

  req.machinePrincipal = { type: 'service_account', sub: principal.sub, scope: principal.scope };
  return next();
});

module.exports = router;
