/**
 * public-namespace.js — the /api/public/v1 middleware pipeline, in ONE place so
 * its load-bearing ordering is a single source of truth and directly testable.
 *
 * SECURITY [P2b]: the Bearer gate runs BEFORE body parsing and the content-type
 * check. The global express.json parser and the CSRF/content-type guard
 * (app-setup) intentionally SKIP this namespace, so a pre-auth body-parse error
 * or a non-JSON POST can never short-circuit ahead of the gate and hand an
 * UNAUTHENTICATED caller a distinguishing 400/415 (a state-enumeration signal).
 * The order is:
 *   1. public-gate       Bearer → S2S resolve → 401 invalid_token OR set principal
 *   2. shared limiter    per-account budget (reads + writes)
 *   3. content-type      post-gate (authenticated) JSON-only → public 415
 *   4. body parser       post-gate → a SyntaxError now means authenticated + malformed
 *   5. public-write      POST /templates (falls through otherwise)
 *   6. public-read       GET surface + terminal 404
 *   7. error boundary    map a post-gate parse/decode error to the public model
 *
 * Because parsing runs post-gate, an unauthenticated malformed/non-JSON request
 * is rejected by the gate (uniform 401) before any parse error can surface.
 */
const express = require('express');
const { createPublicApiLimiter } = require('../limiters');
const { sendAvailability } = require('../../shared/lib/send-error');
// Public bodies are tiny ({ path, name?, owner_username? }); a small cap bounds
// the parse cost (the 10mb global limit exists only for setup/seed).
const PUBLIC_JSON_LIMIT = '1mb';

/**
 * Post-gate content-type guard: the customer authenticated, so a non-JSON POST
 * gets a public-shaped 415 (never the internal { success:false, ... } envelope).
 * GET/HEAD/OPTIONS and an empty body carry no content-type and pass through.
 */
function publicContentTypeGuard(req, res, next) {
  if (req.method === 'GET' || req.method === 'HEAD' || req.method === 'OPTIONS') return next();
  const contentLength = parseInt(req.headers['content-length'] || '0', 10);
  if (contentLength === 0 && !req.headers['content-type']) return next();
  const ct = (req.headers['content-type'] || '').toLowerCase();
  if (ct.startsWith('application/json')) return next();
  return res.status(415).json({ error: 'validation_failed' });
}

/**
 * Public-tier error boundary. Runs only for POST-gate failures (the gate 401s
 * unauthenticated callers before parsing), so a body-parse SyntaxError / route
 * URIError is an authenticated malformed request → 400 validation_failed. Any
 * other error collapses to edge_unreachable. Never the internal apiError
 * envelope (meta.db_type/provider must not leak to a public caller).
 */
function publicErrorHandler(err, req, res, _next) {
  if (res.headersSent) return;
  const status = err && (err.status || err.statusCode);
  // A post-gate body-parse SyntaxError / route URIError / bounded 4xx (e.g. a 413
  // payload-too-large from the JSON parser) is an authenticated malformed request
  // → public 400. (Non-JSON 415 is emitted directly by publicContentTypeGuard.)
  if (err instanceof SyntaxError || err instanceof URIError
    || (typeof status === 'number' && status >= 400 && status < 500)) {
    return res.status(400).json({ error: 'validation_failed' });
  }
  return sendAvailability(req, res, {
    target: 'infra:public-namespace',
    body: { error: 'edge_unreachable' },
    err: err instanceof Error ? err : undefined,
  });
}

/**
 * Mount the full /api/public/v1 pipeline onto an app in the load-bearing order.
 * @param {import('express').Express} app
 */
function mountPublicNamespace(app) {
  app.use('/api/public/v1', require('./public-gate'));
  app.use('/api/public/v1', createPublicApiLimiter());
  app.use('/api/public/v1', publicContentTypeGuard);
  app.use('/api/public/v1', express.json({ limit: PUBLIC_JSON_LIMIT }));
  app.use('/api/public/v1', require('./public-write'));
  app.use('/api/public/v1', require('./public-read'));
  app.use('/api/public/v1', publicErrorHandler);
}

module.exports = { mountPublicNamespace, publicContentTypeGuard, publicErrorHandler, PUBLIC_JSON_LIMIT };
