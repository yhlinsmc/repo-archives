/**
 * flow-recipe-run.js — infra-side handler for POST /api/flow-recipes/:id/run.
 *
 * A plain user calls this endpoint with a rendered payload. The handler:
 *   1. Gates + creates a partial run row at edge (run-begin S2S).
 *   2. Loops the ordered step list, dispatching each via dispatchOneStep.
 *   3. Finalizes the run at edge (run-finalize S2S) with the outcome.
 *   4. Returns the finalized run summary to the caller.
 *
 * The caller never sees step config, connector secrets, or edge DB state.
 *
 * BOUNDARY (Ship Gate Step 15, infra-talks-to-edge-only):
 *   No DB import — all persistence goes through forwardToEdge S2S calls.
 */
const { forwardToEdge, passthroughResponse } = require('../lib/remote-client');
const { dispatchOneStep } = require('../lib/flow-dispatch-step');
const { apiOk, requireAuth } = require('../../shared/helpers');
const { logger: rootLogger } = require('../../shared/lib/logger');
// Pure module (no DB/pool/S2S) — safe for infra (infra-talks-to-edge-only).
const { sendError } = require('../../shared/lib/send-error');
// Pure function module (no DB) — safe for infra (infra-talks-to-edge-only).
// Each step now carries its own content_type/yaml_version/yaml_quoting
// (flow-yaml-dialect PR-Y2); this server-orchestrated (no-JS) loop never
// changes the underlying payload value between steps, but two steps can still
// declare DIFFERENT dialects, so the {{payload}} fill is re-serialized fresh
// per step rather than computed once at run-begin and reused verbatim.
const { serializeFlowPayload } = require('../../shared/lib/flow-payload-serialize');
// Pure module (no DB/pool/S2S) — safe for infra (infra-talks-to-edge-only).
const { markReadOnly } = require('../../shared/middleware/route-markers');

const logger = rootLogger.child({ module: 'infra-flow-recipe-run' });

// Chars. TRANSPORT cap only — bounds what this S2S call relays toward edge; it
// is NOT a storage cap (that one, STEP_ERROR_BODY_MAX = 8192, is edge-only —
// serializer.js — and is applied to MASKED text, never to this raw value).
//
// INVARIANT: the masker only ever sees INTACT structure; anything it cannot
// see intact is withheld entirely. A body over this cap is therefore never
// SLICED — slicing raw upstream bytes before they are masked can land
// mid-token, turn valid JSON/YAML into invalid text, and make the masker's
// own parser throw; the (still-raw, still-unmasked) text then has nothing to
// fall back to but itself. That defect was empirically reproduced (
// PR-2 review F1): a 10 KB body containing `access_token`, sliced to 8192
// chars, failed both parsers, and the token reached the durable, admin-
// searchable audit row verbatim. A body over this cap sets `error_body_omitted`
// (a char count) instead of `error_body` — see relayErrorBody below for why a
// synthetic placeholder STRING was tried and reverted (review round 2).
const STEP_ERROR_BODY_TRANSPORT_MAX = 32768;

// OVER CAP → `{ error_body_omitted: <chars> }`, NEVER `{ error_body: <text> }`.
// A first attempt sent a placeholder STRING as error_body instead — and
// reproduced its own bug: a placeholder starting with `[` parses as a YAML
// flow sequence, which the edge masker's structured-parse gate (F2) accepts
// as real structure and mis-stores. Putting the omission on a NUMBER field
// the masker never inspects removes that failure mode entirely rather than
// special-casing around it.
function relayErrorBody(v) {
  if (typeof v !== 'string' || v === '') return {};
  if (v.length <= STEP_ERROR_BODY_TRANSPORT_MAX) return { error_body: v };
  return { error_body_omitted: v.length };
}

// Threads the upstream Content-Type through onto a FAILED step entry, verbatim
// (no parsing/normalization — the FE decides what to do with it). Only ever
// present when the step round-tripped to a real HTTP response: the transport-
// failure path (dispatchOneStep ok:false — timeout/unreachable/blocked/malformed)
// never has an envelope to read a header off, so it stays correctly absent
// there rather than emitting a fabricated value.
function relayContentType(headers) {
  const ct = headers && headers['content-type'];
  return typeof ct === 'string' && ct !== '' ? { content_type: ct } : {};
}

function mountFlowRecipeRun(app) {
  app.post('/api/flow-recipes/:id/run', async (req, res) => {
    if (!requireAuth(req, res)) return;

    const recipeId = req.params.id;
    const { payload, output_snapshot, input_snapshot, template_id, blueprint_id, mode } = req.body || {};
    const extraHeaders = req.id ? { 'x-request-id': req.id } : {};

    try {
      // 1. Gate + create a partial run row at edge.
      const beginResult = await forwardToEdge({
        method: 'POST',
        path: '/edge/internal/flow-recipes/run-begin',
        pathPrefix: '/edge/internal/flow-recipes/run-begin',
        user: req.user,
        body: { recipe_id: recipeId, payload, output_snapshot, input_snapshot, template_id, blueprint_id, mode },
        headers: extraHeaders,
        req,
      });

      // Gate rejected (recipe not approved / inactive / unbound / not found) — pass through.
      if (beginResult.status !== 200) {
        return passthroughResponse(req, res, beginResult);
      }

      const { run_id, steps } = beginResult.data.data;
      // Non-null when edge created the run without its capture. Carried onto
      // whatever this endpoint answers with, so the operator is told once,
      // beside the run's own result — the browser-chain endpoint below relays
      // the whole begin payload and gets this for free.
      const snapshotNotice = beginResult.data.data.input_snapshot_notice ?? null;

      // 2. Dispatch each step in order. Stop on first failure.
      let okFlag = true;
      let errorSummary = null;
      let finalEnvelope = null;
      const stepResults = [];

      // Guard: a recipe with no steps performed zero dispatches, so it MUST NOT
      // report success. Without this, the for-loop below never runs and okFlag
      // stays true — a false success. Finalize the run as failed instead.
      if (!Array.isArray(steps) || steps.length === 0) {
        const finalizeResult = await forwardToEdge({
          method: 'POST',
          path: '/edge/internal/flow-recipes/run-finalize',
          pathPrefix: '/edge/internal/flow-recipes/run-finalize',
          user: req.user,
          body: {
            run_id,
            recipe_id: recipeId,
            ok: false,
            upstream_status: null,
            body: '',
            error_summary: 'Recipe has no steps to run',
            step_results: JSON.stringify([]),
          },
          headers: extraHeaders,
          req,
        });
        if (finalizeResult.status !== 200) {
          return passthroughResponse(req, res, finalizeResult);
        }
        return res.json(apiOk({ ...finalizeResult.data.data, input_snapshot_notice: snapshotNotice }));
      }

      for (const step of steps) {
        // Re-serialize with THIS step's own dialect — never the run-begin
        // audit default (`serialized_payload`, the first step's dialect) —
        // so a later step whose content_type/yaml_version/yaml_quoting
        // differs from an earlier one gets its own bytes, not a stale value
        // computed under a different step's config.
        //
        // WARNING: this is a bare sync call INSIDE a loop the rest of
        // which never throws (every other stop condition sets okFlag/
        // errorSummary/stepResults and `break`s, falling through to the
        // finalize call below). A throw here (e.g. a circular payload) would
        // instead propagate to the route's outermost try/catch, which 500s
        // the caller WITHOUT ever calling run-finalize — the run row a
        // prior step may already have begun stays open at edge forever.
        let stepSerializedPayload;
        try {
          stepSerializedPayload = serializeFlowPayload(payload, {
            content_type: step.content_type,
            yaml_version: step.yaml_version,
            yaml_quoting: step.yaml_quoting,
          });
        } catch (serializeErr) {
          req.log.error(
            { err: serializeErr, recipeId, stepId: step.id },
            'flow-recipe step payload serialization failed id=' + step.id,
          );
          okFlag = false;
          errorSummary = 'Step payload could not be serialized';
          stepResults.push({
            step_id: step.id, step_name: step.name ?? undefined, ok: false, upstream_status: null,
          });
          break;
        }
        const r = await dispatchOneStep({
          stepId: step.id,
          inputs: { payload: stepSerializedPayload },
          runId: run_id,
          test: false,
          user: req.user,
          reqId: req.id,
          req,
        });

        if (!r.ok) {
          // Transport failure — stop the loop immediately.
          okFlag = false;
          errorSummary = r.errorCode
            ? `${r.errorCode}: ${r.message || 'Step request failed'}`
            : (r.message || 'Step request failed');
          stepResults.push({
            step_id: step.id, step_name: step.name ?? undefined, ok: false,
            upstream_status: r.status, ...relayErrorBody(r.message),
          });
          break;
        }

        // Transport succeeded — check the upstream HTTP status before continuing.
        // A non-2xx upstream response is a step failure: record it and stop the loop
        // so subsequent steps are not dispatched (dishonest audit + side-effect risk).
        finalEnvelope = r.envelope;
        const us = finalEnvelope ? finalEnvelope.upstream_status : null;
        const stepIs2xx = typeof us === 'number' && us >= 200 && us < 300;

        if (!stepIs2xx) {
          okFlag = false;
          errorSummary = `Upstream returned ${us}`;
          stepResults.push({
            step_id: step.id, step_name: step.name ?? undefined, ok: false,
            upstream_status: us, ...relayErrorBody(finalEnvelope?.body),
            ...relayContentType(finalEnvelope?.headers),
          });
          break;
        }

        stepResults.push({ step_id: step.id, step_name: step.name ?? undefined, ok: true, upstream_status: us });
      }

      const finalUpstreamStatus = finalEnvelope ? (finalEnvelope.upstream_status || null) : null;
      const finalBody = finalEnvelope ? (finalEnvelope.body || '') : '';

      // 4. Finalize the run row at edge.
      const finalizeResult = await forwardToEdge({
        method: 'POST',
        path: '/edge/internal/flow-recipes/run-finalize',
        pathPrefix: '/edge/internal/flow-recipes/run-finalize',
        user: req.user,
        body: {
          run_id,
          recipe_id: recipeId,
          ok: okFlag,
          upstream_status: finalUpstreamStatus,
          body: finalBody,
          error_summary: errorSummary,
          step_results: JSON.stringify(stepResults),
        },
        headers: extraHeaders,
        req,
      });

      // If finalize itself failed, pass the error through unchanged.
      if (finalizeResult.status !== 200) {
        return passthroughResponse(req, res, finalizeResult);
      }

      // 5. Return the finalized run summary to the caller.
      return res.json(apiOk({ ...finalizeResult.data.data, input_snapshot_notice: snapshotNotice }));

    } catch (err) {
      // SECURITY: don't leak internal error detail to the caller — `reason`
      // is this fixed developer string, never err.message.
      return sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Run failed', entity_id: recipeId });
    }
  });

  // Browser-orchestrated chain: the client runs each step's before/after JS in its
  // sandbox and dispatches steps one at a time via /api/flow-recipe-steps/:id/dispatch.
  // These two endpoints bracket that loop — begin creates the partial run row and
  // returns the ordered steps (with non-secret JS) + the create/update guard verdict;
  // finalize records the outcome. The result link/external_id is extracted
  // server-side (edge) from the final response body via the recipe's stored specs;
  // the client only relays a step-emit signal that can override that extraction.
  app.post('/api/flow-recipes/:id/run-begin', async (req, res) => {
    if (!requireAuth(req, res)) return;
    const recipeId = req.params.id;
    const { payload, output_snapshot, input_snapshot, template_id, mode } = req.body || {};
    const extraHeaders = req.id ? { 'x-request-id': req.id } : {};
    try {
      const beginResult = await forwardToEdge({
        method: 'POST',
        path: '/edge/internal/flow-recipes/run-begin',
        pathPrefix: '/edge/internal/flow-recipes/run-begin',
        user: req.user,
        body: { recipe_id: recipeId, payload, output_snapshot, input_snapshot, template_id, mode, client_orchestration: true },
        headers: extraHeaders,
        req,
      });
      if (beginResult.status !== 200) return passthroughResponse(req, res, beginResult);
      return res.json(apiOk(beginResult.data.data));
    } catch (err) {
      return sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Run begin failed', entity_id: recipeId });
    }
  });

  // Read-only compare pass (spec Q19/Q20): returns the recipe's compare-only
  // steps for the browser to run through the same test-mode chain engine, no
  // run row and nothing persisted at edge either. Mirrors run-begin's shape;
  // see the edge route's own doc for why template_id is required here.
  app.post('/api/flow-recipes/:id/compare-begin', markReadOnly, async (req, res) => {
    if (!requireAuth(req, res)) return;
    const recipeId = req.params.id;
    const { payload, template_id } = req.body || {};
    const extraHeaders = req.id ? { 'x-request-id': req.id } : {};
    try {
      const beginResult = await forwardToEdge({
        method: 'POST',
        path: '/edge/internal/flow-recipes/compare-begin',
        pathPrefix: '/edge/internal/flow-recipes/compare-begin',
        user: req.user,
        body: { recipe_id: recipeId, payload, template_id },
        headers: extraHeaders,
        req,
      });
      if (beginResult.status !== 200) return passthroughResponse(req, res, beginResult);
      return res.json(apiOk(beginResult.data.data));
    } catch (err) {
      return sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Compare begin failed', entity_id: recipeId });
    }
  });

  app.post('/api/flow-recipes/:id/run-finalize', async (req, res) => {
    if (!requireAuth(req, res)) return;
    const recipeId = req.params.id;
    const {
      run_id, ok, upstream_status, body: upstreamBody, error_summary, step_results,
      link_emitted, link_emitted_value, external_id_emitted, external_id_emitted_value,
      // Reserved output key (spec Q14) — run-chain.ts sends the final chain
      // ctx's remote_refs so edge can write back its per-template cache; this
      // relay had dropped it, so a browser-orchestrated chain's remote_refs
      // never reached the write-back path.
      remote_refs,
    } = req.body || {};
    const extraHeaders = req.id ? { 'x-request-id': req.id } : {};
    try {
      const finalizeResult = await forwardToEdge({
        method: 'POST',
        path: '/edge/internal/flow-recipes/run-finalize',
        pathPrefix: '/edge/internal/flow-recipes/run-finalize',
        user: req.user,
        body: {
          run_id, recipe_id: recipeId, ok, upstream_status, body: upstreamBody,
          error_summary, step_results,
          link_emitted, link_emitted_value, external_id_emitted, external_id_emitted_value,
          remote_refs,
        },
        headers: extraHeaders,
        req,
      });
      if (finalizeResult.status !== 200) return passthroughResponse(req, res, finalizeResult);
      return res.json(apiOk(finalizeResult.data.data));
    } catch (err) {
      return sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Run finalize failed', entity_id: recipeId });
    }
  });

  // Reset a template's prior-push signal so a re-run can create a fresh external
  // record — the escape hatch for the runs_on create/update guard. Owner-scoped at
  // the edge.
  app.post('/api/flow-templates/:id/reset-flow-link', async (req, res) => {
    if (!requireAuth(req, res)) return;
    const templateId = req.params.id;
    const extraHeaders = req.id ? { 'x-request-id': req.id } : {};
    try {
      const result = await forwardToEdge({
        method: 'POST',
        path: '/edge/internal/flow-recipes/reset-flow-link',
        pathPrefix: '/edge/internal/flow-recipes/reset-flow-link',
        user: req.user,
        body: { template_id: templateId },
        headers: extraHeaders,
        req,
      });
      if (result.status !== 200) return passthroughResponse(req, res, result);
      return res.json(apiOk(result.data.data));
    } catch (err) {
      return sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Reset failed', entity_id: templateId });
    }
  });
}

module.exports = mountFlowRecipeRun;
