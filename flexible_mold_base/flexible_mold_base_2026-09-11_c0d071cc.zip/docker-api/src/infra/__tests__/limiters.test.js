/**
 * limiters.test.js — connectorLimiterKind routing decision.
 *
 * The /api/api-connectors limiter mount dispatches each request to the fetch
 * budget, the write budget, or no limiter, based on (method, mount-relative
 * path). That decision is the new logic introduced with connectorWriteLimiter;
 * it is a pure function so it is unit-tested here without standing up express +
 * the real rate-limit middleware.
 */
import { describe, it, expect } from 'vitest';

const { connectorLimiterKind, isClaimReleaseRequest, grantLimiterKind } = require('../limiters');

describe('connectorLimiterKind', () => {
  it('routes dispatch (POST .../fetch) to the fetch budget', () => {
    expect(connectorLimiterKind('POST', '/123e4567-e89b-12d3-a456-426614174000/fetch')).toBe('fetch');
  });

  it('routes a create (POST /) to the write budget', () => {
    expect(connectorLimiterKind('POST', '/')).toBe('write');
  });

  it('routes import (POST /import) to the write budget', () => {
    expect(connectorLimiterKind('POST', '/import')).toBe('write');
  });

  it('routes clone (POST /:id/clone) to the write budget', () => {
    expect(connectorLimiterKind('POST', '/abc/clone')).toBe('write');
  });

  it('routes an update (PUT /:id) to the write budget', () => {
    expect(connectorLimiterKind('PUT', '/abc')).toBe('write');
  });

  it('routes a delete (DELETE /:id) to the write budget', () => {
    expect(connectorLimiterKind('DELETE', '/abc')).toBe('write');
  });

  it('routes a reassign (PATCH /:id/owner) to the write budget', () => {
    expect(connectorLimiterKind('PATCH', '/abc/owner')).toBe('write');
  });

  it('does NOT limit reads (GET list)', () => {
    expect(connectorLimiterKind('GET', '/')).toBeNull();
  });

  it('does NOT limit the data-entry projection (GET /usable)', () => {
    expect(connectorLimiterKind('GET', '/usable')).toBeNull();
  });

  it('does NOT limit the allow-list read (GET /host-allowlist)', () => {
    expect(connectorLimiterKind('GET', '/host-allowlist')).toBeNull();
  });

  it('does NOT limit export (GET /:id/export)', () => {
    expect(connectorLimiterKind('GET', '/abc/export')).toBeNull();
  });

  it('classifies fetch ahead of write (POST .../fetch is fetch, not write)', () => {
    expect(connectorLimiterKind('POST', '/x/fetch')).toBe('fetch');
    expect(connectorLimiterKind('POST', '/x')).toBe('write');
  });

  it('counts a trailing-slash dispatch (POST .../fetch/) as fetch, not write', () => {
    expect(connectorLimiterKind('POST', '/x/fetch/')).toBe('fetch');
  });
});

describe('grantLimiterKind', () => {
  it('routes mutations (POST/PUT/PATCH/DELETE) to the write budget', () => {
    expect(grantLimiterKind('POST')).toBe('write');
    expect(grantLimiterKind('PUT')).toBe('write');
    expect(grantLimiterKind('PATCH')).toBe('write');
    expect(grantLimiterKind('DELETE')).toBe('write');
  });

  it('leaves reads unlimited (null)', () => {
    expect(grantLimiterKind('GET')).toBe(null);
    expect(grantLimiterKind('HEAD')).toBe(null);
    expect(grantLimiterKind('OPTIONS')).toBe(null);
  });
});

describe('isClaimReleaseRequest', () => {
  it('matches POST /:id/claim', () => {
    expect(isClaimReleaseRequest('POST', '/123e4567-e89b-12d3-a456-426614174000/claim')).toBe(true);
  });

  it('matches POST /:id/release', () => {
    expect(isClaimReleaseRequest('POST', '/abc/release')).toBe(true);
  });

  it('matches a trailing-slash claim/release', () => {
    expect(isClaimReleaseRequest('POST', '/abc/claim/')).toBe(true);
    expect(isClaimReleaseRequest('POST', '/abc/release/')).toBe(true);
  });

  it('does NOT match a non-POST method', () => {
    expect(isClaimReleaseRequest('GET', '/abc/claim')).toBe(false);
    expect(isClaimReleaseRequest('DELETE', '/abc/release')).toBe(false);
  });

  it('does NOT match other POSTs on the mount (create, update, reorder)', () => {
    expect(isClaimReleaseRequest('POST', '/')).toBe(false);
    expect(isClaimReleaseRequest('POST', '/abc')).toBe(false);
    expect(isClaimReleaseRequest('POST', '/abc/reorder')).toBe(false);
    expect(isClaimReleaseRequest('PUT', '/abc')).toBe(false);
  });

  it('does NOT match a path that merely contains the word elsewhere', () => {
    expect(isClaimReleaseRequest('POST', '/claim-something/x')).toBe(false);
  });
});
