/**
 * constants.js — Single source of truth for table base names.
 *
 * NOTE: using `t(TABLES.USERS)` instead of `t('users')` means a typo
 * (`TABLES.USRES`) becomes `t(undefined)` at module-load time, surfacing
 * as `PoolNotConfiguredError` at first use rather than producing a
 * wrong-table query against `${prefix}undefined`.
 *
 * The two arrays in `table-ddls.js` (`INFRA_TABLE_NAMES`,
 * `ENGINE_TABLE_NAMES`) drive DDL generation; the `TABLES` map below
 * is the symbolic equivalent for call sites. They MUST stay in lockstep
 * — `scripts/cicd/no-hardcoded-prefix.sh` (Ship Gate Step 8) plus
 * `infrastructure/docs/DUAL_SOURCE_REGISTRY.md` enforce that.
 *
 * RULE: identifier-via-tables — every `t(arg)` argument must be a
 * `TABLES.*` reference, not a string literal. See CLAUDE.md §3 Ship
 * Gate Step 8 for the lint enforcement.
 */

/**
 * @typedef {Object} TablesRegistry
 * Maps logical table identifier (UPPER_SNAKE_CASE) to the unprefixed
 * SQL table base name (lower_snake_case). The full physical name is
 * `${_tablePrefix}${TABLES.X}` (e.g., `example_app_` + `users` →
 * `example_app_users`).
 */

/**
 * @type {TablesRegistry}
 * Frozen so `TABLES.USERS = 'something'` throws in strict mode tests.
 */
const TABLES = Object.freeze({
  // Infra tables (mirror docker-api/src/table-ddls.js INFRA_TABLE_NAMES)
  USERS:           'users',
  LOGIN_AUDIT:     'login_audit',
  SYSTEM_SETTINGS: 'system_settings',
  DB_CONNECTIONS:  'db_connections',
  ACCESS_RULES:    'access_rules',
  FEATURE_AUDIT:   'feature_audit',
  SERVICE_ACCOUNTS:            'service_accounts',
  SERVICE_ACCOUNT_IDEMPOTENCY: 'service_account_idempotency',

  // Engine tables (mirror docker-api/src/table-ddls.js ENGINE_TABLE_NAMES)
  HIERARCHY_NODES:        'hierarchy_nodes',
  BLUEPRINT_FIELDS:       'blueprint_fields',
  FIELD_OPTIONS:          'field_options',
  BLUEPRINT_SECTIONS:     'blueprint_sections',
  BLUEPRINT_GROUPS:       'blueprint_groups',
  BLUEPRINT_OUTPUT_ORDER: 'blueprint_output_order',
  VARIANT_OVERRIDES:      'variant_overrides',
  USER_TEMPLATES:         'user_templates',
  TRANSFORMERS:           'transformers',
  TRANSFORMER_VERSIONS:   'transformer_versions',
  API_CONNECTORS:         'api_connectors',
  FLOW_RECIPES:           'flow_recipes',
  FLOW_RECIPE_STEPS:      'flow_recipe_steps',
  FLOW_RECIPE_RUNS:       'flow_recipe_runs',
  FLOW_RECIPE_CODE_VERSIONS: 'flow_recipe_code_versions',
  DECISION_TABLES:        'decision_tables',
  DELEGATED_GRANTS:       'delegated_grants',
  TEMPLATE_ACTIVITY:      'template_activity',
  TEMPLATE_SNAPSHOTS:     'template_snapshots',
  TEMPLATE_VERSIONS:      'template_versions',
  API_CONNECTOR_BLUEPRINTS: 'api_connector_blueprints',

  // Capacity Planner (App-tier; mirror docker-api/src/table-ddls.js CAP block)
  // Config-rewrite table set (spec §17.1): cap_sizing_tiers DROPPED; 7 new tables.
  CAP_SCENARIOS:            'cap_scenarios',
  CAP_SITES:                'cap_sites',
  CAP_HARDWARE_SPECS:       'cap_hardware_specs',
  CAP_DISK_COMBOS:          'cap_disk_combos',
  CAP_TEAMS:                'cap_teams',
  CAP_HYPERVISORS:          'cap_hypervisors',
  CAP_DATABASES:            'cap_databases',
  CAP_VMS:                  'cap_vms',
  CAP_DB_INSTANCES:         'cap_db_instances',
  CAP_CUSTOM_GROUPS:        'cap_custom_groups',
  CAP_CUSTOM_GROUP_MEMBERS: 'cap_custom_group_members',
  CAP_BUNDLES:              'cap_bundles',
  CAP_BUNDLE_ITEMS:         'cap_bundle_items',
  CAP_RULES:                'cap_rules',
  CAP_VM_PROFILES:          'cap_vm_profiles',
  CAP_FIELD_DEFS:           'cap_field_defs',
  CAP_SETTINGS:             'cap_settings',
  CAP_VERSIONS:             'cap_versions',
  CAP_WAIVERS:              'cap_waivers',
});

/**
 * VARIANT_OVERRIDE_ACTIONS — the canonical, exhaustive set of valid
 * `variant_overrides.action` enum values. Single source of truth shared by
 * every layer that must agree on what a valid action is:
 *   • the write-path validator (edge/routes/app/schema/routes-variant-overrides.js POST/PUT)
 *   • the boot-time cleanup that DELETEs rows whose action falls outside this
 *     set (edge/db.js runSchemaMigrations). The cleanup MUST derive its
 *     allowlist from here, never hard-code it — a newly added action that
 *     drifts out of a hard-coded allowlist gets its rows silently DELETEd on
 *     every boot.
 * Mirrors the frontend `OverrideAction` union in
 * src/fmb/lib/types/hierarchy.ts — keep in lockstep.
 */
const VARIANT_OVERRIDE_ACTIONS = Object.freeze(['lock', 'hide', 'autofill', 'compute']);

// RATE_LIMIT_SETTINGS — single source of the UI-adjustable rate limiters.
// Consumed by: edge /rate-limits read, settings-PUT validator, infra limiters
// fallback derivation, and (mirrored, not imported) the FE Rate Limits tab.
// `floor` for general is 100 because the settings-PUT that would fix a bad
// value itself passes through generalLimiter — a lower value risks self-brick.
const RATE_LIMIT_SETTINGS = Object.freeze([
  { snapshotKey: 'general',        settingKey: 'rate_limit_general_max',         floor: 100, envName: 'RATE_LIMIT_GENERAL_MAX',         default: 2000 },
  { snapshotKey: 'connectorFetch', settingKey: 'rate_limit_connector_fetch_max', floor: 1,   envName: 'RATE_LIMIT_CONNECTOR_FETCH_MAX', default: 60 },
  { snapshotKey: 'connectorWrite', settingKey: 'rate_limit_connector_write_max', floor: 1,   envName: 'RATE_LIMIT_CONNECTOR_WRITE_MAX', default: 60 },
  { snapshotKey: 'auditSearch',    settingKey: 'rate_limit_audit_search_max',    floor: 1,   envName: 'RATE_LIMIT_AUDIT_SEARCH_MAX',    default: 60 },
]);
const RATE_LIMIT_MAX_CEILING = 100000;

// The UNIQUE index behind "one field key per blueprint". Named here rather than
// in either of its readers because they cannot require each other: the migration
// step that CREATES it takes its table function as an argument precisely so it
// pulls in no db module, and the write path that reads a driver error to see
// WHICH index refused a row lives inside the schema routes. A literal in both
// places is one rename away from a duplicate-key error reported as a server
// fault again.
const FIELD_KEY_INDEX = 'uq_blueprint_field_key';

// The UNIQUE index behind "one section key per blueprint" — same reasoning as
// FIELD_KEY_INDEX above (migration step and driver-error reader cannot require
// each other), named here so a rename of the index is one edit, not two.
const SECTION_KEY_INDEX = 'uq_blueprint_section_key';

module.exports = {
  TABLES,
  VARIANT_OVERRIDE_ACTIONS,
  RATE_LIMIT_SETTINGS,
  RATE_LIMIT_MAX_CEILING,
  FIELD_KEY_INDEX,
  SECTION_KEY_INDEX,
};
