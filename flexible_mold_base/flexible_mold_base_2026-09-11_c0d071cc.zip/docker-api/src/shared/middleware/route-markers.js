/**
 * route-markers.js — tiny middlewares that override the request-log §5
 * default derivation for two route classes: a read-as-POST endpoint that
 * would otherwise count as a write (`markReadOnly`), and a route that issues
 * or mutates a security-sensitive credential (`markSecurity`), which needs
 * its own kind/level regardless of HTTP method or status. This is the ONLY
 * per-route list in the design (spec §5) — every other request line derives
 * its kind/level from method + status alone.
 */

function markReadOnly(req, res, next) {
  // Defensive: res.locals always exists on a real Express response, but a
  // bare test double might omit it.
  res.locals = res.locals || {};
  res.locals.logPolicy = 'read';
  next();
}

function markSecurity(req, res, next) {
  res.locals = res.locals || {};
  res.locals.logPolicy = 'security';
  next();
}

module.exports = { markReadOnly, markSecurity };
