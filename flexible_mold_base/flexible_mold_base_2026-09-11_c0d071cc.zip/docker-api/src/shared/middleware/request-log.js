/**
 * request-log.js — one structured line per HTTP request, emitted at finish
 * through the per-request child logger (`req.log`, request-id.js), so the
 * line carries the `req_id` + `actor` bindings set upstream by the identity
 * middlewares. Falls back to the injected/base logger only when no child
 * exists (a bare req built by an older test harness).
 *
 * `kind`/`level` derive from the outcome per the spec §5 table (see
 * `derivePolicy`), first-match-wins: a route marked `security` (login/
 * logout/token-issue), then 401/403/429, then >=500, then other 4xx, then a
 * chatty S2S route downgraded via the `debug` predicate, then a mutating
 * method (`audit`) unless marked read-only, then OPTIONS (never logged),
 * then everything else at `debug`. A slow success (`ms > SLOW_MS`) is bumped
 * to `warn` with `slow:true` regardless of which row produced it, so a slow
 * read is never silently invisible at debug/info level.
 *
 * Logs the pathname ONLY — never the query string (it can hold tokens /
 * ids) and never the body or headers. "What changed" stays in the DB
 * feature_audit table (spec §5).
 */
const { logger: rootLogger } = require('../lib/logger');

// Case-insensitive, mirrors logger.js's isProduction check — gates the
// _internals test-only export below the same way.
const isProduction = String(process.env.NODE_ENV || '').toLowerCase() === 'production';

const MUTATING_METHODS = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);

// SLOW_MS: env override, fail-open to the default on anything that is not a
// finite positive number so a bad ConfigMap value can never silently disable
// (or invert) the slow-request warning. Parsed once at module load, mirrors
// the parseCaptureBudget/parseLogLevel pattern in shared/lib/logger.js.
const DEFAULT_SLOW_MS = 1000;
function parseSlowMs(raw) {
  if (raw === undefined || raw === null || raw === '') return DEFAULT_SLOW_MS;
  const n = Number(raw);
  if (!Number.isFinite(n) || n <= 0) return DEFAULT_SLOW_MS;
  return n;
}
const SLOW_MS = parseSlowMs(process.env.SLOW_MS);

/**
 * Pure §5 derivation — kept separate from the middleware so the table can be
 * asserted row-by-row (request-log-policy.test.js) without driving a full
 * request/response cycle.
 *
 * @param {object} ctx
 * @param {string} ctx.method
 * @param {number} ctx.status
 * @param {*} [ctx.logPolicy] - res.locals.logPolicy; only 'security'/'read'
 *   are meaningful. Any other value (including undefined, or a typo) is the
 *   default derivation — a strict-equality check can never crash or throw
 *   for an unrecognised value, and never silently mutes a route.
 * @param {number} [ctx.ms]
 * @param {object} [ctx.securityEvent] - res.locals.securityEvent, a note left
 *   by a deferred logSecurity call (raised from middleware that could not yet
 *   know the request's real outcome). Folded in by `mergeSecurityEventFields`
 *   once `kind` below is derived from the REAL status: a security-kind finish
 *   carries the note's fields in full (it IS this request's security line
 *   now); any other kind carries only `event`, so e.g. a banned user's
 *   successful call to a public route still greps for the block.
 * @returns {{ logged: boolean, kind?: string, level?: string, slow?: boolean, fields?: object }}
 */
function derivePolicy({ method, status, logPolicy, ms, securityEvent }) {
  let kind;
  let level;

  // A stream helper (logRateLimited / a terminal logSecurity) already emitted
  // the one security line this request warrants, and marked the request as its
  // last step. Emit nothing more — this is the single suppression point that
  // keeps a 429 / failed login to one line. Only a <500 is suppressed: a >=500
  // still logs its own access/error line (paired with the separate app-error
  // stack line), which a security-event mark must never silence. The `&&
  // status < 500` lives IN the condition (not a nested if with no else) so a
  // marked request that finishes >=500 falls through to the ordinary elseif
  // chain below and gets a real kind/level from the `status >= 500` row,
  // instead of leaving kind/level undefined and throwing on `log[undefined]`.
  if (logPolicy && typeof logPolicy === 'object' && logPolicy.logged === true && status < 500) {
    return { logged: false };
  } else if (logPolicy === 'security') {
    kind = 'security';
    // A security route's own 5xx (e.g. Keycloak unreachable during login)
    // must still land at `error` like every other 5xx — the `security`
    // marker changes `kind`, never the severity a failure is logged at.
    level = status >= 500 ? 'error' : status >= 400 ? 'warn' : 'info';
  } else if (status === 401 || status === 403 || status === 429) {
    kind = 'security';
    level = 'warn';
  } else if (status >= 500) {
    // The request line itself stays `access` — the app-error line with the
    // stack is emitted by a separate response helper, not here.
    kind = 'access';
    level = 'error';
  } else if (status >= 400) {
    kind = 'access';
    level = 'warn';
  } else if (MUTATING_METHODS.has(method) && logPolicy !== 'read') {
    kind = 'audit';
    level = 'info';
  } else if (method === 'OPTIONS') {
    return { logged: false };
  } else {
    kind = 'access';
    level = 'debug';
  }

  // Row 8: any logged success (info/debug — a failure already sits at
  // warn/error above and is not re-processed) slower than SLOW_MS keeps its
  // kind but is bumped to warn so it is never invisible at the default level.
  let slow;
  if (typeof ms === 'number' && ms > SLOW_MS && (level === 'info' || level === 'debug')) {
    level = 'warn';
    slow = true;
  }

  const decision = { logged: true, kind, level };
  if (slow) decision.slow = true;
  const fields = mergeSecurityEventFields(kind, securityEvent);
  if (fields) decision.fields = fields;
  return decision;
}

// A deferred note only ever names a fact ("this middleware saw a banned
// user"), never the outcome — the outcome is `kind`, already derived above
// from the REAL status. When the finish line ended up `security` anyway (the
// banned user hit a protected route and 401'd), the note IS that line's
// content, so it rides in full (minus `ip`, already carried at the top level
// by `deriveIp`). Any other kind (the banned user's call to a public route
// still returned 200) only carries `event` — enough to grep the block
// without recasting an ordinary access line as a security one.
function mergeSecurityEventFields(kind, securityEvent) {
  if (!securityEvent || typeof securityEvent !== 'object' || securityEvent.event == null) return undefined;
  if (kind !== 'security') return { event: securityEvent.event };
  const fields = {};
  for (const k of Object.keys(securityEvent)) {
    if (k === 'ip') continue;
    fields[k] = securityEvent[k];
  }
  return fields;
}

/**
 * route = req.route?.path joined to the router mount (req.baseUrl). When
 * req.route is missing (e.g. a 404 with no matched route, or a raw
 * middleware-only response) route falls back to the baseUrl alone; when
 * baseUrl is also empty the field is omitted rather than emitting an empty
 * string a consumer would have to special-case. `req.route.path` can also be
 * a RegExp (a route registered with a pattern, e.g. public-read.js's
 * `/^\/blueprints\/(.+)$/`) — string-concatenating a RegExp coerces it to its
 * `/pattern/flags` source text, which is not a usable route label, so that
 * case falls back to baseUrl alone exactly like the missing-route case.
 * @param {import('express').Request} req
 * @returns {string | undefined}
 */
function deriveRoute(req) {
  if (typeof req.route?.path === 'string') return `${req.baseUrl || ''}${req.route.path}`;
  return req.baseUrl || undefined;
}

/**
 * The finish line's `ip` field, factored out to a single definition so a
 * stream helper that emits a request's TERMINAL line (logSecurity marking a
 * 401/403 login/S2S-key failure) binds the exact same value the finish line
 * would otherwise have carried — a terminal security line must never be
 * poorer than the access line it replaces. Same cross-import pattern as
 * `deriveRoute` (send-error.js already imports that one from here).
 * @param {import('express').Request | null | undefined} req
 * @returns {string | undefined}
 */
function deriveIp(req) {
  return req ? req.ip : undefined;
}

/**
 * @param {object} [opts]
 * @param {(path: string) => boolean} [opts.skip] - return true to log nothing
 * @param {(path: string) => boolean} [opts.debug] - return true to downgrade a
 *   successful (2xx/3xx) request to debug level regardless of method — the
 *   S2S auth-probe chatter downgrade. A route already marked `security` is
 *   never downgraded by this predicate (the two are not meant to overlap,
 *   but security must win if they ever do).
 * @param {import('pino').Logger} [opts.logger] - injectable for tests; falls
 *   back to req.log when present, else this, else the root logger.
 */
function createRequestLog({ skip, debug, logger = rootLogger } = {}) {
  return function requestLog(req, res, next) {
    // pathname only — strip any query string defensively even though req.path
    // already excludes it.
    const path = (req.path || req.url || '').split('?')[0];

    if (typeof skip === 'function' && skip(path)) return next();

    const startNs = process.hrtime.bigint();
    res.on('finish', () => {
      const ms = Math.round(Number(process.hrtime.bigint() - startNs) / 1e6);
      const status = res.statusCode;
      const method = req.method;

      const rawPolicy = res.locals?.logPolicy;
      const alreadyLogged = rawPolicy && typeof rawPolicy === 'object' && rawPolicy.logged === true;
      const isDebugChatter = typeof debug === 'function' && status < 400 && debug(path);
      // The already-logged mark must survive the chatter downgrade — a helper
      // that already emitted this request's line wins over the read downgrade.
      const logPolicy = alreadyLogged
        ? rawPolicy
        : ((isDebugChatter && rawPolicy !== 'security') ? 'read' : rawPolicy);

      const decision = derivePolicy({ method, status, logPolicy, ms, securityEvent: res.locals?.securityEvent });
      if (!decision.logged) return;

      const fields = {
        module: 'http',
        kind: decision.kind,
        method,
        route: deriveRoute(req),
        path,
        status,
        ms,
        ip: deriveIp(req),
      };
      if (decision.slow) fields.slow = true;
      if (decision.fields) Object.assign(fields, decision.fields);
      if (decision.kind === 'audit' && req.params?.id !== undefined) {
        fields.entity_id = req.params.id;
      }

      const log = req.log || logger;
      log[decision.level](fields, `${method} ${path} ${status} ${ms}ms`);
    });

    next();
  };
}

module.exports = {
  createRequestLog,
  derivePolicy,
  // Exported so send-error.js derives the `route` log field with the exact
  // same logic as the finish-time access line — one definition, never a
  // drifting copy, so the app-error line and the access line label a request
  // identically.
  deriveRoute,
  // Exported so log-streams.js's logSecurity binds the exact same `ip` value
  // a terminal request's finish line would otherwise have carried.
  deriveIp,
  // Exposed for direct unit testing of parseSlowMs's fail-open parsing only
  // (same _internals-style test-only escape hatch as shared/lib/logger.js);
  // absent from module.exports in production so accidental application use
  // throws immediately instead of silently relying on a private helper.
  ...(isProduction ? {} : { _internals: { parseSlowMs } }),
};
