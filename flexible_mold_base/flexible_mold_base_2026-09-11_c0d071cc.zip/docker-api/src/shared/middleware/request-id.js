/**
 * request-id.js — per-request correlation id + child logger.
 *
 * Infra mints a short id at the very front of the chain and echoes it on the
 * response as `X-Request-Id`. Edge adopts a well-formed inbound id (so an
 * infra→edge forward shares one id across both pods' logs) and otherwise mints
 * its own. The inbound value is format-guarded before adoption so a hostile
 * caller cannot inject newlines / control chars into the log stream.
 *
 * `req.log` is a pino child bound to this id, created here (mounted before
 * any router on both request-serving pods) so every downstream call and
 * middleware — including request-log.js at finish time — joins to the same
 * request without re-passing the id explicitly.
 */
const crypto = require('crypto');
const { logger } = require('../lib/logger');

// 4–64 chars of url-safe id alphabet. Wide enough for our 8-char ids and a
// full UUID, tight enough to reject log-injection payloads.
const REQ_ID_RE = /^[a-zA-Z0-9-]{4,64}$/;

function genId() {
  return crypto.randomUUID().split('-')[0]; // 8 hex chars — enough to correlate
}

/**
 * @param {object} [opts]
 * @param {boolean} [opts.trustInbound] - When true, adopt a well-formed
 *   `x-request-id` request header instead of always minting. Edge sets this;
 *   infra (the chain's front door) does not.
 */
function createRequestId({ trustInbound = false } = {}) {
  return function requestId(req, res, next) {
    let id;
    if (trustInbound) {
      const inbound = req.headers['x-request-id'];
      if (typeof inbound === 'string' && REQ_ID_RE.test(inbound)) {
        id = inbound;
      }
    }
    if (!id) id = genId();
    req.id = id;
    res.setHeader('X-Request-Id', id);
    req.log = logger.child({ req_id: id });
    next();
  };
}

module.exports = { createRequestId, _genId: genId, _REQ_ID_RE: REQ_ID_RE };
