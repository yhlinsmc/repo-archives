const { v4: uuidv4 } = require('uuid');
const { getHint } = require('./lib/error-hints');

// Canonical UUID shape for validating path/body identifiers before a query.
// Parameterized queries already block injection; this rejects a malformed id
// early with a 400 instead of leaking a 404 existence signal.
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Standard API response wrapper.
 *
 * Produces the canonical success envelope shape consumed by the front-end
 * http-client platformFetch: `{ data, error: null, meta: { ... } }`.
 *
 * @param {*} data - Payload for the response.
 * @param {object} [extraMeta] - Optional extra meta fields merged over the defaults.
 */
function apiOk(data, extraMeta) {
  return {
    data,
    error: null,
    meta: {
      timestamp: new Date().toISOString(),
      db_type: 'MARIADB',
      provider: 'CUSTOM_API',
      ...extraMeta,
    },
  };
}

/**
 * Map raw MariaDB/mysql2 SQL driver error codes to stable, semantic codes
 * exposed in API responses. The raw driver codes leak schema details
 * (column names, constraint names) and also change between driver
 * versions, so we translate them to a whitelist that clients can depend on.
 *
 * Anything not in the whitelist falls through to `SQL_ERROR`, which still
 * carries a human-readable `message` but hides the driver code.
 *
 * @param {string|undefined} rawCode - The `err.code` field from the driver.
 * @returns {string|null} A stable semantic code, or null if the raw code
 *   is not SQL-related (caller should use its own code instead).
 */
function mapSqlErrorCode(rawCode) {
  if (!rawCode || typeof rawCode !== 'string') return null;
  switch (rawCode) {
    case 'ER_DUP_ENTRY':               return 'DUPLICATE_KEY';
    case 'ER_NO_REFERENCED_ROW':
    case 'ER_NO_REFERENCED_ROW_2':     return 'FOREIGN_KEY_MISSING';
    case 'ER_ROW_IS_REFERENCED':
    case 'ER_ROW_IS_REFERENCED_2':     return 'FOREIGN_KEY_IN_USE';
    case 'ER_BAD_FIELD_ERROR':         return 'UNKNOWN_COLUMN';
    case 'ER_NO_SUCH_TABLE':           return 'UNKNOWN_TABLE';
    case 'ER_BAD_DB_ERROR':            return 'UNKNOWN_DATABASE';
    case 'ER_ACCESS_DENIED_ERROR':     return 'DB_ACCESS_DENIED';
    case 'ER_DATA_TOO_LONG':           return 'VALUE_TOO_LONG';
    case 'ER_TRUNCATED_WRONG_VALUE':
    case 'ER_TRUNCATED_WRONG_VALUE_FOR_FIELD': return 'VALUE_TRUNCATED';
    case 'ER_LOCK_WAIT_TIMEOUT':       return 'DB_LOCK_TIMEOUT';
    case 'ER_LOCK_DEADLOCK':           return 'DB_DEADLOCK';
    case 'ECONNREFUSED':
    case 'ER_CON_COUNT_ERROR':         return 'DB_UNAVAILABLE';
    default:
      if (rawCode.startsWith('ER_')) return 'SQL_ERROR';
      return null;
  }
}

/**
 * Structured error response with optional source and hint.
 *
 * NOTE: the response body NEVER carries a stack trace or raw SQL driver
 *   fields — those live only on the >=500 app-error log line (send-error.js),
 *   correlated to the response by req_id. Raw SQL driver codes are translated
 *   to a stable semantic whitelist via mapSqlErrorCode() — callers passing
 *   `cause: err` on a SQL failure automatically get the mapped code unless
 *   they override it.
 *
 * @param {string} message - Human-readable error message
 * @param {string} [code='ERROR'] - Machine-readable error code
 * @param {number} [status=500] - HTTP status code
 * @param {object} [options] - Additional options
 * @param {string} [options.source] - API route/path that produced the error
 * @param {string} [options.hint] - Override auto-resolved hint
 * @param {Error}  [options.cause] - Original error for debug mode
 * @param {Object} [options.details] - Structured payload merged into the
 *   `error.details` response field for MISSING_PRIVILEGES + similar
 *   contracts that need `missing[] / grant_sql / docs_url / run_as`
 *   delivered to clients. Keep inner keys primitive / plain-object; avoid
 *   circular refs (no Error instances).
 * @returns {{ status: number, body: object }}
 *
 * NOTE: earlier callers assumed extra keys on the fourth argument (e.g.
 * `{ missing, grant_sql, docs_url }`) would be merged into the response.
 * They were silently dropped. Use `options.details` going forward —
 * existing callers (hint / source / cause) remain untouched.
 */
function apiError(message, code = 'ERROR', status = 500, options = {}) {
  // If the caller did not pass an explicit code and we have a cause with
  // a SQL driver code, promote the mapped semantic code. This ensures a
  // default `apiError(err.message, 'ERROR', 500, { cause: err })` call
  // does not leak the raw driver code through the default path.
  let effectiveCode = code;
  if ((code === 'ERROR' || code === 'DB_ERROR') && options.cause && options.cause.code) {
    const mapped = mapSqlErrorCode(options.cause.code);
    if (mapped) effectiveCode = mapped;
  }

  const hint = options.hint || getHint(effectiveCode);
  const errorObj = { message, code: effectiveCode };

  if (options.source) {
    errorObj.source = options.source;
  }
  if (hint) {
    errorObj.hint = hint;
  }
  if (options.details && typeof options.details === 'object') {
    errorObj.details = options.details;
  }

  // SECURITY: the error cause's stack and raw SQL driver fields are NEVER
  // echoed into the response body. Every >=500 response already logs the real
  // stack + src under the request's req_id (send-error.js), and the response
  // carries that same req_id in X-Request-Id, so an operator correlates a
  // failure to its stack from the logs — a body copy is a pure extra leak
  // surface (it reaches any client, including an unauthenticated one).

  return {
    status,
    body: {
      data: null,
      error: errorObj,
      meta: {
        timestamp: new Date().toISOString(),
        db_type: 'MARIADB',
        provider: 'CUSTOM_API',
      },
    },
  };
}

function requireAuth(req, res) {
  if (!req.user) {
    const err = apiError('Unauthorized', 'UNAUTHORIZED', 401);
    // lint-allow: logger-discipline apiError is defined here and imported by send-error; importing it back would be a circular dependency
    res.status(err.status).json(err.body);
    return false;
  }
  return true;
}

function requireAdmin(req, res) {
  if (!requireAuth(req, res)) return false;
  if (req.user.role !== 'admin') {
    const err = apiError('Forbidden', 'FORBIDDEN', 403);
    // lint-allow: logger-discipline apiError is defined here and imported by send-error; importing it back would be a circular dependency
    res.status(err.status).json(err.body);
    return false;
  }
  return true;
}

/**
 * Admin-or-editor gate for the schema authoring surface. `editor` is a
 * role tier added between `admin` and `user`:
 *
 *   admin  > editor > user
 *
 * Editors can mutate Blueprint-level schema (fields / sections / output
 * order / transformer code) but NOT platform-admin surfaces (users,
 * connections, settings, access rules, destructive ops, sync-schema
 * truncate, Generation/Release node creation).
 */
function requireAdminOrEditor(req, res) {
  if (!requireAuth(req, res)) return false;
  if (req.user.role !== 'admin' && req.user.role !== 'editor') {
    const err = apiError('Forbidden', 'FORBIDDEN', 403);
    // lint-allow: logger-discipline apiError is defined here and imported by send-error; importing it back would be a circular dependency
    res.status(err.status).json(err.body);
    return false;
  }
  return true;
}

// `isOwnerOrAdmin` used to live here. It decides "is this row the caller's",
// which is a question about an `owner_id` COLUMN and therefore has to be asked
// of the engine — so it now needs an open connection and lives beside the
// comparison it uses, in edge/routes/app/schema/helpers.js. It is not
// re-exported from here on purpose: a synchronous owner check reachable from
// this module is the shape that produced the defect, and a caller reaching for
// the old name should fail to find it rather than find a byte comparison.

module.exports = { apiOk, apiError, requireAuth, requireAdmin, requireAdminOrEditor, mapSqlErrorCode, uuidv4, UUID_RE };
