'use strict';
const TABLE_FIELD_MAX_ROWS = 500;
module.exports = { TABLE_FIELD_MAX_ROWS };
