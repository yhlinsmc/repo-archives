'use strict';

// Tolerant parse for a JSON-typed column: the value may already have been
// driver-auto-parsed to an object, may be the raw JSON string MariaDB
// returns for some connection/column configurations, or may be NULL/absent
// (a no-DDL fallback SELECT never carries the key at all). Never throws —
// a malformed stored value degrades to null rather than 500ing the request
// that happens to read it.
function parseJsonColumn(value) {
  if (value == null) return null;
  if (typeof value === 'object') return value;
  if (typeof value === 'string') {
    try { return JSON.parse(value); } catch { return null; }
  }
  return null;
}

module.exports = { parseJsonColumn };
