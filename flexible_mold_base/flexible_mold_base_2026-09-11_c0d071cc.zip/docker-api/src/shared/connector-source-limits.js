'use strict';

// Named per CLAUDE.md §9's cross-cutting rule (spec §6/§9): every new limit
// is a constant a test reads, never a literal repeated at each call site.
// STATIC_BODY_MAX_BYTES bounds api_connectors.source_config.body for
// source_kind='static' — 64 KB keeps a pathological payload out of the JSON
// column and out of the /prepare response envelope's byte budget.
const STATIC_BODY_MAX_BYTES = 64 * 1024;

// SOURCE_LIST_MAX_ITEMS caps a template source's mode:'list' envelope and the
// GET .../source-candidates search — both list rows of user_templates, and an
// unbounded list would blow the envelope's byte budget before the byte cut
// even runs.
const SOURCE_LIST_MAX_ITEMS = 500;

// SOURCE_CANDIDATES_MAX caps the 300 "ambiguous match" envelope's candidate
// array — a match that hits every row of a blueprint must not turn into a
// multi-megabyte disambiguation prompt.
const SOURCE_CANDIDATES_MAX = 50;

// SOURCE_CANDIDATES_QUERY_MAX_LEN bounds the ESCAPED LIKE pattern the
// source-candidates endpoint matches on (route truncates AFTER escapeLike,
// not the raw ?q=) — escaping can double a run of %, _ or \, so bounding the
// raw string first would still let the pattern that actually reaches the DB
// (and the query log line) grow past this length.
const SOURCE_CANDIDATES_QUERY_MAX_LEN = 200;

module.exports = { STATIC_BODY_MAX_BYTES, SOURCE_LIST_MAX_ITEMS, SOURCE_CANDIDATES_MAX, SOURCE_CANDIDATES_QUERY_MAX_LEN };
