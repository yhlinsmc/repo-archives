'use strict';

// Cross-level conflict messages, warn-but-allow. Byte-identical to the FE
// mirror src/fmb/lib/policy/override-conflicts.ts (a parity test pins them).
// The server returns the applicable ones in a `warnings` array on a 200 — they
// are advisories about a legal write, never a 4xx.
const OVERRIDE_CONFLICT_MESSAGES = {
  autofill_over_calculated:
    'This field is calculated at blueprint level; the auto-fill value is ignored while the rule is non-overridable.',
  hide_over_required:
    'This field is required; hiding it leaves the requirement unmet unless retain-when-hidden is on.',
};

// input: { action, blueprintValueSource, isRequired, retainWhenHidden } →
// string[] of the messages that apply.
function overrideConflictWarnings(input) {
  const out = [];
  if (input.action === 'autofill'
    && (input.blueprintValueSource === 'calculated' || input.blueprintValueSource === 'copied')) {
    out.push(OVERRIDE_CONFLICT_MESSAGES.autofill_over_calculated);
  }
  if (input.action === 'hide' && input.isRequired && !input.retainWhenHidden) {
    out.push(OVERRIDE_CONFLICT_MESSAGES.hide_over_required);
  }
  return out;
}

module.exports = { OVERRIDE_CONFLICT_MESSAGES, overrideConflictWarnings };
