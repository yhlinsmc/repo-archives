# flexible_mold_base — System Design Document (SDD)

| Meta | |
|---|---|
| Version | v1.0 |
| Last Updated | 2026-06-14 |
| Status | active |
| Related Files | CLAUDE.md, LEARN.md, frontend-rules/frontend-rules.md |

---

## 1. Background & Scope

**flexible_mold_base (FMB)** is a Modular Monolith blueprint/template + API-connector engine deployed on-premises and in air-gapped private networks.

The project adopts a **Platform / App separation**:

- **Platform** (`src/platform/`, `docker-api/src/{shared,infra,edge}/`, `infrastructure/`) — reusable infrastructure: auth, setup wizard, feature gates, API client, env detection.
- **App** (`src/fmb/`, `docker-api/src/edge/routes/app/`) — business logic. The `Fmb` class/component prefix corresponds to the `fmb_` table prefix in the database.

Detailed separation guide: `src/platform/PLATFORM_GUIDE.md`.

---

## 2. Target Users

| Role | Description |
|------|-------------|
| **admin** | Full platform access: user management, privilege grants, all CRUD, schema tools, connector management, proceed-anyway overrides. |
| **editor** | Self-service access to own or shared resources: create/edit/delete own connectors and templates, export/import connectors for own or shared blueprints; cannot touch foreign resources or admin-only endpoints. |
| **user** | Read access + data entry: run fetch-from-connector flows on assigned blueprints, view templates; no write to platform config. |

---

## 3. Architecture Overview

### 3.1 Deployment Environments (Dual-State)

FMB targets two production deployment states:

| | ONPREM | AIRGAP |
|---|---|---|
| **Purpose** | Daily development + milestone verification | Official production deployment |
| **OS** | WSL Ubuntu 24.04 | Ubuntu 22.04 |
| **Docker** | >= 26.0, Compose >= 2.20 | 26.1.3, Compose 2.35.0 |
| **Auth** | SSO JWT / Keycloak OIDC | SSO JWT / Keycloak OIDC |
| **DB** | MariaDB container sidecar | External MariaDB (private network) |
| **Network** | Internet available | No external network; Nexus proxy for apt/npm |

- **ONPREM dev flow**: `npm run dev` (daily) → `docker compose up --build` (milestone verify).
- **AIRGAP hard constraint**: 100% offline. **Zero new npm dependencies** — any new dep is a CRITICAL blocking issue (Nexus curation is manual).

### 3.2 Backend Architecture

**Single Docker image** runs as one of three roles, selected by the `API_ROLE` environment variable:

| Role | Port | Responsibility |
|------|------|----------------|
| `infra` | 3200 | Frontend-facing: auth middleware, request forwarding to edge |
| `edge` | 3201 | DB-facing: all route handlers, direct MariaDB access |
| `frontend` | 3000 | Static file serving + `/config.js` injection |

Entry point: `docker-api/src/index.js` → role dispatcher → `index-infra.js` / `index-edge.js` / `index-frontend.js`.

**S2S authentication**: `S2S_API_KEY` shared secret. Infra strips incoming `X-Forwarded-User-*` headers, verifies identity via edge S2S, then reconstructs and forwards them. Edge never trusts infra-supplied claims — it re-verifies the bearer token via JWKS.

**Circuit breaker**: 3 consecutive failures → 30 s open → half-open probe. Setup endpoints bypass the breaker.

Internal edge S2S endpoints (never exposed to the public network):

| Endpoint | Purpose |
|----------|---------|
| `POST /edge/internal/auth/identity-resolve` | `{source:'oidc',claims}` or `{source:'jwt-bearer',userId}` → DB lookup + JIT provisioning + banned audit |
| `GET /edge/internal/system/auth-mode` | DB-backed canonical auth_mode + source |
| `/edge/health` | Includes `pool:{...}` block consumed by infra pool-state cache |

### 3.3 Cold-Boot Contract

Infra's `app.listen()` runs immediately at boot. Edge readiness is **not** a prerequisite.

| Route | Behaviour |
|-------|-----------|
| `GET /health` | Always HTTP 200. Body degrades (`edge_unreachable:true`, `db:'unknown'`) but **status code never flaps** — this is the k8s readiness probe target. |
| Protected `GET /api/*` (post pool-gate) | Returns HTTP 503 `code:'EDGE_UNREACHABLE'` + `details.hint_code:'edge_unreachable'` when edge is down. |
| `POST/GET /api/setup/*` | Always HTTP 200. The setup wizard must work during cold-boot before edge is ready, so operators can configure the DB. |

Additional boot invariants:

- `detectAuthMode(null, null)` runs at boot time in-memory only (no DB reads/writes). The canonical `auth_mode` for each request comes from `GET /edge/internal/system/auth-mode` S2S.
- Pool state is cached via `infra/lib/pool-state-cache.js` with a 5 s positive / 1 s negative TTL to avoid a round-trip to edge on every `/api/` request. First request after boot incurs one cache miss (~5–50 ms); subsequent requests within 5 s hit the cache.

Cache strategy decisions: `LEARN.md §81` (30 s `_userCache` in auth.js retained / auth-mode not cached / pool-state 5 s cached — each call site has its own trade-off).

### 3.4 k3d Local Cluster (K8S_LOCAL)

k3d mirrors the AIRGAP dual-zone topology for local testing. Dev entry: `port-forwards.sh --zones=test` (8130 zone-test frontend / 8143 infra / 8144 edge / 9090 argocd). `setup.sh` maps host port 443 to Istio Gateway so browsers can reach prod-shape URLs (`https://zonea-fmb-web.localhost/`, etc.) with all routing/TLS/cross-zone S2S mirroring production. See `infrastructure/k8s/README.md` and `infrastructure/docs/LOCAL_CICD_RECIPE.md §6.7`.

---

## 4. Stack Lock

| Dimension | Choice | Notes |
|-----------|--------|-------|
| Build tool | Vite 7 | |
| Framework | React 18 + TypeScript | |
| Compiler | SWC | |
| TypeScript mode | **strict + 3 extra flags** | `strict`, `exactOptionalPropertyTypes`, `noFallthroughCasesInSwitch`, `noUncheckedIndexedAccess` — downgrade is CRITICAL |
| Styling | Tailwind CSS (tokens only, no inline styles) | |
| Component library | shadcn/ui (copy-paste, not a published package) | |
| Data fetching | TanStack Query | |
| Forms | react-hook-form | |
| Package manager | npm | |
| Runtime (API) | Node 22 | |

TypeScript strict mode is locked in `tsconfig.app.json`. Verification: `npx tsc -p tsconfig.app.json --noEmit` must return 0 errors.

Escape hatch policy: `@ts-ignore` forbidden; `as any` forbidden in non-test files (new additions); `@ts-expect-error TSxxxx: <reason>` + `as unknown as X` (with comment) are the approved alternatives.

---

## 5. Design System

All UI direction is documented in `frontend-rules/frontend-rules.md`. Key principles:

- Accent colour used in at most ~3 action spots per screen; no decorative icons on form fields.
- Dark mode is mandatory.
- UI direction requires an HTML mockup sign-off before any coding begins.
- No inline styles; Tailwind tokens only.
- shadcn components are copied into the repo — do not import from a published package.

---

## 6. Information Architecture

### 6.1 Platform UI Surfaces (`src/platform/`)

| Surface | Access | Description |
|---------|--------|-------------|
| **Auth Guard** | All | Unauthorized → auto-redirect. `GET /api/auth/diagnostics` (public, connection status) vs `/details` (admin, full Keycloak config) — layered to prevent information leakage. **Keycloak session storage:** `keycloak-oidc.js` runs express-openid-connect's default **stateless encrypted-cookie session** (`appSession`, dir/A256GCM JWE keyed off `KEYCLOAK_SECRET`, auto-chunked past 4KB) — replaces the former in-process `MemoryStore`, so a session survives an infra pod restart/redeploy without a server-side store (`infra-talks-to-edge-only` respected: no store/DB reached from infra). Frontend `keycloak-auth.ts` treats a network-class failure on `/api/auth/me` / `/api/auth/access-check` as transient (one bounded retry, then HOLD the current session) — only a confirmed 401/403 drives logout, so a deploy blip never ejects an authenticated user. |
| **User Management** | Admin only | Suspend/delete users including Auth cleanup. Adjusts dynamically for SSO mode. |
| **Environment Switcher + Connection Profiles** | Admin | Dynamic switch of DB/Auth/SSO within the Platform UI. Default profile `local-default` (CUSTOM_API) for both ONPREM and AIRGAP. Wrong-env built-in profiles are auto-purged. |
| **First Setup Wizard** | Admin (cold-boot) | 6-step wizard: EnvDetect → DbConnect → SchemaInit → SeedData → SsoConfig → CreateAdmin. `GET /api/setup/status` returns `recommended_step`; frontend auto-skips completed steps. `StepDbConnect.handleTest()` auto-chains `/api/setup/configure-db` after a successful test to write config and start the pool. `POST /api/setup/init-db` accepts optional `bootstrap_credentials` (one-shot DDL pool, destroyed after use, never persisted); returns 412 `NEED_BOOTSTRAP_CREDENTIALS` if body is empty and `_rwPool === null`. pino redacts `bootstrap_credentials.*` and `runtime_credentials.*`. |
| **Seed Data** | Admin | Export MariaDB SQL from DB Connections page (`GET /api/export/mariadb-sql`, `__PREFIX__` placeholder); import via Setup Wizard (`POST /api/setup/seed`, allowlist: INSERT/REPLACE only). |
| **Privileges** | Admin + ONPREM/AIRGAP only | GRANT/REVOKE on `fmb_*` tables to a MariaDB service account. Double self-guard (`CURRENT_USER()` + `DB_RW/RO_USER`) prevents a DBA from locking themselves out. 2-phase audit (pending → success/fail) written to `feature_audit`. DDL rejected from UI (`CREATE`/`ALTER`/`DROP`/`GRANT OPTION`/`SUPER`). Includes diff mode, preset buttons, date-range filter, CSV export. |
| **Keycloak Realm Multi-zone** | Admin | `redirectUris` / `webOrigins` / `post.logout.redirect.uris` must include every zone's `*-fmb-{web,api}.localhost` (dev k3d) or the equivalent prod hostname. Dev: `.devcontainer/keycloak/realm-export.json`. Prod: `infrastructure/keycloak/realm-patch.template.json` (envsubst; never commit real hostnames). Operator runbook: `infrastructure/docs/KEYCLOAK_REALM_SETUP.md`. |

### 6.2 App Business Pages (`src/fmb/`)

- Blueprint/template management
- Data entry forms driven by blueprint field definitions
- API connector data-fetch flows and modal UIs
- Transformer admin UI
- Author-flow orchestration: **Build flow** modal on the Generated-Outputs card, read-only run-history page (`/flow-runs`) — core PR4 path shipped v3.2.359; full recipe/step authoring UI deferred to PR5
- **Capacity Planner** (`/capacity`, shipped v3.2.497–502; config-rewrite R1–R5 v3.2.513–518): a self-contained data-center capacity/placement tool (place KVM VMs on hypervisors across sites, DB instances grouped under first-class Databases on DB-host VMs, UI-configurable non-blocking placement rules — a six-keeper rule model — drag-drop placement canvas with team-color group marking and live validation, versioned scenarios, xlsx/CSV/PNG import-export). Extraction-ready subtree — see §7.10.
- **Template versioning & compare** (`/data-entry`, `fmb_template_versions` timeline merged with `flow_recipe_runs`; six-item batch fmb-1934 v3.2.909–914) — see §7.11.

### 6.3 UI Conventions

- **Truncation is two classes, never mixed** (connector-editor-batch fmb-2022): a **control label** (option text, select trigger, radio/checkbox label) never truncates — it wraps (`flex-wrap` / `break-words`), because hover is not a fallback on a touch device and a truncated option is an unreadable control. A **data cell** (table cell, read-only display value) truncates and always carries a `title` attribute with the full value. `scripts/cicd/truncate-title-lint.sh` (ship-gate step 41, ast-grep-based) enforces this tree-wide with zero pragmas.
- **One CodeMirror wrapper**: every JSON/code editing surface in the connector editor renders on the single shared `CodeEditorPane` (`src/fmb/components/shared-code-editor/CodeEditorPane.tsx`), which memoizes its extensions and composes the `readOnly` facet once. `BodyEditor` (HTTP request body) and `StaticBodyPane` (static-source body) are thin wrappers around it — neither owns its own CodeMirror instance or theme wiring.

---

## 7. Module Specs

### 7.1 Directory Boundaries

| Directory | Role |
|-----------|------|
| `src/platform/` | Auth / Setup / Feature Gate / API Client / Env detection |
| `src/fmb/` | Business pages / components / hooks / transformers |
| `docker-api/src/shared/` | config / helpers / logger / crypto |
| `docker-api/src/infra/` | Auth middleware / remote-client (no DB imports allowed) |
| `docker-api/src/edge/` | DB code + all route handlers |
| `docker-api/src/edge/routes/platform/` | Platform APIs: audit / users / settings / connections / access-rules / setup / export / query |
| `docker-api/src/edge/routes/app/` | App APIs: schema / sync-schema / transformers / api-connectors / flow-recipes / flow-recipe-steps |
| `docker-api/src/edge/routes/app/capacity/` | Capacity Planner APIs: config (global catalogue) / scenarios (owner-scoped) / children / versions / import-export / bundles / setup wizard (§7.10) |

### 7.2 Three-Layer Table Taxonomy

**Platform Tables (6)** — managed by `buildInfraTableDDLs()`:

`users`, `login_audit`, `system_settings`, `db_connections`, `access_rules`, `feature_audit`

- `access_rules`: `rule_value` for the `user` type stores email (not keycloak_sub).
- `db_connections`: 4 nullable columns support RW/RO split (`pool.rw` / `pool.ro`). `runSchemaMigrations()` adds missing columns automatically. Canonical env: `DB_RW_*` / `DB_RO_*`. See `LEARN.md §60`.

**Engine Tables (14)** — managed by `buildEngineTableDDLs()`:

`hierarchy_nodes`, `blueprint_fields`, `field_options`, `blueprint_sections`, `blueprint_groups`, `blueprint_output_order`, `variant_overrides`, `user_templates`, `transformers`, `transformer_versions`, `api_connectors`, `flow_recipes`, `flow_recipe_steps`, `flow_recipe_runs`

- `blueprint_groups`: blueprint-scoped identity-lane definitions for the group-cards/matrix data-entry layouts — see §8.9.
- `flow_recipes`: per-template recipe config that authors an external flow definition. The payload-shaping step is inline code on the recipe (`payload_transform_code`, authored 1:1 with the recipe and run in the browser transformer sandbox), not a reference to a shared `transformers` row — so flow transforms never need a blueprint link and cannot hit the orphan-editor dead-end.
- `flow_recipe_steps`: ordered per-step API call config, including AES-256-GCM-encrypted `auth_config`.
- `flow_recipe_runs`: immutable per-run execution history with encrypted `rendered_payload`.

Routes (PR2, backend only): `flow_recipes` CRUD + approval lifecycle; `flow_recipe_steps` CRUD (encrypted `auth_config`, masked on read; step edit re-pends parent recipe); serialize-only object→YAML endpoint. Both routers at `/edge/app/`. Dispatch (PR3, shipped v3.2.358): edge S2S prepare/result + infra proxy + `flow-recipe-runs` persistence routes. FE orchestration (PR4, shipped v3.2.359): render→serialize→dispatch→persist→show-link pipeline + `BuildFlowModal`/`BuildFlowButton` in Generated-Outputs card + read-only `FmbFlowRuns` run-history page. Full recipe/step authoring UI → PR5 (deferred).

**Custom Data / App-tier** — frontend Seed Data import or build-time injection; never committed to git. The **19 Capacity Planner tables** (`cap_*`, §8.12) also live in this tier: App-tier DDL (not Platform, not Engine), not Auth tables, created inside `runSchemaMigrations()` gated on `PLATFORM_SCHEMA_VERSION` (a `cap_*` schema change MUST bump that version or the tables are never created on stamped DBs). They are currently **excluded from the cross-environment sync order** (capacity sync design is an open decision; the drift-guard documents the exclusion).

### 7.3 `api_connectors` Behavioral Contracts

`api_connectors` describes an outbound API call: `auth_type` ENUM(none/bearer/api_key/basic) + `auth_config` JSON (the only engine table that stores secrets — token/value/password sub-values use AES-256-GCM field-level encryption via `settings-crypto`; API responses mask all secret values as `****`) + `request_config` / `response_config` JSON + `dispatch_origin` ENUM(infra/edge).

**Owner model**

- `ownerColumn: 'owner_id'`. POST stamps `owner_id = creator` for **all roles** — a connector is never shared.
- `allowedRoles: ['admin', 'editor']`. Plain users access connectors only via `/usable`.
- Editor PUT/DELETE is restricted to the caller's own connectors.
- `parentOwnership` chain via `blueprint_id` → `hierarchy_nodes.owner_id`: editor creation requires the target blueprint to be own (`owner_id === editor`) or shared (`owner_id === NULL`). Admin bypasses this check.
- List/detail reads are view-all for both admin and editor, but `serializeRead` masks all secret values as `****`.

**Reassign** (`PATCH /api-connectors/:id/owner`, registered before CRUD `/:id`)

- admin: `requireCondition: 'any'` — can reassign any connector.
- Current owner: `requireCondition: 'self'` — can transfer their own connector.
- Non-owner non-admin: returns 403 `NOT_SELF`.
- `make_shared` is forbidden — connectors can never become unowned.
- `applyOwnerChange` allowlist includes `api_connectors`.

**Editor self-service export/import** (Group B PR-2)

- Export is read-only and already redacted → editor can export **any** connector (read parity with list/detail).
- Import: `owner_id` is set to the importer. For non-admin importers, the bound blueprint must be own or shared (`hierarchy_nodes.owner_id` is NULL or equals the importer) — otherwise the API returns 403 immediately and does not create an unbound connector. Rationale: an unbound connector would be an orphan because editor PUT/DELETE passes through the `parentOwnership EXISTS` chain; 0 matching rows means the editor can never manage it. Admin importers are unrestricted and may create unbound connectors.
- health counts-only endpoint is open to editors.

**`GET /users/assignable`** (`requireAdminOrEditor`)

- Returns `{ id, display_name, role }` only. **Never returns email** (PII; compliance environment).
- Server-side filters `WHERE banned = 0`; uses `pool.ro`.
- The admin-only `GET /users` endpoint is unaffected.
- Frontend `useAssignableUsers` hook consumes this endpoint to populate `TransferOwnerDialog`.

**Owner name resolution** (`resolveOwnerName: 'owner_id'`)

- On list/detail GET, `owner_id` is resolved server-side to `owner_name` (`display_name || kc_username || 'Unknown'`).
- Runs under `requireAuth` (not `requireAdmin`); resolves only the owner IDs already present in the caller's result set (deduped `IN` — not a full directory scan).
- **Never returns email** (PII).

**Detail view & JSON edit** (connector UI parity PR-3)

- The detail page (`/api-connectors/:id`) has Form / JSON / Raw tabs. The JSON tab is **editable** for owners and admins (`canEdit = isAdmin || owner`); non-owners get a read-only viewer. Entry is the `FileJson` list-action icon (matching the template detail entry point).
- **Editable scope is connector-local config only.** `connectorEditableView` exposes `name`, `description`, `is_active`, `method`, `url`, `dispatch_origin`, `request_config`, `response_config`. It **excludes** `auth_*` (secrets), bundle membership (`group_*`, `sequence`) and `blueprint_id` — these keep secret/ownership/cross-connector rules owned by the structured editor — and `allowed_hosts` (deprecated, see below).
- **Save = partial PUT** (`usePatchApiConnector`) of only the editable keys present. The backend PUT is a partial update (SETs only keys in the body) so every omitted column is preserved → secrets are never clobbered. Any hand-added non-editable key (e.g. `auth_config`, `owner_id`) is dropped by `parseConnectorEdit` before the body is built; the backend independently re-enforces owner gating + drops `owner_id`/`blueprint_id` for non-admins.
- **Chain wiring exception:** when the edited `request_config` carries `input_from_step`, the connector's **current** bundle quartet (`group_*`, `sequence`) is injected unchanged, because the backend's `validateInputFromStep` requires `sequence` and its bundle-consistency check would NULL the bundle if `sequence` arrived without `group_id`. This preserves the bundle without letting JSON retarget it.
- **Client is the only outputs[] gate:** `response_config.outputs` is validated before save with the same rules the structured editor uses (`isLegalOutput` from×to matrix, fan-out single-purpose, filter AND/cell rules) and a present-but-non-array `outputs` is rejected; the backend trusts `outputs[]`. Backend defense-in-depth for `outputs[]` legality remains a deferred follow-up.

**Schema routing (intentional)**

`api_connectors` CRUD intentionally uses the default pool only — `/edge/app/api-connectors` is **not** in `SCHEMA_ROUTABLE_PREFIXES` (only `query`/`schema`/`sync-schema` consume the `X-Database` header). Connectors are platform configuration, not tenant data. This is not a gap.

**Approval lifecycle**

Only an admin-**approved** connector dispatches. Columns: `status ENUM('pending','approved','rejected')`, `approved_by`, `approved_at`, `review_note` — all nullable; **`status` NULL = grandfathered = treated as approved** at the dispatch gate, so pre-existing connectors and a no-ALTER operator DB (additive migration skipped) keep dispatching (the gate blocks only an EXPLICIT pending/rejected). Lifecycle: editor create → `pending`; admin create → `approved`; `PATCH /:id/approve` / `PATCH /:id/reject` (requireAdmin; reject requires `review_note`); editing a rejected connector (resubmit) or sensitive-editing an approved one → re-pends. Sensitive fields = `url`/`method`/`auth_type`/`dispatch_origin` + `request_config` (canonical-JSON compare); `auth_config` is excluded (masked secrets would spuriously re-pend; `auth_type` is the proxy). The create/edit middleware **strips client-supplied `status`/`approved_*`** (approval state is server-owned — an editor cannot self-approve by body injection). Dispatch gate `CONNECTOR_NOT_APPROVED` (422) runs after `is_active`, before the breaker; an admin test-dispatch bypasses it. No-ALTER tolerance mirrors `timeout_ms` (dispatch SELECT fallback drops `status`; PATCH routes → `APPROVAL_UNAVAILABLE` 409 on `ER_BAD_FIELD_ERROR`). UI: an Approval badge column + admin-only filter + inline Approve/Reject on `FmbApiConnectors`.

**Source kind** (`source_kind`, PR-5/PR-6, fmb-1953)

`api_connectors` gains `source_kind ENUM('http','template','static') NOT NULL DEFAULT 'http'` and `source_config JSON NULL`. `url` stays `TEXT NOT NULL`; non-http rows store `url = ''`. `source_config` shapes:

```
template: {
  blueprint_id: string,                  // source blueprint (may equal the connector's home)
  mode: 'one' | 'list',
  select?: { kind: 'pick' }              // mode 'one' only; default
         | { kind: 'match', field: 'name' | { field_key: string }, value: string },  // value may contain {{var}}
  parts: ('inputs' | 'outputs')[]        // non-empty; default ['outputs']
}
static: { body: string }                 // JSON text, ≤ 64 KB, must parse
```

Write-time: `normalizeForSourceKind` (`api-connectors/source-config.js`) forces the http-only columns (`method`, `auth_type`, `auth_config`, `dispatch_origin`) to inert defaults and clears `request_config` for a non-http row (a template/static row has no Request section to author or clear one from — the CRUD write overwrites whatever the caller sent regardless), and clears `source_config` for an http row so a stale template/static shape cannot survive a kind switch back. No-DDL fail-closed: a non-http write on a database whose migration has not applied (`source_kind`/`source_config` physically absent) returns 409 `SOURCE_KIND_UNAVAILABLE` rather than silently dropping the columns from the INSERT/UPDATE — checked by a live `probeSourceColumns` SELECT, independent of the CRUD factory's own (unbounded-TTL) column-set cache. `source_kind` and `source_config` are members of the approval lifecycle's `SENSITIVE_SCALAR` / `SENSITIVE_JSON` sets, so changing either re-pends an approved connector the same way `url`/`method`/`request_config` do. `/usable` projects `source_kind` and a derived `source_select_kind` (`source_config.select.kind` for a `template`/`pick`|`match` row, else `null`) alongside the existing columns.

**Multi-blueprint binding** (`fmb_api_connector_blueprints`, PR-4, fmb-1953)

A join table (`connector_id`, `blueprint_id`, `UNIQUE(connector_id, blueprint_id)`) that lists a connector as also usable in a blueprint beyond its home. `api_connectors.blueprint_id` stays the home blueprint — ownership chain, editor edit authority and exec authority are unchanged and are never duplicated into the join table (a write naming the home as an extra is rejected). `PUT /api-connectors/:id/bindings` replaces the full extras set for a connector; `assertBindingTargets` (`edge/lib/connector-binding-authority.js`) is the single authority for every write path that can change bindings — the bindings PUT, `io.js` import, and the bundle-join guard in `index.js` all call through it, so no second copy of the editor-scope / field-key-completeness / group-coherence rules can drift from the others. Bindings are a **group property**: every member of a `group_id` must carry the identical binding set (home + extras); a binding write that would break that returns 400 `BINDING_GROUP_MISMATCH`. `usable.js` widens its read to `blueprint_id = ? OR id IN (SELECT connector_id FROM fmb_api_connector_blueprints WHERE blueprint_id = ?)`; `health.js` and `validate.js` widen the same way per bound blueprint.

**Bundle sequential apply** (PR-3, fmb-1953)

A bundle run keeps one working copy per target table (`working: Map<tableKey, Row[]>`, `bundle-working-copy.ts`), seeded from the raw committed rows at run start. Members fold into it in member order — each row-writing member reads its base from the working copy and writes its result back — and the form commits once per touched table after every member has folded. The only write-mode rule this enforces: the first writer of a table may use any mode (`append`/`merge`/`replace`); every later writer must use `append` or `merge` — a `replace` after an earlier writer is the only blocked configuration (`findReplaceAfterWriteViolations`), because a later `replace` discards the earlier writer's rows by definition and every other combination composes cleanly through the shared working copy.

**Source-candidates owner filter** (connector-editor-batch fmb-2011)

`GET /:id/source-candidates?q=&owner=me|all` (`docker-api/src/edge/routes/app/api-connectors/source-candidates.js`) and the in-process 300-body "ambiguous match" envelope (`docker-api/src/edge/lib/template-source.js`, `resolveTemplateSource`'s `pick` path) both list candidate `user_templates` rows for a template-source connector's configured blueprint. `owner` is validated to exactly `me` or `all` (400 `INVALID_OWNER_FILTER` otherwise); the implicit default when the query param is absent is `all`, never `me`. Each candidate item carries `{ id, name, updated_at, owner_id, owner_name, is_mine }` on **both** endpoints — `owner_id` is the raw column (`null` = shared/unowned), `owner_name` is `''` for a null `owner_id` and the resolved display name otherwise (the null-means-two-things rule: absence of an owner is a distinct state from an unresolved name), `is_mine` is `sameStoredId(owner_id, callerId)` (case-insensitive compare, never `===`). `source-candidates` additionally returns `mine_total`: the caller's owned-template count in the blueprint **ignoring** `q`, so the frontend can default the picker's Mine|All filter to Mine when `mine_total > 0` without a second round trip.

### 7.4 `user_templates` Owner Model

Owner column: `owner_id` (NULL = unowned). `PATCH /user_templates/:id/owner` follows the same tri-state as connectors: admin any / current owner self / non-owner → 403. No shared / claim / release semantics. Legacy `user_id` column retained read-only pending DBA `DROP COLUMN`.

A `template` source (`api_connectors.source_kind`, §7.3) reads the source blueprint's templates through `/prepare` at fetch time — a direct `SELECT ... WHERE id = ?` on `user_templates`, never a cached or versioned snapshot — so the envelope always reflects the row as currently saved.

### 7.5 Request Logging and Tracing

One access log line per request (`module:'http'`, pathname-only — never includes query string or email) + `req_id` propagated across the infra ↔ edge boundary. `X-Request-Id` returned to the frontend (error toasts display the trace ID). `LOG_LEVEL` env variable controls verbosity (ConfigMap dual-source). Zero-dependency middleware at `shared/middleware/request-{id,log}.js`. See `infrastructure/docs/LOGGING.md` and `LEARN.md §107`.

### 7.6 Schema Builder — Right-Pane Layout Shell (PR2)

The Schema Builder right pane (`SchemaBuilderLayout.tsx`) is a **router**, not one fixed form:

- **Field selected (or create mode)** → `SchemaFieldEditorTabs` — three `<TabsContent forceMount>` tabs (Basic settings / Type settings / Display & rules) behind an accent header band that echoes the selected tree row's accent color, a monochrome type chip (reuses the existing lucide type-icon map, no per-type color — that's PR3), and a sticky-footer field-props Save.
- **Nothing selected** → `BlueprintSettingsView` — the relocated `GroupsManagerPanel` (verbatim, same props) plus `OutputOrderPanel` restyled as a numbered chip-card grid. Both blocks are fronted by a real-data, empty-safe micro-schematic (tinted lanes for groups, a numbered strip for outputs) that renders `null` when its source data is empty.

**Save-flow map (1:1, unchanged) — no new aggregate save:**

| Data | Persists via | Save button |
|---|---|---|
| Basic + Display fields, Type tab's parent-field/checkbox-limits controls | field-props PUT | sticky-footer Save (shared across all three tabs) |
| Type tab's options grid | field-options replace | in-tab Save |
| Type tab's table editor | table-columns save | in-tab Save |

All three tabs are `forceMount`, so switching tabs never unmounts a sub-form — an edit left in a background tab is never lost. A per-tab dirty dot is a display-only derivation of the same aggregate `isDirty` that already feeds the page-level unsaved-navigation guard (no new dirty source). Splitter width persists across reloads via `autoSaveId="fmb.schema-builder.split"` (paired with a matching stable `id` on the `ResizablePanelGroup`, since react-resizable-panels derives its group id from `id`, not `autoSaveId`); the pre-existing `min-w-0` clamp chain and `defaultSize`/`minSize`/`maxSize` bounds on both panes are preserved verbatim, so a restored width can never push the sticky Save offscreen. `SchemaDetailPanel.tsx` is retired (replaced by `SchemaFieldEditorTabs`); `SchemaSidebar` drops the two bottom docks it used to render inline (Groups + Output Order moved into `BlueprintSettingsView`).

**PR3 — field row tokens:** the tree's field row (`FieldRow.tsx`) reads its type glyph/label/tooltip from the single-source `src/fmb/lib/field-type-tokens.ts` (color-free by design) and paints its own group color dot from `groupColorByKey` (`blueprint_groups` meta), falling back to a neutral dot on a stale/unknown group key.

### 7.7 `EditableDataGrid` — Opt-In Props Extension Contract (PR4)

`EditableDataGrid` (`src/fmb/components/EditableDataGrid.tsx`) gains four new props — `filterable`, `rowValidation`, `cellDecoration`, `reorderableRows` — plus a `readOnly` flag on `GridColumn`. All five default OFF; a caller that passes none of them gets a byte-identical grid to the pre-PR4 component (pinned by the `EditableDataGrid.optInProps.baseline` R3 snapshot test, which must stay green through every grid-touching change). `cellDecoration` is the seam other Schema Builder features hang off (the duplicate/alias tint, the invalid-row marker, the delete-guard on a cascade-referenced row) without the grid itself knowing about aliasing or cascades. `filterable` and `readOnly` are chokepoints, not display flags: every write op (edit, paste, delete, drag-reorder) resolves against REAL row indices before touching the underlying data, so a row hidden by an active filter can never be edited by index-drift, and a `readOnly` column rejects a write at the same chokepoint rather than only hiding the input visually. `FieldOptionsPanel` is the first consumer, driving the extended grid at field level for select/checkbox options; `TableColumnsEditor` is intentionally untouched and keeps the existing `OptionPairEditor` (§3.6).

### 7.8 `TableColumnsEditor` — Master-Detail + Type Registry (PR5a)

`TableColumnsEditor.tsx` drops its accordion for a master-detail split: a left column list (drag reorder, add, delete) and a right full config pane for the selected column, so every column stays reachable without expand/collapse. Inner-column typing (per-column `type`, distinct from the field-level type covered by §7.2/PR3) is now sourced from `src/fmb/lib/table-column-types.ts`, a registry mirroring the field-level `field-type-tokens.ts` pattern: each `TableColumnTypeDescriptor` bundles glyph (T1 monochrome, shape-identified), label, tooltip, and an `OptionsSource` seam (`{ kind: 'none' | 'pairs' }`) selecting which options editor the detail pane mounts. Seeded with `text` (`none`) and `select` (`pairs`) only — no visible coming-soon/disabled control. Adding a future inner-column type (Q8 structural reserve) is a registry entry plus, only if it needs a new options UI, one new `OptionsSourceDescriptor` kind — never a new conditional branch inside the editor. `resolveTableColumnType()` is own-key-guarded (`Object.prototype.hasOwnProperty.call`, not a bare index lookup) so an out-of-registry or prototype-polluting key (e.g. `__proto__`) degrades to the neutral `text` descriptor rather than crashing the render tree; a legacy stored column whose `type` isn't in the registry is normalized to `text` at save time. Table-column options remain on `OptionPairEditor` v1 (§3.6, unchanged) — the registry only decides which options UI mounts, not its implementation.

**PR5b** adds a collapsible preview dock (default expanded, native `<button>` toggle, no persistence) hosting the default-rows `EditableDataGrid` below the master-detail split, plus bidirectional column linkage between the master list and the preview header — carried by two default-OFF `EditableDataGrid` opt-in props, `onColumnHeaderClick(colIndex)` (delegates the header click to the master list and suppresses the grid's own internal copy-column select) and `highlightedColumnIndex` (primary-accent tint on the `<th>` top-bar and its body `<td>`s) — so every existing grid caller renders byte-identical (R3 baseline preserved).

### 7.9 Schema Builder Polish Batch — Layout Schematic + Section Selection (PR-B/PR-C)

`LayoutSchematic.tsx` is a pure presentational preview of a section's `layout_mode` (stacked / group-cards / matrix), reusing `GroupsSchematic`'s tinted-lane visual grammar and resolving real group colors via `group-palette.ts`. Stacked renders one neutral column (groups never affect stacked rendering); group-cards and matrix render up to 4 tinted lanes/columns from the blueprint's actual groups, falling back to a grey-scale placeholder + a one-line hint when the blueprint has no groups yet. Label/icon lookup for the three layout modes is single-sourced in `src/fmb/lib/layout-mode-meta.ts` (`resolveLayoutModeMeta`, `normalizeLayoutMode`) so `SectionEditDialog`'s live preview, `BlueprintSettingsView`'s per-section layout usage strip, the left-tree section header badge (`SectionHeader.tsx`, hidden for stacked sections), and `SectionSettingsView` all read the same wording/iconography and never drift.

`SectionSettingsView.tsx` is the read-focused right-pane view that opens when a section (not a field) is selected in the left tree — a new selection axis, `selectedSectionKey`, held in `FmbSchemaBuilder.tsx` mutually exclusive with `selectedField` (setting one clears the other; `SchemaBuilderLayout.tsx` routes field → `SchemaFieldEditorTabs`, else section → `SectionSettingsView`, else → `BlueprintSettingsView`). Tree interaction contract: clicking a section's title text selects it (and expands if collapsed, never collapses); the chevron only toggles expand/collapse and never changes selection. The view shows a "← Blueprint settings" back link (clears the section selection), the section's `LayoutSchematic` (md size), a groups-usage list (blueprint's group lanes rendered bright when ≥1 field in this section carries that `group_key`, dimmed otherwise — display-only derivation, nothing persisted; groups stay blueprint-scoped per §7.2), and, for matrix sections, a row-key summary sourced from `buildMatrix()`'s row order rather than re-derived, so it can never drift from the actual matrix render. `SectionEditDialog` remains the only edit surface — this view has no form controls of its own.

`FieldEditor.tsx` becomes layout-aware: a hint line under the Group select reports the owning section's layout ("Section layout: Matrix", tracking the live `form.section` value so switching the picker updates the hint before Save), and the matrix row-key block renders only when the owning section's `layout_mode` is `'matrix'` OR the row-key value is non-empty on EITHER the loaded snapshot OR the live form value — the OR-of-both-clauses gate keeps a stale/unsaved key visible and clearable in both edit directions (section switched away from matrix mid-edit, or a typed key not yet saved) rather than stranding it. The loaded snapshot advances to the current value on Save, so a cleared stale key stays cleared afterward instead of reappearing on the next render.

**PR-D** replaces the field-level matrix row-key `<input>` with a creatable combobox sourced from distinct row keys already used by other fields in the same section, ordered by the same effective `buildMatrix` order as the render surfaces — selecting a listed key reuses it verbatim, and typing an unlisted value creates it with no normalization (no trim/case-fold), matching the field-key convention that a row key is opaque, admin-authored text. `SectionSettingsView`'s PR-C read-only row-key summary is replaced by a mini-matrix that supports row drag-reorder: a drag reuses the existing field-order persistence mechanism unchanged (no new backend/data design; `buildMatrix()` itself is untouched — it just reads the same field order it always has) and is scoped to reordering the first color group's fields by row key. Row-drag is gated to "dense" matrices — every row key present in the first group — because reordering a sparse matrix's rows by the first group's field order would not move the rows missing from that group; a sparse matrix falls back to the PR-C read-only list plus a hint explaining why drag is unavailable. No §8 data-design change (no new column, no DDL).

On `/data-entry`, `MatrixCell` reserves a field-key line in every cell's layout (rendered blank when the cell has no visible key), so all cells in a row commit to the same height regardless of whether an individual cell shows a key — presentation-only, no payload/compute change.

### 7.10 Capacity Planner (`src/fmb/capacity`, shipped v3.2.497–502; config-rewrite R1–R5 v3.2.513–518)

A self-contained module that replaces an Excel + PPT workflow for data-center capacity planning: place KVM VMs on hypervisors across sites, DB instances (grouped under first-class Databases) on DB-host VMs, configure non-blocking placement rules, drag-drop with live validation and team-color group marking, snapshot versions, and xlsx/CSV/PNG import-export. Full design: `docs/superpowers/specs/2026-07-11-capacity-planner-design.md` (the original PR-A…F rollout — **partially superseded**, see its own top-of-doc banner) plus `docs/superpowers/specs/2026-07-14-capacity-config-rewrite-design.md` (the binding spec for the reference-model rewrite; its §18 "Supersession map" is the section-by-section disposition against the 07-11 doc).

**Module boundary (extraction-ready).** Frontend lives entirely under `src/fmb/capacity/{routes.tsx, menu-items.ts, pages/, components/, lib/, hooks/}`; `src/fmb/routes.tsx` and `src/fmb/menu-items.ts` each spread it in on one line. The subtree may import `src/platform/` shared modules and itself **only** — no cross-imports with other `src/fmb/` features (it re-implements a minimal `CapacityPageHeader` rather than reach into `src/fmb/components/`). Backend routes live under `docker-api/src/edge/routes/app/capacity/` (`index`/`_shared`/`config`/`scenarios`/`children`/`versions`/`io`/`bundles`/`wizard`), composing `createCrudRoutes` for generic CRUD and adding the module-specific endpoints (reference-model create, version freeze/clone, import validate/commit, export projections, setup-wizard one-tx create).

**API split — two permission tiers on distinct mounts** (avoids one mount branching on `scenario_id`):
- `/api/app/capacity/config/*` operates on the global catalogue rows (`scenario_id IS NULL`) — `hardware_specs`, `disk_combos`, `teams`, `vm_profiles`, `field_defs`, `settings`, `rules`, plus the never-scenario-scoped `bundles`/`bundle_items`; gated `allowedRoles: ['admin','editor']` (editor IS the "designated people" mechanism — don't bottleneck config on admin).
- `/api/app/capacity/scenarios` and `/scenarios/:id/*` (sites, hypervisors, databases, vms, db_instances, custom_groups, custom_group_members, rules, waivers, versions, plus merged-with-global reads of teams/disk_combos/vm_profiles/hardware_specs) operate on scenario-scoped rows; gated by **owner scope** (`ownerColumn: 'owner_id'` on `cap_scenarios`, `parentOwnership` FK chain on children — the `api_connectors` precedent). Admin-created scenarios may leave `owner_id` NULL (shared); editor-created stamp the actor. Reads are view-all for all authenticated users.

**Reference model (R1 — supersedes the deep-copy template layer).** A new scenario **copies nothing** at create time. Its working state is a read-time merge of the global catalogue (`scenario_id IS NULL`) with its own local rows (`scenario_id = :id`) — the pre-rewrite design deep-copied the 5-table template layer into every new scenario; this rewrite drops that copy entirely.

**Rule evaluator — TWO copies, lockstep obligation, six-keeper rule model.** The evaluator is a pure, deterministic, I/O-free typed function (`evaluate(scenarioState, rules) → Violation[]`, iteration budget + `budget_exceeded` flag). The rewrite (R1) reduces the rule-type library to **six keepers** — `no-oversell`, `max-vms-per-host`, `max-instances-per-vm`, `keep-apart`, `spread-across-sites`, `keep-in-one-site` — each targeting a structural `level` (hypervisor/vm/db_instance) with a `group_by` (each_database/each_primary_cluster/each_standby_cluster/all_of_type/custom_group), replacing the original ten-type library. It exists as **two mirrored implementations**: backend CJS `docker-api/src/shared/capacity/evaluator.js` (drives `GET /scenarios/:id/violations`, version freeze, import report) and frontend TS `src/fmb/capacity/lib/evaluator.ts` (drives live drag feedback on the placement canvas). Any change to either MUST mirror to the other and keep the **lockstep conformance test green** (`evaluator.lockstep.test.ts` + the conformance suite) — the two are a single logical contract. `objectSetKey = sorted-ids join '|'` is a byte-stable waiver key (never client-recomputed; the server echoes it). Rules **never block** any operation (§3.1 of the spec) — violations are computed markers (red `hard` / amber `soft`), waivable per-occurrence (the waiver UI is labeled "Exception").

**Placement canvas.** Single zoomable canvas, two discrete zoom modes (Fit All ⇄ 100% Edit, no free zoom — CSS transform, zero new deps). Framed host-tile rows with an identity rail; dnd-kit drag for KVM boxes and independently draggable DB cylinders; a drop **lands immediately** with Undo (never a confirm bar — never-block invariant). **Team-color amendment (R5, config-rewrite spec §6.2 — a formal amendment of the r8.9-locked "color = spec tier + load ONLY, never grouping" rule):** the `var(--owner)` token reserved on the primary DB cylinder body is the team-color hook — an instance's owning database's `team_id` wins over its hosting VM's own `team_id` (`placement-model.ts` `resolveOwner`); the operator-entered `cap_teams.color` (VARCHAR(32)) is sanitized against a hex-only allowlist and paired with a WCAG-luminance ink pick before it ever reaches an inline style, so a malformed/unsafe value silently falls back to the pre-amendment default rather than reaching the DOM. The three encodings stay distinguishable: spec-tier = box border, load = the CPU·MEM number ink, team = the small-area cylinder-body marking (never a full-tile flood). An **outer dirty-tab guard** (`useDirtyTabGuard`) protects the Grid tab's staged local edits across tab switches, the Back button, `beforeunload`, and a same-URL popstate sentinel; only the Grid tab holds an unsaved buffer. The scenario header carries a **version chip** (`CapacityVersionChip`, "working copy · N versions", clause omitted when N=0) that routes to the Versions tab through the same guard — there is no live version pointer by design (versions are frozen snapshots, restore = clone).

**Versions & clone.** "Save as new version" writes a **server-computed** immutable snapshot (`{schema_rev, tables:{…}}`, the **14 `SNAPSHOT_TABLES`**, §8.12; the client sends name + optional note only, 4 MB guard). The snapshot closure also pulls in the FK-reachable global-catalogue rows it references (`CATALOGUE_CLOSURE`: hardware_specs, vm_profiles, disk_combos, teams), so a frozen/exported doc is self-contained. Snapshots are read-only; restore is a **clone into a brand-new scenario** (full deep copy, all FKs remapped, waiver `object_set_key` members re-sorted). Clone rights = scenario-create (`admin + editor`); save/delete = owner + admin. History is never overwritten.

**Import/Export.** A single `SHEET_SPECS` registry drives both directions (frontend `src/fmb/capacity/lib/xlsx-io.ts`; the backend mirror in `docker-api/src/edge/routes/app/capacity/io.js` is **column-for-column identical** — a column change updates both plus tests). xlsx parsing is **browser-side** (the xlsx lib pair is frontend-only; no server upload path — the backend validates/commits already-parsed JSON). Sheets carry `ref` / `*_ref` columns (payload-internal stable tokens; FK resolution is ref-first, name-fallback, so duplicate display names round-trip and only an ambiguous NAME reference errors); an **unmatched closure reference on import is auto-created as a scenario-local row** (never global) rather than rejected. Import = validate (structural-only report, never a rule gate) then commit = **all-or-nothing replace-all** of the **14 `SNAPSHOT_TABLES`** in one transaction (`cap_versions` never wiped); imported rule rows reuse `validateRuleWritePayload` (same DoS bounds, six-keeper enum). `GET /config/export` exports the **9 global-catalogue tables** — `hardware_specs, disk_combos, teams, vm_profiles, field_defs, settings, rules, bundles, bundle_items`. `bundles`/`bundle_items` are config-export-only: they carry no `scenario_id`, are not in `SNAPSHOT_TABLES`, and scenario import never writes them. PNG export rasterizes a dedicated 1920×1080 estate + legend stage via `modern-screenshot` `domToBlob` — never a screenshot of the live zoomed canvas.

**Dependencies (FE-only, dep-gate approved v3.2.502; xlsx lib swapped 2026-07-13):** **`write-excel-file` 4.1.1** + **`read-excel-file` 9.3.1** (npm-registry packages, exact-pinned) for xlsx write/read — replaces the originally-shipped SheetJS CE 0.20.3 (`cdn.sheetjs.com` dist tarball), which internal deployment networks cannot reach and which is not published to the npm registry under a usable name; also not `exceljs` (inactive) or the stale/deprecated npm `xlsx` package. **modern-screenshot 4.7.0** for PNG capture, unchanged. No React Flow, no rule-engine library, no virtualization (~250 nodes; windowing would contradict the no-elision rule).

**PR-E** makes the left tree group-aware for group-cards/matrix sections: instead of one flat field list, such a section renders per-group clustered frames — a tinted frame per color group in canonical blueprint group order, with ungrouped fields trailing in their own untinted cluster (stacked sections are unaffected). Per-cluster numbering follows the displayed order within each cluster, with matrix-placement dashes ("–") for a matrix field's non-primary cell positions, matching the existing placement-aware numbering convention. Within-cluster drag reorder shares the same deterministic permutation helper as the mini-matrix row drag, `reorderFieldsWithinSubset`, so both surfaces persist through the existing field-order mechanism unchanged (no new backend, no new column); a cross-cluster drop is rejected (the row snaps back with a hint) since regrouping a field is deliberately kept to `FieldEditor` only, not draggable.

**Phase-5 scenario validation, delete-impact, and ownership (item 7/8/11, spec §9–§11).**
- **Scenario health.** `capacity-scenario-health.ts` `computeScenarioHealth` is a pure function (no I/O) returning a status + typed findings in three classes: data integrity (broken FK refs / orphaned rows), incomplete configuration (0 datacenters, a database with no profile), and placement rule violations (folded in from the evaluator's summary, never recomputed). The integrity checks deliberately mirror the placement segments of the backend's `CHILD_FK_VALIDATIONS` (and the list-health `SCENARIO_INTEGRITY_FK_PROBES`) so a `!set.has(fk)` miss on the frontend is the same verdict the backend join encodes; a dedicated FE/BE parity test (`capacity-scenario-health-fk-parity.test.ts`) locks the two probe sets together so they cannot drift. The scenarios list (Layer A) shows a per-row status icon + status filter + per-status counts, fed by a lightweight server aggregate `GET /scenarios/health` (counts only, no names, RO pool) mapped through `scenarioStatusFromFacts` — so the list needs no full per-scenario entity fetch. The in-scenario **Validation** tab (Layer B) runs the full pure core over the live placement-model entities + violation summary and lists findings grouped by class.
- **Delete-impact tiering.** A shared fail-closed `CapacityDeleteImpactDialog` fetches a blast-radius preview before opening and BLOCKS the delete (toast, no confirm) on any fetch failure — it never degrades to a plain confirm. **T1** (`GET /scenarios/:id/delete-preview`, RO pool, authz mirrors the scenario DELETE gate) returns per-scoped-table counts + a bounded affected-name list ("+N more") and the dialog requires typing the scenario name to confirm; T1 is wired end-to-end on `CapacityScenarios.tsx`. **T2** (`GET /config/:group/:id/delete-preview`, RO pool) returns which entity **kinds** reference a global catalogue row as counts only — no scenario names/ids (a global row is cross-scope; the cross-scenario security precedent surfaces kind nouns only); the backend endpoint and the dialog's catalogue-phase rendering are shipped, but no catalogue-grid delete action calls it yet (UI wiring deferred, tracked on the phase-5 backlog card). Ordinary in-scenario row deletes keep the existing staged-save gate (T3, unchanged). A monotonic sequence guard discards a superseded preview.
- **Clone + reassign + drop Open.** The scenario row menu drops the redundant Open (the name cell already navigates), adds **Clone** (`canClone` mirrors `canDelete`; the server stamps the owner, ignoring any client value) and an admin-only **Reassign owner** via the shared `TransferOwnerDialog` bound to `cap_scenarios`. Ownership transfer extends the `OwnershipTable` union + `PATCH /scenarios/:id/owner` (admin-only, allows shared/NULL, validates the target is a real admin/editor, never echoes email) through the shared `applyOwnerChange` service (`cap_scenarios` added to its table whitelist).

### 7.11 Template Versioning & Compare (`/data-entry`, fmb-1912 base + fmb-1934 six-item batch + fmb-1948 three-item batch, v3.2.909–919)

`fmb_template_versions` (fmb-1912, 3.2.890 CREATE, severity `warning` — legitimately absent on an operator install without DDL privilege, degrades to `unavailable: true`) holds MANUAL saves; `GET /edge/app/templates/:id/versions` (`docker-api/src/edge/routes/app/template-versions.js`) merges them with a **projection** of `flow_recipe_runs` into one timeline, newest-first — a flow-projected id is spelled `run:<flow_recipe_runs.id>` so the two id spaces never collide. `actor_name` (fmb-1934 PR-6) is resolved server-side via the shared `attachOwnerNames` pattern (`flow-recipe-runs/aggregate.js`'s own `attachActorNames`), one bounded `users` lookup shared across both sources — never a raw `actor_id` reaching the client.

**One History entry, one panel, one two-way compare (fmb-1948 PR-3, supersedes the three-mode strip/N-side compare bar this section used to describe).** The header action row's `Versions` button is `History` (`GitBranch` icon), opening `TemplateVersionsPanel.tsx` — day-grouped **Versions** / **Runs** / **Legacy snapshots** sections (`Runs` fed by the same query the retired `RunHistoryControl` used), each row one line (label · kind badge · time · actor · action slots). Collapsing never hides `Current`, a named manual version, a failed run, or a row from today/yesterday — only older days' unnamed versions and succeeded runs fold into a one-line summary (`groupByDay`/`collapseOlderRows`, `src/fmb/components/versions/group-by-day.ts`); `Named only` (Versions) and `Failed only` (Runs) filter chips and a name/actor search box are client-side over the one already-fetched list, no paging. The standalone run-browsing entry point is retired — a flow run is addressed the same way a version is, through `browsingVersionId`, `kind: 'flow'` — and `run-browsing-guard.ts` (the mechanical write lock every mutation path still asks before touching the network) keeps its ONE-LOCK-FOR-BOTH design but is renamed off run-specific vocabulary onto browse-neutral names (`activeBrowseId`/`setActiveBrowse`/`isBrowseArmed`/`assertNotBrowsing`), since version browsing is now the dominant caller. Snapshot **creation** (`fmb_template_snapshots` POST) stays retired in favor of versions; the snapshot table's GET/DELETE routes stay live for pre-existing legacy rows (fmb-1940 tracks the eventual table drop) under the panel's own "Legacy snapshots" heading.

**Pick-mode two-way compare (`compareOther`, spec §3.6/§3.6-2026-09-01).** The panel's `Compare versions…` button enters pick mode: every row (incl. `Current`) carries a `Base`/`Compare` radio pair, the same row cannot hold both (the other radio disables with a title naming why), a `Swap` button flips the pair, and a checked radio's own title now names which side it holds (`Base — {label}` / `Compare — {label}`) rather than the generic pick instruction. State (`src/fmb/pages/compare-other.ts`) is `browsingId: string | null` (which version's saved values are on the form; `null` = the live draft) plus `compareOther: {kind:'current'} | {kind:'version'; id} | null` (the OTHER side, independent of `browsingId`) — **base = Current is a legal pair**: picking Current as base and a version as compare leaves `browsingId` null (the form stays live/editable) while `compareOther` names the version, so `VersionStrip.tsx`'s `current` mode carries the SAME `Base: Current` / `vs {label}` / count / Prev-Next / `Exit compare` cluster a browsed version's `compare` mode does — Current-vs-Current is unreachable by construction (pick mode forbids both radios on one row), not merely unrepresented. `nextCompareOther` (`compare-other.ts`) is the one reducer both entry points (pick-mode `Compare`, the shipped `Show differences vs current` switch on a browsed version) resolve through; `Exit compare`/`Back to current` both clear `compareOther`. `VersionStrip.tsx`'s `run` mode is retired along with the standalone run-browse entry point above.

**Two-way diff engine (fmb-1934 PR-5, spec §5, generalised for fmb-1948 pick-mode compare).** `buildBrowseDiff` (`src/fmb/pages/browse-diff-model.ts`) computes scalars via the U10 N-way engine's own `buildFieldDiffs` (this module differs only in always seeing exactly two sides) and tables via `buildRowArrayDiff` (the SAME row-array engine the U10 compare layer already renders from). `useBrowseDiff` (`src/fmb/pages/useBrowseDiff.ts`) takes `leftSide`/`rightSide: CompareSide` — the BASE (a browsed version's saved values, or the captured current draft when base = Current) and the COMPARE side (the captured current draft via `baselineCompareSide()`, or another version) — so pick mode's every pairing (version-vs-current, version-vs-version, run-vs-run) goes through the one hook regardless of which side happens to be Current. A differing scalar field renders under its control via `OtherSideValueLine` (renamed from `CurrentValueLine` — the label is the right side's short label, `Current:` when `kind === 'current'`, otherwise the version/run label); a differing table field renders inline (changed cell, ghost "only in current" row, "not in current" trailing label) rather than through a popover. **Schema is authoritative for what counts** (fmb-1934 PR-6): `buildTableBrowseDiff` narrows a table field's counted/rendered columns to `parseTableFieldColumns(field.table_config)`'s own set (falling back to the implicit single `value` column when none are authored, `isSimpleTableField`'s own convention) — a column present in stored data and absent from schema no longer inflates the diff pill for a cell `TableFieldRenderer`'s browse view never draws; row add/remove state is unaffected.

**Outputs are strings before they reach state (fmb-1948 PR-1).** `stringifyOutputs` (`src/fmb/pages/fmb-input-outputs.ts`) is the one boundary a transformer's raw `Record<string, unknown>` result crosses on its way into `FmbInput`'s `outputs` state: a string value passes through, every other value becomes pretty-printed JSON, and an `undefined` value is dropped (rather than serialised to the literal string `"undefined"`). Both the load path (`fmb-input-load.ts`) and `generateOutputs`'s single choke point (`fmb-input-generate.ts`, shared by the generate handler and `persistTemplate`'s own re-generation) route through it, so `outputs` is `Record<string, string>` by construction rather than by convention — the Copy/Download affordances (`FmbInputOutputs.tsx`) can assume a string without a render-time cast.

**Table-cell `row: 'all'` (fmb-1948 PR-2).** `TableCellRow` (`src/fmb/lib/compute/compute-types.ts`) is `'first' | 'last' | 'all'`; `TableCellRef.separator` (optional, meaningful only when `row === 'all'`) is a plain join delimiter — absent or `''` means concatenation with no delimiter, and a stored rule without it keeps working (no migration, JSON column). `resolveCellRef`'s (`compute-rule.ts`) `all` branch maps every row to its column's cell, drops blank-after-`trim()` values (TEXTJOIN's own `ignore_empty`), and joins what remains — an empty table and an all-blank column are two different internal shapes (`undefined` vs `''`) that read identically at every consumer, which already folds `value ?? ''`. Backend validation (`docker-api/src/edge/lib/compute-rule-validate.js`): `ROWS` admits `'all'`; `separator` present requires `row === 'all'` (else `bad_table_cell`) and `length <= 16`; an `arith` operand with `row === 'all'` is rejected (`bad_table_cell` — arith reads one numeric cell, and a joined string is not one). The builder (`ComputeRuleBuilder.tsx` `TableCellEditor`) takes an `allowAll: boolean` prop — the arith operand editor passes `false` (no `All rows` option ever offered where the backend would reject it); concat parts, transform source, and lookup source pass `true` and show a `Separator` input (seeded `', '` on switching to `all`, deleted on switching away) beside the row select, sized to keep every row the same height whether or not the input is present.

**Compute source operand union (fmb-1934 PR-2, spec decision D5).** `SourceOperand` (`src/fmb/lib/compute/compute-types.ts`) — `field | table_cell | same_table_column | table_column_lookup` — is the one shape `TransformConfig.source`/`LookupConfig.source` and `ConcatPart`/`ArithOperand`'s non-literal terms all resolve to, replacing four independently-drifting per-op reads. `normalizeComputeRule`/`normalizeSource` (`normalize-compute-rule.ts`) is the read-boundary: a legacy bare-string `source` (pre-union stored rows) normalizes to `{type:'field', key}`; anything else unrecognized (schema drift, hand-edited row) degrades to the `malformed_source_operand` sentinel tag rather than throwing — every exhaustive `SourceOperand['type']` switch (`resolveSourceOperand`, `renderSourceOperand`, `SourceOperandEditor`'s own `safeValue` render fallback) falls through its existing `default`/unrecognized-kind branch, no fifth union member added. **The sentinel is a render fallback, never a write value** (PR-6 fix): `ComputeRuleBuilder`'s unrelated-field handlers (e.g. the Overridable toggle) spread the ORIGINAL, unnormalized `value.config` — not the normalized render-time form — so an edit that never touches `source` cannot silently overwrite a malformed persisted value with the sentinel literal. Backend/frontend kind parity is fixture-locked (`compute-types.ts`'s `SOURCE_KINDS` against `src/fmb/lib/compute/__fixtures__/source-kinds.json`, checked from both `source-kinds-parity.test.ts` and `docker-api/tests/unit/compute-rule-validate-kinds-parity.test.js`).

**Shared field-candidate builder (fmb-1934 PR-3, spec decision D5).** `buildFieldCandidates` (`src/fmb/lib/schema-builder/field-candidates.ts`) is the one builder every "pick a field" picker in the calculated family (`ValueSourceBlock`, `TableColumnsEditor`, `OverrideDialogs`, `FmbVariantPolicy`) reads instead of four hand-rolled candidate lists — self excluded by `field_key` (or by `id` when a scope passes `selfId`, the pre-migration semantics a legacy duplicate-`field_key` row still needs), a table-type candidate carries its own parsed `columns`. Ship-gate Step 39 (`scripts/cicd/field-candidates-lint.{sh,cjs}`) forbids a NEW hand-rolled `allFields.filter(`/`fields.filter(`/`field_key:` picker expression anywhere reachable from `BlueprintFieldPicker`/`CellTargetPicker`/`SearchableSelect`/`PlainSelect`/`VisibilityBlock`, resolved one hop through a same-file `const`/`useMemo`/`function` — full detection contract, its two fail-closed escape hatches (a file-level `buildFieldCandidates` import allowlist; a `// lint-allow: field-candidates <reason>` pragma), and the not-yet-migrated pragma'd sites (tracked `fmb-1937`) are documented in the lint's own header, not restated here.

### 7.12 Connector Options-List Output + Options-Source Binding (fmb-1976)

**Connector side.** `response_config.outputs` gains a `to.mode:'options'` sink — `{id, from:{mode:'list', path}, to:{mode:'options', value_path, label_path?}}` — validated at the connector write boundary (`api-connectors/validate.js`): `id` non-empty and unique across `outputs[]`, `from.mode === 'list'`, `value_path` non-empty, `label_path` non-empty when present. An options output writes nowhere: `apply-connector-response.ts`'s no-transformer loop skips it before any `from.mode` handling, and it is excluded from both sides of the fan-out single-purpose count (`countsTowardSinglePurpose` in `src/fmb/lib/connectors/connector-fanout.ts`, the one predicate the BE `validateConnectorCoherence` and FE `validateFanoutSinglePurpose` both filter by) — a connector may declare any number of options outputs alongside a single `to:rows` output with no violation.

**Field / table-column side.** `blueprint_fields.options_source` (and a table field's `table_config.columns[].options_source`) gains a `connector`-type shape requiring `output_id` — the id of one of the connector's `to.mode:'options'` outputs — plus an optional `filter`. There is no backward-compatibility branch: a stored old-shape connector source (no `output_id`) parses `ok:false` and is not silently treated as valid or as empty; an operator hand-cleans pre-existing rows at rollout. `filter` (shared by field- and connector-type sources) is `{groups: [{join: 'and'|'or', conditions: [{target: 'label'|'value', op: 'like'|'not_like'|'equals'|'not_equals', pattern}]}]}` — groups are OR-joined, an empty `groups` or an empty `conditions` array keeps every option (never blanks a live select), and `like`/`not_like` use `%` as the only wildcard (case-insensitive; `_` is a literal, D-1) compiled to an anchored regex.

**Runtime resolve** (`src/fmb/lib/option-source/`, order fixed): look up the referenced `output_id` on the connector → `pathGet` the list at `from.path` (blank = root array) → per item, `value = pathGet(item, value_path)` and `label = label_path ? pathGet(item, label_path) : value` (an item with no usable value is dropped, never blanks the whole list) → apply `filter` → dedupe last-occurrence-wins with blank values dropped (`dedupeToOptions`, unchanged). Every unresolvable step (missing `output_id`, an `output_id` naming no output, a list path that is not an array, a failed fetch) renders as a visible error IN the select — never an empty list, never a silent fall-back to a static shape.

**Health.** A connector's health target set gains the options lists it declares that are actually referenced by ≥1 field/column `options_source` (census over `blueprint_fields.options_source` and table `table_config.columns[].options_source`); `computeConnectorHealth(c, knownFieldKeys, optionsReferenced)` takes one boolean per connector so a connector with zero write-target keys but a referenced options list reports `healthy`, not `broken-no-op` — and the data-entry connector-visibility filter, reading the same health status, no longer hides it. An options-only connector with NO reference stays `broken-no-op` (genuinely unused). **Every `source_kind` derives.** `health.js` runs the same derive for `http`, `template`, and `static` connectors alike — the question "do this connector's outputs map onto its bound blueprints' fields (+ referenced options lists)" is answerable for all three, so there is no `n/a` sentinel; a template/static row's `request_config` is `null` and its `url`/`auth_type` are inert (`normalizeForSourceKind`), which `computeConnectorHealth` and `probeDecryptable` already tolerate without special-casing.

**Editor header identity + right-panel source slot** (connector-editor-batch fmb-2023/fmb-2026). The editor's sticky header (`ConnectorIdentityHeader.tsx`) carries the connector's identity fields in two rows: row 1 is the name input + Active toggle (always sticky), row 2 is the description (sticky only in the two-column layout; a plain block in 1col/stacked). The right panel's top slot holds **only editable source content** for the connector's `source_kind` — `http` renders the Request group, `static` renders the Source body pane (`StaticBodyPane`), `template` has no top slot at all and Output fills the whole right panel (a template kind has nothing left to edit once its blueprint/select rule is set; its test-run output is not a second copy of that config). The 1col/stacked layout renders the same groups in a single column in the fixed order **Setup → Combine → Request/Source → Output**.

### 7.13 Delegated Access — Blueprint-Subtree Authority (fmb-1976)

**Model.** `delegated_grants` (`scope_type: 'blueprint'|'template'`, `scope_id`, `grantee_id`, `granted_by`) names one grantee on one subject. A **blueprint** grant reaches the whole subtree under it — blueprint fields, table columns (`blueprint_fields` PUT), variants, variant overrides/policy (including the factory-routed `variant_overrides` DELETE), and connector-blueprint bindings (both the binding PUT's home-blueprint arm and its target-blueprint arm). A **template** grant reaches only that one record. Neither reaches delete-blueprint, transfer-ownership, or cascade-delete of a structural (category/release) node — those stay owner/admin only, unconditionally. A grant likewise does not reach connector ownership: a grantee may write objects under the granted blueprint, but binding a connector still requires owning (or the connector being unowned by) that connector — a blueprint subtree grant is not a connector-ownership grant. A grant follows the subject, not the owner: transferring ownership (`PATCH /hierarchy_nodes/:id/owner`, `PATCH /user_templates/:id/owner`) leaves the subject's grants active for the new owner, who can revoke them from the delegated-access dialog.

**One shared resolver, several call sites.** The blueprint-subtree authority — owner OR admin OR a blueprint-scope grant — is `checkBlueprintWriteTarget`/`editorMayWriteBlueprint` (`docker-api/src/edge/routes/app/schema/helpers.js`), inherited automatically by every call site of `editorMayWriteBlueprint` / `checkBlueprintWriteTarget` (enumerate with `grep -rn "editorMayWriteBlueprint(\|checkBlueprintWriteTarget(" docker-api/src --include=*.js`), plus two independent inline copies that ask the identical question against the same grant-scope resolver (`callerHasBlueprintGrant`, `docker-api/src/edge/lib/delegated-grants.js`) rather than re-deriving it: `validateVariantOverrideContext` (variant overrides) and `connector-binding-authority.js`'s `assertBindingTargets` (the target-blueprint side of a connector binding) and `bindings.js`'s home-blueprint arm.

**Role floor.** Granting requires the caller be an admin, or the subject's owner with a CURRENT role of editor or admin (`grantEligibleRole`). A grant is honoured only for a grantee whose role, AT THE TIME OF USE, is editor or admin — a plain-user grantee, whether they always were one or were demoted after the grant was made, is refused by the schema write routes' own `requireAdminOrEditor` gate regardless of the grant. The SAME floor applies to a blueprint owner's own delegated reach over records they do not directly own: `buildTemplateAccessExists`'s optional `callerRole` and `/mine`'s `owned_blueprint_ids` both require the OWNER to be currently editor/admin, so an editor who owned blueprints before being demoted to a plain user loses that cross-record reach exactly as a stale grant row would.

**Connector home blueprint and the owned-blueprint requirement (fmb-1992).** A blueprint-scope grant is a stand-in for the blueprint's owner over the connector surface too: a grantee may CREATE, UPDATE, DELETE, CLONE, IMPORT or TEST-DISPATCH a connector whose home is the granted blueprint, and may be the TARGET of an owner's reassign of such a connector — the same "owner OR admin OR effective blueprint grant" authority as the rest of §7.13's subtree, reached through the identical shared resolver rather than a second grant query. Test-dispatch is `connector-manage-authority.js`'s `callerCanManageConnector` — the shared rule read by `/prepare`'s `test:true` bypass and `source-candidates`' `?test=1` bypass, so a grantee may verify their own pending/inactive connector before an admin approves it, exactly as they may edit it (station 10). The generic `blueprint_fields` CREATE/DELETE routes honour the grant the same way the existing PUT does. None of this confers connector OWNERSHIP: a grantee who creates a connector under the granted blueprint owns that connector row, but a grant never lets a grantee clone, transfer, or delete a connector another user owns — those stay owner/admin of the CONNECTOR — and it never reaches blueprint delete or transfer-ownership, which stay owner/admin of the BLUEPRINT as stated above. A blueprint grant requires the blueprint to be OWNED at the moment it is minted (an unowned blueprint has no owner for the grant to stand in for) and is DORMANT for the whole time the blueprint is shared (`owner_id IS NULL`) — the grant row survives the sharing and reactivates automatically if the owner reclaims the blueprint, so no re-grant is needed either way. A grant follows the subject, not the owner: transferring ownership (`PATCH /hierarchy_nodes/:id/owner`, `PATCH /user_templates/:id/owner`) leaves the subject's grants active for the new owner, who can revoke them from the delegated-access dialog.

**Variant nodes (fmb-1993).** The `hierarchy_nodes` mount declares `parentOwnership { via: 'parent_id', whenNodeType: 'variant', parentNodeType: 'blueprint' }` with `blueprintGrantScope`, so an editor's variant CREATE is judged by the same owner OR shared OR blueprint-grant resolver as every other subtree write (`checkParentOwnership` → `callerHasBlueprintGrant`), against the same blueprint row `inheritOwnerFromParent` copies the owner from — a parent that is not a blueprint is refused before the inherit lookup could diverge from the gate. Variant rows are in grant scope for rename (the factory PUT owner arm widens to "owner OR grant on the parent blueprint" for `node_type = 'variant'` only) and delete (`mayActOnHierarchyNode`'s variant arm; its cascade preview shares it). Blueprint rows are not: blueprint rename, delete, claim, release, reparent and transfer stay owner/admin. `whenNodeType` is validated against the column's ENUM at registration and enforced inside `checkParentOwnership`, so every caller of the resolver inherits the scoping; the PUT and DELETE scope predicates share one `parentOwnershipScopeFragment`. The FE mount (`FmbHierarchy`) shows the "Add child" door on a granted foreign blueprint and Edit/Delete on its variants, fail-closed while the grant read is pending.

### 7.14 Shared Code Editor — One Mount, Injected Extensions (flow-recipes-batch epic 1, fmb-2034/2035/2045)

**One-code-pane rule.** `CodeEditorPane` (`src/fmb/components/shared-code-editor/CodeEditorPane.tsx`) is the ONLY file allowed to default-import `@uiw/react-codemirror` (the CodeMirror MOUNT) in `src/`; every other JSON/YAML/JS pane in the tree — connector `BodyEditor`, the flow step editor's request body, `StepTraceCard`'s Request/Response/Outputs/Context panes, `ChainTestRunner`'s starting-context pane, the transformer editor's `CodePanes` — is a thin wrapper that passes its own `extensions: Extension[]` (language, wrap, template tokens, secret chips, …) as PROPS rather than mounting its own editor. `@codemirror/*` extension modules may be imported and composed anywhere; only the MOUNT is the choke point. Enforced by `scripts/cicd/one-code-pane-lint.sh` (Ship Gate Step 42, full-scan, zero baseline beyond three named grandfather pragmas — `ReadonlyJsonEditor.tsx`, `CodePreviewPane.tsx`, `FmbTemplateDetail.tsx` — each carrying a `lint-allow: one-code-pane` pragma and a PR-UZ follow-up card, spec S5). `ReadonlyJsonView`'s `renderer="static"` mode is the one sanctioned exception to "wrapper, not mount" — a plain-`<span>` regex tokenizer (`json-static-highlight.ts` + `json-token-colors.ts`, the same palette CodeMirror's own theme paints from) for a HIGH-FAN-OUT repeated-cell site (compare tables, per-step disclosures), never importing `@codemirror`/`@uiw` at all so the ~510 KB CodeMirror chunk stays behind `ReadonlyJsonEditor`'s `React.lazy` boundary.

**`{{var}}` token extension — one regex, FE/BE parity-tested.** `templateTokenExtension` (`shared-code-editor/template-token-extension.ts`) is a `MatchDecorator` over `TEMPLATE_TOKEN_RE` (`src/fmb/lib/connectors/connector-vars.ts`'s `VAR_RE`, `/\{\{\s*([\w.-]+)\s*\}\}/g`) — the SAME source the preview resolver (`preview-request.ts`) and the connector-editor autocomplete import, so the highlighter can never classify a token the resolver would fill differently. The BE mirror is `docker-api/src/edge/lib/connector-dispatch.js`'s own `VAR_RE`, byte-identical by construction (`.source` parity-tested); a drifted grammar on either side would highlight a token this pane accepts as "known" that the dispatch route actually leaves unresolved, or vice versa. A known token renders `.cm-template-token`; unknown, `.cm-template-token--unknown`; hover shows the resolved value with secrets masked (`maskSecrets` config). Opt in via the `templateTokens` prop (`CodeEditorPane`); omit for a pane with no sample context to classify against.

**`StepTraceCard` — one shape, three producers.** `StepTraceCard.tsx` renders a single `StepTrace` (`step-trace-adapter.ts`) regardless of which of three producers built it — the per-step Test pane (`toStepTraceFromTest`), the whole-chain Test runner (`toStepTraceFromChain`), or a persisted run-detail entry (`toStepTraceFromPersisted`, which additionally carries `persistedMeta` for failure metadata a live dispatch never has). `ChainTestRunner` and `RunStepResultsList` mount the identical component — no second card, no per-producer branch in the JSX. Every JSON section (Request sent / Response / Outputs / Context after) renders on a bordered, read-only `CodeEditorPane`, never a plain `<pre>`; the card is collapsed by default and a failed step auto-expands.

**`request_sent` — resolve from masked sources, don't mask after the fact (PR-U5, fmb-2045).** The one dispatch entry (`POST /flow-recipe-steps/:id/dispatch`, called once per step by both the Test pane and the whole-chain runner) returns `request_sent: { method, url, headers, body }` — the request the EDGE actually resolved (`resolveRequest`, server-authoritative `context.*` + the current, possibly just-edited, step definition), masked on the edge by the SAME function the run serializer already applies to a persisted row (`maskRequestSent`, wrapping `maskDeep`/`maskSerializedPayload` in `flow-recipe-runs/serializer.js`) — never a second masking copy, never the client rebuilding a request from a local snapshot. `StepTrace.requestSent` reads that field directly; the deleted client path (`reconstructRequestSent`/`stepToRequestDraft`/`RUN_ID_NULL_CONTEXT_KEYS`) used to rebuild the display request from a FROZEN pre-dispatch snapshot, which could lie about a server-only context token, a step edited mid-chain, or a step re-saved after its test ran (three Codex-caught regressions across two prior fix rounds — Token 紀律 5's "the family keeps returning" signal). The FE-only `maskedAuthHeaders` (`preview-request.ts:67-84`) is a DIFFERENT surface — the pre-dispatch PREVIEW, which never holds a real header — and is not a second copy of this rule. **Known gap (fmb-2063, found live against the deployed build, not yet fixed):** `maskSerializedPayload`'s parse→re-stringify pass re-serialises a masked YAML body at the bare `{lineWidth:0}` default, silently losing a step's real `yaml_version`/`yaml_quoting` (§7.16) on BOTH `request_sent.body` and the persisted `flow_recipe_runs.rendered_payload` — the REAL dispatched bytes are unaffected (a separate, unmasked computation); only these two audit/preview surfaces currently mis-report a non-default dialect.

**`InlineNotice` — the class, not two icon names.** `src/components/ui/InlineNotice.tsx` (shared platform+fmb) is the only sanctioned renderer for an icon+text notice; a bare `AlertTriangle`/`TriangleAlert`/`AlertCircle`/`CircleAlert`/`AlertOctagon`/`OctagonAlert` JSX tag (binding-aware — an aliased or namespaced import resolves too) anywhere else in `src/**/*.tsx` fails Ship Gate Step 43 (`inline-notice-lint.cjs`, full-scan, ZERO pragmas — amendment A1/Q25: all 72 tree-wide sites migrated in one PR, no backfill left to grandfather). The icon sits vertically centred on the notice's first text line (a multi-line body keeps the icon on line 1, never re-centred on the block). `InlineNoticeIcon` is the bare-glyph sibling for a table-cell marker, a heading, or a button/Tooltip label icon — the same six-glyph class, no text row.

### 7.15 `EditableDataGrid` — Measured-Width Engine (grid-measured-width, fmb-2046–2051, v3.2.975–979+)

**DEVIATION FROM THE PLAN TEXT (recorded, not silent): the plan named this section "§7.7" — that number was already taken (§7.7 is the PR4 opt-in-props contract above, unrelated). This is §7.15, the next free subsection.**

**One measured pass, no hand-written px constants.** `useColumnWidths.ts` no longer estimates a column's floor from canvas `measureText` plus a table of per-type constants (the family of fixes fmb-2005/2018/2027/2028 kept re-discovering one wrong constant at a time — see LEARN.md for the full history). Instead, on mount and on every column-set/content-shape change, the table renders ONCE under a `data-measuring` attribute that a single CSS rule (`index.css`) uses to force every column to `width: max-content` and every cell's content to `white-space: nowrap`, unlocking any inline pin from a prior freeze for that one pass. `measureColumnBoxWidths` then reads each column's own rendered border-box — `getBoundingClientRect()` on the `<th data-grid-measure="header">`, the `<td data-grid-measure="cell">` of every visible row, and the gutter's own `data-grid-measure="gutter"` cell — and the header/content pair is assembled into that column's `ColumnFloorTerms`. The measured px widths are then frozen onto the `<colgroup>`; a resize or re-render never re-measures a column downward (frozen values never shrink), and `distributeSlack` (`column-width-math.ts`) is the ONLY place remaining container width is ever handed out afterward — proportionally, to every non-manually-resized column, so a wide viewport can render a column wider than its own content without the measure pass itself lying about that column's floor. `scripts/cicd/grid-no-width-constants.sh` (Ship Gate) forbids reintroducing a hand-written px/character-count constant in the width path.

**Border-box read, not content-box + inset.** `data-grid-measure` stays on the `<th>`/`<td>` itself, never on the inner value box — moving it inward would drop the cell's own horizontal inset from the measured floor and clip content the moment the frozen width equals exactly the text's own width. The one shared inset token, `--grid-cell-inset` (8px each side), is declared once in `index.css` and consumed by every header/body/gutter cell's `px-[var(--grid-cell-inset)]`; `scripts/cicd/grid-cell-content-box.cjs` (ast-grep, Ship Gate) forbids a grid-internal cell wrapper from reintroducing its own literal `px-`/`pl-`/`pr-` token.

**`CellValueBox` — one nowrap value box, `flex` not `inline-flex`.** Every value cell (and the message/stranded-value/multiSelect-chip variants) renders through `CellValueBox` (`EditableDataGrid/CellValueBox.tsx`): `flex items-center gap-1 whitespace-nowrap min-w-0 min-h-[1.75rem] leading-7` plus the column's own `justify-*`. `flex`, never `inline-flex`: a shrink-to-fit box has no free space for `justify-center`/`justify-end` to distribute into (a centred/right value stayed flush-left in a wider cell), and with nothing forcing it narrower than its own content, a narrow frozen column let the box paint past its own `<td>` edge into the next column instead of the `truncate` child clamping to it — both regressions are pinned by `e2e/grid-measured-width.spec.ts`'s "frozen wider still centres" and "frozen narrower truncates, no bleed" checks. A `cellDecoration` consumer's return renders as this box's CHILD only when the column is flagged `mayShowInlineDecoration` (compute-rule override, follower state, or a row marker — the same three conditions the decoration content itself is keyed on, so a table-field column can never carry an unflagged decoration); for every OTHER column the decoration is the box's SIBLING inside a `flex-col` wrapper (`withStackedDecoration`, `grid-row-cells.tsx`), stacking on a second line instead of silently becoming a flex item beside the value. The one decoration in this batch reachable without the flag is `OptionsGridEditor`'s duplicate-value "alias" mark, which the Schema Builder options editor computes from a column's static `options` array alone.

**One-line header, badge on the title line.** The header's status-badge chip used to render on its OWN row below the label (`GridHeaderRow.tsx`), making every header 20px taller than its body row regardless of the outer wrapper's own flex/grid structure — PR-1's baseline (`offsetHeight` per template, badge-present flagged) proved the second LINE, not the wrapper shape, was the entire cause. The chip now rides the title line: inside the trailing decoration cluster for the ≤5-data-column (left-aligned) branch, and OUTSIDE the >5-column branch's 3-track CSS Grid (a chip inside that grid's trailing track would have its width reserved twice — once by the leading track's mirror, once by the track itself — nearly doubling a badge column's floor purely on the badge). Both branches now share the same `min-h-[1.75rem]` title-line box the body's `CellValueBox` renders through, so header row height equals body row height on every template, badge or not.

**Arrowless, centred row-number gutter.** The gutter (`GridBody.tsx`, both the plain and reorderable row paths) dropped its fixed-width `→` arrow slot; the row number now centres on `justify-center` inside a `px-[var(--grid-cell-inset)]` cell carrying the same `data-grid-measure="gutter"` read every other column gets, so gutter width tracks the widest actual row number instead of a hand-picked constant plus arrow-slot allowance.

**Known cost, not fixed this batch: a generic `cellDecoration` that only appears later, by data, on a column not flagged `mayShowInlineDecoration`.** A column's floor is measured once, at mount/content-shape-change time; if a consumer's `cellDecoration` starts returning non-null for a row ONLY after some later state change (a value edited into a duplicate, a follower link degrading), and that column was never flagged, the column's floor never reserved room for it — the decoration then either stacks (per the invariant above, correct but a one-time layout JUMP the first time it appears) or, for a flagged column with a data-driven `deco`, the natural-pass measure already reads every row's decoration slot up front so no jump occurs there. Decided (fmb-2057 item 1) NOT to add a column-level `decorationPlaceholder` opt-in for the stacked case: no real consumer in this codebase currently needs one (the census — `AdjustmentsGridView.tsx`, `OverrideGrid.tsx`, `OptionsGridEditor.tsx` — every stacked-decoration site is either static per-render or already flagged), and a speculative opt-in prop with no caller is exactly the kind of unused surface CLAUDE.md's build-lean rule asks not to add. Revisit if a real consumer needs it.

**Ship Gate lints added this batch:** `grid-no-width-constants.sh` (no hand-written width constant survives in the measure path); `grid-cell-content-box.cjs` (no grid-internal cell wrapper reintroduces its own horizontal inset outside the shared token).

**e2e acceptance (`e2e/grid-measured-width.spec.ts`, `k3d` project, PR-Z fmb-2051):** runs against the five synthetic `gmw-` mock templates (`e2e/fixtures/grid-measured-width-seed.ts`, PR-1) on deployed zone-test — header/body row height parity, header/value text-start-x parity, no content-box overflow on the four "fits its own content" templates, gutter centring and arrow-glyph absence, every decoration inside its own cell, `<col>` width covering rendered content, a column frozen wider than its content still centring its value (exercised by `distributeSlack`'s own organic stretch at a wide viewport, no manual drag needed), a manually-narrowed column truncating without bleeding past its frozen width, a stacked decoration on an unflagged column landing on a second line (via the Schema Builder options editor, the only reachable unflagged site), and the badge column not being doubled in width purely by the badge. `scripts/verify/grid-geometry-probe.mjs` (PR-1) is the companion playwright-cli instrument for a manual all-template baseline/regression sweep, `ci=N` only.

### 7.16 `flow_recipes` / `flow_recipe_steps` — Per-Step Body Dialect + CRUD Contract (flow-yaml-dialect epic, fmb-2044/2061/2062)

**Content type and YAML dialect live on the STEP, not the recipe.** `flow_recipe_steps` carries three ENUM columns — `content_type` (`application/json` default | `application/yaml`), `yaml_version` (`1.2` default | `1.1`), `yaml_quoting` (`plain` default | `double` | `single`) — added by PR-Y1 (fmb-2044, `3.2.972`). Each step's Request-tab "Body format" row edits its own three fields; the Preview and Test panes for THAT step always serialise with THAT step's own config (`StepSerializeConfig`, `src/fmb/lib/flow/serialize-options.ts` / BE twin `docker-api/src/shared/lib/serialize-options.js`, function bodies pinned byte-identical by `serialize-options.parity.test.ts`). A brand-new step defaults to the previous step's dialect in the UI's display-only sense (`firstStepConfig`-style seeding); its STORED row still gets the DDL defaults on INSERT unless the author changes them. `DEFAULT_STEP_SERIALIZE_CONFIG` (exported from both twins, PR-YZ Task Z.2a) is the single source for "no per-step config yet" fallbacks (a zero-step recipe's display default, a new step's draft, a persisted step flipped YAML→JSON resetting its `yaml_*` fields to the DDL default) — never hand-copy the literal `'application/json'`/`'1.2'`/`'plain'` triple at a new call site.

**The shared `{{payload}}` seed re-serialises at EACH step, with THAT step's own dialect** (amendment A1, PR-Y1 Task Y1.0) — not once at run-begin and reused. `serializeFlowPayload(payload, stepConfig)` runs inside the per-step loop on every engine that dispatches a chain: the browser real-run (`run-chain.ts`), the authoring-time chain-test (`step-exec.ts`), and the server-orchestrated no-JS path (`docker-api/src/infra/routes/flow-recipe-run.js`). A compute step's `before_code` returning a NEW `payload` value (object or array) becomes the running value for every later step's default fill; an ARRAY-shaped override is a documented pre-existing exception — both engines share the identical `!Array.isArray(v)` carry-forward guard (`run-chain.ts`'s `refreshPayload`, `step-exec.ts`'s own copy, its comment states the two "match"), so an array override does NOT carry forward to a later step, pinned by a parity test on each engine rather than fixed (PR-YZ Task Z.2b, fmb-2062).

**`flow_recipes.content_type` is retired — dropped wherever a supported install does not need it forever.** The recipe-level column (the pre-Y1 shape) is superseded entirely by the step-level trio; PR-Y2 (fmb-2061, `3.2.978`) cut every code reader over to the step columns first, leaving the recipe column zero-read but still present in the DDL. PR-YZ Task Z.0 (fmb-2062, `3.2.981`, amendment A2) then drops it — as a `kind: 'custom'` migration step, not `drop-column`, because the drop is conditional on live schema state a structural kind cannot express: `flow_recipes_content_type_drop`'s `probe()` is satisfied (nothing to do, not failed) when EITHER the column is already gone, OR any of the three step columns is itself absent — that second case is a supported PERMANENTLY no-ALTER install (fmb-1329 Q9), not just a mid-rollout gap, and on it the recipe column stays forever by design.

**The no-ALTER legacy tier (Y2.6c ruling, fmb-2061 third fix round): on an install missing the step columns, `flow_recipes.content_type` is the dialect of EVERY step of that recipe** (`yaml_version` 1.2 / `yaml_quoting` plain — the only dialect that existed before per-step dialects did), read via a tier-index callback on the same `selectWithLegacyFallback`/`selectFirstOk` helpers every other additive-column reader in this codebase already uses (`flow-recipes-run.js` run-begin, `flow-recipes/io.js` export). The migrated (full-tier) path never reads the recipe column — zero-read holds exactly as PR-Y2 intended; the fallback fires ONLY on the tier that also lacks the step columns, which cannot coexist with PR-YZ's drop having already run there (the drop's own precondition requires the step columns to exist first). Import onto a no-ALTER target follows the same rule in reverse: a UNIFORM bundle (every step resolving to the same `content_type`) stamps the ONE legacy column; a bundle mixing dialects is refused `409 DIALECT_COLUMNS_UNAVAILABLE` before any row exists, rather than silently recasting some steps' format. **Documented accept (PR-YZ Task Z.2c, fmb-2062):** because the legacy column carries `content_type` only, a uniform bundle authored at a non-default `yaml_version`/`yaml_quoting` (e.g. `1.1`/`double`) COLLAPSES to the implicit `1.2`/`plain` dialect on a no-ALTER target — there is nowhere on that schema to remember the other two fields. A server-side `log.warn` (pathname-only, names the recipe id) fires on that collapse; `flow-yaml-dialect-no-alter-db.test.js` pins the exact collapsed bytes against a real scratch DB.

### 7.17 `EditableDataGrid` — Showcase Surface + Gutter Max-Number Sample + State-Decoration Signature (grid-showcase-and-header epic, fmb-2076–2084, v3.2.983–995)

**DEVIATION FROM THE PLAN TEXT (recorded, not silent, mirroring §7.15's own §7.7 note): the plan named this section "SDD §7.16+" — §7.16 is already taken (the `flow_recipes` dialect section above). This is §7.17, the next free subsection.**

**One standing measuring surface, not a scattered set of one-off mocks.** The five separate synthetic `gmw-` templates §7.15 measured against are retired; every later fix in this engine (and every future one) measures against ONE blueprint, "Shared Table Showcase" — seven table fields, one discriminating axis each (`T1-left`/`T2-wide`/`T3-deco`/`T4-types`/`T5-extreme`/`T6-paged`/`T7-cap`, `e2e/fixtures/grid-measured-width-seed.ts`). A single idempotent command upserts the ONE standing copy by exact name (`seedShowcaseStanding` — `GET`, exact-name match, `PUT` in place, never a prefix purge, because `owner_id` is `immutableColumns` on `user_templates` and a mismatched owner needs a dedicated `PATCH .../owner` transfer, re-`GET`-verified); the e2e acceptance suite (`e2e/grid-showcase.spec.ts`, `k3d` project) seeds and purges its OWN run-id-suffixed copy instead, so a parallel run or the standing measuring copy can never collide.

**The gutter column is sized from the largest row number this table can ever show, not from whatever page happens to be painted.** `GridBody.tsx`'s `gutterMaxSampleFoot` renders a HIDDEN `[data-gutter-sample]` cell holding the widest possible row-number glyph (`rows.length`'s own digit count) in the same natural measuring pass every other column goes through — `measureColumnBoxWidths` reads that sample, not the currently-painted page's own row numbers, so a table showing page 1 of a 500-row table still reserves 3-digit gutter width from the very first mount, and paging forward never re-triggers a gutter-width jump. `--grid-cell-inset` is added twice, `Math.ceil`'d, same as every other column floor.

**A per-cell STATE decoration (a data-driven lock, not a static column flag) re-measures just that ONE column, not the whole table.** The natural width pass runs once at mount/content-shape-change; a lock icon that appears later because of a row's OWN data (not a static per-column flag) never widened that column's floor before this batch, silently letting the locked value's text run past its own content box (`text right > content right`, an invisible ellipsis-equivalent bleed). `column-signature.ts`'s per-column state-decoration signature (a string keyed on which rows in that column currently carry a lock/other data-driven decoration) changes exactly when that set changes; `EditableDataGrid.tsx`'s memo diffs it and triggers `useColumnWidths.ts`'s single-column re-measure for the changed column(s) only — never a full-table re-measure for a per-row data change.

**Reserved-slot rule, uniform across the header and the cell (Q8, superseding grid-measured-width Q8's "overlay the icon on the cell padding"): every affordance is ALWAYS in the DOM, in a real box the natural pass counts, split by whether it carries STATE or is pure ACTION.** A revert-to-formula triangle (the only per-cell signal that a value diverges from its own compute rule) is visible AT REST — it is state. The override pencil (pure affordance, no state on a non-overridden cell) is `opacity-0` at rest and reveals on hover/`focus-visible`/the column's own `data-selected-col` state; both share the SAME reserved `h-3 w-3` box either way, so revealing costs 0px reflow by construction, both carry `data-cell-action-slot` (the reveal hook and the `grid-cell-action-slot` ship-gate lint's structural anchor). The header generalises the same rule to its own trailing action group (filter trigger, column-select arrow): always in the DOM with reserved width, transparent at rest, revealed the same way, never covering the label. On a CENTRED (>5-column) branch, a hidden action slot is mirrored on BOTH sides of the value/label so the VISIBLE content still centres on the true cell/header centre — the mirror is a FIXED spacer gated on a static per-column `actionSlot` flag (never a clone of a data-driven `cellDecoration` return; a follower/lookup marker is visible STATE, not a hidden action, and must never be mirrored).

**One title-line header structure for both alignment branches (Q6/Q9).** The left (≤5 data columns) and centred (>5) branches share the identical three-track grid (leading | label+descriptors | actions) and the identical vertical-centre token (`items-center` on both, no `align-top` on the `<th>`) — they differ ONLY in `grid-template-columns`/`justify` values, never in element structure. Label + descriptors (state: status-badge chip, api-role icons, help icon, sort arrow) are NEVER truncated and fully counted in the header floor — the badge chip's old `max-w-[7rem] truncate` cap is REMOVED (supersedes grid-measured-width Q1). On the centred branch, descriptors ride WITH the actions in the mirrored trailing group (not beside the label) so the label track holds the label alone and sits on the `<th>`'s TRUE centre; the accepted cost is a centred badge column's header floor = label + 2×(descriptors + actions) — double-reserved by design, the trade every mainstream grid makes for an uncapped, always-centred label. The header/body 0.5px height residual (Q10) is fixed to 0 with one shared row-line token (`--grid-row-line`) used by both the `<th>` and the `<td>`.

**e2e acceptance (`e2e/grid-showcase.spec.ts`, `k3d` project, PR-Z fmb-2084):** runs against the standing showcase's seven tables on deployed zone-test, both 1600×900 and 900×1440 — header/body band-height and vertical-centre parity on every table; text-start-x parity (T1-left) and visible-centre parity with descriptors+actions counted (T2-wide); no ellipsis on a locked value and an untruncated badge header (T3-deco); numeric right-alignment with tabular digits and no chip overflow (T4-types); no `aria-label=""`, an em-dash placeholder on an empty value, a truncating long value and a fitting single-character column (T5-extreme); gutter glyph centring and zero-or-safe-slack sizing after paginating to the 3-digit last page (T6-paged) and at the 500-row cap (T7-cap); 0px reflow on an action-slot reveal (T3-deco, fmb-2079 — see below). Also folds the three Chromium-only regressions unique to the retired `e2e/grid-measured-width.spec.ts` (fmb-2057 item 4): a column frozen wider than its content still centring its value, a manually-narrowed column truncating without bleed, and a stacked decoration on an unflagged column (the Schema Builder options-editor "alias" mark) landing on a second line. `scripts/verify/grid-geometry-probe.mjs`'s `collectGridGeometry` (PR-1, extended through PR-4) is reused directly by the e2e suite (not re-implemented) for the engine-authoritative fields; a spec-local collector covers the content-overflow/decoration-containment/header-truncation family the probe was never asked to carry.

**fmb-2079 closed — corrected root cause, no probe code change.** The card's premise ("no unlocked/overridable compute column exists on the showcase, so the action-reveal fields read null") was false: `T3-deco` ci=0 is `computeRule: true` with `overridable: true` and never `lockedAllRows`, so the override pencil DOES render. The observed null reads were `TableFieldRenderer`'s `disabled` prop, which zeroes EVERY compute decoration (pencil AND revert triangle, unconditionally) when the viewing session does not own the template — a blanket read-only-viewer behaviour, not a per-cell or per-resolver defect. Measured directly against an owner-of-record session (exactly what the e2e suite's own `seedShowcase(page, adminId, { runId })` always produces), the existing probe resolver already returns non-null reveal/rest pairs with 0px reflow.

### 7.18 Flow Recipes — Create/Update/Compare (flow-recipes-batch epic 3, fmb-2090–2102, v3.2.998–3.3.14)

**One recipe both creates and later updates the same remote workflow.** `user_templates.flow_remote_refs` (JSON, nullable) caches sub-item ids an update needs to re-address deep tasks — written ONLY by run-finalize, behind a plain-object + 64 KB guard (a value failing either degrades to "nothing stored", never a hard failure of a dispatch already made), and is on the server-only column list every write mount enforces so a plain CRUD PUT cannot bypass the guard and re-seed it (fmb-2090 review: a reserved-key column needs the server-only list on EVERY write mount). `reset-flow-link` clears it alongside `flow_external_id`/`flow_last_run_id`. **Push mode** — whether the next dispatch is a create or an update — is decided from ONE durable signal, `flow_last_run_id` (stamped on every successful run); `flow_external_id` is deliberately NOT part of the signal because a successful update can return 204 and leave it null. The predicate is `docker-api/src/shared/lib/flow-push-mode.js`'s `modeFromLastRunId`, a byte-for-byte logic twin of `src/fmb/lib/flow/push-mode.ts`'s `flowModeFromLastRunId` (parity test imports both real modules — never a regex over the route's source text, which is brittle to a harmless refactor).

**Step-level `runs_on`** (`flow_recipe_steps.step_runs_on`, ENUM `create`/`update`/`both`/`compare`, default `both`) lets one recipe skip a step per mode; a `compare` step runs ONLY in the read-only compare pass and must dispatch GET. The recipe's own `runs_on` (ENUM `create`/`update`/`both`) narrows which modes the WHOLE recipe answers at all. `selectStepsForMode`/`stepRunsInMode`/`stepDivergesFromRecipe` (`docker-api/src/shared/lib/flow-step-select.js`, FE twin `src/fmb/lib/flow/step-select.ts`) are the one filter both the real run and the chain test use, so a step excluded from a mode is excluded identically everywhere.

**`assertStepInvariants`** (`docker-api/src/shared/lib/flow-step-invariants.js`, FE twin `src/fmb/lib/flow/step-invariants.ts`) is the ONE write primitive for every invariant a step/recipe write must satisfy — not a copy per route. I1: a `compare` step must be GET (`compute` exempt, no dispatch). I2: a step's own `step_runs_on` must never diverge from a non-`both` recipe's `runs_on` (`FLOW_STEP_MODE_CONFLICT`); this is enforced pre-transaction (friendly 400) AND re-checked inside the write transaction on the recipe row locked `FOR UPDATE` (the pre-tx read can go stale under a concurrent write). I3 (fmb-2102, PR-CZ): the three JSON-column shapes below. Every caller — the step CRUD mount, the recipe CRUD mount (reverse narrow-gate), and the raw-SQL import path — resolves the EFFECTIVE row and asks this one function; an unrecognised `step_runs_on`/`runs_on` value fails closed (`FLOW_STEP_TRIGGER_INVALID`/`FLOW_RECIPE_MODE_INVALID`), never coerces to the more-permissive `both`.

**JSON-column shape validation (I3, fmb-2102) — no column had one before this PR.** `flow_recipe_steps.preset_config` (`{ kind:'merge_by_key', rules: [{ itemsPath, matchField, refsSource, writeField }] }`), `flow_recipes.compare_spec` (`{ localPath, remotePath }`, both non-empty strings), and `flow_recipes.link_extract` (a bare string, the legacy untagged `{ path }`, `{ kind:'path', path }`, or `{ kind:'template', template }`) are validated inside `assertStepInvariants` with an EXACT-key-set rule (no extra keys, unlike the tolerant readers downstream that rebuild a value from its known fields for an already-stored row) — a violation fails the write closed with a 400 in the existing error-code family (`FLOW_PRESET_CONFIG_INVALID`/`FLOW_COMPARE_SPEC_INVALID`/`FLOW_LINK_EXTRACT_INVALID`). Applied identically to create, update (CRUD mounts) and import (`flow-recipes/io.js`'s raw-SQL create) — a guard on one write path of a several-path write is a defect. `external_id_extract` (the same union type as `link_extract`) is explicitly OUT of this validation's scope (unchanged degrade-to-null behaviour on import) — a deliberate scope line, not an oversight, because widening it is a separate change with its own site census.

**Reserved output keys** `payload` / `remote_refs` / `external_id` / `link` (`src/fmb/lib/flow/reserved-keys.ts`'s `RESERVED_CTX_KEYS`, one constant shared with `run-chain.ts` and the Merge-by-key codegen) are the chain-plumbing vocabulary a step's before/after JS may set to influence the running context; `remote_refs` in particular is captured by a "Capture ids" generated after-JS from an array response node and shown under the step's existing "Outputs" heading (not a separate "Added to context" label — the plan draft's wording, corrected in PR-CZ).

**Compare pass** (`POST /edge/internal/flow-recipes/:id/compare-begin`, GET-only, nothing persisted) returns the compare-branch-only steps plus a purpose-tagged, 5-minute-lived HMAC **compare token** bound to `(templateId, recipeId, userId)` — a short-lived credential, not the client-supplied `run_id` a real run uses. `/prepare` (the per-step dispatch endpoint, `flow-steps.js`) accepts the token in place of `run_id`, re-verifies it (signature/expiry/binding — never trusts a client-supplied claim), builds the server-RESOLVED template bag from the token's own template id (so a `{{context.template.*}}` compare GET fills exactly as a real run would), and re-applies the GET-only guard at DISPATCH time through the SAME `stepRunsInMode(step.step_runs_on, 'compare')` predicate compare-begin's own step list used to pick candidates — closing the family (a compare token may dispatch only a step compare-begin itself would have offered, not merely "any GET"). A pending/success compare skips the `flow_audit` write entirely (nothing persisted is the contract, both storage AND audit); a failed/blocked compare KEEPS its audit row, same as a real dispatch, so a blocked egress attempt is still visible to an operator reviewing the trail. **Why a server-signed token replaced client context:** the first design threaded the client's own `context`/`outputs` through to `/prepare` with `run_id: null`; that meant NO server-authoritative template bag existed for a compare-branch step referencing `{{context.template.*}}` (every such GET failed `MISSING_INPUT`, blocking every update for that recipe) and, separately, let a caller who could reach `/prepare` at all point it at ANY of the recipe's GET steps by construction, not only the compare-branch ones. Minting a server-side token at compare-begin (where the SAME access predicate run-begin uses already ran) closes both: the token IS the authorization, and it can only ever resolve to the template/recipe pair it was minted for.

**Blueprint parity (fmb-2102, PR-CZ).** `callerHasTemplateAccess` (delegated-grants.js) answers "may this caller touch this template" — ownership or a delegated grant on the TEMPLATE's own blueprint — which is a DIFFERENT question from "was this recipe authored for this template's blueprint", and neither access arm compares the two ids. `checkRecipeMatchesTemplateBlueprint` (one shared predicate in `flow-recipes-run.js`, used identically by `run-begin` and `compare-begin`) closes the gap: `sameId(tmplRow.blueprint_id, recipe.blueprint_id)` — collation-safe (trim + lowercase, `shared/lib/same-id.js`), not `===`, since CHAR(36) ids collate case-insensitively and a re-imported id can differ in case from the one this recipe was bound to — checked only once template access is already confirmed (so a caller with no access at all still sees only the existence-neutral `TEMPLATE_FORBIDDEN`, never a blueprint-mismatch signal) — a mismatch is a `409 FLOW_BLUEPRINT_MISMATCH`, checked ahead of the admin bypass too, because it is a correctness fault (the recipe's field-extraction paths are authored against a different blueprint's field names) rather than an access question an administrator should be able to wave through. `user_templates.blueprint_id` is nullable, so a record saved before any blueprint was picked still fails closed with the same `409 FLOW_BLUEPRINT_MISMATCH` code (a blueprint-bound recipe cannot build a payload from a record naming no blueprint) but with its own message, "Record has no blueprint; recipe is bound to one", so an operator does not read a null record as a mismatched one. The early read is not the last word: `run-begin`'s conditional INSERT ANDs `blueprint_id = ?` onto its permission gate for BOTH the owner/grant arm and the admin arm, so a template reparented between the read and the write still writes no row; a 0-row gated insert is answered `403 TEMPLATE_FORBIDDEN` — existence-neutral, regardless of which reason the gate refused for (reparented blueprint, ownership/grant revoked, or the row gone outright) — because the pre-insert parity read above is the only source of the `409 FLOW_BLUEPRINT_MISMATCH` reason; a second read at refusal time would race against the same window the gate just closed.

**Build-flow modal status header's "Last write" line approximates a run timestamp from `updated_at`, not a dedicated column (fmb-2102, PR-CZ, documented not fixed).** There is no `flow_last_run_at` (or similar) column on `user_templates` — `useFlowLinkStatus`'s `lastRunAt` reads the template row's own `updated_at`, which advances on ANY write to the row (a plain field edit with no build included), so `BuildFlowStatusHeader` labels it "Last write" rather than "Last run" and its tooltip states the caveat verbatim ("Last write to this record; a save without a build also updates it") — the UI is already honest about the approximation. A dedicated last-dispatch timestamp column is a schema change out of scope for this PR; re-carded for a future PR to decide whether the added precision is worth an additive column.

**Deferred to a future card (fmb-2102, PR-CZ): a row-scoped array picker for Merge-by-key's rules table**, instead of the shared response-tree data panel every picker round so far has reused — recorded as a design candidate after three picker-defect rounds on the shared panel (PR-C3 confirm r1/r2/r3), not built here.

**`text-warning-strong` on `bg-muted/20` clears AA once the real host is used (fmb-2102, PR-CZ, measured not fixed).** PR-C3's design pass flagged the Merge-by-key rules panel's "N matched / M unmatched" stats line (`MergeByKeyEditor.tsx`) at 4.75:1 in light mode without naming the composited stack; the wash sits directly on `<body>`'s `bg-background` (StepEditorWorkbench's own wrapper carries no `bg-*` class), NOT on `--card` — measured explicitly (`MergeByKeyEditor.contrast.test.ts`, same parse-from-source + HSL/alpha-composite arithmetic `step-trace-card-outcome-contrast.test.ts` uses): light 4.753:1, dark 10.666:1, both clearing the 4.5:1 AA floor. No token change (commander ruling: ≥4.5 both themes → record and leave it).

---

## 8. Data Design

### 8.1 Schema Management

- **DDL builders**: `buildInfraTableDDLs()` (Platform tables) and `buildEngineTableDDLs()` (Engine tables).
- **`runSchemaMigrations()`**: automatically adds missing columns on boot (additive only). Non-additive changes (DROP COLUMN, etc.) require a DBA migration.
- **Schema version visibility**: `GET /api/platform/schema/status` (admin-only, `docker-api/src/edge/routes/platform/schema-status.js`) — live-derived, not cached, ~3 indexed queries at <5 ms each. Returns `{ schema_status, skipped_steps[], target_version, current_version, derived_at }`. On any derive failure, degrades to `schema_status: 'unknown'` + HTTP 200 — **never 5xx**. Each query has a 3 s hard timeout; on timeout the connection is treated as poisoned and destroyed via `conn.destroy()`. Full design: `docs/RFC/visibility-surface.md`.
  - **Version card**: The General Settings version card shows program + schema version (stamp-sourced for alignment status) and exposes a `recheck()` button (audited `source:ui`) that re-reads the endpoint without re-running migrations; pending migration steps display as a bulleted list when status is not `Aligned`.

### 8.2 RW / RO Split

All DB access uses the `pool.rw.*` / `pool.ro.*` namespace. The `pool.getConnection()` and `pool.query()` shims are forbidden (enforced by Ship Gate Step 5). Canonical environment variables: `DB_RW_*` (writer) and `DB_RO_*` (optional read-replica; omit to route reads through the writer). See `LEARN.md §60`.

### 8.3 Nullable Y-Pattern (API Boundary Normalization)

Backend serializer: `docker-api/src/shared/serializers/normalize-nullable.js`.

- Nullable `string` column → coerced to `''` at the API boundary.
- Nullable `number` column → coerced to `0` (or a specified default).
- TypeScript interfaces stay non-nullable; no `| null` in TS types for these fields.
- Truly inheritance-semantic columns (e.g., `parent_id`, `order_index`) are explicitly typed `T | null`.

In ONPREM/AIRGAP operator mode, `ALTER TABLE` may fail with error 1142 (insufficient privileges). The API serializer is the runtime safety net; the DBA must run the migration manually for full schema alignment.

### 8.4 Encryption

- `auth_config` secrets (`token`, `value`, `password` sub-fields) in `api_connectors`: AES-256-GCM field-level encryption via the `settings-crypto` module. API responses replace all secret values with `****`.
- `system_settings` sensitive values (e.g., `clientSecret`): same AES-256-GCM + `SETTINGS_ENCRYPTION_KEY` env variable. API responses use `****` masking.

### 8.5 Pool-State Visibility Surface

Both `/health` and `/edge/health` return a sanitised `pool` block:

```
pool: {
  pool_state,        // 'configured' | 'setup-required' | 'degraded'
  hint_code,         // env_missing | config_mismatch | connection_refused | grants_insufficient | unknown | null
  env_keys_present,
  db_config_json_present,
  table_prefix_set,
  last_configure_error
}
```

HTTP status is always 200 — body degrades, status does not — because the setup wizard needs this route reachable even when the pool is null. Sanitisation is enforced by `docker-api/src/shared/lib/pool-diagnostic.js` (allowlist: `code/errno/sqlState` only; `err.message` and raw env values are never included in the response body). Full design: `LEARN.md §79`.

### 8.6 Hidden-Field Value Retention

A field hidden by its visibility rule (condition unmet) or a variant `hide` override has its value **discarded** by default — `selectVisibleValues` (`src/fmb/lib/visible-values.ts`) subtracts every `isHidden` field at the single value-consumer boundary (save payload / generated output / connector reads). This is the v3.2.297 leak fix.

Per-field opt-out: `blueprint_fields.retain_when_hidden` (BOOLEAN, default false). When set, the field's value is **retained** — kept in the saved payload AND flowed to output/connectors even while hidden — via the one selector predicate `isHidden && !retainWhenHidden`. It is an explicit, designer-set, labeled toggle (Field Editor when a visibility rule exists; Variant Policy for any override action — both write the same field-level column), so the default-discard safety property is preserved unless a human names a specific field. Design rationale: `LEARN.md §124`.

### 8.7 Connector Egress Allow-list

A global security boundary (admin-owned) constraining which external **host + method + path** a connector may call. Stored in `system_settings.connector_host_allowlist`; an empty/absent list = opt-in allow-all (enforcement starts at the first entry, so existing connectors are never broken).

Value shape: `[{ hosts: string | string[], rules: [{ method: string[], path: string[] }] }]`. Host = exact or `*.sub` wildcard (reuses the host-allowlist matcher). Method = uppercase list or `"*"` (any). Path = glob list via **picomatch** (pinned `4.0.4`, FE + BE identical): `*` matches one segment, `**` any depth. A request is allowed only when some entry's host matches AND that entry has a rule whose method AND path both match.

Before matching, the request path is **normalized + traversal-hardened** (`egress-policy.js` / `egress-policy.ts`, byte-compatible): WHATWG-URL parse (clamps `..` at root) → reject raw `%2f`/`%5c` encoded slashes → decode once → resolve dot-segments → collapse duplicate/trailing slashes. An unparseable URL or a `..` escaping root is blocked. The shared gate `egressAllowedForUrl` enforces at dispatch, save, import and clone, returning `EGRESS_BLOCKED` (422) with a `reason` (`host`/`method`/`path`/`normalize`).

Back-compat: a legacy host-only string array is read as "this host, any method, any path" and rewritten to the structured shape on the next admin save (no migration, no enforcement window). A corrupt stored value fails **closed** (500). Design rationale: `LEARN.md §125`; full spec `docs/superpowers/specs/2026-06-24-connector-egress-and-approval-design.md`.

**This allow-list is the SINGLE outbound host control.** The former per-entity allowlists (`api_connectors.allowed_hosts`, `flow_recipe_steps.allowed_hosts`) are deprecated and unenforced: the editor fields, JSON projections, `/prepare` payload keys and the execution-time check were removed. The columns (and any stored values) remain but are never read at dispatch. The unconditional SSRF guard (blocked-IP classifier + DNS-pinning lookup in `executeRequest`) is independent of both and unchanged. Connector `response_config.transformer_id` is likewise soft-deprecated in the same cleanup: a stored id still executes and shows read-only on the detail page, but the editor no longer offers the input — declarative `outputs[]` are the supported response mapping.

### 8.8 Checkbox Multi-Select Field (`choice_config`)

The `checkbox` field type is a **multi-select group**, not a boolean. Its options **reuse the `field_options` table** (same editor as `select`); its per-field selection limits live in the additive JSON column `blueprint_fields.choice_config` = `{ minSelected?, maxSelected? }` (mirrors `table_config`; NULL for every other field type). `is_required` supplies the "at least one" floor, so an unset `minSelected` with `is_required` still enforces min 1.

**Value contract.** The form pipeline is string-typed, so a checkbox value is a **JSON-stringified array of option values** in the string channel and in `user_templates.payload` (`payload[key] = '["r","b"]'`) — identical to how a `table` field is stored. It is parsed to a real `string[]` only at the consumer boundary:
- **Transformer** — `build-transformer-payload` treats checkbox as a third value class beside scalar/table: the array is placed under `payload.form.<key>` (a real array, not a JSON blob).
- **Visibility** — `evaluateVisibility` is checkbox-aware when the **subject** field is a checkbox (selected set `S`, rule value `v`): `contains v` → `v ∈ S`; `eq v` → `S == {v}`; `neq v` → `S != {v}`; `in [a,b,…]` → `S ∩ {a,b,…} ≠ ∅`. A scalar subject keeps string-compare semantics. `VisibilityRule.operator` gains `'contains'`.
- **Connector mapping** — `deriveConnectorValues(visibleValues, fields)` builds the connector-facing values map with checkbox selections comma-joined (`"r, b"`), **type-driven** by `field_type === 'checkbox'`. Substituted at the single hand-off in `FmbInput` (the five `currentValues` props), it covers request-input resolution, fetch fingerprints, merged-review diffs and readiness/chain gating uniformly; save/transformer/compute keep the raw map.

**Uniqueness.** `option_value` is unique **within a checkbox field** (the value is the identity in the saved array) — enforced design-time in the editor **and** rejected by the `field_options/replace` API (`DUPLICATE_OPTION_VALUE`); it is **not** a DB unique key, because `field_options` is shared with `select`, which permits duplicate-value aliases.

**Additive-column tolerance.** `choice_config` follows the `depends_on_field_key` / `retain_when_hidden` playbook: a guarded `ALTER ADD COLUMN` migration (operator-mode `1142` → warn-skip), `information_schema` write-gate tolerance so a pre-migration DB drops the column instead of `1054`-crashing (the type-change `NULL`-clear is column-gated too), plus dto-mapper `json`, CRUD `jsonColumns`, a payload-consistency guard, sync-schema, export/serialization/fingerprint, and a drift-registry entry. Design rationale (JSON-column-over-dedicated-column): `LEARN.md §149`; spec `docs/superpowers/specs/2026-07-02-list-ux-pr4-checkbox-multiselect.md`.

### 8.9 Data-Entry Color Groups (Identity Lanes)

A **group** is a blueprint-scoped, design-time identity lane — a structural clone of `blueprint_sections` — stored in the `blueprint_groups` engine table (`group_key`, `display_label`, `color_key`, `sort_order`). Groups are shared across all sections of a blueprint: the same lanes (e.g. `prod` / `preprod` / `standby`) keep an identical color and order everywhere they appear. A field opts into a lane via the additive `blueprint_fields.group_key` (nullable VARCHAR) — a key reference into `blueprint_groups.group_key`, mirroring exactly how `blueprint_fields.section` references `blueprint_sections.section_key` (no FK id, so it round-trips through export/import/sync without remapping). `group_key = NULL` is ungrouped and always renders normally.

**Layout modes.** The additive `blueprint_sections.layout_mode` (nullable VARCHAR) selects a section's rendering:

| `layout_mode` | Meaning |
|---|---|
| `NULL` / `''` | Stacked — today's flat field grid (default; unaffected by groups). |
| `group-cards` | Per-section tinted parallel cards, one card per group. |
| `matrix` | Per-section parameter-row × group-column table with copy actions. |

Activation is implicit — a section only renders a group-aware layout when its `layout_mode` is non-default; there is no separate feature flag. `color_key` is a stable palette key string (not a numeric index), indexing into a literal Tailwind class array (`GROUP_PALETTE`, purge-safe, same pattern as `SECTION_PALETTE`) so a lane keeps its color across group reorders.

**Additive-column tolerance.** Both `blueprint_groups` and the two new columns follow the same guarded-`ALTER`/`information_schema`-tolerance playbook as §8.8: an operator-mode DB that cannot `ALTER` (error 1142) degrades to "no groups" — sections render stacked, fields render ungrouped — instead of crashing.

**Invariant: group metadata never enters the payload.** `group_key`, `layout_mode`, and `blueprint_groups` rows are design-time-only structural metadata, exactly like `section` and `blueprint_sections`. They select how a field is *presented*; they are never written to `user_templates.payload`, never read by the transformer/connector/visibility pipelines, and never serialized into a generated output. A group-cards or matrix layout is a pure rendering of the already-resolved field set — variant lock/hide/autofill/compute overrides are unchanged and unaware of groups.

### 8.10 Field Options — Trimmed-Non-Empty Write Guard

A `field_options` row (`option_label`, `option_value`) that trims to empty can never render as a selectable item (`select`/`checkbox`) and is exactly what gates `connector-ready.ts` off. Three write paths bypass the main-UI `saveAll` guard and are gated individually, each modeled on an existing in-file precedent so no new machinery is introduced:

- **Blueprint clone** (`src/fmb/lib/clone-blueprint.ts`) — the options-copy block filters out any source row whose label or value trims to empty before calling `schemaCreate('field_options', ...)`.
- **Generic CRUD write** (`createCrudRoutes`, `docker-api/src/edge/routes/app/schema.js`) — a present-only `trimmedNonEmptyColumns` validator (mirroring the existing `slugColumns` gate) rejects a POST/PUT whose *present* `option_label`/`option_value` trims to empty with `400 EMPTY_NOT_ALLOWED`. A column omitted from the body (partial PUT) is not validated — mirrors `slugColumns` exactly.
- **`/field_options/replace` bulk optimistic-lock write** — `isValidStr` now requires `v.trim().length > 0`, so a whitespace-only label/value fails the existing `expected`/`next` items malformed check (both arrays are gated by the same validator) and returns the existing `400 BAD_REQUEST` (no new error code).
- **Environment sync** (`docker-api/src/edge/routes/app/sync-schema.js`, `syncData`) — a dirty `field_options` row (empty/whitespace-only label or value) is skipped rather than failing the whole sync; the per-table result becomes `{ upserted, skipped, total }` for every table (`skipped` is `0` outside `field_options`).

Guard at write time; tolerate legacy rows at read time — no behavior change for rows written before this guard existed.

**Known residual.** The raw-SQL `POST /import-sql` route (`docker-api/src/edge/routes/app/sync-schema.js`) executes operator-supplied SQL and by design bypasses every app-layer validator, including this guard — an accepted known-residual (design spec §9, `docs/superpowers/specs/2026-07-05-schema-builder-ui-refactor-design.md`), not a miss.

**Stale-data compensating control.** A read-only inventory query enumerates every pre-existing dirty `field_options` row (blast radius before any deletion), and a ready-to-adopt cleanup migration is drafted — modeled on the `blueprint_groups` dedup precedent (`db.js:1587-1678`): a `tableExistsInCurrentSchema` gate, a sampled-id audit before a transactional DELETE of still-empty rows, and a `failure_policy: 'recover'` / `severity: 'warning'` `migrations-registry.js` entry. Both are documented as a **proposal** in `docs/superpowers/plans/2026-07-05-schema-builder-pr1-empty-option-guard.md` Appendix A — **not shipped in this PR, not auto-applied by boot, no `PLATFORM_SCHEMA_VERSION` bump**. Adoption is a separate, data-affecting PR.

### 8.11 Output Order Save Chain — Presentation-Only Restyle (PR2)

`OutputOrderPanel`'s optimistic-lock chained-`expected` save chain (`persistOrder` / `debouncedPersist` / `savePromiseRef` / `lastCommittedRef` / `serverSnapshotRef`, shipped v3.2.430) is preserved byte-identical through the Schema Builder PR2 layout shell. PR2 changes only the item-render presentation (list → numbered chip-card grid) and the drag strategy (`verticalListSortingStrategy` → `rectSortingStrategy`) — no data-path change.

### 8.12 Capacity Planner Tables (`cap_*`, 19)

App-tier tables backing the Capacity Planner module (§7.10). Base names registered in the `TABLES` registry and referenced via `t(TABLES.X)` (never a hardcoded prefix). Scenario-scoped tables are self-contained per scenario; several are dual-mode (global catalogue rows with `scenario_id IS NULL` alongside scenario-local rows); **every derived number is computed, never stored**.

**The 19 tables:** `cap_scenarios` (ownership + scoping root), `cap_sites`, `cap_hardware_specs` (dual-mode — now a **global catalogue**, no longer per-scenario only), `cap_disk_combos` (dual-mode, new), `cap_teams` (dual-mode, new — name + color only, no member lists), `cap_hypervisors`, `cap_databases` (new first-class entity: `function_name`/`topology`/`node_count`/`profile_id`/`disk_combo_id`/`team_id`; structural cluster membership derives from its instances' `(database_id, role)`, never a stored key), `cap_vms` (`vm_type` = `db_host` | `ap_host`; `hypervisor_id` NULL = unplaced; own `team_id` independent of any instance's database team; `database_id` is a non-normative display hint), `cap_db_instances` (child of a `db_host` VM only; `role` primary/standby, `database_id`, `sga_gb`; `cluster_key` DROPPED — see `cap_databases`), `cap_custom_groups` (new, scenario-level named group, optional `team_id`), `cap_custom_group_members` (new; exactly one of `member_vm_id` / `member_instance_id`, app-layer enforced, no DB constraint), `cap_bundles` / `cap_bundle_items` (new, global-config bundle templates for the setup wizard — **not** scenario-scoped, **not** part of the scenario snapshot/import content set below), `cap_rules` (six-keeper `type` enum, `level`/`group_by`/`custom_group_id`/`overrides_rule_id`, `UNIQUE(scenario_id, overrides_rule_id)`), `cap_vm_profiles` (merged entity — `cap_sizing_tiers` **DROPPED**, folded in as `class`/`mode`/`sga_cap_gb`/`allowed_disk_combos`), `cap_field_defs` (global-only, `scenario_id` always NULL now; `entity_type` gains `database`, `+required`/`+default_value`, `order_index` dropped), `cap_settings` (dual-mode; `sga_mem_factor`/`sga_fixed_subtract` renamed `sga_factor`/`sga_subtract`, `+sga_divisor`), `cap_versions`, `cap_waivers` (unchanged structurally; UI label "Exception"). Column detail: config-rewrite spec §17.1 (mirrors `table-ddls.js` exactly).

**Three orthogonal layers over these tables:**
- **Global catalogue layer** — `scenario_id IS NULL` rows in `cap_hardware_specs` / `cap_disk_combos` / `cap_teams` / `cap_vm_profiles` / `cap_field_defs` / `cap_settings` / `cap_rules` (7 tables) plus the never-scenario-scoped `cap_bundles` / `cap_bundle_items` (2 tables) — **9 tables total**, exported whole by `GET /config/export`. A new scenario **copies none of this** (reference model, R1 — supersedes the old deep-copy-on-create template layer that seeded a 5-table subset into every new scenario); its working state merges these global rows with its own `scenario_id = :id` rows at read time. Edited via the `config/*` mount (admin + editor).
- **Scenario content layer** — the **14 `SNAPSHOT_TABLES`**: `hardware_specs, disk_combos, teams, vm_profiles, settings, rules, sites, hypervisors, databases, vms, db_instances, custom_groups, custom_group_members, waivers`. This single list is both the version-freeze snapshot content AND the import/export replace-all scope (`buildScenarioSnapshotDoc` builds both). Excludes `cap_scenarios` (the root, not content), `cap_versions` (history, never nests), `cap_field_defs` (global-only, no scenario rows), and `cap_bundles`/`cap_bundle_items` (not scenario-scoped).
- **Snapshot layer** — `cap_versions.snapshot` holds a server-computed immutable deep copy (`{schema_rev, tables:{…}}`, the 14 `SNAPSHOT_TABLES` plus the FK-reachable closure of referenced global-catalogue rows — `CATALOGUE_CLOSURE`: hardware_specs, vm_profiles, disk_combos, teams) at freeze time, so a frozen/exported doc is self-contained. Never mutated; restore = clone (§7.10). An import's replace-all touches the 14 content tables only and **never wipes `cap_versions`**; an unmatched closure reference on import is auto-created as a scenario-local row (never global).

**Registry paired update (per table):** each `cap_*` table follows the standard registry change — `table-ddls.js` (DDL, APP-tier) + `shared/constants.js` (`TABLES` constant) + `platform/lib/tables.ts` + `platform/lib/table-display.ts` + the two paired tests — plus platform-tables.json, the dto-mapper REGISTRY, the drift-guard exclusion set, and the sync-schema fallback. Engine-table CREATE is gated inside `runSchemaMigrations()` on `PLATFORM_SCHEMA_VERSION`, so a `cap_*` schema change MUST bump that version (missing bump = tables never created on stamped DBs = deploy blocker). Currently excluded from the cross-environment `SYNC_ORDER` (capacity sync design is an open decision; drift-guard-documented). Child-delete semantics: hypervisor delete unplaces its VMs; profile delete NULLs `sizing_profile_id`; VM delete cascades its db_instances; rule delete cascades its waivers; site/spec delete → 409 while referenced; scenario delete = one transaction cascading across all 14 scoped tables (the `SNAPSHOT_TABLES` set — the same 14 tables that can carry a `scenario_id = :id` row).

---

## 9. Deployment

### 9.1 Docker

- **Root Dockerfile**: multi-stage build. `BASE_IMAGE` ARG is required — build fails hard if undefined.
- **`docker-compose.yml`**: orchestrates the three roles (infra / edge / frontend) as separate containers from the same image.
- **DevContainer**: two named configurations — `onprem/` and `airgap/` — sharing a single `Dockerfile.dev`. See `infrastructure/docs/ONPREM_SOP.md` / `AIRGAP_SOP.md`.
- All image references, URLs, and credentials are injected via `.env`. Secrets must never enter version control.

### 9.2 Export Source (`npm run export:source`)

Produces a clean ONPREM/AIRGAP deployable tree at `dist-source/` (gitignored).

| Flag | Description |
|------|-------------|
| `--mode=AIRGAP\|ONPREM` | Default: AIRGAP. AIRGAP = self-contained (Keycloak stripped, no external network). ONPREM = shared-infra (joins root devcontainer external network). |
| `--dev-env=<path>` / `--api-env=<path>` | Staging env override (realpath / 64 KB / no-symlink validated). |
| `--keycloak-issuer=<url>` | Injected as Keycloak issuer URL. |
| `--config=<path>` | Dockerfile ARG injection. |

Verification: `bash scripts/export-source/verify.sh ./dist-source` runs ~90 assertions (topology / renamed services / strip-cloud / no-supabase / no-lovable). All assertions must pass before shipping. YAML transforms use `compose.transform.cjs` (js-yaml AST walk) — never `sed`.

### 9.3 GitLab CI / CD and k8s

- **Pipeline**: push to `gitlab` remote → CI builds image tagged `fmb:<8-char SHA>` → ArgoCD syncs → 3 zones updated. `origin` remote points to GitHub (canonical source) and is separate.
- **k8s**: ArgoCD + Istio, 3-zone topology. Manifests at `infrastructure/k8s/`. See `infrastructure/docs/DUAL_SOURCE_REGISTRY.md` for the CI ↔ CD repo mapping.
- **Env placement**: secrets → Vault; per-zone config → ConfigMap; build-time constants → Dockerfile ARG. See `infrastructure/docs/ENV_PLACEMENT.md`.

---

## 10. Hard Constraints / Invariants

| Invariant | Rule |
|-----------|------|
| **Cold-boot HTTP 200** | `/health` must always return HTTP 200. Body may degrade; status code must never flap. Violation breaks k8s readiness probes. |
| **Pool-facade purity** | `pool.getConnection()` and `pool.query()` shims are forbidden in `docker-api/src/`. All DB access uses `pool.rw.*` / `pool.ro.*`. Mechanically enforced by Ship Gate Step 5. |
| **infra-talks-to-edge-only** | `docker-api/src/infra/` must not import any DB module (`mariadb`, `mysql2`, `pg`, `../../edge/db`, `../shared/db`) or call any function that returns a pool/connection object. All request-time DB access from infra must go through S2S to edge. Boot: infra must not call `initializeFromConfig` or anything that triggers `mariadb.createPool`. Enforced by Ship Gate Step 15 (`scripts/cicd/infra-talks-to-edge-only.sh`). Escape hatch: `// lint-allow: infra-talks-to-edge-only <reason>`. |
| **No hardcoded prefix** | `docker-api/src/`, `src/platform/`, and `src/fmb/` must not contain literal `'fmb_'` or `"fmb_"`. All SQL table references use `t(TABLES.X)`. Mechanically enforced by Ship Gate Step 8. Escape hatch: `// lint-allow: no-hardcoded-prefix <reason>`. |
| **AIRGAP zero-new-dep** | No new npm dependencies may be added for AIRGAP deployments. Any new dep is a CRITICAL blocking issue (Nexus curation is manual and offline). Removing deps is allowed. |
| **Schema-status never 5xx** | `GET /api/platform/schema/status` must always return HTTP 200. On derive failure, returns `schema_status: 'unknown'`. |

---

## 11. Out-of-Scope / Deferred

| Item | Notes |
|------|-------|
| **CLOUD / Supabase / Lovable** | The CLOUD environment mode (Supabase Postgres + Lovable hosting) is being removed in a separate stream (Stream 2 of the doc-convergence epic). This SDD describes the post-removal dual-state world. Supabase is mentioned here only for this removal note. |
| **Multi-tenant schema routing** | Engine CRUD (including `api_connectors`) intentionally uses the default pool. Multi-tenant routing would require a separate design. |
| **`src/features/` folder convergence** | Deferred to the physical FMB + PDX merge. |
| **DBA migrations** | `section_key` / `user_id` column drops and the `SUPABASE` enum value drop require DBA-executed SQL; out of scope for the application code. |
| **`legacyToOutputs` deprecation** | The shim is still load-bearing at the import boundary; deprecation requires a grace period + import audit. |

---

## 12. Decision Log

Key decisions are recorded in `LEARN.md`. Quick-reference index:

| LEARN.md Section | Topic |
|-----------------|-------|
| §50 | API error logging: pino `src` field at level ≥ 50; verb+noun+identifier message format |
| §60 | RW/RO split design: `db_connections` 4 columns, `pool.rw`/`pool.ro` namespace, `DB_RW_*`/`DB_RO_*` env |
| §70 | `export:source` env-rewrite: value-aware strict skip for DB credential lines |
| §79 | Pool-state visibility surface design |
| §81 | Cache strategy: `_userCache` 30 s / auth-mode uncached / pool-state 5 s — per-call-site rationale |
| §107 | Request logging and tracing architecture |
| §115 | Connector `outputs[]` unification (PR-A) |
| §121 | Connector editor self-service export/import (Group B PR-2) |
| §122 | Owner self-reassign + `GET /users/assignable` (Group B PR-3) |
| §123 | Connector detail editable JSON without secret risk (UI parity PR-3) |
| §136 | Author-flow FE orchestration: persist-first run correlation, single-output-key contract, serialize envelope, best-effort cache write-back |

---

## 13. Verification

Every PR must pass the Ship Gate before merge. Summary of the 15-step gate:

1. Unit tests green (`npm test` / `docker-api npm test` / `tsc --noEmit`).
2. Runtime verification for any change touching a runtime path, Dockerfile, or container entrypoint — real image boot required; unit green alone is not sufficient.
3. Mechanical gate: `bash scripts/cicd/ship-gate-check.sh` must exit 0.
   - Step 4: rename-audit (when commit subject contains `rename`).
   - Step 5: pool-facade purity (no `pool.getConnection()`/`pool.query()` shims).
   - Step 5b: structural invariants (boot-banner role count, `fmb.io/env-sources` annotation, `printBootBanner` call per `index-*.js`).
   - Step 6: docker-role-boot-smoke (3 roles × 10 s, triggered by `docker-api/src/` or Dockerfile changes).
   - Step 7: k3d deploy-verify (triggered by `infrastructure/k8s/**` or CI config changes).
   - Step 8: no-hardcoded-prefix.
   - Step 9: comment-discipline (diff-aware; new lines only).
   - Step 13: forbid-eval-helpers (`dangerouslySetInnerHTML`, `.innerHTML =`, etc.).
   - Step 14: export-config.example lint.
   - Step 15: infra-talks-to-edge-only.
4. Codex outside-voice review (`codex review --base <branch>`). Escalate to `code-reviewer` / `security-reviewer` agents only if Codex hits capacity, self-reports insufficient coverage, or the change is boundary-sensitive (auth / payment / migration / Dockerfile).
5. Findings disposition: CRITICAL/HIGH → block merge; MEDIUM → candidates file; LOW → PR body.
6. Push → CI → merge → memory update.

For the full authoritative checklist see `CLAUDE.md §3 Ship Gate`.

---

## 14. References

| Document | Purpose |
|----------|---------|
| `CLAUDE.md` | Behavioral rules, process contracts, security requirements, Codex collaboration (gitignored; not in version control) |
| `LEARN.md` | Technical decision log with numbered sections |
| `frontend-rules/frontend-rules.md` | Frontend coding standards (MUST / MUST NOT / MAY structure) |
| `infrastructure/docs/ONPREM_SOP.md` | ONPREM setup and operations runbook |
| `infrastructure/docs/AIRGAP_SOP.md` | AIRGAP deployment runbook |
| `infrastructure/docs/LOGGING.md` | Request logging and tracing operations guide |
| `infrastructure/docs/KEYCLOAK_REALM_SETUP.md` | Keycloak realm and multi-zone allowlist configuration |
| `infrastructure/docs/DUAL_SOURCE_REGISTRY.md` | CI repo ↔ CD repo mapping table |
| `infrastructure/docs/ENV_PLACEMENT.md` | Environment variable placement guide (secret/ConfigMap/ARG) |
| `infrastructure/docs/LOCAL_CICD_RECIPE.md` | k3d local CI/CD recipe |
| `infrastructure/k8s/README.md` | Kubernetes manifest and zone topology guide |
| `src/platform/PLATFORM_GUIDE.md` | Platform / App separation rules |
| `docs/RFC/api-connectors.md` | API Connectors RFC (P2–P5 roadmap) |
| `docs/RFC/visibility-surface.md` | Pool-state and schema-version visibility surface design |
